# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Wednesday 15. January 2014 12:39 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Wednesday 15. January 2014 12:39 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (0 records)
#

#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Wednesday 15. January 2014 12:39 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (7 records)
#
 
INSERT INTO `wp_links` VALUES (1, 'http://codex.wordpress.org/', 'Documentation', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (2, 'http://wordpress.org/development/', 'WordPress Blog', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', 'http://wordpress.org/development/feed/') ; 
INSERT INTO `wp_links` VALUES (3, 'http://wordpress.org/extend/ideas/', 'Suggest Ideas', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (4, 'http://wordpress.org/support/', 'Support Forum', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (5, 'http://wordpress.org/extend/plugins/', 'Plugins', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (6, 'http://wordpress.org/extend/themes/', 'Themes', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (7, 'http://planet.wordpress.org/', 'WordPress Planet', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ;
#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Wednesday 15. January 2014 12:39 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=1832 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (210 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'Gosford Tigers Junior AFL', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'andy.tan2624@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'links_recently_updated_prepend', '<em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'links_recently_updated_append', '</em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'links_recently_updated_time', '120', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'comment_moderation', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'permalink_structure', '/%category%/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (36, 'active_plugins', 'a:9:{i:0;s:19:"akismet/akismet.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:3;s:36:"contact-form-7/wp-contact-form-7.php";i:4;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:5;s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";i:6;s:30:"lightbox-plus/lightboxplus.php";i:7;s:45:"limit-login-attempts/limit-login-attempts.php";i:8;s:23:"ml-slider/ml-slider.php";i:9;s:40:"twitter-widget-pro/wp-twitter-widget.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'home', 'http://localhost/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (41, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'recently_edited', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'template', 'expound', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'stylesheet', 'expound', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (49, 'comment_registration', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'db_version', '25824', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'uploads_use_yearmonth_folders', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'upload_path', 'wp-content/uploads', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'blog_public', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'avatar_default', 'retro', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'image_default_link_type', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'close_comments_for_old_posts', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'page_comments', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (83, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'embed_size_w', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'embed_size_h', '600', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'page_on_front', '4', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:4:"Yeah";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (101, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:5:{i:0;s:8:"search-2";i:1;s:6:"meta-2";i:2;s:10:"archives-2";i:3;s:12:"categories-2";i:4;s:17:"recent-comments-2";}s:9:"sidebar-1";a:2:{i:0;s:9:"twitter-2";i:1;s:14:"recent-posts-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (646, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (102, 'ftp_credentials', 'a:3:{s:8:"hostname";s:9:"localhost";s:8:"username";N;s:15:"connection_type";s:3:"ftp";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (103, 'uninstall_plugins', 'a:2:{s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";s:22:"hupso_plugin_uninstall";s:30:"lightbox-plus/lightboxplus.php";s:12:"UninstallLBP";}', 'no') ; 
INSERT INTO `wp_options` VALUES (104, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, 'link_manager_enabled', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, 'initial_db_version', '15260', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (108, 'cron', 'a:7:{i:1389667483;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1389667614;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1389669379;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1389812400;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1389826800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1389913200;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (760, '_transient_timeout_feed_c809918297b2c893fd8504c06adcaf00', '1384557928', 'no') ; 
INSERT INTO `wp_options` VALUES (476, '_site_transient_timeout_browser_00760e848c8aef5785b4a3f89f42352c', '1384866155', 'yes') ; 
INSERT INTO `wp_options` VALUES (118, 'limit_login_retries', 'a:1:{s:15:"211.110.140.155";i:8;}', 'no') ; 
INSERT INTO `wp_options` VALUES (119, 'limit_login_retries_valid', 'a:1:{s:15:"211.110.140.155";i:1384911769;}', 'no') ; 
INSERT INTO `wp_options` VALUES (120, '_transient_random_seed', '6d3e0af83b1493a3c98f079a43ad6d71', 'yes') ; 
INSERT INTO `wp_options` VALUES (123, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:23:"http://localhost/tigers";s:4:"link";s:99:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://localhost/tigers/";s:3:"url";s:132:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://localhost/tigers/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:26:"http://wordpress.org/news/";s:3:"url";s:31:"http://wordpress.org/news/feed/";s:5:"title";s:14:"WordPress Blog";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:28:"http://planet.wordpress.org/";s:3:"url";s:33:"http://planet.wordpress.org/feed/";s:5:"title";s:20:"Other WordPress News";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1398, '_transient_timeout_feed_808390979aa7eed5a9c06ad6a9dd19d0', '1387234104', 'no') ; 
INSERT INTO `wp_options` VALUES (1399, '_transient_feed_808390979aa7eed5a9c06ad6a9dd19d0', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:4:"
  
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:33:"
    
    
    
    
    
    
  ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"link:http://localhost/tigers/ - Google Blog Search";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://www.google.com/search?ie=utf-8&q=link:http://localhost/tigers/&tbm=blg&tbs=sbd:1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:81:"Your search - <b>link:http://localhost/tigers/</b> - did not match any documents.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://a9.com/-/spec/opensearch/1.1/";a:3:{s:12:"totalResults";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:10:"startIndex";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:12:"itemsPerPage";a:1:{i:0;a:5:{s:4:"data";s:2:"10";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:28:"text/xml; charset=ISO-8859-1";s:4:"date";s:29:"Mon, 16 Dec 2013 10:48:14 GMT";s:7:"expires";s:2:"-1";s:13:"cache-control";s:18:"private, max-age=0";s:10:"set-cookie";a:2:{i:0;s:143:"PREF=ID=f870726bf488e2a9:FF=0:TM=1387190894:LM=1387190894:S=Rvy7K9i0V9ZZWxCl; expires=Wed, 16-Dec-2015 10:48:14 GMT; path=/; domain=.google.com";i:1;s:212:"NID=67=f5dsaSHM5EbIOdIBpIj7qywM0O597XrX8LNfytRe7aL4ouzmUox1qQt5tgVPvLOxDPWZjDfJUgDZID9SM_75Y0cxGFB0Am7gLJtqYrchxZfNCCfJsISq5QVOL382WeTP; expires=Tue, 17-Jun-2014 10:48:14 GMT; path=/; domain=.google.com; HttpOnly";}s:3:"p3p";s:122:"CP="This is not a P3P policy! See http://www.google.com/support/accounts/bin/answer.py?hl=en&answer=151657 for more info."";s:6:"server";s:3:"gws";s:16:"x-xss-protection";s:13:"1; mode=block";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20131111120855";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1400, '_transient_timeout_feed_mod_808390979aa7eed5a9c06ad6a9dd19d0', '1387234104', 'no') ; 
INSERT INTO `wp_options` VALUES (1401, '_transient_feed_mod_808390979aa7eed5a9c06ad6a9dd19d0', '1387190904', 'no') ; 
INSERT INTO `wp_options` VALUES (977, 'limit_login_lockouts', 'a:1:{s:15:"211.110.140.155";i:1384869769;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1615, '_transient_timeout_feed_mod_77fa140e07ce53fe8c87136636f83d72', '1388369534', 'no') ; 
INSERT INTO `wp_options` VALUES (1616, '_transient_feed_mod_77fa140e07ce53fe8c87136636f83d72', '1388326334', 'no') ; 
INSERT INTO `wp_options` VALUES (1613, '_transient_timeout_feed_77fa140e07ce53fe8c87136636f83d72', '1388369534', 'no') ; 
INSERT INTO `wp_options` VALUES (1614, '_transient_feed_77fa140e07ce53fe8c87136636f83d72', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/plugins/browse/new/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 29 Dec 2013 13:07:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Simple OpenErp7 Login";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.org/plugins/simple-openerp7-login/#post-62156";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 28 Dec 2013 09:47:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62156@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:88:"This plugin is able to handle the wordpress login using the authentication of OpenERP 7.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"archetipo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Simple OpenErp6.1 Login";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/simple-openerp61-login/#post-62155";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 28 Dec 2013 09:47:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62155@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:90:"This plugin is able to handle the wordpress login using the authentication of OpenERP 6.1.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"archetipo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"BMI BMR Calculator";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/bmi-bmr-calculator/#post-62133";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 Dec 2013 17:37:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62133@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:100:"Body mass index and Basal Metabolic Rate calculator that saves calculation data for logged in users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"r0by";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google Font Manager";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/plugins/google-font-manager/#post-62173";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 29 Dec 2013 04:23:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62173@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:139:"Easily add Google fonts to your WordPress website. With multiple use options, it is perfect for regular and advanced WordPress users alike.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Thomas S. Butler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"Kento Latest Tabs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/kento-latest-tabs/#post-62105";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 26 Dec 2013 15:38:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62105@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:77:"Get list of latest post, comment and most popular post on sidebar via widget.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"KentoThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Bixt - Words into Affiliate Links";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/bixt/#post-42884";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 07 Sep 2012 16:55:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"42884@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:91:"Bixt replaces keywords or keyword phrases with affiliate links that you define per keyword.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Svetoslav Marinov";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Indeed Job Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/plugins/indeed-job-importer/#post-62157";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 28 Dec 2013 10:09:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62157@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:84:"Indeed Job Importer Plugin Import job from indeed according to your given parameter.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Shambhu Patnaik";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"OG Tags";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/og-tags/#post-62167";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 29 Dec 2013 00:22:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62167@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:122:"OG Tags includes the tags necessary to integrate your website to Facebook with almost no configuration. Automatic. Simple.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Mário";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"Wpp Customization";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/wpp-customization/#post-62074";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 25 Dec 2013 09:50:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62074@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:32:"Customize wordpress admin footer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"phpdevp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"List Last Changes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/list-last-changes/#post-61718";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 14 Dec 2013 15:57:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"61718@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:52:"Shows a list of the last changes in the widget area.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"rbaer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WP Live Preview Links";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.org/plugins/wp-live-preview-links/#post-62130";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 Dec 2013 12:49:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62130@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:81:"See a live scaled preview of the site you are linking to prior to clicking on it.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Per Soderlind";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Latest Post Accordian Slider";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wordpress.org/plugins/latest-post-accordian-slider/#post-62098";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 26 Dec 2013 06:26:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62098@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Best Accordian Slider for displaying latest posts in wordpress.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Anop Goswami";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:9:"Server IP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/server-ip/#post-62117";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 Dec 2013 00:40:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62117@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:92:"Server IP - Simply display IP Address (and hostname) on the WordPress dashboard admin panel.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"VPN Dock";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Cherkasy Weather";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://wordpress.org/plugins/cherkasy-weather/#post-62112";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 26 Dec 2013 19:01:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62112@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:40:"A simple weather plugin Cherkasy Weather";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"karmeljuk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"Twitter Feeds";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/twitter-feeds/#post-62128";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 Dec 2013 12:34:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"62128@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Twitter feeds that outputs your latest tweets in HTML into any post, page or sidebar widget. Customizable,Colorful and easy to configure!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Viavi Webtech";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:41:"http://wordpress.org/plugins/rss/view/new";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 29 Dec 2013 13:08:06 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Sun, 29 Dec 2013 13:42:03 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Sun, 29 Dec 2013 13:07:03 +0000";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (853, 'ml-slider_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (761, '_transient_feed_c809918297b2c893fd8504c06adcaf00', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:50:"
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"WebDevStudios.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:24:"http://webdevstudios.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:40:"WordPress Website Development and Design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 20:25:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=3.6.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"WDS Welcomes Cristina Cannon!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://webdevstudios.com/2013/11/14/wds-welcomes-cristina-cannon/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:74:"http://webdevstudios.com/2013/11/14/wds-welcomes-cristina-cannon/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 20:25:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:13:"WebDevStudios";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7909";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:406:"WebDevStudios is happy to announce our newest member of the team, Cristina, who will be taking on the role of Project Manager! Cristina Cannon has over 6 years of experience in project management; running new business projects and full marketing &#8230; <a class="more-link" href="http://webdevstudios.com/2013/11/14/wds-welcomes-cristina-cannon/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1537:"<p>WebDevStudios is happy to announce our newest member of the team, Cristina, who will be taking on the role of Project Manager!</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2013/11/CMC2.png"><img class="alignleft size-full wp-image-7905" alt="CMC2" src="http://webdevstudios.com/wp-content/uploads/2013/11/CMC2.png" width="210" height="230" /></a><a title="Cristina Cannon" href="http://webdevstudios.com/team/cristina-cannon/">Cristina Cannon</a> has over 6 years of experience in project management; running new business projects and full marketing campaigns within digital media, SEO, email, website development and database management &#8211; across multiple industries. Cristina has demonstrated a unique ability for problem solving and her strong leadership skills bring passion, reliability, and innovation to WDS, which is imperative for project success. Because of her energetic and collaborative style, Cristina will be a great addition to the WDS team! Cristina is excited to expand on her website development knowledge and learn WordPress inside and out.</p>
<p>After living in NJ for over a decade she recently moved to St. Louis to be closer to family. She have a 17-month old son, Trystan and wonderful boyfriend Jason. In her spare time she likes to read, hike, snowboard, dabble in yoga and go to the park with her awesome son!</p>
<p>WDS is excited to welcome Cristina to our ever growing team. Project management is an extremely important part of our business and we know she is going to rock it!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:70:"http://webdevstudios.com/2013/11/14/wds-welcomes-cristina-cannon/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Products We Love: Sucuri Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://webdevstudios.com/2013/11/07/products-we-love-sucuri-security/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:78:"http://webdevstudios.com/2013/11/07/products-we-love-sucuri-security/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 18:56:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:16:"Products We Love";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"Sucuri";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7893";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:419:"Sucuri Security is a security-based company ran by Dre Armeda, Daniel Cid, and Tony Perez. They specialize in keeping websites secure and clean of hacks and offer services such as Monitoring, Alerting, and Removal. They also feature a Website Application &#8230; <a class="more-link" href="http://webdevstudios.com/2013/11/07/products-we-love-sucuri-security/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2798:"<p><img class="alignleft size-medium wp-image-7896" alt="Screenshot_on_11.7.2013_at_10.52.06_AM" src="http://webdevstudios.com/wp-content/uploads/2013/11/Screenshot_on_11.7.2013_at_10.52.06_AM-300x247.png" width="300" height="247" /><a title="Website Security Monitoring" href="http://sucuri.net/">Sucuri Security</a> is a security-based company ran by <a href="https://twitter.com/dremeda">Dre Armeda</a>, <a href="https://twitter.com/danielcid">Daniel Cid</a>, and <a href="https://twitter.com/perezbox">Tony Perez</a>. They specialize in keeping websites secure and clean of hacks and offer services such as Monitoring, Alerting, and Removal. They also feature a Website Application Firewall and Website Backups. You can find the complete details on what services they offer on their <a href="http://sucuri.net/services">Services page</a>.</p>
<p>We use their services for all of our websites including the one you are on right now- WebDevStudios.com. We know that our site is being monitored by <a href="http://sucuri.net/">Sucuri</a> 24/7, which gives us peace of mind. Also, if we were to be hacked, <a href="http://sucuri.net/">Sucuri</a> would alert us of the issue right away, and it&#8217;s good to know that we have that security bla<a href="http://webdevstudios.com/wp-content/uploads/2013/11/Screenshot_on_11.7.2013_at_11.10.35_AM.png"><img class="alignright size-medium wp-image-7897" alt="Screenshot_on_11.7.2013_at_11.10.35_AM" src="http://webdevstudios.com/wp-content/uploads/2013/11/Screenshot_on_11.7.2013_at_11.10.35_AM-250x300.png" width="250" height="300" /></a>nket in place.</p>
<p>Sucuri offers a free <a href="http://sitecheck.sucuri.net/scanner/">website security scanner</a> that everyone should take advantage of. This scanner allows you to check for blacklisting status, out-of-date software, known malware and website errors if your site is on WordPress or any other platform.</p>
<p>Anyone who has attended one of <a href="http://wordpress.tv/2013/06/24/brad-williams-security/">Brad Williams&#8217; security presentations</a> at WordCamp, know that he is extremely knowledgeable in the best practices of WordPress website security and he cannot say enough good things about using <a href="http://webdevstudios.com/go/sucuri">Sucuri</a> for your website. He says:</p>
<blockquote><p>&#8220;Sucuri is a service anyone serious about their website should have.&#8221;</p></blockquote>
<p>Here at WebDevStudios, we recommend to all of our clients that they sign up Sucuri monitoring services because we strongly trust in their capabilities as a company. If you&#8217;re looking to have affordable peace of mind for your website security, check out <a href="http://sucuri.net/">Sucuri Security</a> today. We promise you won&#8217;t be disappointed!</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:74:"http://webdevstudios.com/2013/11/07/products-we-love-sucuri-security/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"Announcing the PayPal Pro add-on for iThemes Exchange";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://webdevstudios.com/2013/11/01/announcing-the-paypal-pro-add-on-for-ithemes-exchange/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:99:"http://webdevstudios.com/2013/11/01/announcing-the-paypal-pro-add-on-for-ithemes-exchange/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 14:27:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:7:"Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"ecommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"Exchange";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:7:"iThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7878";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:427:"We are very excited to announce the release of our first iThemes Exchange premium add-on: PayPal Pro With the PayPal Pro Add-On, you can easily accept credit cards directly from your website with the iThemes Exchange eCommerce plugin. We all &#8230; <a class="more-link" href="http://webdevstudios.com/2013/11/01/announcing-the-paypal-pro-add-on-for-ithemes-exchange/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2762:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/10/paypalpro2-440x440.png"><img class="alignleft  wp-image-7879" alt="paypalpro2-440x440" src="http://webdevstudios.com/wp-content/uploads/2013/10/paypalpro2-440x440-150x150.png" width="65" height="65" /></a>We are very excited to announce the release of our first <a href="http://ithemes.com/exchange/" target="_blank">iThemes Exchange</a> premium add-on: <a href="http://ithemes.com/purchase/paypal-pro/" title="PayPal Pro for iThemes Exchange WordPress eCommerce" target="_blank">PayPal Pro</a></p>
<div id="attachment_7881" class="wp-caption alignright" style="width: 288px"><a href="http://webdevstudios.com/wp-content/uploads/2013/10/paypal-cc-input.png"><img class="size-medium wp-image-7881 " alt="paypal-cc-input" src="http://webdevstudios.com/wp-content/uploads/2013/10/paypal-cc-input-278x300.png" width="278" height="300" /></a><p class="wp-caption-text">PayPal Pro Credit Card Input</p></div>
<p>With the <a href="http://ithemes.com/purchase/paypal-pro/">PayPal Pro Add-On</a>, you can easily accept credit cards directly from your website with the <a href="http://ithemes.com/exchange/">iThemes Exchange</a> eCommerce plugin. We all know how wary we feel when we have to be directed off of a site to pay for what we&#8217;re purchasing. <a href="http://ithemes.com/purchase/paypal-pro/">PayPal Pro</a> takes that worry away by allowing you to stay on the site in which you&#8217;re purchasing from.</p>
<h2>Features of the PayPal Pro Add-On</h2>
<ul>
<li><em>Accept payments directly on your website.</em></li>
<li><em><a href="http://webdevstudios.com/wp-content/uploads/2013/10/paypal-pro-settings1.png"><img class="alignright  wp-image-7880" alt="paypal-pro-settings1" src="http://webdevstudios.com/wp-content/uploads/2013/10/paypal-pro-settings1.png" width="278" height="419" /></a>Support for PayPal’s transaction sale methods: authorize and capture the payment, charge the total to the credit card or authorize the payment amount and capture that amount via PayPal Pro’s admin later.</em></li>
<li><em>Enable or disable PayPal Pro Sandbox Mode for testing your payments.</em></li>
<li><em>Easily change the “Purchase” button text to whatever you want like “Pay with Card” or “Pay Like a Pro.”</em></li>
</ul>
<p>&nbsp;</p>
<p>Learn more about the iThemes Exchange plugin on their website at <a href="http://ithemes.com/exchange/" target="_blank"> http://ithemes.com/exchange</a> and the PayPal Pro add-on at <a href="http://ithemes.com/purchase/paypal-pro/" title="PayPal Pro WordPress eCommerce Exchange" target="_blank">http://ithemes.com/purchase/paypal-pro/</a>. We are very proud to be part of Exchange and will be releasing additional add-ons very soon!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:95:"http://webdevstudios.com/2013/11/01/announcing-the-paypal-pro-add-on-for-ithemes-exchange/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"WDS Helps To Improve Documentation in WordPress 3.7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://webdevstudios.com/2013/10/28/wds-helps-to-improve-documentation-in-wordpress-3-7/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:97:"http://webdevstudios.com/2013/10/28/wds-helps-to-improve-documentation-in-wordpress-3-7/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 28 Oct 2013 15:49:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7866";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:452:"For the 3.7 release, WebDevStudios&#8217; own Brian Richards and dozens of others turned their collective focus to documenting the many hooks that WordPress provides for developers. The hooks docs initiative was birthed from a conversation between Andrew Nacin and Jon &#8230; <a class="more-link" href="http://webdevstudios.com/2013/10/28/wds-helps-to-improve-documentation-in-wordpress-3-7/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3166:"<p>For the 3.7 release, WebDevStudios&#8217; own <a title="Brian Richards" href="http://webdevstudios.com/team/brian-richards/">Brian Richards</a> and dozens of others turned their collective focus to documenting the many hooks that WordPress provides for developers.</p>
<blockquote><p>The hooks docs initiative was birthed from a conversation between <a href="https://twitter.com/nacin">Andrew Nacin</a> and <a href="https://twitter.com/joncave">Jon Cave</a> that I overheard during the WordCamp San Francisco After Party. They were talking about something called a &#8220;hash notation&#8221; for easily documenting arrays in inline docs, and improving the documentation efforts of WordPress, and I wanted to know more. By the end of the night I was convinced this would be a perfect way to document the multitude of hooks littered throughout WordPress Core, and a perfect way for me (and others) to contribute to WordPress. &#8211; Brian Richards</p></blockquote>
<p>During WordCamp San Fransisco contributor day, Brian connected with <a href="https://twitter.com/nacin">Andrew Nacin</a>, <a href="https://twitter.com/joncave">Jon Cave</a>, <a href="https://twitter.com/ericandrewlewis">Eric Lewis</a>, and <a href="https://twitter.com/DrewAPicture">Drew Jaynes. </a>They sat down and began working out the logistics of updating the documentation together.</p>
<p>Fast-forward several weeks, <a href="https://twitter.com/DrewAPicture">Drew Jaynes</a> and <a href="https://twitter.com/kimparsell">Kim Parsell</a> put in a lot of hours writing and refining PHP Documentation Standards pages for the WordPress handbook. <a href="https://twitter.com/rzen">Brian Richards</a> helped define and create the Hook Documentation standards portion, and they wrote up a few leading posts for make.wordpress.org/core. After this they hit the ground running.</p>
<blockquote><p><a href="https://twitter.com/ericandrewlewis">Eric</a>, <a href="https://twitter.com/kimparsell">Kim</a>, <a href="https://twitter.com/DrewAPicture">Drew</a> and myself comprised the core hook docs team, and we&#8217;ve held meetings every week since the project started. Drew and Kim shouldered much of the work reviewing other peoples patches, and Drew was even granted temporary commit access to help make the process flow more smoothly (congrats, Drew!).</p>
<p>At this moment, 74 of the 185 files containing hooks have been documented. There is still much to be done, and this initiative will continue to thrive well into (and possibly through) WordPress 3.8. &#8211; Brian Richards</p></blockquote>
<p>We want to thank everyone who contributed to the release of WordPress 3.7 including WDS&#8217; <a title="Brian Richards" href="http://webdevstudios.com/team/brian-richards/">Brian Richards</a> and <a title="Michael Beckwith" href="http://webdevstudios.com/team/michael-beckwith/">Michael Beckwith</a>. There is still a lot more work to do and anyone looking to help can get involved by reading this post on make/core: <a href="http://make.wordpress.org/core/2013/09/05/add-inline-docs-for-hooks/" target="_blank">http://make.wordpress.org/core/2013/09/05/add-inline-docs-for-hooks/</a></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:93:"http://webdevstudios.com/2013/10/28/wds-helps-to-improve-documentation-in-wordpress-3-7/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Brian Messenlehner Speaking at WordCamp Sofia 2013";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://webdevstudios.com/2013/10/23/brian-messenlehner-speaking-at-wordcamp-sofia-2013/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:96:"http://webdevstudios.com/2013/10/23/brian-messenlehner-speaking-at-wordcamp-sofia-2013/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Oct 2013 17:37:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7842";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:410:"Brian Messenlehner is speaking at WordCamp Sofia this year! WordCamp Sofia 2013 is being held on Friday, October 26th at The Hall of Telerik Academy. Brian&#8217;s talk will be held in the general track at 2:30pm and he will be &#8230; <a class="more-link" href="http://webdevstudios.com/2013/10/23/brian-messenlehner-speaking-at-wordcamp-sofia-2013/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2320:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/10/Screenshot_on_10.17.2013_at_11.56.02_AM.png"><img class="aligncenter size-full wp-image-7843" alt="Screenshot_on_10.17.2013_at_11.56.02_AM" src="http://webdevstudios.com/wp-content/uploads/2013/10/Screenshot_on_10.17.2013_at_11.56.02_AM.png" width="856" height="184" /></a></p>
<p><a title="Brian Messenlehner" href="http://webdevstudios.com/team/brian-messenlehner/">Brian Messenlehner</a> is speaking at <a href="http://2013.sofia.wordcamp.org/">WordCamp Sofia</a> this year! <a href="http://2013.sofia.wordcamp.org/">WordCamp Sofia 2013</a> is being held on Friday, October 26th at The Hall of Telerik Academy.</p>
<p>Brian&#8217;s talk will be held in the general track at 2:30pm and he will be speaking (in English!) about: <a href="http://2013.sofia.wordcamp.org/session/wordpress-as-an-application-framework/">WordPress as an Application Framework</a>:</p>
<blockquote><p>Despite starting out as a blogging platform and currently existing primarily as a content management system, WordPress is powerful enough and flexible enough to run any type of web application. Whether you&#8217;re a novice WordPress user or an experienced web developer you can leverage WordPress in many non-traditional ways. We will go over how to rapidly build scalable and secure applications and how to save time and money doing so. We will also showcase some really cool applications and examples of building things with WordPress while thinking out of the box.</p></blockquote>
<p>This topic will be expanded on and explainied in depth in Brian&#8217;s upcoming book <a href="http://www.amazon.com/Building-Apps-WordPress-Brian-Messenlehner/dp/1449364071/ref=sr_1_1?ie=UTF8&amp;qid=1382548056&amp;sr=8-1&amp;keywords=Brian+messenlehner">Building Web Apps with WordPress</a>. The book will be available on Amazon in the next few weeks &#8211; but you are able to<a href="http://www.amazon.com/Building-Apps-WordPress-Brian-Messenlehner/dp/1449364071/ref=sr_1_1?ie=UTF8&amp;qid=1382548056&amp;sr=8-1&amp;keywords=Brian+messenlehner"> pre-order it right now</a>!</p>
<p>If you&#8217;re attending WordCamp Sofia, make sure you stop by and say hey to Brian! As always, he&#8217;s excited to meet new people and catch up with those he&#8217;s already met.</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:92:"http://webdevstudios.com/2013/10/23/brian-messenlehner-speaking-at-wordcamp-sofia-2013/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"WebDevStudios Welcomes Brad Parbs!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://webdevstudios.com/2013/10/21/webdevstudios-welcomes-brad-parbs/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:79:"http://webdevstudios.com/2013/10/21/webdevstudios-welcomes-brad-parbs/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Oct 2013 14:30:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7844";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:427:"WebDevStudios is proud to announce another great addition to our team &#8211; Welcome to Brad Parbs! Brad  is a WordPress fanatic. He is involved with the WordPress community in a number of ways including organizing various events, speaking about WordPress at &#8230; <a class="more-link" href="http://webdevstudios.com/2013/10/21/webdevstudios-welcomes-brad-parbs/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1593:"<p>WebDevStudios is proud to announce another great addition to our team &#8211; Welcome to <a href="http://webdevstudios.com/team/brad-parbs/">Brad Parbs</a>!</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2013/10/brad-parbs-profile-square.jpg"><img class="alignleft size-full wp-image-7849" alt="brad-parbs-profile-square" src="http://webdevstudios.com/wp-content/uploads/2013/10/brad-parbs-profile-square.jpg" width="253" height="253" /></a>Brad  is a WordPress fanatic. He is involved with the WordPress community in a number of ways including organizing various events, speaking about WordPress at conferences, contributing to WordPress core and writing and maintaining plugins.</p>
<p>Brad is co-organizer for both the <a href="http://www.wpmke.com/" target="_blank">WordPress Milwaukee</a> &amp; <a href="http://www.meetup.com/web414/" target="_blank">Web414</a> monthly meetups, as well as WordCamp Milwaukee <a href="http://2012.milwaukee.wordcamp.org/" target="_blank">2012</a> and <a href="http://2013.milwaukee.wordcamp.org/" target="_blank">2013</a>.</p>
<blockquote><p>I&#8217;m super excited to be joining Web Dev Studios. Ever since I first started freelancing, I&#8217;ve always looked up to WDS as a company I would one day work for. I can&#8217;t wait to work with some of the smartest people in the community, on some really fun projects. &#8211; Brad Parbs</p></blockquote>
<p>We are also very excited to have Brad joining the team! With his expertise and passion, we know he is going to be an excellent addition to our WDS family!</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:75:"http://webdevstudios.com/2013/10/21/webdevstudios-welcomes-brad-parbs/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:38:"Lisa Sabin-Wilson at PressNomics 2013!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://webdevstudios.com/2013/10/14/lisa-sabin-wilson-at-pressnomics-2013/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:83:"http://webdevstudios.com/2013/10/14/lisa-sabin-wilson-at-pressnomics-2013/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Oct 2013 18:46:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7833";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:424:"For those of you who don&#8217;t already know what PressNomics is &#8211; The conference for those that power the WordPress Economy There is a diverse group of passionate and very successful entrepreneurs creating the products and services that drive the &#8230; <a class="more-link" href="http://webdevstudios.com/2013/10/14/lisa-sabin-wilson-at-pressnomics-2013/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2060:"<p>For those of you who don&#8217;t already know what PressNomics is &#8211;</p>
<blockquote><p>The conference for those that power the WordPress Economy<br />
There is a diverse group of passionate and very successful entrepreneurs creating the products and services that drive the WordPress economy. PressNomics is a 3 day event for these folks to collaborate, learn, and relax.</p>
<p>&nbsp;</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2013/10/pressnomics-logos_06.png"><img class="aligncenter size-medium wp-image-7834" alt="pressnomics-logos_06" src="http://webdevstudios.com/wp-content/uploads/2013/10/pressnomics-logos_06-300x47.png" width="300" height="47" /></a></p></blockquote>
<p>An awesome thing about PressNomics is that it&#8217;s a <em>not-just-for-profit </em>event. The 2012 Event donated $5,126 to <a href="http://www.stjude.org">St. Jude Children&#8217;s Research Hospital</a>.</p>
<p>PressNomics is being held from Thursday, October 16th until Saturday, October 19th at the Tempe Mission Palms Hotel.</p>
<p>Lisa&#8217;s presentation begins on Friday, October 17th at 1:30pm</p>
<p>In her talk at PressNomics this year, Lisa Sabin-Wilson will be sharing the process and outcome of her decision to merge with WDS.  She is planning on talking about the decision making process and considerations for her to take her one-woman operation at <a href="http://ewebscapes.com">eWebscapes</a> and merge with a larger team, taking on not one, but two partners in the process.  What did it take to get there and reflections now, almost a year later, on how she has made the transition.</p>
<p>Lisa has been doing WordPress design/development since 2003 with the business she founded at <a href="http://ewebscapes.com">eWebscapes</a>. In 2012, Lisa, Brad and Brian began talks about merging eWebscapes with WebDevStudios to pull their collective brain power and resources together to form WD3, a.k.a. WebDevStudios.</p>
<p>If you are planning on being in Tempe, AZ for the PressNomics conference &#8211; find Lisa and say hello!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:79:"http://webdevstudios.com/2013/10/14/lisa-sabin-wilson-at-pressnomics-2013/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WebDevStudios Presents a Free WordPress Security Webinar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://webdevstudios.com/2013/09/25/webdevstudios-presents-a-free-wordpress-security-webinar/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:102:"http://webdevstudios.com/2013/09/25/webdevstudios-presents-a-free-wordpress-security-webinar/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 25 Sep 2013 15:00:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7808";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:451:"Brad  and Brian,two out of the three owners behind WebDevStudios, are hosting a webinar on WordPress security offered by SiteGround. Brad and Brian have extensive experience in dealing with website security and WordPress. This will be a great webinar to attend &#8230; <a class="more-link" href="http://webdevstudios.com/2013/09/25/webdevstudios-presents-a-free-wordpress-security-webinar/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1691:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/09/siteground.png"><img class="size-medium wp-image-7816 alignright" alt="siteground" src="http://webdevstudios.com/wp-content/uploads/2013/09/siteground-300x87.png" width="300" height="87" /></a><a href="http://webdevstudios.com/team/brad-williams/">Brad</a>  and <a title="Brian Messenlehner" href="http://webdevstudios.com/team/brian-messenlehner/">Brian</a>,two out of the three owners behind WebDevStudios, are hosting a webinar on WordPress security offered by <a href="http://www.siteground.com" target="_blank">SiteGround</a>. Brad and Brian have extensive experience in dealing with website security and WordPress. This will be a great webinar to attend if you want to learn how to beef up security on your WordPress website and to learn what to look out for to avoid security venerabilities. This event is taking place on <em>Thursday, September 26th</em> at <em>4pm EDT</em>. The session will include a 40 minute presentation followed by Q&amp;A.</p>
<h2 style="text-align: center"><a href="https://attendee.gotowebinar.com/register/2233504293348347905">Click Here to Register</a></h2>
<p>The WordPress Security webinar will include:</p>
<ul>
<li>WordPress Security Threats and trends</li>
<li>WordPress admin Security settings</li>
<li>Securing files, folders and databases</li>
<li>Bulletproof passwords</li>
<li>Web Server Vulnerabilities</li>
<li>Vulnerable WordPress extensions</li>
<li>Recommended Plugins and Services</li>
<li>Q &amp; A</li>
</ul>
<p>If you are interested in attending <a href="https://attendee.gotowebinar.com/register/2233504293348347905">click here</a> and sign up today!</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:98:"http://webdevstudios.com/2013/09/25/webdevstudios-presents-a-free-wordpress-security-webinar/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WordPress Web Design for Dummies (2nd edition) Giveaway!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://webdevstudios.com/2013/09/24/wordpress-web-design-for-dummies-2nd-edition-giveaway/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:99:"http://webdevstudios.com/2013/09/24/wordpress-web-design-for-dummies-2nd-edition-giveaway/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 24 Sep 2013 14:56:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Giveaway";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7804";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:469:"Lisa Sabin-Wilson; a co-owner here at WebDevStudios has written yet another helpful WordPress book.  WordPress Web Design for Dummies (2nd edition) is Lisa&#8217;s 11th dummies book based around WordPress! Updated, full-color guide to creating dynamic websites with WordPress 3.6 In &#8230; <a class="more-link" href="http://webdevstudios.com/2013/09/24/wordpress-web-design-for-dummies-2nd-edition-giveaway/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3529:"<p><a title="Lisa Sabin-Wilson" href="http://webdevstudios.com/team/lisa-sabin-wilson/">Lisa Sabin-Wilson</a>; a co-owner here at WebDevStudios has written yet another helpful WordPress book.  <a href="http://www.amazon.com/WordPress-Design-Dummies-Computer-Tech/dp/111854661X/ref=sr_1_1?s=books&amp;ie=UTF8&amp;qid=1380029870&amp;sr=1-1&amp;keywords=wordpress+web+design+for+dummies+2nd+edition">WordPress Web Design for Dummies (2nd edition)</a> is Lisa&#8217;s 11th dummies book based around WordPress!</p>
<blockquote>
<div id="outer_postBodyPS">
<div id="postBodyPS">
<div>
<p><b><a href="http://webdevstudios.com/wp-content/uploads/2013/09/Screen_Shot_2013-09-24_at_08.50.40.png"><img class="alignleft size-medium wp-image-7805" alt="Screen_Shot_2013-09-24_at_08.50.40" src="http://webdevstudios.com/wp-content/uploads/2013/09/Screen_Shot_2013-09-24_at_08.50.40-240x300.png" width="240" height="300" /></a>Updated, full-color guide to creating dynamic websites with WordPress 3.6</b></p>
<p>In this updated new edition, bestselling <i>For Dummies</i> author and WordPress expert Lisa Sabin-Wilson makes it easy for anyone with a basic knowledge of the WordPress software to create a custom site using complementary technologies such as CSS, HTML, PHP, and MySQL. You&#8217;ll not only get up to speed on essential tools and technologies and further advance your own design skills, this book also gives you pages of great case studies, so you can see just how other companies and individuals are creating compelling, customized, and cost-effective websites with WordPress.</p>
<ul>
<li>Shows you how to incorporate WordPress templates, graphic design principles, HTML, CSS, and PHP to build one-of-a-kind websites</li>
<li>Explains how to create an effective navigation system, choose the right color palette and fonts, and select different layouts</li>
<li>Reveals how you can tweak existing website designs with available themes, both free and premium</li>
<li>Provides numerous case studies to illustrate techniques and processes, and the effects you can achieve</li>
<li>Discusses how you can translate your design skills into paid work</li>
</ul>
<p>Want to create cost-effective and fantastic websites with WordPress? This do-it-yourself book will get you there.</p>
</div>
</div>
</div>
</blockquote>
<div id="outer_postBodyPS">
<div id="postBodyPS">
<div>
<p> We are giving away a copy of this awesome book!</p>
<h1>How to enter:</h1>
<ul>
<li>All you have to do is <strong>comment on this post</strong> about how one of Lisa&#8217;s books has helped you, or why you would like this book to help in your WordPress web design.</li>
<li>The giveaway with be running from 11 AM EDT today (Tuesday September 24th) until Thursday, September 26th at 3 PM EDT.</li>
<li>We will announce a winner at 4pm EDT on Thursday the 26th.</li>
<li>You will receive one copy of WordPress Web Design for Dummies (2nd edition) <strong>autographed</strong> by Lisa Sabin-Wilson.</li>
<li>US submissions only.</li>
<li>Employees and family members of WDS are encouraged to submit an entry, but are not eligible to win.</li>
</ul>
<p>We look forward to reading about how Lisa&#8217;s books have helped you or why this book would improve your WordPress web design!</p>
<p>Also, make sure to check out the entire list of books that WebDevStudios has under our belt (with more to come in the not so distant future!) <a href="http://webdevstudios.com/wordpress/books/">http://webdevstudios.com/wordpress/books/</a></p>
</div>
</div>
</div>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:95:"http://webdevstudios.com/2013/09/24/wordpress-web-design-for-dummies-2nd-edition-giveaway/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"14";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"WordCamp Baltimore 2013!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://webdevstudios.com/2013/09/19/wordcamp-baltimore-2013/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:69:"http://webdevstudios.com/2013/09/19/wordcamp-baltimore-2013/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 19 Sep 2013 14:14:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7797";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:386:"Add another WordCamp chalk line on the board for the WDS team &#8212; Brad Williams and Jayvie Canono will be attending WordCamp Baltimore 2013 this year! The event is happening on Saturday, September 21st and is being held at the &#8230; <a class="more-link" href="http://webdevstudios.com/2013/09/19/wordcamp-baltimore-2013/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2104:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/09/baltimore.png"><img class="alignleft size-full wp-image-7798" alt="baltimore" src="http://webdevstudios.com/wp-content/uploads/2013/09/baltimore.png" width="305" height="248" /></a>Add another WordCamp chalk line on the board for the WDS team &#8212; <a title="Brad Williams" href="http://webdevstudios.com/team/brad-williams/">Brad Williams</a> and <a title="Jayvie Canono" href="http://webdevstudios.com/team/jayvie-canono/">Jayvie Canono</a> will be attending <a href="http://2013.baltimore.wordcamp.org/">WordCamp Baltimore 2013</a> this year! The event is happening on Saturday, September 21st and is being held at the University of Baltimore in the Thumel Business Center. We would like to give a big round of applause to the organizers; <a href="https://twitter.com/theandystratton">Andy Stratton</a> and <a href="https://twitter.com/BmoreDrew">Drew Poland</a>, along with the <a href="http://2013.baltimore.wordcamp.org/sponsors/">sponsors</a>, for making this event possible!</p>
<p>Now, we already know that Brad Williams and Jayvie Canono of WDS will be going to this event, but make sure you check out the entire list of <a href="http://2013.baltimore.wordcamp.org/attendees/">attendees</a> and <a href="http://2013.baltimore.wordcamp.org/speakers/">speakers</a> that you will be learning from and getting to know. Also, have a look at the full <a href="http://2013.baltimore.wordcamp.org/schedule/">schedule</a> so you know which presentations you would like to attend and you can plan accordingly.</p>
<p>What would a WordCamp be without an after party? When you&#8217;re finished having a long day of cramming your brain full of WordPress knowledge, it&#8217;s time to relax. The after party is being held at the The Waterfront Hotel in Baltimore’s historic Fell’s Point starting at 7:30pm.</p>
<p>If you plan on attending WordCamp Baltimore 2013, make sure you find Brad and Jayvie in the crowd and say hey. As always, they are looking forward to meeting new people and reunited with the ones they have already met!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:65:"http://webdevstudios.com/2013/09/19/wordcamp-baltimore-2013/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:41:"http://feeds.feedburner.com/webdevstudios";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:3:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:13:"webdevstudios";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:14:"emailServiceId";a:1:{i:0;a:5:{s:4:"data";s:13:"webdevstudios";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:18:"feedburnerHostname";a:1:{i:0;a:5:{s:4:"data";s:28:"http://feedburner.google.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:13:"last-modified";s:29:"Fri, 15 Nov 2013 11:25:19 GMT";s:4:"etag";s:27:"ckZROX+iCad1haqhYYrTOh5TsbE";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"date";s:29:"Fri, 15 Nov 2013 11:25:19 GMT";s:7:"expires";s:29:"Fri, 15 Nov 2013 11:25:19 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20131111120855";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1617, '_transient_timeout_plugin_slugs', '1388412734', 'no') ; 
INSERT INTO `wp_options` VALUES (1618, '_transient_plugin_slugs', 'a:11:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:19:"akismet/akismet.php";i:2;s:35:"backupwordpress/backupwordpress.php";i:3;s:36:"contact-form-7/wp-contact-form-7.php";i:4;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:5;s:9:"hello.php";i:6;s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";i:7;s:30:"lightbox-plus/lightboxplus.php";i:8;s:45:"limit-login-attempts/limit-login-attempts.php";i:9;s:23:"ml-slider/ml-slider.php";i:10;s:40:"twitter-widget-pro/wp-twitter-widget.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1777, '_transient_timeout_feed_a09314b1a57acfaba9faaca775e0e5d2', '1389569126', 'no') ; 
INSERT INTO `wp_options` VALUES (1775, '_site_transient_timeout_browser_8b7535adeddc223aa9c8b2b378cdf189', '1390130723', 'yes') ; 
INSERT INTO `wp_options` VALUES (1776, '_site_transient_browser_8b7535adeddc223aa9c8b2b378cdf189', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"31.0.1650.63";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1791, '_transient_timeout_feed_mod_84a2c3a212a03c2875beccb4aed6e465', '1389569128', 'no') ; 
INSERT INTO `wp_options` VALUES (1792, '_transient_feed_mod_84a2c3a212a03c2875beccb4aed6e465', '1389525928', 'no') ; 
INSERT INTO `wp_options` VALUES (1793, '_transient_timeout_dash_20494a3d90a6669585674ed0eb8dcd8f', '1389569128', 'no') ; 
INSERT INTO `wp_options` VALUES (1794, '_transient_dash_20494a3d90a6669585674ed0eb8dcd8f', '<ul>
	<li><strong>Frances</strong> linked here <a href="http://forums.anvisoft.com/viewtopic-45-7799-0.html">saying</a>, "Once installed, Lpcloudsvr302.com constantly displ &hellip;"</li>
	<li><strong>Asha</strong> linked here <a href="https://blogs.vtiger.com/">saying</a>, "“Ring” – A notification pops up on your screen say &hellip;"</li>
	<li><strong>lx_sunwei</strong> linked here <a href="http://www.cnblogs.com/SWDreaming/p/3507975.html">saying</a>, "printStackTrace(); } return dataList; } /** * 返回总页 &hellip;"</li>
	<li><strong>Trex</strong> linked here <a href="http://wiki.contribs.org/Email">saying</a>, "6.1 Allow external IMAP mail access; 6.2 POP3 &hellip;"</li>
	<li><strong>ボーノ</strong> linked here <a href="http://buono.in/?p=1250">saying</a>, "photo credit: Tiger Pixel via photopin cc こんにちは、ボー &hellip;"</li>
	<li><strong>Jacques Distler</strong> linked here <a href="http://golem.ph.utexas.edu/wiki/instiki/show/Installation">saying</a>, "See these instructions, to obtain the necessary pr &hellip;"</li>
	<li><strong>Görkem Karadoğan</strong> linked here <a href="http://gis.stackexchange.com/questions/81378/openlayers-map-save-feature-srid-error-into-postgis">saying</a>, "WFS({ version: &quot;1.0.0&quot;, // loading data &hellip;"</li>
	<li><strong>S. Nageswara Rao, Corporate Trainer</strong> linked here <a href="http://way2java.com/hibernate/hibernate-example-using-hbm2ddl-and-hibernatesessionfactory/">saying</a>, "... &lt;session-factory&gt; &lt;property name= &hellip;"</li>
	<li><strong>Vũ Long</strong> linked here <a href="http://www.byglongvu.com/2013/11/9-buoc-bao-ve-trang-wordpress-cua-ban.html">saying</a>, "http://www.wildlove.co/ http://www.chinatax.co/ .. &hellip;"</li>
	<li><strong>Frances</strong> linked here <a href="http://forums.anvisoft.com/viewtopic-45-7115-0.html">saying</a>, "Once installed, Fix-issues.timehare.com constantly &hellip;"</li>
</ul>
', 'no') ; 
INSERT INTO `wp_options` VALUES (1609, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1388369533', 'no') ; 
INSERT INTO `wp_options` VALUES (1610, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 29 Dec 2013 12:54:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your Wordpress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"WPtouch Mobile Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/plugins/wptouch/#post-5468";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 May 2008 04:58:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"5468@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Create a slick mobile WordPress website with just a few clicks.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"BraveNewCode Inc.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"BackWPup Free - WordPress Backup Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/plugins/backwpup/#post-11392";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 23 Jun 2009 11:31:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"11392@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:146:"Schedule complete automatic backups of your WordPress installation. Decide which content will be stored (Dropbox, S3…). This is the free version";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Daniel Huesken";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Ultimate TinyMCE";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://wordpress.org/plugins/ultimate-tinymce/#post-32088";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Nov 2011 09:06:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"32088@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Description: Beef up the WordPress TinyMCE content editor with a plethora of advanced options.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Josh (Ult. Tinymce)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:122:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 7.5 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Captcha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/captcha/#post-26129";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Apr 2011 05:53:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"26129@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:79:"This plugin allows you to implement super security captcha form into web forms.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2082@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Contact Form";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/plugins/contact-form-plugin/#post-26890";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 26 May 2011 07:34:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"26890@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:43:"Add Contact Form to your WordPress website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:7:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 29 Dec 2013 13:08:05 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Thu, 01 Jan 2009 20:34:44 GMT";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1785, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1389569128', 'no') ; 
INSERT INTO `wp_options` VALUES (1786, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1389525928', 'no') ; 
INSERT INTO `wp_options` VALUES (1787, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1389569128', 'no') ; 
INSERT INTO `wp_options` VALUES (1788, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2013/12/parker/\' title=\'Version 3.8 of WordPress, named “Parker” in honor of Charlie Parker, bebop innovator, is available for download or update in your WordPress dashboard. We hope you’ll think this is the most beautiful update yet. Introducing a modern new design WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. […]\'>WordPress 3.8 “Parker”</a> <span class="rss-date">December 12, 2013</span><div class=\'rssSummary\'>Version 3.8 of WordPress, named “Parker” in honor of Charlie Parker, bebop innovator, is available for download or update in your WordPress dashboard. We hope you’ll think this is the most beautiful update yet. Introducing a modern new design WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. […]</div></li><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2013/12/3-8-rc2/\' title=\'Release candidate 2 of WordPress 3.8 is now available for download. This is the last pre-release, and we expect it to be effectively identical to what’s officially released to the public on Thursday. This means if you are a plugin or theme developer, start your engines! (If they’re not going already.) Lots of admin code […]\'>3.8 RC2</a> <span class="rss-date">December 10, 2013</span><div class=\'rssSummary\'>Release candidate 2 of WordPress 3.8 is now available for download. This is the last pre-release, and we expect it to be effectively identical to what’s officially released to the public on Thursday. This means if you are a plugin or theme developer, start your engines! (If they’re not going already.) Lots of admin code […]</div></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (1789, '_transient_timeout_feed_84a2c3a212a03c2875beccb4aed6e465', '1389569128', 'no') ; 
INSERT INTO `wp_options` VALUES (1790, '_transient_feed_84a2c3a212a03c2875beccb4aed6e465', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:4:"
  
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:83:"
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:4:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"link:http://localhost/tigers/ - Google Blog Search";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://www.google.com/search?ie=utf-8&q=link:http://localhost/tigers/&tbm=blg&tbs=sbd:1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:19:"About 3,650 results";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"How to Remove Lpcloudsvr302.com Pop-up Ads?(Adware Removal &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://forums.anvisoft.com/viewtopic-45-7799-0.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:501:"Once installed, Lpcloudsvr302.com constantly displays you various advertisements whenever you browsing on the Internet with Internet Explorer, Firefox or Google Chrome or any other browsers, such as this <em>http</em>://lpcloudsvr302.com/... Usually the <b>...</b> Although Lpcloudsvr302.com is not a vicious and malicious computer virus like ransomware, the advertisements and sponsored <em>links</em> shown from Lpcloudsvr302.com may put your computer at great danger of being infected with malware.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:15:"Anvisoft Forums";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Frances";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Wed, 08 Jan 2014 06:12:09 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"The Official Vtiger CRM Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"https://blogs.vtiger.com/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:290:"“Ring” – A notification pops up on your screen saying that it&#39;s John Decker, with a <em>link</em> to his CRM contact record. You click through to it. “Ring” – You quickly glance over your most recent note on him. It turns out that after you last spoke he had&nbsp;<b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:28:"The Official vtiger CRM Blog";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Asha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Tue, 07 Jan 2014 08:00:00 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"Servlet + JSP 数据分页的实现- lx_sunwei - 博客园";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://www.cnblogs.com/SWDreaming/p/3507975.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:668:"printStackTrace(); } return dataList; } /** * 返回总页数* @return */ public int getMaxPage(int rowsPerPage) { int maxPage; int maxRowCount = 0; String url = &quot;jdbc:oracle:thin:@<em>localhost</em>:1521:orcl&quot;; try { conn = DriverManager. <b>...</b> UserData&quot; %&gt; &lt;% @ page contentType=&quot;text/html;charset=UTF-8&quot; language=&quot;java&quot; %&gt; &lt;html&gt; &lt;head&gt; &lt;title&gt;servlet数据分页&lt;/title&gt; &lt;<em>link</em> rel=&quot;stylesheet&quot; type=&quot;text/css&quot; href=&quot;css.css&quot;&gt; &lt;/head&gt; &lt;body&gt; &lt;div style=&quot;margin-top: 15%; margin-left: 25%&quot;&gt; &lt;table&gt;&nbsp;<b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:19:"博客园_lx_sunwei";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"lx_sunwei";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Mon, 06 Jan 2014 14:28:00 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Email - SME Server";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:30:"http://wiki.contribs.org/Email";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:278:"6.1 Allow external IMAP mail access; 6.2 POP3 &amp; webmail <em>HTTP</em>; 6.3 Allow external pop3 access. 7 Imap <b>......</b> So, if your server is offline due to a <em>link</em> or ISP outage, the mail just stays at the sender&#39;s server until you are once again reachable.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:32:"SME Server - Recent changes [en]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Trex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Mon, 06 Jan 2014 08:00:00 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:102:"これだけやれば大丈夫！MacBookPro Late2013に買い換えて最初に &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:23:"http://buono.in/?p=1250";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:359:"photo credit: <em>Tiger</em> Pixel via photopin cc こんにちは、ボーノです。 念願のMacBook Pro <b>...</b> OSX MavericksはApacheを再インストールしてしまうが慌てなくていい - ITコンサルタント成長録にもある通り、<em>localhost</em>にアクセスすると 「It works!」というデフォルト&nbsp;<b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:6:"b.Labo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"ボーノ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sun, 29 Dec 2013 02:28:24 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Installation in Instiki";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://golem.ph.utexas.edu/wiki/instiki/show/Installation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:323:"See these instructions, to obtain the necessary prerequisites under <em>Tiger</em>. <b>...</b> though, apparently, you may need to supply the necessary soft <em>link</em> <b>...</b> Point your web browser at <em>http</em>://<em>localhost</em>:2500 and start configuring your first wiki! It&#39;s really that&nbsp;<b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:7:"Instiki";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Jacques Distler";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Thu, 26 Dec 2013 08:00:00 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:80:"wfs - Openlayers map save feature SRID error into PostGis &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:96:"http://gis.stackexchange.com/questions/81378/openlayers-map-save-feature-srid-error-into-postgis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:323:"WFS({ version: &quot;1.0.0&quot;, // loading data through <em>localhost</em> url path url: &quot;<em>http</em>://192.168.1.236:8080/geoserver/wfs&quot;, featureNS : &quot;<em>http</em>://192.168.1.236:8080/KASKIDB&quot;, maxExtent: bounds, // layer name featureType: &quot;DBadres_mahalle&quot;, // geometry&nbsp;<b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:64:"Recent Questions - Geographic Information Systems Stack Exchange";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:18:"Görkem Karadoğan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Wed, 25 Dec 2013 14:41:05 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"Hibernate Example Using hbm2ddl and HibernateSessionFactory &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://way2java.com/hibernate/hibernate-example-using-hbm2ddl-and-hibernatesessionfactory/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:644:"<b>...</b> &lt;session-factory&gt; &lt;property name=&quot;dialect&quot;&gt;org.hibernate.dialect.Oracle9Dialect&lt;/property&gt; &lt;property name=&quot;connection.url&quot;&gt;jdbc:oracle:thin:@<em>localhost</em>:1521:orcl&lt;/property&gt; &lt;property name=&quot;connection.username&quot;&gt;scott&lt;/property&gt; &lt; property name=&quot;connection.password&quot;&gt;<em>tiger</em>&lt;/property&gt; &lt;property name=&quot;connection.driver_class&quot;&gt;oracle.jdbc.driver. <b>....</b> Follows the Thread Local Session * pattern, see {@<em>link http</em>://hibernate.org/42.html }. */ public class HibernateSessionFactory&nbsp;<b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:33:"Java Tutorials, tips, forums, faq";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:35:"S. Nageswara Rao, Corporate Trainer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Tue, 10 Dec 2013 03:20:23 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:104:"9 bước bảo vệ trang WordPress của bạn ! | chia sẻ vì cộng đồng &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://www.byglongvu.com/2013/11/9-buoc-bao-ve-trang-wordpress-cua-ban.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:601:"<em>http</em>://www.wildlove.co/ <em>http</em>://www.chinatax.co/ <b>......</b> Open Server – Tạo <em>localhost</em> kiểu Nga &middot; Cài đặt và cấu hình Apache Server trên môi trường ... Phần mềm <b>.....</b> blocking meta refresh with <em>link</em> tags javascript port scanning web application security <b>....</b> edit end user license agreements EULA bookmarklet. Ek Tha <em>Tiger</em>. Elder Scrolls V Skyrim. Elie Saab. Elisha Cuthbert. Eliza Dushku. Elizabeth Hurley. Elizabeth Taylor. Elle. Elly Trần. Elly Trần 2013. Elly Trần Dai loan. Elly Trần khoe ngực.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:48:"chia sẻ vì cộng đồng longvu-Dj-byglongvu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"Vũ Long";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Sat, 23 Nov 2013 12:17:00 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:47:"
      
      
      
      
      
      
    ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"How to Remove Fix-issues.timehare.com Pop-up Ads?(Adware &lt;b&gt;...&lt;/b&gt;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://forums.anvisoft.com/viewtopic-45-7115-0.html";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:266:"Once installed, Fix-issues.timehare.com constantly displays you various advertisements whenever you browsing on the Internet with Internet Explorer, Firefox or Google Chrome or any other browsers, such as this <em>http</em>://fix-issues.timehare.com/&nbsp;<b>...</b>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:3:{s:9:"publisher";a:1:{i:0;a:5:{s:4:"data";s:15:"Anvisoft Forums";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Frances";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"date";a:1:{i:0;a:5:{s:4:"data";s:29:"Thu, 21 Nov 2013 01:35:31 GMT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:36:"http://a9.com/-/spec/opensearch/1.1/";a:3:{s:12:"totalResults";a:1:{i:0;a:5:{s:4:"data";s:4:"3650";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:10:"startIndex";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:12:"itemsPerPage";a:1:{i:0;a:5:{s:4:"data";s:2:"10";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:28:"text/xml; charset=ISO-8859-1";s:4:"date";s:29:"Sun, 12 Jan 2014 10:20:41 GMT";s:7:"expires";s:2:"-1";s:13:"cache-control";s:18:"private, max-age=0";s:10:"set-cookie";a:2:{i:0;s:143:"PREF=ID=78d1c383dc3ea2af:FF=0:TM=1389522041:LM=1389522042:S=yOKDtPyKFZV27t9h; expires=Tue, 12-Jan-2016 10:20:42 GMT; path=/; domain=.google.com";i:1;s:212:"NID=67=K8ypRXDvtjLsJpCrpwQ5COVZNTMvYjyIh57f4g1-x4TXrDzyOefVUXYz2hxfiav1teuCDWmTqRxchoZ_bRhkQGEI7v1zdFaaO67VTJY22I5H6I_RXaFt2-ZjJmVzYHZX; expires=Mon, 14-Jul-2014 10:20:42 GMT; path=/; domain=.google.com; HttpOnly";}s:3:"p3p";s:122:"CP="This is not a P3P policy! See http://www.google.com/support/accounts/bin/answer.py?hl=en&answer=151657 for more info."";s:6:"server";s:3:"gws";s:16:"x-xss-protection";s:13:"1; mode=block";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1591, '_site_transient_timeout_browser_c4e86ff1b653ad5eff93e52bc1c6434d', '1388931128', 'yes') ; 
INSERT INTO `wp_options` VALUES (1592, '_site_transient_browser_c4e86ff1b653ad5eff93e52bc1c6434d', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"31.0.1650.63";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (978, 'limit_login_logged', 'a:1:{s:15:"211.110.140.155";a:2:{s:5:"admin";i:1;s:4:"Page";i:1;}}', 'no') ; 
INSERT INTO `wp_options` VALUES (979, 'limit_login_lockouts_total', '2', 'no') ; 
INSERT INTO `wp_options` VALUES (1303, '_site_transient_timeout_browser_6f7c62fdea85348b09138021703fd1a5', '1387254559', 'yes') ; 
INSERT INTO `wp_options` VALUES (1304, '_site_transient_browser_6f7c62fdea85348b09138021703fd1a5', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"31.0.1650.63";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1623, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1388369534', 'no') ; 
INSERT INTO `wp_options` VALUES (1624, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1388326334', 'no') ; 
INSERT INTO `wp_options` VALUES (1826, '_transient_doing_cron', '1389789598.8306589126586914062500', 'yes') ; 
INSERT INTO `wp_options` VALUES (1830, '_site_transient_update_themes', 'O:8:"stdClass":1:{s:12:"last_checked";i:1389789599;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1831, '_site_transient_update_plugins', 'O:8:"stdClass":1:{s:12:"last_checked";i:1389789599;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1631, 'theme_mods_roar', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1389525932;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:8:"search-2";i:1;s:6:"meta-2";i:2;s:10:"archives-2";i:3;s:12:"categories-2";i:4;s:17:"recent-comments-2";}s:18:"orphaned_widgets_1";a:2:{i:0;s:9:"twitter-2";i:1;s:14:"recent-posts-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1795, '_transient_is_multi_author', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (1779, '_transient_timeout_feed_mod_a09314b1a57acfaba9faaca775e0e5d2', '1389569126', 'no') ; 
INSERT INTO `wp_options` VALUES (1780, '_transient_feed_mod_a09314b1a57acfaba9faaca775e0e5d2', '1389525926', 'no') ; 
INSERT INTO `wp_options` VALUES (857, 'wp_cart_title', 'Your Shopping Cart', 'yes') ; 
INSERT INTO `wp_options` VALUES (858, 'wp_cart_empty_text', 'Your cart is empty', 'yes') ; 
INSERT INTO `wp_options` VALUES (859, 'cart_return_from_paypal_url', 'http://localhost/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (843, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1384647424', 'yes') ; 
INSERT INTO `wp_options` VALUES (844, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3898";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2456";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2344";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1930";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1856";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1583";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1329";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1325";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1310";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1260";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1225";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1121";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1000";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"982";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"974";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"950";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"844";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"821";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"780";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"722";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"686";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"681";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"678";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"623";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"615";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"595";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"572";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"570";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"541";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"539";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"530";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"522";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"506";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"505";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"471";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"458";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"453";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"452";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"436";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"432";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (530, 'twp_version', '2.6.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (236, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (253, '_transient_update_plugins', 'O:8:"stdClass":1:{s:12:"last_checked";i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (254, '_transient_update_themes', 'O:8:"stdClass":1:{s:12:"last_checked";i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (297, 'hmbkp_default_path', '/Applications/MAMP/htdocs/tigers/wp-content/uploads/backupwordpress-b46642cc98-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (298, 'hmbkp_path', '/Applications/MAMP/htdocs/tigers/wp-content/uploads/backupwordpress-b46642cc98-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (299, 'hmbkp_schedule_default-1', 'a:3:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (300, 'hmbkp_schedule_default-2', 'a:3:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (301, 'hmbkp_plugin_version', '2.3.3', 'yes') ; 
INSERT INTO `wp_options` VALUES (559, 'wpcf7', 'a:1:{s:7:"version";s:5:"3.5.4";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (759, 'rewrite_rules', 'a:73:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=4&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:31:".+?/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:".+?/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:".+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"(.+?)/([^/]+)/trackback/?$";s:57:"index.php?category_name=$matches[1]&name=$matches[2]&tb=1";s:46:"(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:41:"(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:34:"(.+?)/([^/]+)/page/?([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&paged=$matches[3]";s:41:"(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&cpage=$matches[3]";s:26:"(.+?)/([^/]+)(/[0-9]+)?/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&page=$matches[3]";s:20:".+?/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:".+?/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:".+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:26:"(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:33:"(.+?)/comment-page-([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&cpage=$matches[2]";s:8:"(.+?)/?$";s:35:"index.php?category_name=$matches[1]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (698, '_site_transient_timeout_browser_202665350ff96275d5f63aa102c7a322', '1385072848', 'yes') ; 
INSERT INTO `wp_options` VALUES (699, '_site_transient_browser_202665350ff96275d5f63aa102c7a322', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"30.0.1599.101";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (193, 'theme_mods_twentythirteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1378623403;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:0:{}s:19:"primary-widget-area";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:21:"secondary-widget-area";a:0:{}s:24:"first-footer-widget-area";a:0:{}s:25:"second-footer-widget-area";a:0:{}s:24:"third-footer-widget-area";a:0:{}s:25:"fourth-footer-widget-area";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (194, 'current_theme', 'Expound', 'yes') ; 
INSERT INTO `wp_options` VALUES (195, 'theme_mods_tigertheme', 'a:5:{i:0;b:0;s:12:"header_image";s:79:"http://localhost/tigers/wp-content/uploads/2013/09/cropped-football_generic.jpg";s:17:"header_image_data";a:5:{s:13:"attachment_id";i:28;s:3:"url";s:79:"http://localhost/tigers/wp-content/uploads/2013/09/cropped-football_generic.jpg";s:13:"thumbnail_url";s:79:"http://localhost/tigers/wp-content/uploads/2013/09/cropped-football_generic.jpg";s:5:"width";i:1050;s:6:"height";i:250;}s:16:"header_textcolor";s:6:"e9e0e1";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1389617407;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:1:{i:0;s:9:"twitter-2";}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (196, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (477, '_site_transient_browser_00760e848c8aef5785b4a3f89f42352c', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"30.0.1599.101";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (304, '_transient_timeout_hmbkp_schedule_default-1_filesize', '2758062890', 'no') ; 
INSERT INTO `wp_options` VALUES (305, '_transient_hmbkp_schedule_default-1_filesize', '418160', 'no') ; 
INSERT INTO `wp_options` VALUES (484, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:2:{i:0;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:39:"https://wordpress.org/wordpress-3.8.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:39:"https://wordpress.org/wordpress-3.8.zip";s:10:"no_content";s:50:"https://wordpress.org/wordpress-3.8-no-content.zip";s:11:"new_bundled";s:51:"https://wordpress.org/wordpress-3.8-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"3.8";s:7:"version";s:3:"3.8";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}i:1;O:8:"stdClass":10:{s:8:"response";s:10:"autoupdate";s:8:"download";s:39:"https://wordpress.org/wordpress-3.8.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:39:"https://wordpress.org/wordpress-3.8.zip";s:10:"no_content";s:50:"https://wordpress.org/wordpress-3.8-no-content.zip";s:11:"new_bundled";s:51:"https://wordpress.org/wordpress-3.8-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"3.8";s:7:"version";s:3:"3.8";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1389789599;s:15:"version_checked";s:5:"3.7.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (485, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (1819, '_site_transient_timeout_wporg_theme_feature_list', '1389628207', 'yes') ; 
INSERT INTO `wp_options` VALUES (1820, '_site_transient_wporg_theme_feature_list', 'a:5:{s:6:"Colors";a:15:{i:0;s:5:"black";i:1;s:4:"blue";i:2;s:5:"brown";i:3;s:4:"gray";i:4;s:5:"green";i:5;s:6:"orange";i:6;s:4:"pink";i:7;s:6:"purple";i:8;s:3:"red";i:9;s:6:"silver";i:10;s:3:"tan";i:11;s:5:"white";i:12;s:6:"yellow";i:13;s:4:"dark";i:14;s:5:"light";}s:7:"Columns";a:6:{i:0;s:10:"one-column";i:1;s:11:"two-columns";i:2;s:13:"three-columns";i:3;s:12:"four-columns";i:4;s:12:"left-sidebar";i:5;s:13:"right-sidebar";}s:8:"Features";a:19:{i:1;s:8:"blavatar";i:2;s:10:"buddypress";i:3;s:17:"custom-background";i:4;s:13:"custom-colors";i:5;s:13:"custom-header";i:6;s:11:"custom-menu";i:7;s:12:"editor-style";i:8;s:21:"featured-image-header";i:9;s:15:"featured-images";i:10;s:15:"flexible-header";i:11;s:20:"front-page-post-form";i:12;s:19:"full-width-template";i:13;s:12:"microformats";i:14;s:12:"post-formats";i:15;s:20:"rtl-language-support";i:16;s:11:"sticky-post";i:17;s:13:"theme-options";i:18;s:17:"threaded-comments";i:19;s:17:"translation-ready";}s:7:"Subject";a:3:{i:0;s:7:"holiday";i:1;s:13:"photoblogging";i:2;s:8:"seasonal";}s:5:"Width";a:2:{i:0;s:11:"fixed-width";i:1;s:14:"flexible-width";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1783, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1389569128', 'no') ; 
INSERT INTO `wp_options` VALUES (1784, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 20 Dec 2013 08:24:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/?v=3.9-alpha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"WordPress 3.8 “Parker”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:41:"http://wordpress.org/news/2013/12/parker/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/12/parker/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Dec 2013 17:00:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2765";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:354:"Version 3.8 of WordPress, named “Parker” in honor of Charlie Parker, bebop innovator, is available for download or update in your WordPress dashboard. We hope you&#8217;ll think this is the most beautiful update yet. Introducing a modern new design WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:18197:"<p>Version 3.8 of WordPress, named “Parker” in honor of <a href="http://en.wikipedia.org/wiki/Charlie_Parker">Charlie Parker</a>, bebop innovator, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. We hope you&#8217;ll think this is the most beautiful update yet.</p>
<div id="v-6wORgoGb-1" class="video-player"><embed id="v-6wORgoGb-1-video" src="http://s0.videopress.com/player.swf?v=1.03&amp;guid=6wORgoGb&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<h2 class="aligncenter">Introducing a modern new design</h2>
<p><img class="wp-image-2951 aligncenter" alt="overview" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/overview.jpg?resize=623%2C193" data-recalc-dims="1" /></p>
<p>WordPress has gotten a facelift. 3.8 brings a fresh new look to the entire admin dashboard. Gone are overbearing gradients and dozens of shades of grey — bring on a bigger, bolder, more colorful design!</p>
<p><img class="aligncenter  wp-image-2856" style="margin-left: 0;margin-right: 0" alt="about-modern-wordpress" src="http://i2.wp.com/wpdotorg.files.wordpress.com/2013/12/design.png?resize=623%2C151" data-recalc-dims="1" /></p>
<h3>Modern aesthetic</h3>
<p>The new WordPress dashboard has a fresh, uncluttered design that embraces clarity and simplicity.</p>
<h3>Clean typography</h3>
<p>The Open Sans typeface provides simple, friendly text that is optimized for both desktop and mobile viewing. It’s even open source, just like WordPress.</p>
<h3>Refined contrast</h3>
<p>We think beautiful design should never sacrifice legibility. With superior contrast and large, comfortable type, the new design is easy to read and a pleasure to navigate.</p>
<hr />
<h2 class="aligncenter">WordPress on every device</h2>
<p><img class="alignright  wp-image-2984" alt="responsive" src="http://i2.wp.com/wpdotorg.files.wordpress.com/2013/12/responsive.jpg?resize=255%2C255" data-recalc-dims="1" />We all access the internet in different ways. Smartphone, tablet, notebook, desktop — no matter what you use, WordPress will adapt and you’ll feel right at home.</p>
<h3>High definition at high speed</h3>
<p>WordPress is sharper than ever with new vector-based icons that scale to your screen. By ditching pixels, pages load significantly faster, too.</p>
<hr />
<h2 class="aligncenter">Admin color schemes to match your personality</h2>
<p><img class="aligncenter  wp-image-2954" alt="colors" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/colors.jpg?resize=623%2C339" data-recalc-dims="1" /></p>
<p>WordPress just got a colorful new update. We’ve included eight new admin color schemes so you can pick the one that suits you best.</p>
<p>Color schemes can be previewed and changed from your Profile page.</p>
<hr />
<h2 class="aligncenter">Refined theme management</h2>
<p><img class="alignright  wp-image-2967" alt="themes" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/themes.jpg?resize=360%2C344" data-recalc-dims="1" />The new themes screen lets you survey your themes at a glance. Or want more information? Click to discover more. Then sit back and use your keyboard’s navigation arrows to flip through every theme you’ve got.</p>
<h3>Smoother widget experience</h3>
<p>Drag-drag-drag. Scroll-scroll-scroll. Widget management can be complicated. With the new design, we’ve worked to streamline the widgets screen.</p>
<p>Have a large monitor? Multiple widget areas stack side-by-side to use the available space. Using a tablet? Just tap a widget to add it.</p>
<hr />
<h2 class="aligncenter">Twenty Fourteen, a sleek new magazine theme</h2>
<p><img class="aligncenter size-large wp-image-2789" alt="The new Twenty Fourteen theme displayed on a laptop. tablet and phone" src="http://i0.wp.com/wpdotorg.files.wordpress.com/2013/12/twentyfourteen.jpg?resize=692%2C275" data-recalc-dims="1" /></p>
<h3>Turn your blog into a magazine</h3>
<p>Create a beautiful magazine-style site with WordPress and Twenty Fourteen. Choose a grid or a slider to display featured content on your homepage. Customize your site with three widget areas or change your layout with two page templates.</p>
<p>With a striking design that does not compromise our trademark simplicity, Twenty Fourteen is our most intrepid default theme yet.</p>
<hr />
<h2>Beginning of a new era</h2>
<p>This release was led by Matt Mullenweg. This is our second release using the new plugin-first development process, with a much shorter timeframe than in the past. We think it’s been going great. You can check out the features currently in production on the <a title="Make WordPress Core" href="http://make.wordpress.org/core/" target="_blank">make/core blog</a>.</p>
<p>There are 188 contributors with props in this release:</p>
<p><a href="http://profiles.wordpress.org/aaronholbrook">Aaron Holbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/adamsilverstein">adamsilverstein</a>, <a href="http://profiles.wordpress.org/admiralthrawn">admiralthrawn</a>, <a href="http://profiles.wordpress.org/ahoereth">Alexander Hoereth</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/aralbald">Andrey Kabakchiev</a>, <a href="http://profiles.wordpress.org/apeatling">Andy Peatling</a>, <a href="http://profiles.wordpress.org/ankitgadertcampcom">Ankit Gade</a>, <a href="http://profiles.wordpress.org/atimmer">Anton Timmermans</a>, <a href="http://profiles.wordpress.org/fliespl">Arkadiusz Rzadkowolski</a>, <a href="http://profiles.wordpress.org/aubreypwd">Aubrey Portwood</a>, <a href="http://profiles.wordpress.org/bassgang">bassgang</a>, <a href="http://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy (bananastalktome)</a>, <a href="http://profiles.wordpress.org/binarymoon">binarymoon</a>, <a href="http://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/calin">Calin Don</a>, <a href="http://profiles.wordpress.org/carldanley">Carl Danley</a>, <a href="http://profiles.wordpress.org/sixhours">Caroline Moore</a>, <a href="http://profiles.wordpress.org/caspie">Caspie</a>, <a href="http://profiles.wordpress.org/chrisbliss18">Chris Jean</a>, <a href="http://profiles.wordpress.org/iblamefish">Clinton Montague</a>, <a href="http://profiles.wordpress.org/corphi">Corphi</a>, <a href="http://profiles.wordpress.org/dbernar1">Dan Bernardic</a>, <a href="http://profiles.wordpress.org/danieldudzic">Daniel Dudzic</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/datafeedrcom">datafeedr</a>, <a href="http://profiles.wordpress.org/lessbloat">Dave Martin</a>, <a href="http://profiles.wordpress.org/drw158">Dave Whitley</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="http://profiles.wordpress.org/dougwollison">Doug Wollison</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/dziudek">dziudek</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/faison">Faison</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/gnarf37">gnarf37</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky</a>, <a href="http://profiles.wordpress.org/hanni">hanni</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/isaackeyet">Isaac Keyet</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jacklenox">Jack Lenox</a>, <a href="http://profiles.wordpress.org/janhenckens">janhenckens</a>, <a href="http://profiles.wordpress.org/jblz">Jeff Bowen</a>, <a href="http://profiles.wordpress.org/jeffr0">Jeff Chandler</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/buffler">Jeremy Buller</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jeherve">Jeremy Herve</a>, <a href="http://profiles.wordpress.org/jpry">Jeremy Pry</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/jhned">jhned</a>, <a href="http://profiles.wordpress.org/jim912">jim912</a>, <a href="http://profiles.wordpress.org/jartes">Joan Artes</a>, <a href="http://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="http://profiles.wordpress.org/joen">Joen Asmussen</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="http://profiles.wordpress.org/johnafish">John Fish</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/joshuaabenazer">Joshua Abenazer</a>, <a href="http://profiles.wordpress.org/nukaga">Junko Nukaga</a>, <a href="http://profiles.wordpress.org/devesine">Justin de Vesine</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K. Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/codebykat">Kat Hagan</a>, <a href="http://profiles.wordpress.org/littlethingsstudio">Kate Whitley</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kwight">Kirk Wight</a>, <a href="http://profiles.wordpress.org/koki4a">Konstantin Dankov</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/drozdz">Krzysiek Drozdz</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="http://profiles.wordpress.org/lite3">lite3</a>, <a href="http://profiles.wordpress.org/lucp">Luc Princen</a>, <a href="http://profiles.wordpress.org/latz">Lutz Schroer</a>, <a href="http://profiles.wordpress.org/mako09">Mako</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markmcwilliams">Mark McWilliams</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="http://profiles.wordpress.org/iammattthomas">Matt Thomas</a>, <a href="http://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="http://profiles.wordpress.org/mdbitz">Matthew Denton</a>, <a href="http://profiles.wordpress.org/mattheu">Matthew Haines-Young</a>, <a href="http://profiles.wordpress.org/matveb">Matías Ventura</a>, <a href="http://profiles.wordpress.org/megane9988">megane9988</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/micahwave">micahwave</a>, <a href="http://profiles.wordpress.org/cainm">Michael Cain</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">Michael Erlewine</a>, <a href="http://profiles.wordpress.org/michelwppi">Michel - xiligroup dev</a>, <a href="http://profiles.wordpress.org/chellycat">Michelle Langston</a>, <a href="http://profiles.wordpress.org/gradyetc">Mike Burns</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikelittle">Mike Little</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="http://profiles.wordpress.org/mt8biz">moto hachi</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/neil_pie">Neil Pie</a>, <a href="http://profiles.wordpress.org/nickdaugherty">Nick Daugherty</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="http://profiles.wordpress.org/ninio">ninio</a>, <a href="http://profiles.wordpress.org/ninnypants">ninnypants</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nvwd">Nowell VanHoesen</a>, <a href="http://profiles.wordpress.org/odysseygate">odyssey</a>, <a href="http://profiles.wordpress.org/originalexe">OriginalEXE</a>, <a href="http://profiles.wordpress.org/swissspidy">Pascal Birchler</a>, <a href="http://profiles.wordpress.org/pauldewouters">Paul de Wouters</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/senlin">Piet</a>, <a href="http://profiles.wordpress.org/ptahdunbar">Ptah Dunbar</a>, <a href="http://profiles.wordpress.org/raamdev">Raam Dev</a>, <a href="http://profiles.wordpress.org/bamadesigner">Rachel Carden</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/radices">Radices</a>, <a href="http://profiles.wordpress.org/mauryaratan">Ram Ratan Maurya</a>, <a href="http://profiles.wordpress.org/defries">Remkus de Vries</a>, <a href="http://profiles.wordpress.org/ounziw">Rescuework Support</a>, <a href="http://profiles.wordpress.org/rickalee">Ricky Lee Whittemore</a>, <a href="http://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="http://profiles.wordpress.org/wet">Robert Wetzlmayr, PHP-Programmierer</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/otto42">Samuel Wood</a>, <a href="http://profiles.wordpress.org/sanchothefat">sanchothefat</a>, <a href="http://profiles.wordpress.org/sboisvert">sboisvert</a>, <a href="http://profiles.wordpress.org/scottbasgaard">Scott Basgaard</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shaunandrews">Shaun Andrews</a>, <a href="http://profiles.wordpress.org/designsimply">Sheri Bigelow (designsimply)</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirbrillig">sirbrillig</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="http://profiles.wordpress.org/iamtakashi">Takashi Irie</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tmtoy">Takuma Morikawa</a>, <a href="http://profiles.wordpress.org/thomasguillot">Thomas Guillot</a>, <a href="http://profiles.wordpress.org/tierra">tierra</a>, <a href="http://profiles.wordpress.org/tillkruess">Till Krüss</a>, <a href="http://profiles.wordpress.org/tlamedia">TLA Media</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tommcfarlin">tommcfarlin</a>, <a href="http://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>, <a href="http://profiles.wordpress.org/taupecat">Tracy Rotton</a>, <a href="http://profiles.wordpress.org/trishasalas">trishasalas</a>, <a href="http://profiles.wordpress.org/mbmufffin">Tyler Smith</a>, <a href="http://profiles.wordpress.org/grapplerulrich">Ulrich</a>, <a href="http://profiles.wordpress.org/l10n">Vladimir</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/yonasy">yonasy</a>, and <a href="http://profiles.wordpress.org/tollmanz">Zack Tollman</a>. Also thanks to <a href="http://benmorrison.org/">Ben Morrison</a> and <a href="http://christineswebb.com/">Christine Webb</a> for help with the video.</p>
<p>Thanks for choosing WordPress. See you soon for version 3.9!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:46:"http://wordpress.org/news/2013/12/parker/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"3.8 RC2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://wordpress.org/news/2013/12/3-8-rc2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wordpress.org/news/2013/12/3-8-rc2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Dec 2013 01:08:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2805";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:343:"Release candidate 2 of WordPress 3.8 is now available for download. This is the last pre-release, and we expect it to be effectively identical to what&#8217;s officially released to the public on Thursday. This means if you are a plugin or theme developer, start your engines! (If they&#8217;re not going already.) Lots of admin code [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1180:"<p>Release candidate 2 of WordPress 3.8 is <a href="http://wordpress.org/wordpress-3.8-RC2.zip">now available for download</a>. This is the last pre-release, and we expect it to be effectively identical to what&#8217;s officially released to the public on Thursday.</p>
<p>This means if you are a plugin or theme developer, start your engines! (If they&#8217;re not going already.) Lots of admin code has changed so it&#8217;s especially important to see if your plugin works well within the new admin design and layout, and update <a href="http://wordpress.org/plugins/about/readme.txt">the &#8220;Tested up to:&#8221; part of your plugin readme.txt</a>.</p>
<p>If there is something in your plugin that you&#8217;re unable to fix, or if you think you&#8217;ve found a bug, join us <a href="http://codex.wordpress.org/IRC">in #wordpress-dev in IRC</a>, especially if you&#8217;re able to join during the dev chat on Wednesday, or post in the <a href="http://wordpress.org/support/forum/alphabeta">alpha/beta forum</a>. The developers and designers who worked on this release are happy to help anyone update their code before the 3.8 release.</p>
<p>Happy hacking, everybody!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:47:"http://wordpress.org/news/2013/12/3-8-rc2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"WordPress 3.8 RC1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2013/12/3-8-almost/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/news/2013/12/3-8-almost/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Dec 2013 09:54:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2760";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:345:"We&#8217;re entering the quiet but busy part of a release, whittling down issues to bring you all of the new features you&#8217;re excited about with the stability you expect from WordPress. There are just a few days from the &#8220;code freeze&#8221; for our 3.8 release, which includes a number of exciting enhancements, so the focus [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1873:"<p>We&#8217;re entering the quiet but busy part of a release, whittling down issues to bring you all of the new features you&#8217;re excited about with the stability you expect from WordPress. There are just a few days from the &#8220;code freeze&#8221; for our 3.8 release, <a href="http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/">which includes a number of exciting enhancements</a>, so the focus is on identifying any major issues and resolving them as soon as possible.</p>
<p>If you&#8217;ve ever wondered about how to contribute to WordPress, here&#8217;s a time you can: download this release candidate and use it in as many ways as you can imagine. Try to break it, and if you do, let us know how you did it so we can make sure it never happens again. If you work for a web host, this is the release you should test as much as possible and start getting your automatic upgrade systems and 1-click installers ready.</p>
<p><a href="http://wordpress.org/wordpress-3.8-RC1.zip">Download WordPress 3.8 RC1</a> (zip) or use the <a href="http://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;).</p>
<p>If you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.8">everything we’ve fixed</a> so far.</p>
<p><em>We&#8217;re so close to the</em><br />
<em>finish line, jump in and help</em><br />
<em>good karma is yours.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/12/3-8-almost/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.8 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 21 Nov 2013 05:21:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2754";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:307:"The first beta of the 3.8 is now available, and the next dates to watch out for are code freeze on December 5th and a final release on December 12th. 3.8 brings together several of the features as plugins projects and while this isn&#8217;t our first rodeo, expect this to be more beta than usual. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2236:"<p>The first beta of the 3.8 is now available, and the next dates to watch out for are code freeze on December 5th and a final release on December 12th.</p>
<p>3.8 brings together <a href="http://make.wordpress.org/core/features-as-plugins/">several of the features as plugins projects</a> and while this isn&#8217;t our first rodeo, expect this to be more beta than usual. The headline things to test out in this release are:</p>
<ul>
<li>The new admin design, especially the responsive aspect of it. Try it out on different devices and browsers, see how it goes, especially the more complex pages like widgets or seldom-looked-at-places like Press This. Color schemes, which you can change on your profile, have also been spruced up.</li>
<li>The dashboard homepage has been refreshed, poke and prod it.</li>
<li>Choosing themes under Appearance is completely different, try to break it however possible.</li>
<li>There&#8217;s a new default theme, Twenty Fourteen.</li>
<li>Over 250 issues closed already.</li>
</ul>
<p>Given how many things in the admin have changed it&#8217;s extra super duper important to test as many plugins and themes with admin pages against the new stuff. Also if you&#8217;re a developer consider how you can make your admin interface fit the MP6 aesthetic better.</p>
<p>As always, if you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.8">everything we’ve fixed</a> so far.</p>
<p><a href="http://wordpress.org/wordpress-3.8-beta-1.zip">Download WordPress 3.8 Beta 1</a> (zip) or use the <a href="http://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;).</p>
<p><em>Alphabet soup of</em><br />
<em>Plugins as features galore</em><br />
<em>The future is here</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/11/wordpress-3-8-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.7.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/10/wordpress-3-7-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2013/10/wordpress-3-7-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 29 Oct 2013 21:04:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2745";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:371:"WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including: Images with captions no longer appear broken in the visual editor. Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org. Avoid fatal errors with certain plugins that were incorrectly calling some [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1594:"<p>WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including:</p>
<ul>
<li>Images with captions no longer appear broken in the visual editor.</li>
<li>Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org.</li>
<li>Avoid fatal errors with certain plugins that were incorrectly calling some WordPress functions too early.</li>
<li>Fix hierarchical sorting in get_pages(), exclusions in wp_list_categories(), and in_category() when called with empty values.</li>
<li>Fix a warning that may occur in certain setups while performing a search, and a few other notices.</li>
</ul>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.7.1">list of tickets</a> and <a href="http://core.trac.wordpress.org/log/branches/3.7?stop_rev=25914&amp;rev=25986">the changelog</a>.</p>
<p>If you are one of the <a href="http://wordpress.org/download/counter/">nearly two million</a> already running WordPress 3.7, we will start rolling out the all-new <a href="http://wordpress.org/news/2013/10/basie/">automatic background updates</a> for WordPress 3.7.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.7.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p><em>Just a few fixes<br />
Your new update attitude:<br />
Zero clicks given</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/10/wordpress-3-7-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.7 “Basie”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2013/10/basie/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2013/10/basie/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Oct 2013 22:35:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2736";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:357:"Version 3.7 of WordPress, named &#8220;Basie&#8221; in honor of Count Basie, is available for download or update in your WordPress dashboard. This release features some of the most important architectural updates we&#8217;ve made to date. Here are the big ones: Updates while you sleep: With WordPress 3.7, you don&#8217;t have to lift a finger to [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:17229:"<p>Version 3.7 of WordPress, named &#8220;Basie&#8221; in honor of <a href="http://en.wikipedia.org/wiki/Count_basie">Count Basie</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features some of the most important architectural updates we&#8217;ve made to date. Here are the big ones:</p>
<ul>
<li><strong>Updates while you sleep</strong>: With WordPress 3.7, you don&#8217;t have to lift a finger to apply maintenance and security updates. Most sites are now able to automatically apply these updates in the background. The update process also has been made even more reliable and secure, with dozens of new checks and safeguards.</li>
<li><strong>Stronger password recommendations</strong>: Your password is your site&#8217;s first line of defense. It&#8217;s best to create passwords that are complex, long, and unique. To that end, our password meter has been updated in WordPress 3.7 to recognize common mistakes that can weaken your password: dates, names, keyboard patterns (123456789), and even pop culture references.</li>
<li><strong>Better global support</strong>: Localized versions of WordPress will receive faster and more complete translations. WordPress 3.7 adds support for automatically installing the right language files and keeping them up to date, a boon for the many millions who use WordPress in a language other than English.</li>
</ul>
<p>For developers there are lots of options around how to control the new updates feature, including allowing it to handle major upgrades as well as minor ones, more sophisticated date query support, and multisite improvements. As always, if you&#8217;re hungry for more <a href="http://codex.wordpress.org/Version_3.7">dive into the Codex</a> or browse the <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.7">over 400 closed tickets on Trac</a>.</p>
<h3>A New Wave</h3>
<p>This release was led by Andrew Nacin, backed up by Dion Hulse and Jon Cave. This is our first release using the new plugin-first development process, with a much shorter timeframe than in the past. (3.6 was released in August.) The 3.8 release, due in December, will continue this plugin-led development cycle that gives much more autonomy to plugin leads and allows us to decouple feature development from a release. You can follow this grand experiment, and what we&#8217;re learning from it, <a href="http://make.wordpress.org/core/">on the make/core blog</a>. There are 211 contributors with props in this release:</p>
<p><a href="http://profiles.wordpress.org/technosailor">Aaron Brazell</a>, <a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/aaronholbrook">Aaron Holbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/adamsilverstein">adamsilverstein</a>, <a href="http://profiles.wordpress.org/ahoereth">Alexander Hoereth</a>, <a href="http://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/andg">andg</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/andrewspittle">Andrew Spittle</a>, <a href="http://profiles.wordpress.org/askapache">askapache</a>, <a href="http://profiles.wordpress.org/atimmer">atimmer</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/beaulebens">Beau Lebens</a>, <a href="http://profiles.wordpress.org/benmoody">ben.moody</a>, <a href="http://profiles.wordpress.org/bhengh">Ben Miller</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bftrick">BFTrick</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy (bananastalktome)</a>, <a href="http://profiles.wordpress.org/bmb">bmb</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brianhogg">brianhogg</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/carldanley">Carl Danley</a>, <a href="http://profiles.wordpress.org/charlesclarkson">CharlesClarkson</a>, <a href="http://profiles.wordpress.org/chipbennett">Chip Bennett</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisrudzki">Chris Rudzki</a>, <a href="http://profiles.wordpress.org/aeg0125">coderaaron</a>, <a href="http://profiles.wordpress.org/coenjacobs">Coen Jacobs</a>, <a href="http://profiles.wordpress.org/crrobi01">Colin Robinson</a>, <a href="http://profiles.wordpress.org/andreasnrb">cyonite</a>, <a href="http://profiles.wordpress.org/daankortenbach">Daan Kortenbach</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/convissor">Daniel Convissor</a>, <a href="http://profiles.wordpress.org/dartiss">dartiss</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/csixty4">Dave Ross</a>, <a href="http://profiles.wordpress.org/davidjlaietta">David Laietta</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/dllh">dllh</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling (ocean90)</a>, <a href="http://profiles.wordpress.org/dpash">dpash</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/dzver">dzver</a>, <a href="http://profiles.wordpress.org/cais">Edward Caissie</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/faishal">faishal</a>, <a href="http://profiles.wordpress.org/faison">Faison</a>, <a href="http://profiles.wordpress.org/foofy">Foofy</a>, <a href="http://profiles.wordpress.org/fjarrett">Frankie Jarrett</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/gayadesign">Gaya Kessler</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/gizburdt">Gizburdt</a>, <a href="http://profiles.wordpress.org/goldenapples">goldenapples</a>, <a href="http://profiles.wordpress.org/gradyetc">gradyetc</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/webord">Gustavo Bordoni</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/creativeinfusion">itinerant</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jakubtyrcha">jakub.tyrcha</a>, <a href="http://profiles.wordpress.org/jamescollins">James Collins</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/buffler">Jeremy Buller</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="http://profiles.wordpress.org/johnnyb">John Beales</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn (johnbillion)</a>, <a href="http://profiles.wordpress.org/johnafish">John Fish</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/jchristopher">Jonathan Christopher</a>, <a href="http://profiles.wordpress.org/desrosj">Jonathan Desrosiers</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jonlynch">Jon Lynch</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/josephscott">Joseph Scott</a>, <a href="http://profiles.wordpress.org/betzster">Josh Betz</a>, <a href="http://profiles.wordpress.org/devesine">Justin de Vesine</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/ketwaroo">Ketwaroo</a>, <a href="http://profiles.wordpress.org/kevinb">kevinB</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/koopersmith">koopersmith</a>, <a href="http://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis (leewillis77)</a>, <a href="http://profiles.wordpress.org/lessbloat">lessbloat</a>, <a href="http://profiles.wordpress.org/layotte">Lew Ayotte</a>, <a href="http://profiles.wordpress.org/lgedeon">Luke Gedeon</a>, <a href="http://profiles.wordpress.org/iworks">Marcin Pietrzak</a>, <a href="http://profiles.wordpress.org/cimmo">Marco Cimmino</a>, <a href="http://profiles.wordpress.org/marco_teethgrinder">Marco Galasso</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markmcwilliams">Mark McWilliams</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/tw2113">Michael Beckwith</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/usermrpapa">Mr Papa</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/naomicbush">Naomi</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/natejacobs">NateJacobs</a>, <a href="http://profiles.wordpress.org/nathanrice">nathanrice</a>, <a href="http://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="http://profiles.wordpress.org/nickdaugherty">Nick Daugherty</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nickmomrik">Nick Momrik</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="http://profiles.wordpress.org/noahsilverstein">noahsilverstein</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nukaga">nukaga</a>, <a href="http://profiles.wordpress.org/nullvariable">nullvariable</a>, <a href="http://profiles.wordpress.org/butuzov">Oleg Butuzov</a>, <a href="http://profiles.wordpress.org/paolal">Paolo Belcastro</a>, <a href="http://profiles.wordpress.org/xparham">Parham</a>, <a href="http://profiles.wordpress.org/pbiron">Paul Biron</a>, <a href="http://profiles.wordpress.org/pauldewouters">Paul de Wouters</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/peterjaap">peterjaap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/plocha">plocha</a>, <a href="http://profiles.wordpress.org/pollett">Pollett</a>, <a href="http://profiles.wordpress.org/ptahdunbar">Ptah Dunbar</a>, <a href="http://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="http://profiles.wordpress.org/rasheed">Rasheed Bydousi</a>, <a href="http://profiles.wordpress.org/raybernard">RayBernard</a>, <a href="http://profiles.wordpress.org/rboren">rboren</a>, <a href="http://profiles.wordpress.org/greuben">Reuben Gunday</a>, <a href="http://profiles.wordpress.org/rfair404">rfair404</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/r3df">Rick Radko</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/wpmuguru">Ron Rennick</a>, <a href="http://profiles.wordpress.org/rpattillo">rpattillo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/hotchkissconsulting">Sam Hotchkiss</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/scottsweb">scottsweb</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/scruffian">scruffian</a>, <a href="http://profiles.wordpress.org/tenpura">Seisuke Kuraishi (tenpura)</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sillybean">Stephanie Leary</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar (@netweb)</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/strangerstudios">strangerstudios</a>, <a href="http://profiles.wordpress.org/sweetie089">sweetie089</a>, <a href="http://profiles.wordpress.org/swissspidy">swissspidy</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tmtoy">Takuma Morikawa</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tivnet">tivnet</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/toscho">toscho</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/sorich87">Ulrich Sossou</a>, <a href="http://profiles.wordpress.org/vericgar">vericgar</a>, <a href="http://profiles.wordpress.org/vinod-dalvi">Vinod Dalvi</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wikicms">wikicms</a>, <a href="http://profiles.wordpress.org/willnorris">Will Norris</a>, <a href="http://profiles.wordpress.org/wojtekszkutnik">Wojtek Szkutnik</a>, <a href="http://profiles.wordpress.org/wycks">wycks</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p>Enjoy what may be one of your last few manual updates. See you soon for version 3.8!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2013/10/basie/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.7 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Oct 2013 00:05:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2729";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:417:"The second release candidate of WordPress 3.7 is now available for testing! Those of you already testing WordPress 3.7 will be updated automatically to RC2. (Nice.) If you&#8217;d like to start testing, there&#8217;s no time like the present! Try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”) or download the release candidate here (zip). Please post to the Alpha/Beta [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1183:"<p>The second release candidate of WordPress 3.7 is now available for testing!</p>
<p>Those of you already testing WordPress 3.7 will be updated automatically to RC2. (<em>Nice.</em>) If you&#8217;d like to start testing, there&#8217;s no time like the present! Try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”) or <a href="http://wordpress.org/wordpress-3.7-RC2.zip">download the release candidate here</a> (zip). Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a> if you think you&#8217;ve found a bug, and if any known issues are raised, you’ll be able to <a href="http://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>Developers, please test your plugins and themes against WordPress 3.7. If there is a compatibility issue, let us know as soon as possible so we can deal with it before the final release.</p>
<p>For more on WordPress 3.7, check out the <a href="http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/">announcement post for Release Candidate 1</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Upcoming WordCamps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Oct 2013 19:25:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2723";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:368:"WordCamps are casual, locally-organized conferences that celebrate everything related to WordPress, and are a great opportunity to meet other WordPress users and professionals in your community. This has been a great year for WordCamps &#8212; there have been 56 so far in more than 20 countries, and there another 15 on the calendar before the year&#8217;s [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"Jen Mylo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3584:"<p><a href="http://central.wordcamp.org/">WordCamps</a> are casual, locally-organized conferences that celebrate everything related to WordPress, and are a great opportunity to meet other WordPress users and professionals in your community. This has been a great year for WordCamps &#8212; there have been 56 so far in more than 20 countries, and there another 15 on the calendar before the year&#8217;s over. If there&#8217;s one near you, check it out! In addition to getting to know your local WordPress community, most WordCamps attract some traveling visitors a well, giving you the chance to meet contributors to the WordPress open source project and <a href="http://make.wordpress.org/">get involved</a> yourself.</p>
<p>Here are the WordCamps on the schedule for the rest of this year.</p>
<p>October 25-27: <strong><a href="http://2013.boston.wordcamp.org/">WordCamp Boston</a></strong>, Boston, MA, USA<br />
October 25-26: <strong><a href="http://2013.malaga.wordcamp.org/">WordCamp Malaga</a></strong>, Spain<br />
October 26: <strong><a href="http://2013.nepal.wordcamp.org/">WordCamp Nepal</a></strong>, Kathmandu, Nepal<br />
October 26: <strong><a href="http://2013.sofia.wordcamp.org/">WordCamp Sofia</a></strong>, Bulgaria<br />
November 7: <strong><a href="http://2013.capetown.wordcamp.org/">WordCamp Cape Town</a></strong>, South Africa<br />
November 9: <strong><a href="http://2013.porto.wordcamp.org/">WordCamp Porto</a></strong>, Portugal<br />
November 9-10: <strong><a href="http://2013.kenya.wordcamp.org/">WordCamp Kenya</a></strong>, Nairobi, Kenya<br />
November 15: <strong><a href="http://2013.edmonton.wordcamp.org/">WordCamp Edmonton</a></strong>, AB, Canada<br />
November 16-17: <strong><a href="http://2013.orlando.wordcamp.org/">WordCamp Orlando</a></strong>, FL, USA<br />
November 16: <strong><a href="http://2013.denver.wordcamp.org/">WordCamp Denver</a></strong>, CO, USA<br />
November 23-24: <strong><a href="http://2013.london.wordcamp.org/">WordCamp London</a></strong>, UK<br />
November 23-24: <strong><a href="http://2013.raleigh.wordcamp.org/">WordCamp Raleigh</a></strong>, NC, USA<br />
November 23: <strong><a href="http://2013.saopaulo.wordcamp.org/">WordCamp São Paulo</a></strong>, Brazil<br />
December 14: <strong><a href="http://2013.vegas.wordcamp.org/">WordCamp Las Vegas</a></strong>, NV, USA<br />
December 14-15: <strong><a href="http://2013.sevilla.wordcamp.org/">WordCamp Sevilla</a></strong>, Spain</p>
<p>No WordCamps on this list in your area? Not to worry! There are thriving <a href="http://wordpress.meetup.com/">WordPress meetups</a> all over the world where you can meet like-minded people, and we maintain a library of <a href="http://wordpress.tv/category/wordcamptv/">WordCamp videos</a> at <a href="http://wordpress.tv/">WordPress.tv</a>.</p>
<h3>Get Involved</h3>
<ul>
<li>If you&#8217;re interested in organizing a WordCamp in your area, check out our <a href="http://plan.wordcamp.org/">WordCamp planning</a> site.</li>
<li>If you&#8217;re interested in <a href="http://make.wordpress.org/community/meetup-interest-form/">starting a WordPress meetup</a> in your area, let us know and we can set up a group on meetup.com for you.</li>
<li>And speaking of WordCamp videos, we&#8217;ve recently enabled volunteer-generated subtitles/closed captioning of the videos on WordPress.tv to make them more accessible. Interested in helping? Check out the <a href="http://wordpress.tv/using-amara-org-to-caption-or-subtitle-a-wordpress-tv-video/">WordPress.tv subtitling instructions</a>.</li>
</ul>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.7 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Oct 2013 19:52:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2718";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:331:"The first release candidate for WordPress 3.7 is now available! In RC 1, we&#8217;ve made some adjustments to the update process to make it more reliable than ever. We hope to ship WordPress 3.7 next week, but we need your help to get there. If you haven’t tested 3.7 yet, there’s no time like the present. (Please, [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2274:"<p>The first release candidate for WordPress 3.7 is now available!</p>
<p>In RC 1, we&#8217;ve made some adjustments to the update process to make it more reliable than ever. We hope to ship WordPress 3.7 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.7 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>WordPress 3.7 introduces <strong>automatic background updates</strong> for security and minor releases (like updating from 3.7 to 3.7.1). These are really easy to test  — RC 1 will update every 12 hours or so to the latest development version, and then email you the results. (You may get two emails: one for debugging, and one all users of 3.7 will receive.) If something went wrong, you can report it.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="http://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>To test WordPress 3.7 RC1, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.7-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what&#8217;s new in WordPress 3.7, visit the awesome About screen in your dashboard (<strong><img alt="" src="http://i0.wp.com/core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png?w=692" data-recalc-dims="1" /> → About</strong> in the toolbar). There, you can also see if your install is eligible for background updates. WordPress won’t automatically update, for example, if you’re using version control like Subversion or Git.</p>
<p><strong>Developers,</strong> please test your plugins and themes against WordPress 3.7, so that if there is a compatibility issue, we can figure it out before the final release. Make sure you post any issues to the support forums.</p>
<p><em>WordPress three seven</em><br />
<em>A self-updating engine</em><br />
<em>Lies beneath the hood</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.7 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/10/wordpress-3-7-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/10/wordpress-3-7-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Oct 2013 21:28:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2706";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:357:"WordPress 3.7 Beta 2 is now available for download and testing. This is software still in development, so we don&#8217;t recommend that you run it on a production site. This has been a quiet beta period. We&#8217;re hoping to get some more testers for automatic background updates, which will occur for security and minor releases (like updating [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2108:"<p>WordPress 3.7 Beta 2 is now available for download and testing. This is software still in development, so we don&#8217;t recommend that you run it on a production site.</p>
<p>This has been a quiet beta period. We&#8217;re hoping to get some more testers for <strong>automatic background updates</strong>, which will occur for security and minor releases (like updating from 3.7 to 3.7.1). It&#8217;s really easy to test this, as Beta 2 will update each day to the latest development version and then email you the results. If something goes wrong, you can report it — it&#8217;s that simple. To get the beta, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="http://wordpress.org/wordpress-3.7-beta2.zip">download the beta here</a> (zip). Check out <strong>Dashboard → Updates</strong> to see if your install is eligible for background updates. WordPress won&#8217;t update if, for example, you&#8217;re using version control like SVN or Git.</p>
<p>For more of what&#8217;s new in version 3.7, <a title="WordPress 3.7 Beta 1" href="http://wordpress.org/news/2013/09/wordpress-3-7-beta-1/">check out the Beta 1 blog post</a>. In Beta 2, we further increased the stability of background updates and also added about 50 bug fixes, including a fix for Internet Explorer 11 in the visual editor.</p>
<p>If you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.7">everything we’ve fixed</a>.</p>
<p>Happy testing!</p>
<p><em>Beta 2 released<br />
Dotting i&#8217;s and crossing t&#8217;s</em><br />
<em>Expect RC next</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/10/wordpress-3-7-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 12 Jan 2014 10:20:41 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Fri, 20 Dec 2013 08:24:58 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (508, 'theme_mods_expound', 'a:8:{i:0;b:0;s:16:"header_textcolor";s:6:"000000";s:16:"background_color";s:6:"ffffff";s:16:"background_image";s:53:"http://localhost/tigers/wp-content/uploads/grass1.jpg";s:17:"background_repeat";s:9:"no-repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";s:14:"rateme-dismiss";b:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (376, 'theme_mods_wingchun', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1384261449;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";N;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1778, '_transient_feed_a09314b1a57acfaba9faaca775e0e5d2', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Range:  Week in WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:13:"http://ran.ge";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:45:"High quality design and WordPress development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Dec 2013 21:11:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:35:"http://wordpress.org/?v=3.8.1-alpha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"Brian guest appears on a podcast  Week in WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/11/01/brian-guest-appears-on-a-podcast/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:67:"http://ran.ge/2013/11/01/brian-guest-appears-on-a-podcast/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 21:03:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4131";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:167:"Our own Brian Krogsgard talked to Matt Medeiros and Scott Sousa of Slocum Studio on Week in WordPress, a podcast about the news of the week in the WordPress ecosystem.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:555:"<p>Our own Brian Krogsgard talked to Matt Medeiros and Scott Sousa of <a href="http://slocumstudio.com/">Slocum Studio</a> on Week in WordPress, a podcast about the news of the week in the WordPress ecosystem.</p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/81i_v73ONgQ?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:63:"http://ran.ge/2013/11/01/brian-guest-appears-on-a-podcast/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Ranger Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://ran.ge/2013/10/13/ranger-brian-krogsgard/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:57:"http://ran.ge/2013/10/13/ranger-brian-krogsgard/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 13 Oct 2013 17:45:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:5:"Range";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4112";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:348:"Hey y&#8217;all. My name is Brian Krogsgard, and I&#8217;m happy to be joining Range as a Junior Partner. I&#8217;m looking forward to working with the outstanding team here. I&#8217;ve followed Range since its inception, and I&#8217;ve always loved their mentality that a small company could do big things. So, who am I? I graduated from [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1658:"<p><span style="line-height: 1.5;">Hey y&#8217;all. My name is Brian Krogsgard, and I&#8217;m happy to be joining Range as a Junior Partner. I&#8217;m looking forward to working with the outstanding team here.</span></p>
<p>I&#8217;ve followed Range since its inception, and I&#8217;ve always loved their mentality that a small company could do big things.</p>
<p>So, who am I?</p>
<p>I graduated from Auburn University with an Industrial Engineering degree, and for a few years web development was purely a hobby for me. My first job was as a technical sales engineer in the manufacturing industry, where I got my feet wet learning the value of effectively managing customer relationships and complex projects from start to finish.</p>
<p>But eventually I made the leap and turned my web development hobby into my career. Today, I bring experience building websites large and small across a variety of industries. I specialize in theme and light plugin development.</p>
<p>I also keep a keen eye on what&#8217;s happening in the WordPress community. I run a WordPress news blog called Post Status, which helps me learn more about my craft, share what I learn, and get to know many wonderful people that make the WordPress ecosystem great.</p>
<p>I&#8217;m based out of Birmingham, Alabama, where I live with my wife, Erica, and our blue Great Dane, Lucy May. I organize the Birmingham WordPress Meetup Group and co-organize WordCamp Birmingham.</p>
<p>At Range, I&#8217;ll wear many hats, just like Sara, Pete, and Aaron. My skill set compliments theirs nicely, and I really look forward to learning from them and bringing my best efforts to the table.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ran.ge/2013/10/13/ranger-brian-krogsgard/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"8";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"Disney Books relaunches on WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://ran.ge/2013/10/10/disney-books-relaunches-on-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:71:"http://ran.ge/2013/10/10/disney-books-relaunches-on-wordpress/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Oct 2013 14:32:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:8:"Branding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"Design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"Front End";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:17:"Project Spotlight";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4082";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:348:"Disney Publishing Worldwide has relaunched it&#8217;s books site, books.disney.com, on WordPress. When Disney came to us, we were excited, but it was clear that the biggest struggle was going to be the timeline. They wanted to build an all new books.disney.com on WordPress, and they needed it in less than a month. It was a tall order, [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Pete Mall";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1719:"<p><img class="size-large alignright" alt="disney-books-iphone" style="box-shadow: none;" src="http://s1.ran.ge/content/uploads/2013/10/disney-books-iphone-241x500.png" width="241" height="500" /><br />
Disney Publishing Worldwide has relaunched it&#8217;s books site, <a title="Disney Publishing Worldwide" href="http://books.disney.com/">books.disney.com</a>, on WordPress. When Disney came to us, we were excited, but it was clear that the biggest struggle was going to be the timeline. They wanted to build an all new books.disney.com on WordPress, and they needed it in less than a month. It was a tall order, but we pulled it off. From concept, to wireframing, design, development, and launch, Range put in a team effort to design and build the new books.disney.com.</p>
<p>In order to keep such a tight timeline, we knew wireframes needed to be done in less than a week, and the design needed to be finished just a week after that. Sara Cannon stepped up to the plate to lead the wireframes and design, and kept the schedule right on track. The design is also responsive, so it looks great on every device.</p>
<p>The development team pulled some crazy hours for a little while there, but the end result is an amazing site that meets our client&#8217;s needs and was delivered on time. We couldn&#8217;t have done it without Disney, who was a great partner. They held up their end of the bargain to trust our instincts and give quick feedback every time we needed it.</p>
<p>We are proud of the end result, and we hope you like it too. Be sure to <a title="Disney Publishing Worldwide" href="http://books.disney.com/">check out the site</a>, and who knows, you may find a new book for you and your family.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:67:"http://ran.ge/2013/10/10/disney-books-relaunches-on-wordpress/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Sara Cannon’s Be the Unicorn Published on Torque";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ran.ge/2013/07/29/sara-cannons-be-the-unicorn/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:62:"http://ran.ge/2013/07/29/sara-cannons-be-the-unicorn/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 30 Jul 2013 04:35:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:7:"Writing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"unicorns";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"writing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4024";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:342:"Check Out the full post on Torque at WCSF! Be The Unicorn by Sara Cannon What’s all this talk about Unicorns? Beautiful, sparkling, Golden Unicorns. My beginnings in Web Design and Development surfaced out of a love for technology an art. I was an artist and print designer with a thirst for something more. Because I wanted to [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2904:"<p><strong>Check Out the full post on <a href="http://torquemag.io/be-the-unicorn/">Torque</a> at WCSF!</strong></p>
<h3 style="padding-left: 60px;">Be The Unicorn by Sara Cannon</h3>
<p style="padding-left: 60px;">What’s all this talk about Unicorns? Beautiful, sparkling, Golden Unicorns.</p>
<p dir="ltr" style="padding-left: 60px;">My beginnings in Web Design and Development surfaced out of a love for technology an art. I was an artist and print designer with a thirst for something more. Because I wanted to be relevant and engaged, I ended up diving head first into the fast moving waters of web design and development. To get things done, I hunkered down, studied, imitated, and learned. To be completely self-sustainable, you end up learning bits of everything. I strived to become a renaissance woman. I wanted to build and create, without needing to rely on others to achieve my goals.</p>
<p dir="ltr" style="padding-left: 60px;">A few years later, I was hired by a small agency that really needed a one woman show. They did not want to need to rely multiple departments and titles to get the job done.</p>
<h3 dir="ltr" style="padding-left: 60px;">They needed a Golden Unicorn<img alt="" src="https://lh4.googleusercontent.com/Kf7Lg_5t9odG5Kjj7LF1MPQA39rSG3P_Thk7egmbWK8GEwAJ9hQ6lFcCZbFxbE3__nTgYNeF7qdMWcXI0Y0bl_lDQQFjQFsnrh_J2bZiyJGK_H-tNbPZbgZ8" width="223px;" height="233px;" /></h3>
<p dir="ltr" style="padding-left: 60px;">They wanted someone who could not only always solve the technical problems at hand, but had an eye for design and user experience. Someone who could say “yes that can happen” without hesitation and then google it right after making the promise. Since then, I decided to strive to be the unicorn.</p>
<p dir="ltr" style="padding-left: 60px;">In the industry now, there seems to be a long standing tension between designers and developers. This tension is manifested in the workplace, in social settings, but it is also within ourselves – with how we think. It is the longstanding battle of the left brain and right brain. The left side of the brain is known to be logical, analytical, and objective (hello technical directors!) while the right side is known to be intuitive, thoughtful, and subjective (creative thinkers). But the one thing both sides of our brains have in common is Problem Solving. Even though both sides are radically different, there is a common thread there. No one wants to be a code monkey or a pixel pusher. We want to solve problems, and do great work.</p>
<p dir="ltr" style="padding-left: 60px;"><img alt="" src="https://lh3.googleusercontent.com/Qw9xPk_1Ao-OXe8S2SSW0Qe78766iau8sXfgAQxvW46rljL5hG-ejlInKKnFFLPpSslgx0TYxyN-kS2lJ_T6l6tupzlWf0uaethYaGfFDW1yKzFWo1QLqx0X" width="652px;" height="484px;" /></p>
<p><strong>Check Out the rest of the Post on <a href="http://torquemag.io/be-the-unicorn/">Torque</a></strong></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/07/29/sara-cannons-be-the-unicorn/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"Pete Mall to talk about the YouTube Upload Widget Live today at 10am PDT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://ran.ge/2013/07/10/pete-mall-to-talk-about-the-youtube-upload-widget/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:84:"http://ran.ge/2013/07/10/pete-mall-to-talk-about-the-youtube-upload-widget/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 10 Jul 2013 16:26:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:5:"Range";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=3996";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:351:"Join Ran.ge and YouTube this week to find out more about our open source upload widget for WordPress. We will show you how it works and walk you through the source code for the widget itself. Tune in to @YouTube Developers Live at 10am PDT https://developers.google.com/live/shows/38132276-6003 &#160; update: check out the video of the show [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:840:"<p>Join Ran.ge and YouTube this week to find out more about our open source upload widget for WordPress. We will show you how it works and walk you through the source code for the widget itself.</p>
<p>Tune in to @YouTube Developers Live at 10am PDT</p>
<p><a title="Range and YouTube" href="https://developers.google.com/live/shows/38132276-6003">https://developers.google.com/live/shows/38132276-6003</a></p>
<p>&nbsp;</p>
<p><em>update: check out the video of the show &amp; demo below!</em></p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/LXYwLo4fkIA?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:80:"http://ran.ge/2013/07/10/pete-mall-to-talk-about-the-youtube-upload-widget/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"Sara Cannon to Speak in Montreal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/04/17/sara-cannon-to-speak-in-montreal/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:67:"http://ran.ge/2013/04/17/sara-cannon-to-speak-in-montreal/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 17 Apr 2013 18:01:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:25:"http://dev.ran.ge/?p=3916";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:320:"I can&#8217;t tell you how excited I am to be able to speak at the Montreal WordPress Developers Meetup and the Montreal Girl Geeks! On Tuesday, April 23: The Future of UI: How Mobile Design is Shaping the Web Web design is not an interactive brochure anymore. Smart mobile devices have forever changed the way [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4096:"<p>I can&#8217;t tell you how excited I am to be able to speak at the <a href="http://wpmtl.org/2013/04/montreal-wordpress-developer_meetup-april-23rd-2013/">Montreal WordPress Developers Meetup</a> and the <a href="http://montrealgirlgeeks.com/2013/04/18/april-event/">Montreal Girl Geeks</a>!</p>
<hr />
<p><img class="size-full wp-image-3918 alignleft" alt="wcmtl-developer-meetup-facebook-size-179px" src="http://s1.ran.ge/content/uploads/2013/05/wcmtl-developer-meetup-facebook-size-179px.png" width="179" height="126" />On Tuesday, April 23:</p>
<p><strong>The Future of UI: How Mobile Design is Shaping the Web</strong></p>
<p>Web design is not an interactive brochure anymore. Smart mobile devices have forever changed the way we think and interact with websites. Now you have to consider an array of things you didn’t have to worry about before, such as HiDPI graphics, UI/UX patterns, touch target sizes, gestures, and managing expectations. All the while not losing track of what’s important: Content.</p>
<p>We’re going to discuss the influence of mobile on design, trends, and implementation methods, as well as how touch is changing our lives. As designers and developers, we can benefit from learning about how mobile is changing the way we interact with websites, and what that means for the future of UI. <a href="http://wpmtl.org/2013/04/montreal-wordpress-developer_meetup-april-23rd-2013/" target="_blank" rel="nofollow nofollow">http://wpmtl.org/2013/04/montreal-wordpress-developer_meetup-april-23rd-2013/</a></p>
<p><iframe style="border: 1px solid #CCC; border-width: 1px 1px 0; margin-bottom: 5px;" src="http://www.slideshare.net/slideshow/embed_code/19911427" height="356" width="427" allowfullscreen="" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></p>
<div style="margin-bottom: 5px;"><strong> <a title="The Future of UI - How Mobile Design is Shaping The Web 2" href="http://www.slideshare.net/saracannon/the-future-of-ui-how-mobile-design-is-shaping-the-web-2" target="_blank">The Future of UI &#8211; How Mobile Design is Shaping The Web 2</a> </strong> from <strong><a href="http://www.slideshare.net/saracannon" target="_blank">Sara Cannon</a></strong></div>
<hr />
<p><img class="alignleft size-full wp-image-3917" alt="MTLGGbarcode1-300x300" src="http://s1.ran.ge/content/uploads/2013/05/MTLGGbarcode1-300x300.jpg" width="300" height="300" />On Thursday, April 25:</p>
<p><strong>Font Swoon!</strong></p>
<p>Times New Roman. Helvetica. Comic Sans. We’ve all got fonts we love to use or love to hate. Typography is one of those topics that’s easy to overlook, but when you bring it up, everyone has an opinion. Sara’s talk is not just for designers spending hours debating on the slant of a curly-quote or the perfect sans serif – it’s for anyone who’s ever typed, read, or even just stared at the screen or page. Because typography is essential to how we read, consume, convey, and process the written word and it’s BFF, design.</p>
<p>Let’s take our relationship with web typography to the next level and crush on the latest fonts, check out some awesome CSS3 implementations, and find incredible inspiration for interaction, refinement and our next dates with negative space. Come fall head over heels with us at Font Swoon! <a href="http://montrealgirlgeeks.com/2013/04/18/april-event/" target="_blank" rel="nofollow nofollow">http://montrealgirlgeeks.com/2013/04/18/april-event/</a></p>
<p><iframe style="border: 1px solid #CCC; border-width: 1px 1px 0; margin-bottom: 5px;" src="http://www.slideshare.net/slideshow/embed_code/19994942" height="356" width="427" allowfullscreen="" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></p>
<div style="margin-bottom: 5px;"><strong> <a title="Font swoon" href="http://www.slideshare.net/saracannon/font-swoon" target="_blank">Font swoon</a> </strong> from <strong><a href="http://www.slideshare.net/saracannon" target="_blank">Sara Cannon</a></strong></div>
<p>If you are in Montreal, come on out &#8211; I&#8217;d love to meet you!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:63:"http://ran.ge/2013/04/17/sara-cannon-to-speak-in-montreal/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Join Me at WordSesh Tonight!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ran.ge/2013/04/12/join-me-at-wordsesh-tonight/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:62:"http://ran.ge/2013/04/12/join-me-at-wordsesh-tonight/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 12 Apr 2013 21:24:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"be the unicorn";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"WordSesh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=1844";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:365:"Tonight I&#8217;m going to be speaking at the first ever WordSesh online WordPress Conference! WordSesh is a day of live WordPress presentations from all over the world streamed live, and it&#8217;s free! Tune in at 4UTC 12am EST (midnight tonight!) to join me in my talk &#8220;Be the Unicorn.&#8221; I&#8217;m really looking forward to hearing all the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:519:"<p>Tonight I&#8217;m going to be speaking at the first ever <a href="http://wordsesh.org/">WordSesh</a> online WordPress Conference! WordSesh is a day of live WordPress presentations from all over the world streamed live, and it&#8217;s free! Tune in at 4UTC 12am EST (midnight tonight!) to join me in my talk &#8220;Be the Unicorn.&#8221;</p>
<p>I&#8217;m really looking forward to hearing all the other awesome speakers! If you can&#8217;t make it, don&#8217;t worry, all the sessions will be recorded. #WPYall</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/04/12/join-me-at-wordsesh-tonight/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"Re-thinking WordPress Post Format UI An Exercise ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://ran.ge/2013/04/11/re-thinking-wordpress-post-format-ui-an-exercise/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:83:"http://ran.ge/2013/04/11/re-thinking-wordpress-post-format-ui-an-exercise/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 11 Apr 2013 07:30:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:7:"UI / UX";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"WordPress Core";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=1771";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"Post Formats are slated to drop in 3.6 and are currently in Beta. I love how WordPress is standardizing formats so that when you change your theme, the content format and metadata associated with that format is preserved. This opens up new doors and possibilities for bloggers who want a unique look without having to customize [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:12714:"<div id="attachment_1818" style="width: 1034px" class="wp-caption alignleft"><a href="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach.jpg"><img class="size-large wp-image-1818" alt="Post Format Modal" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach-1024x698.jpg" width="1024" height="698" /></a><p class="wp-caption-text">Post Format Modal</p></div>
<p>Post Formats are slated to drop in 3.6 and are currently in Beta. I love how WordPress is standardizing formats so that when you change your theme, the content format and metadata associated with that format is preserved. This opens up new doors and possibilities for bloggers who want a unique look without having to customize a category display.</p>
<p><img class="alignleft size-full wp-image-1772" alt="3.5 post formats enabled" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.51.52-AM.png" width="299" height="253" />Post formats are currently in WordPress 3.5 but are just in a tiny modal box to you right (if your theme has them enabled)</p>
<p>They don&#8217;t change the metaboxes for use with the content (aka make a &#8220;Video URL&#8221; field when selecting) but in 3.6 they will &#8211; which is exciting.</p>
<p>There has been lots of discussion and wireframes about the Post Formats UI and user testing&#8230; I decided to do an exercise that might address some of the pain points of the current UI&#8217;s iteration.</p>
<h2>Researching Other similar tools</h2>
<h2><strong>WordPress.com New Dash</strong></h2>
<p>Taking a look at the simplified blogging tool for WordPress.com &#8211; they deal with Post Formats right away.</p>
<div id="attachment_1776" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1776" alt="WordPress.com New Dash - Screen right after you hit &quot;New Post&quot;" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.58.11-AM-1024x438.png" width="1024" height="438" /><p class="wp-caption-text">WordPress.com New Dash &#8211; Screen right after you hit &#8220;New Post&#8221;</p></div>
<div id="attachment_1775" style="width: 1068px" class="wp-caption alignleft"><img class=" wp-image-1775" alt="WordPress.com New Dash - Post Page" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.58.22-AM.png" width="1058" height="567" /><p class="wp-caption-text">WordPress.com New Dash &#8211; Post Page :: a simplified version of the one in the admin</p></div>
<div id="attachment_1774" style="width: 1061px" class="wp-caption alignleft"><img class=" wp-image-1774" alt="WordPress.com New Dash - Screen" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.58.36-AM.png" width="1051" height="553" /><p class="wp-caption-text">WordPress.com New Dash &#8211; Video Post Selected<br />note the customized interface just for uploading photos</p></div>
<h2><strong style="font-size: 1.2em;"><strong style="font-size: 1.2em;">Tumblr</strong></strong></h2>
<div id="attachment_1784" style="width: 954px" class="wp-caption alignleft"><img class="size-full wp-image-1784" alt="Tumblr.com Dashboard - choose the format from the icons across before posting" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.16.27-AM.png" width="944" height="453" /><p class="wp-caption-text">Tumblr.com Dashboard &#8211; choose the format from the icons across before posting</p></div>
<div id="attachment_1783" style="width: 977px" class="wp-caption alignleft"><img class="size-full wp-image-1783" alt="tumblr.com Post a Video Screen" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.16.41-AM.png" width="967" height="482" /><p class="wp-caption-text">tumblr.com Post a Video Screen</p></div>
<p>The glaring similarities between WordPress.com New Dash and Tumblr is that they are 1) making a post format decision  before they get to the editor and 2) the editor is only giving them the modals and upload buttons that they need. If we think about #1 philosophically from a UX point of view &#8211; the formats are action-centric. They are not passively opening up the post editor then wondering what they are going to post &#8211; they are forced to make a decision, an action, and therefore the UI they are given is tailored to this decision making for a better UX.</p>
<p>Neither Tumblr or New Dash have a way of changing the post formats &#8211; which I think is good because they would lose all the data that they put in there to the custom modals. (more on this later)</p>
<h2><strong style="font-size: 1.2em;"></strong>Current 3.6 Iteration in Beta</h2>
<div id="attachment_1786" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1786" alt="WordPress.com 3.6 Beta" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.28.04-AM-1024x414.png" width="1024" height="414" /><p class="wp-caption-text">WordPress.com 3.6 Beta</p></div>
<p>The current iteration of the new Post-Formats UI that is now in 3.6 Beta has icons for each of the 10 formats spread across the top of the post editor. They are currently passive button-like selectors with a label to the right. Dave Martin ran some user tests on the current UI and the results were <a href="http://make.wordpress.org/ui/2013/04/09/post-formats-usability-test-round-4/">not good</a>.</p>
<p>I decided to do some action-centric decision-first based UI exercises to explore some options.</p>
<h2>Decision Based Approach &#8211; Working Within the Current Menu System</h2>
<p>The first exercise is one based on just using the current menu system. It turns out that it *could* in theory work &#8211; but in reality there are just way too many post formats.</p>
<div id="attachment_1790" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1790" alt="Action-Centric Dashboard Menu" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-h-copy-1024x695.jpg" width="1024" height="695" /><p class="wp-caption-text">Action-Centric Dashboard Menu</p></div>
<div id="attachment_1792" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1792" alt="Post Page - Sub Menu" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-p-copy-1024x698.jpg" width="1024" height="698" /><p class="wp-caption-text">Post Page &#8211; Sub Menu</p></div>
<p>Basically in this iteration, we make the choice in the menu and then the post screen will have just what you need.</p>
<div id="attachment_1794" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1794" alt="Video Post Format - note the simplified interface, the title changes to include the word &quot;video&quot; in it , and the labels are inside the boxes" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-video-post-1024x699.jpg" width="1024" height="699" /><p class="wp-caption-text">Video Post Format &#8211; note the simplified interface, the title changes to include the word &#8220;video&#8221; in it , and the labels are inside the boxes</p></div>
<h2>Changing Formats</h2>
<p>In the above screenshot &#8211; there is a way to change formats (unlike new dash or tumblr.) It is in the publish meta box. This is a more passive-switch than an in-your-face one which is important, as someone would have to completely change their mind to use it. It also falls under the same importance as the other items in the publish meta box.</p>
<div id="attachment_1799" style="width: 307px" class="wp-caption aligncenter"><img class="size-large wp-image-1799 " alt="Post Format Switching" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.57.34-AM.png" width="297" height="270" /><p class="wp-caption-text">Post Format Switching</p></div>
<div id="attachment_1797" style="width: 306px" class="wp-caption aligncenter"><img class="size-full wp-image-1797 " alt="Post Format Switching - drop down option" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.59.19-AM.png" width="296" height="313" /><p class="wp-caption-text">Post Format Switching &#8211; drop down option</p></div>
<div id="attachment_1798" style="width: 304px" class="wp-caption aligncenter"><img class="size-full wp-image-1798 " alt="Post Format Switching - radio button option" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.58.42-AM.png" width="294" height="541" /><p class="wp-caption-text">Post Format Switching &#8211; radio button option</p></div>
<p>Exploring both radio buttons for switching or a drop-down &#8211; That meta box currently uses both as a standard, but I think I prefer the radio simply because the icons are visual cues.</p>
<h2>Explorations outside of the current navigation pattern</h2>
<p>So, seeing that the navigation above is a bit cramped - I decided to explore in-page and modal decision patterns.</p>
<div id="attachment_1803" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1803" alt="In Page decision with post editor greyed out. Icons will go away and the &quot;switching&quot; will be in the siidebar like above" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-i-copy-1024x698.jpg" width="1024" height="698" /><p class="wp-caption-text">In Page decision with post editor greyed out. Icons will go away and the &#8220;switching&#8221; will be in the sidebar like above</p></div>
<div id="attachment_1804" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1804" alt="not greyed out but post editor fades in after decision" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-i-copy1-1024x698.jpg" width="1024" height="698" /><p class="wp-caption-text">not greyed out but post editor fades in after decision</p></div>
<div id="attachment_1805" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1805" alt="without labels - cursor rollover changes page title" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-in-page-approach-with-cursor-rollover-1024x355.jpg" width="1024" height="355" /><p class="wp-caption-text">without labels &#8211; cursor rollover changes page title</p></div>
<p>While all this is interesting &#8211; I&#8217;m not sure if it feels quite right as it is outside of the typical WordPress interface, but could be explored further.</p>
<h2>Modal Window</h2>
<p>So our natural progression here is to try out a modal. Usually I&#8217;m not-a-fan of modals at all. They tend to be disruptive. After the new media editor launched last release, its made me re-think modals. Lightbox was so terrible and slow &#8211; but using a modal for this action kind of makes sense as you can be on any page and receive it before hitting the post editor, without another page load or coming from any add post action. (think top nav bar add new)</p>
<div id="attachment_1818" style="width: 1034px" class="wp-caption alignleft"><a href="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach.jpg"><img class="size-large wp-image-1818" alt="Post Format Modal" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach-1024x698.jpg" width="1024" height="698" /></a><p class="wp-caption-text">Post Format Modal</p></div>
<p>At this point, I am leaning towards a fast modal with a few caveats. 1) you can turn the modal off if you don&#8217;t use other formats as much and just want to use the passive switcher. 2) you can turn all post formats off from within core settings to override what your theme set. 3) you can filter list tables by format (like you do categories.) The last two I think this should be an option regardless of the approach.</p>
<p>However, that being said, I know we are in Beta for 3.6 and the modal window approach might be a bit out of reach for this release. If I were to have a #2 I would say the greyed out post edit UI with the larger icons. approach might be viable (after the decision is made, the icons go away, post editor fades in, and the format switching is in the publish meta box.)</p>
<p>In conclusion, I hope to get some conversation going and hear what everyone else thinks so that we can make WordPress amazing together.</p>
<p><strong><em>update: if anyone else wants to tinker, here are my thrown together photoshop files etc s.sar.ac/071P0S3r2H2Q</em></strong></p>
<p>Update 2: Mark Jaquith is asking for feedback on the Make UI Blog <a href="http://make.wordpress.org/ui/2013/04/11/saracannon-has-posted-her-take-on-a-new/">http://make.wordpress.org/ui/2013/04/11/saracannon-has-posted-her-take-on-a-new/</a></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:79:"http://ran.ge/2013/04/11/re-thinking-wordpress-post-format-ui-an-exercise/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"29";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"Globalnews.ca Data Migration The MSSQL to MySQL Delima";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://ran.ge/2013/03/26/globalnews-ca-data-migration-and-the-mssql-to-mysql-delima/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:93:"http://ran.ge/2013/03/26/globalnews-ca-data-migration-and-the-mssql-to-mysql-delima/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Mar 2013 16:19:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Migration";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:5:"MSSQL";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:5:"MySQL";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:25:"http://dev.ran.ge/?p=3844";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:350:"Recently Globalnews.ca made the move to WordPress and we were tasked with migrating all their data from their existing custom MSSQL-based environment to the new WordPress environment hosted with WordPress.com VIP. We have a normal process for this kind of thing, and it goes something like this: Create a local WordPress install and get rid [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Aaron D. Campbell";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3593:"<p>Recently Globalnews.ca made the move to WordPress and we were tasked with migrating all their data from their existing custom MSSQL-based environment to the new WordPress environment hosted with <a href="http://vip.wordpress.com/">WordPress.com VIP</a>. We have a normal process for this kind of thing, and it goes something like this:</p>
<ol>
<li>Create a local WordPress install and get rid of the default posts, comments, and meta data.</li>
<li>Put the clients old data into tables in the same WordPress database.</li>
<li>Write a script that pulls the data from the old tables and uses a combination of WordPress functions and direct database queries to put it into the WordPress install.</li>
<li>Check the data and if it&#8217;s not quite right blast out the posts, comments, and meta data and go back to step 3.</li>
<li>When the data is exactly what we want in WordPress we use <a href="http://wp-cli.org/">wp-cli</a> to export the data in <abbr title="WordPress eXtended Rss">WXR</abbr> format, and submit those files to WordPress.com VIP.</li>
</ol>
<p>It sounds pretty straight forward, and usually it is, with the most difficult part obviously being the script that imports the data from the old tables into WordPress. Not this time however. This time the most difficult part turned out to be step 2, putting the clients data into the same database as WordPress. The problem was that the conversion from MSSQL to MySQL was no trivial matter.</p>
<p>Often you can use <a href="http://www.mysql.com/products/workbench/">MySQL Workbench</a> to migrate data from MSSQL to MySQL, so we started by spinning up a Windows cloud server with MSSQL. We imported the data into an MSSQL database on this new server, and then we installed MySQL and the MySQL Workbench. Due to the large amount of data being converted, we ran into memory issues several times and had to resize the cloud server, but once the memory issues were under control we realized that MySQL Workbench simply could not migrate many of the tables that we needed.</p>
<p>After many hours of digging and research, I finally found the problem. It turns out that there were a couple data types that were causing things to choke. In our case that was mostly limited to nvarchar and ntext. Why? Well because MSSQL doesn&#8217;t actually support UTF-8. What?! I know&#8230;I was surprised too, but it seems MSSQL doesn&#8217;t support the standard in character encoding. Instead it has nvarchar and ntext that don&#8217;t store as UTF-8 but offer similar output in a classic Microsoft-proprietary way.</p>
<p>I was able to work around this limitation by creating duplicate tables for each table that contained one of these field types, using nvarchar in place of varchar and ntext in place of text. Then I ran queries to select the data from the old tables and insert it into these newly created tables.</p>
<pre class="brush: sql; title: ; notranslate">
CREATE TABLE [dbo].[ImportFixed](
	[RowNum] [bigint] NULL,
	[post_title] [nvarchar](200) NOT NULL, -- Previously varchar
	[content_html] [ntext] NULL -- Previously text
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
----------------------
INSERT INTO [import].[dbo].[ImportFixed](
	[RowNum],
	[post_title],
	[content_html]
)
SELECT
	[RowNum],
	[post_title],
	[content_html]
FROM [import].[dbo].[Import]
GO
</pre>
<p>This then allowed MySQL Workbench to properly handle the encoding during it&#8217;s migration from MSSQL to MySQL. Even once the process is known it&#8217;s tedious and time consuming at best, but it seems to be very reliable and stable.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:89:"http://ran.ge/2013/03/26/globalnews-ca-data-migration-and-the-mssql-to-mysql-delima/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"Sara Cannon to Speak at WordCamp Atlanta on Saturday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://ran.ge/2013/03/12/sara-cannon-to-speak-at-wordcamp-atlanta-on-saturday/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:87:"http://ran.ge/2013/03/12/sara-cannon-to-speak-at-wordcamp-atlanta-on-saturday/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Mar 2013 22:57:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:16:"WordCamp Atlanta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=1684";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:317:"I&#8217;m so excited to be speaking at WordCamp Atlanta this Saturday! If you haven&#8217;t got tickets, its already SOLD OUT at 450 people. WOW. If you&#8217;re in the South and you missed it, be sure to keep an eye on 2013.Birmingham.WordCamp.org for a date announcement &#38; early tickets for late summer. &#160;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:657:"<p><a href="http://2013.Atlanta.WordCamp.org"><img class="size-full wp-image-3744 alignleft" alt="WCBadge2013-Speaker" src="http://sara-cannon.com/wp-content/uploads/2013/03/WCBadge2013-Speaker.jpg" width="150" height="150" /></a>I&#8217;m so excited to be speaking at <a href="http://2013.atlanta.wordcamp.org/">WordCamp Atlanta</a> this Saturday! If you haven&#8217;t got tickets, its already SOLD OUT at 450 people. WOW. If you&#8217;re in the South and you missed it, be sure to keep an eye on <a href="http://2013.Birmingham.WordCamp.org">2013.Birmingham.WordCamp.org</a> for a date announcement &amp; early tickets for late summer.</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:83:"http://ran.ge/2013/03/12/sara-cannon-to-speak-at-wordcamp-atlanta-on-saturday/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:19:"http://ran.ge/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 12 Jan 2014 10:20:39 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";a:2:{i:0;s:15:"Accept-Encoding";i:1;s:6:"Cookie";}s:13:"cache-control";s:27:"max-age=79, must-revalidate";s:12:"x-powered-by";s:21:"PHP/5.4.23-1~dotdeb.0";s:10:"x-pingback";s:27:"http://ran.ge/wp/xmlrpc.php";s:13:"last-modified";s:29:"Thu, 05 Dec 2013 21:11:57 GMT";s:4:"etag";s:34:""b7c0bed1709eafca6398f5b2d2c4f5b5"";s:4:"node";s:20:"web11.dfw.wphost.com";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (535, 'twp', 'a:16:{s:12:"consumer-key";s:19:"jsu4vXpRoHzNdRdrsrw";s:15:"consumer-secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:8:"username";s:0:"";s:4:"list";s:0:"";s:5:"title";s:0:"";s:5:"items";s:2:"10";s:6:"avatar";s:0:"";s:6:"errmsg";s:0:"";s:6:"showts";s:5:"86400";s:10:"dateFormat";s:14:"h:i:s A F d, Y";s:12:"showretweets";s:4:"true";s:11:"hidereplies";s:5:"false";s:8:"hidefrom";s:5:"false";s:11:"showintents";s:4:"true";s:10:"showfollow";s:4:"true";s:11:"targetBlank";s:5:"false";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (541, 'twp-authed-users', 'a:1:{s:15:"ash_skywalker10";a:4:{s:11:"oauth_token";s:50:"399730397-UUaCZnrCulookeadOgPWcpkEclDv2vZ6IMw9wf8t";s:18:"oauth_token_secret";s:45:"nHgo0EzVefbEbsp5L7FoTlcXaWjSLsu6i0gGOISYFWS7f";s:7:"user_id";s:9:"399730397";s:11:"screen_name";s:15:"ash_skywalker10";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (542, 'widget_twitter', 'a:2:{i:2;a:18:{s:12:"consumer-key";s:19:"jsu4vXpRoHzNdRdrsrw";s:15:"consumer-secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:5:"title";s:0:"";s:6:"errmsg";s:0:"";s:8:"username";s:15:"ash_skywalker10";s:4:"list";s:0:"";s:13:"http_vs_https";s:5:"https";s:11:"hidereplies";s:5:"false";s:12:"showretweets";s:4:"true";s:8:"hidefrom";s:5:"false";s:11:"showintents";s:4:"true";s:10:"showfollow";s:4:"true";s:6:"avatar";s:0:"";s:15:"showXavisysLink";s:5:"false";s:11:"targetBlank";s:5:"false";s:5:"items";s:2:"10";s:6:"showts";s:5:"86400";s:10:"dateFormat";s:14:"h:i:s A F d, Y";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (543, '_transient_timeout_tlc__924771c23f8ee6bf7fb5c83b985d3e5e', '1421153712', 'no') ; 
INSERT INTO `wp_options` VALUES (544, '_transient_tlc__924771c23f8ee6bf7fb5c83b985d3e5e', 'a:2:{i:0;i:1389617712;i:1;a:1:{i:0;O:8:"stdClass":22:{s:10:"created_at";s:30:"Thu Oct 27 23:20:47 +0000 2011";s:2:"id";i:129699090836627458;s:6:"id_str";s:18:"129699090836627458";s:4:"text";s:138:"@contikiaus #contiki I\'m seeking amazing sights, fantastic architecture, absorb large amounts of history,  DELICIOUS FOOD and good friends";s:6:"source";s:118:"<a href="http://contiki.com.au/pages/1734-europe-2012-13-microsite-fortheseekers" rel="nofollow">Contiki Australia</a>";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";i:17455144;s:23:"in_reply_to_user_id_str";s:8:"17455144";s:23:"in_reply_to_screen_name";s:10:"contikiaus";s:4:"user";O:8:"stdClass":38:{s:2:"id";i:399730397;s:6:"id_str";s:9:"399730397";s:4:"name";s:8:"Andy Tan";s:11:"screen_name";s:15:"ash_skywalker10";s:8:"location";s:0:"";s:11:"description";s:0:"";s:3:"url";N;s:8:"entities";O:8:"stdClass":1:{s:11:"description";O:8:"stdClass":1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:1;s:13:"friends_count";i:0;s:12:"listed_count";i:0;s:10:"created_at";s:30:"Thu Oct 27 23:20:36 +0000 2011";s:16:"favourites_count";i:0;s:10:"utc_offset";N;s:9:"time_zone";N;s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:1;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:79:"http://abs.twimg.com/sticky/default_profile_images/default_profile_3_normal.png";s:23:"profile_image_url_https";s:80:"https://abs.twimg.com/sticky/default_profile_images/default_profile_3_normal.png";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:1;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";O:8:"stdClass":4:{s:8:"hashtags";a:1:{i:0;O:8:"stdClass":2:{s:4:"text";s:7:"contiki";s:7:"indices";a:2:{i:0;i:12;i:1;i:20;}}}s:7:"symbols";a:0:{}s:4:"urls";a:0:{}s:13:"user_mentions";a:1:{i:0;O:8:"stdClass":5:{s:11:"screen_name";s:10:"contikiaus";s:4:"name";s:17:"Contiki Australia";s:2:"id";i:17455144;s:6:"id_str";s:8:"17455144";s:7:"indices";a:2:{i:0;i:0;i:1;i:11;}}}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:4:"lang";s:2:"en";}}}', 'no') ; 
INSERT INTO `wp_options` VALUES (553, 'hupso_version', '3.9.22', 'yes') ; 
INSERT INTO `wp_options` VALUES (558, 'lightboxplus_options', 'a:57:{s:18:"lightboxplus_multi";s:1:"0";s:10:"use_inline";s:1:"0";s:10:"inline_num";s:1:"5";s:18:"lightboxplus_style";s:10:"fancypants";s:16:"use_custom_style";s:1:"0";s:11:"disable_css";s:1:"0";s:10:"hide_about";s:1:"0";s:12:"output_htmlv";s:1:"0";s:9:"data_name";s:12:"lightboxplus";s:13:"load_location";s:9:"wp_footer";s:13:"load_priority";s:2:"10";s:11:"use_perpage";s:1:"0";s:11:"use_forpage";s:1:"0";s:11:"use_forpost";s:1:"0";s:10:"transition";s:7:"elastic";s:5:"speed";s:1:"0";s:5:"width";s:0:"";s:6:"height";s:0:"";s:11:"inner_width";s:0:"";s:12:"inner_height";s:0:"";s:13:"initial_width";s:0:"";s:14:"initial_height";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:6:"resize";s:1:"0";s:7:"opacity";s:1:"0";s:10:"preloading";s:1:"0";s:11:"label_image";s:0:"";s:8:"label_of";s:0:"";s:8:"previous";s:0:"";s:4:"next";s:0:"";s:5:"close";s:0:"";s:13:"overlay_close";s:1:"0";s:9:"slideshow";s:1:"0";s:14:"slideshow_auto";s:1:"0";s:15:"slideshow_speed";s:3:"500";s:15:"slideshow_start";s:5:"start";s:14:"slideshow_stop";s:4:"stop";s:17:"use_caption_title";s:1:"0";s:20:"gallery_lightboxplus";s:1:"1";s:18:"multiple_galleries";s:1:"0";s:16:"use_class_method";s:1:"0";s:10:"class_name";s:11:"lbp_primary";s:16:"no_auto_lightbox";s:1:"0";s:10:"text_links";s:1:"0";s:16:"no_display_title";s:1:"0";s:9:"scrolling";s:1:"0";s:5:"photo";s:1:"0";s:3:"rel";s:1:"0";s:4:"loop";s:1:"0";s:7:"esc_key";s:1:"0";s:9:"arrow_key";s:1:"0";s:3:"top";s:0:"";s:6:"bottom";s:0:"";s:4:"left";s:0:"";s:5:"right";s:0:"";s:5:"fixed";s:1:"0";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (580, 'widget_black-studio-tinymce', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:4:"text";s:404:"[caption id="attachment_27" align="alignnone" width="180"]<a href="http://localhost/tigers/wp-content/uploads/2013/09/Jam.jpg"><img class=" wp-image-27 " alt="Michael Jackson and Michael Jordan" src="http://localhost/tigers/wp-content/uploads/2013/09/Jam-300x278.jpg" width="180" height="167" /></a> Michael Jackson and Michael Jordan[/caption]

Important Dates in 2013

AGM/Trophy Presentation Night";s:4:"type";s:6:"visual";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (762, '_transient_timeout_feed_mod_c809918297b2c893fd8504c06adcaf00', '1384557928', 'no') ; 
INSERT INTO `wp_options` VALUES (763, '_transient_feed_mod_c809918297b2c893fd8504c06adcaf00', '1384514728', 'no') ; 
INSERT INTO `wp_options` VALUES (861, 'wpspc_buyer_from_email', 'Gosford Junior Australian Football Club <sales@your-domain.com>', 'yes') ; 
INSERT INTO `wp_options` VALUES (862, 'wpspc_buyer_email_subj', 'Thank you for the purchase', 'yes') ; 
INSERT INTO `wp_options` VALUES (863, 'wpspc_buyer_email_body', 'Dear {first_name} {last_name}

Thank you for your purchase! You ordered the following item(s):

{product_details}', 'yes') ; 
INSERT INTO `wp_options` VALUES (849, '_transient_plugins_delete_result_1', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (860, 'wpspc_send_buyer_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (851, 'metaslider_systemcheck', 'a:2:{s:16:"wordPressVersion";b:0;s:12:"imageLibrary";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1828, '_site_transient_timeout_theme_roots', '1389791399', 'yes') ; 
INSERT INTO `wp_options` VALUES (1829, '_site_transient_theme_roots', 'a:5:{s:7:"expound";s:7:"/themes";s:4:"roar";s:7:"/themes";s:10:"tigertheme";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1713, '_transient_all_the_cool_cats', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (1611, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1388369533', 'no') ; 
INSERT INTO `wp_options` VALUES (1612, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1388326333', 'no') ; 
INSERT INTO `wp_options` VALUES (1621, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1388369534', 'no') ; 
INSERT INTO `wp_options` VALUES (1622, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WordPress.tv: Carl Danley and Eric Mann: WordPress Javascript Hooks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24095";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://wordpress.tv/2013/12/28/carl-danley-and-eric-mann-wordpress-javascript-hooks/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:689:"<div id="v-XFqEDLLE-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24095/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24095/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24095&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/28/carl-danley-and-eric-mann-wordpress-javascript-hooks/"><img alt="Carl Danley and Eric Mann: WordPress Javascript Hooks" src="http://videos.videopress.com/XFqEDLLE/video-6fd56447c5_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 28 Dec 2013 19:47:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WordPress.tv: Adam Pickering: Running A WordPress Theme Shop";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25260";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.tv/2013/12/28/adam-pickering-running-a-wordpress-theme-shop/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:669:"<div id="v-8BzQdlzS-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25260/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25260/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25260&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/28/adam-pickering-running-a-wordpress-theme-shop/"><img alt="Adam Pickering: Running A WordPress Theme Shop" src="http://videos.videopress.com/8BzQdlzS/video-f96ccb73e3_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 28 Dec 2013 19:40:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WordPress.tv: Chris Ford: Creating An Agile WordPress Design Process";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25447";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://wordpress.tv/2013/12/27/chris-ford-creating-an-agile-wordpress-design-process/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:691:"<div id="v-L6f6ZklR-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25447/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25447/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25447&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/27/chris-ford-creating-an-agile-wordpress-design-process/"><img alt="Chris Ford: Creating An Agile WordPress Design Process" src="http://videos.videopress.com/L6f6ZklR/video-6fe6a009fb_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 Dec 2013 19:24:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Alex King: Ghost and Accidental Messaging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=18996";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://alexking.org/blog/2013/12/27/ghost-and-accidental-messaging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2824:"<p>I investigate pretty much every new publishing system that comes out. I&#8217;m eager to see what features they think are important, and see what might spark new ideas for my own site. I got my invite to try <a href="https://ghost.org/">Ghost</a> a short time ago. I put up a test post, and was a shocked by what I saw in the footer.</p>
<p><img src="http://alexking.org/wp-content/uploads/2013/12/ghost-copyright-510x307.png" alt="Ghost Copyright" width="480" height="288" class="alignnone size-medium-img wp-image-18997" /></p>
<p>I&#8217;ve circled the footer area, which includes:</p>
<blockquote><p>All content copyright Ghost &copy; 2013 &middot; All rights reserved.</p></blockquote>
<p>My reaction upon seeing this? <em>Whoah &#8211; &#8220;Copyright Ghost&#8221;? I don&#8217;t think so&#8230;</em></p>
<p>I did a little poking around and found <a href="https://ghost.org/about/terms/">Ghost&#8217;s Terms of Service</a>, which are derived from the <a href="http://en.wordpress.com/tos/">WordPress.com TOS</a> and are released under a Creative Common 3.0 license. That was more like what I expected and didn&#8217;t seem to jive with what I was seeing in the footer.</p>
<p>So I did a little more searching. Pretty soon I found this:</p>
<p><img src="http://alexking.org/wp-content/uploads/2013/12/ghost-template-510x68.png" alt="Template File" width="480" height="64" class="alignnone size-medium-img wp-image-19000" /></p>
<p>In the search results, I could see that the line that was bothering me is actually a pretty reasonable bit of template language:</p>
<blockquote><p><code>All content copyright {{@blog.title}} &copy; 2013 [&hellip;]</code></p></blockquote>
<p>This was a simple matter of defaults causing accidental messaging. See when you create a blog on Ghost, the default name of the blog is &#8220;Ghost&#8221;. Then the footer is outputting the blog name (Ghost) as the copyright holder.<sup id="fnref:1"><a href="http://alexking.org/blog/topic/wordpress/feed#fn:1" rel="footnote">1</a></sup> If I had taken the time to set my blog name to &#8220;Alex King&#8221;, then the footer message would have read &#8220;copyright Alex King&#8221;. This is a case of several things coming together to say something they didn&#8217;t mean.</p>
<p>Be careful with your defaults! Your messaging is important and if you&#8217;re not careful it can say something you didn&#8217;t intend.</p>
<div class="footnotes">
<hr />
<ol>
<li id="fn:1">
I&#8217;m not a lawyer, but I believe this really isn&#8217;t an accurate copyright statement. Copyright is owned by a person or entity; the name of a blog isn&#8217;t something that can own copyright (unless it is also the name of a person or entity).&#160;<a href="http://alexking.org/blog/topic/wordpress/feed#fnref:1" rev="footnote">&#8617;</a>
</li>
</ol>
</div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 Dec 2013 18:23:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:27:"Akismet: Our 2013 In Review";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1097";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://blog.akismet.com/2013/12/27/2013-in-review/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5011:"<p>As 2013 draws to a close, we at Akismet would like to let you know just what we&#8217;ve been up to &#8212; and, of course, wish you a very happy holiday season.</p>
<p>For the abridged version, we&#8217;ve prepared a nifty infographic illustrating the year that was:</p>
<p><a href="http://akismet.files.wordpress.com/2013/12/2013-year-in-review.png"><img class="size-large wp-image-1186 aligncenter" alt="Akismet 2013 Year In Review Infographic" src="http://akismet.files.wordpress.com/2013/12/2013-year-in-review.png?w=468&h=1024" /></a></p>
<p><span id="more-1097"></span></p>
<p>We reached an incredible milestone this year in catching our <strong>100-billionth</strong> spam comment. And we&#8217;re already fast approaching our 115-billionth.</p>
<p>The levels of spam we&#8217;re seeing and catching have increased dramatically over the past year. In fact, when compared with 2012 numbers (as seen in <a href="http://blog.akismet.com/2012/12/21/a-spammy-year-in-review/">last year&#8217;s post</a>), each month in 2013 experienced an average year-over-year increase of <strong>more than 70%</strong>, as the following chart shows:</p>
<p><a href="http://akismet.files.wordpress.com/2013/12/akismet-2013-spam-totals.png"><img class="size-large wp-image-1121 aligncenter" alt="Akismet 2013 Spam Totals - Month by Month" src="http://akismet.files.wordpress.com/2013/12/akismet-2013-spam-totals.png?w=600&h=375" width="600" height="375" /></a></p>
<p>On average, we are currently catching around <strong>200 million</strong> spam comments every day, which is about <strong>80 million more</strong> than our daily average this time last year. That&#8217;s over <strong>8,000,000 per hour</strong>, or over <strong>2,000 per second</strong>. For the year, we averaged over <strong>120 million </strong>spam comments per day &#8211; a year-over-year jump of over 50 million. On December 21, we set a new record zapping <strong>245 million</strong> spam comments in just 24 hours.</p>
<p>While spam themes and schemes are always changing, knockoff fashion-goods spam (which we talked about in last year&#8217;s post) dominated 2013. Even more troubling is the rising trend of these spammers using hacked sites to deliver payloads. You may have seen these before, where links point to individual pages that include an extension (like &#8220;.asp&#8221;). We suspect that <a href="http://www.theawl.com/2013/12/the-new-spammer-panic">disenchanted SEO spammers</a> are using this strategy in response to new policies by Google. Instead of simply posting comments with links to their own sites, they&#8217;ve moved to hacking vulnerable sites and launching buffer pages. Since the launch of Google&#8217;s Penguin 2.1 back in October, we have actually seen a significant increase in daily spam averages.</p>
<p>Other themes of comment spam have certainly developed and intensified over the last 12 months (spell casters, anyone?), but these are merely blips on the radar compared to the knockoff-fashion variety. Here are some recent examples of sites that Akismet intercepted:</p>

<a href="http://blog.akismet.com/2013/12/27/2013-in-review/oakley-knockoff-spam-site/"><img width="150" height="101" src="http://akismet.files.wordpress.com/2013/12/oakley-knockoff-spam-site.png?w=150&h=101" class="attachment-thumbnail" alt="Oakley Knockoff Spam" /></a>
<a href="http://blog.akismet.com/2013/12/27/2013-in-review/nfl-jerseys-knockoff-spam-site/"><img width="150" height="96" src="http://akismet.files.wordpress.com/2013/12/nfl-jerseys-knockoff-spam-site.png?w=150&h=96" class="attachment-thumbnail" alt="NFL Jersey Knockoff Spam" /></a>
<a href="http://blog.akismet.com/2013/12/27/2013-in-review/ugg-knockoff-spam-site/"><img width="150" height="86" src="http://akismet.files.wordpress.com/2013/12/ugg-knockoff-spam-site.png?w=150&h=86" class="attachment-thumbnail" alt="Ugg Knockoff Spam" /></a>

<p>Beyond our usual spam fighting activities, we have also started reaching out to other UGC services to see where, based on our vast pool of spam data, we can help in identifying spam troubling their own communities. We hope to expand that initiative in the coming year, and include hosts in the conversation as well. In 2014 you can also expect more educational anti-spam projects (including webinars), more frequent and insightful blog content, enhanced support documentation, and an increase in developer-friendly initiatives. And, of course, even stronger spam protection.</p>
<p>A sincere Happy Holidays to you and yours,<br />
The Akismet Team <small>(Alex, Mark, Eoin, Anthony, Chris F., Valerie, Chris R., Greg, Dan, and Nick)</small></p><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1097/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1097/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.akismet.com&blog=116920&post=1097&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 Dec 2013 18:08:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Anthony";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WordPress.tv: Tomas Puig: Design And Development Trends In WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25371";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://wordpress.tv/2013/12/27/tomas-puig-design-and-development-trends-in-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:691:"<div id="v-Mqtu8rZl-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25371/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25371/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25371&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/27/tomas-puig-design-and-development-trends-in-wordpress/"><img alt="Tomas Puig: Design And Development Trends In WordPress" src="http://videos.videopress.com/Mqtu8rZl/video-eef3fef18d_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 Dec 2013 14:26:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"Alex King: Will 2014 Be the Year of WordPress Tuck-ins and Roll-ups?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:48:"http://pinboard-be8b48f1c13c5144f15df29a710eb67c";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://torquemag.io/will-2014-be-the-year-of-wordpress-tuck-ins-and-roll-ups/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:801:"<p>Most WordPress businesses are very young (<a href="http://crowdfavorite.com">Crowd Favorite</a> was one of, if not the first in 2007). As these businesses mature and realize what is needed of them to take the next steps, consolidation often looks like a saner route than continuing to build. Especially for technical founders that aren&#8217;t as interested in managing the necessary business infrastructure (I count myself in this group).</p>
<p class="threads-post-notice">This post is part of the thread: <a href="http://alexking.org/blog/thread/crowd-favorite">Crowd Favorite</a> &#8211; an ongoing story on this site. View the thread timeline for more context on this post.</p>
<p><a href="http://alexking.org/blog/2013/12/26/will-2014-be-the-year-of-wordpress-tuck-ins-and-roll-ups">#</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 26 Dec 2013 21:45:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WordPress.tv: Scott Kingsley Clark: Ermahgerd! Content Types!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24087";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://wordpress.tv/2013/12/26/scott-kingsley-clark-ermahgerd-content-types/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:675:"<div id="v-g5NH2v1v-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24087/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24087/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24087&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/26/scott-kingsley-clark-ermahgerd-content-types/"><img alt="Scott Kingsley Clark: Ermahgerd! Content Types!" src="http://videos.videopress.com/g5NH2v1v/video-2d5e47d94d_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 26 Dec 2013 14:21:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WordPress.tv: Noel Tock and Joe Hoyle: WordPress As SaaS";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24115";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.tv/2013/12/26/noel-tock-and-joe-hoyle-wordpress-as-saas/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:667:"<div id="v-ljXD0OmB-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24115/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24115/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24115&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/26/noel-tock-and-joe-hoyle-wordpress-as-saas/"><img alt="Noel Tock and Joe Hoyle: WordPress As SaaS" src="http://videos.videopress.com/ljXD0OmB/video-ca541b8d13_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 26 Dec 2013 14:03:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Matt: Christmas Jazz Music";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43248";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://ma.tt/2013/12/christmas-jazz-music/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:863:"<p>I love Christmas: the lights, the food, the music. The music part can sometimes be fraught, though. There&#8217;s so many cheesy and badly done Christmas albums out there. Fortunately my favorite genre, jazz, has actually a really impressive collection of interesting interpretations of Christmas classics.</p>
<p>Over the years I&#8217;ve curated a few of my favorites. Thanks to Spotify, one of my favorite services I discovered in 2013, it&#8217;s easy to share them with you. Here&#8217;s my Xmas Jazz playlist, including my favorite holiday arrangement of all time, Duke Ellington&#8217;s version of the Nutcracker Suite.</p>
<p></p>
<p>Remember: It&#8217;s okay to play holiday music until at least mid-January.</p>
<p>If you have any favorites you&#8217;d like me to add, send them via Spotify messages or in the comments. Merry Christmas everybody!</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 25 Dec 2013 17:54:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"WordPress.tv: Mari Kane: WordPress in 10 Steps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24401";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.tv/2013/12/25/mari-kane-wordpress-in-10-steps/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:647:"<div id="v-NT0CfMIF-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24401/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24401/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24401&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/25/mari-kane-wordpress-in-10-steps/"><img alt="Mari Kane: WordPress in 10 Steps" src="http://videos.videopress.com/NT0CfMIF/video-27674b3537_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 25 Dec 2013 13:51:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WordPress.tv: Austin Smith: Customizing The Admin Area With Fieldmanager";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24327";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:89:"http://wordpress.tv/2013/12/25/austin-smith-customizing-the-admin-area-with-fieldmanager/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:693:"<div id="v-6Iy3fsYO-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24327/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24327/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24327&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/25/austin-smith-customizing-the-admin-area-with-fieldmanager/"><img alt="Austin Smith: Customizing The Admin Area With Fieldmanager" src="http://videos.videopress.com/6Iy3fsYO/video-8d7530a3e2_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 25 Dec 2013 13:28:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WordPress.tv: Philip Arthur Moore: How To Become A WordPress Theme Developer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=26942";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://wordpress.tv/2013/12/24/philip-arthur-moore-how-to-become-a-wordpress-theme-developer/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:707:"<div id="v-2IaJzR94-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/26942/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/26942/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=26942&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/24/philip-arthur-moore-how-to-become-a-wordpress-theme-developer/"><img alt="Philip Arthur Moore: How To Become A WordPress Theme Developer" src="http://videos.videopress.com/2IaJzR94/video-71c5cbe33d_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 24 Dec 2013 23:08:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: Admin Color Schemer: The Easiest Way to Customize WordPress Admin Colors";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=13795";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://wptavern.com/admin-color-schemer-the-easiest-way-to-customize-wordpress-admin-colors";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3929:"<p>This week on the Tavern we&#8217;ve been following the trend of new plugins popping up for customizing admin color schemes. Since WordPress 3.8 was released, developers have been having fun creating tools that give WordPress users more options beyond the eight default schemes. Yesterday we featured the <a href="http://wptavern.com/create-custom-admin-color-schemes-directly-within-wordpress" target="_blank">HS Custom Admin Theme</a> plugin as one of the first plugins to take a stab at it, but the developer seems to have pulled it from the repo. </p>
<p>In the meantime, Helen Hou-Sandi, in collaboration with Mark Jaquith, released a new plugin today called <a href="http://wordpress.org/plugins/admin-color-schemer/" target="_blank">Admin Color Schemer</a> that gives you the ability to create and preview color schemes within the WordPress admin. This is by far the smoothest implementation of this feature that I&#8217;ve seen to date.</p>
<p>After you install the plugin, you&#8217;ll find a new &#8220;Admin Colors&#8221; menu under <strong>Tools</strong>. This seems a little difficult to find, but Helen <a href="https://github.com/helenhousandi/admin-color-schemer/issues/12" target="_blank">plans to add an &#8220;Edit&#8221; link</a> to the User profile page in the near future. Here&#8217;s a quick test I performed:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/admin-color-schemer.jpg" rel="prettyphoto[13795]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/admin-color-schemer.jpg" alt="admin-color-schemer" width="787" height="437" class="aligncenter size-full wp-image-13829" /></a></p>
<p>The color-picker used with this plugin provides a truly pleasant experience for exploring a full range of different hues. </p>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/color-picker.jpg" rel="prettyphoto[13795]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/color-picker.jpg" alt="color-picker" width="800" height="348" class="aligncenter size-full wp-image-13833" /></a></p>
<p>Clicking the &#8220;Preview&#8221; button will let you see your color scheme live so that you can tweak it as necessary before saving it to use.</p>
<h3>Advanced Options for Editing Admin Color Schemes</h3>
<p>While testing the plugin, I found that if you click on &#8220;Show Advanced Options&#8221;, there are an additional 30 options for editing your admin color scheme. These include the ability to color the buttons, body background, links, menu background, menu current background, checked form controls and so much more. </p>
<p>If you build websites for clients, the Admin Color Schemer provides a great option for customizing the admin to use the colors for your client&#8217;s brand. You could even go all out and try to match the colors to the front-end design. </p>
<p>One thing to note is that this plugin is a tool for the whole admin and does not provide color schemes specific to users or their profiles.  Of course this is just the first iteration and additional features may be added down the line. If you&#8217;d like to collaborate with Helen and Mark to contribute on the project, check out the plugin&#8217;s <a href="https://github.com/helenhousandi/admin-color-schemer" target="_blank">github repo</a>.</p>
<p>If you don&#8217;t trust yourself to create a decent color scheme &#8211; truly, it&#8217;s harder than it looks &#8211; you might install the <a href="http://wptavern.com/get-more-admin-color-schemes-for-wordpress-3-8" target="_blank">Admin Color Schemes</a> plugin for an assortment of eye-pleasing options. For WordPress users who are excited to try creating their own color schemes with a live preview, it looks like the <a href="http://wordpress.org/plugins/admin-color-schemer/" target="_blank">Admin Color Schemer</a> will be the front-runner plugin for providing the best solution with the most options.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 24 Dec 2013 22:18:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WPTavern: Development Agency 10up Acquires Brainstorm Media";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=13637";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://wptavern.com/development-agency-10up-acquires-brainstorm-media";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3816:"<p><a href="http://wptavern.com/wp-content/uploads/2013/12/10UpLogo.jpg" rel="prettyphoto[13637]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/10UpLogo.jpg" alt="10up Logo" width="139" height="164" class="alignright size-full wp-image-13736" /></a>Web development Agency <a title="http://10up.com/" href="http://10up.com/">10up</a> has <a href="http://10up.com/blog/brainstorm-joins-10up/" title="http://10up.com/blog/brainstorm-joins-10up/">announced</a> they have acquired <a title="http://brainstormmedia.com/" href="http://brainstormmedia.com/">Brainstorm Media</a> for an undisclosed amount. Brainstorm Media, also a WordPress development agency, was a staff of eight led by Paul Clark and Taylor Aldridge. The entire team will join 10up at the start of 2014, adding to its development capacity and strengthening the creative design arm of the company. This brings the total number of full time 10up employees to 50.</p>
<p>While Brainstorm Media may not be familiar to you, they&#8217;ve been developing websites on top of WordPress for years. Brainstorm&#8217;s team has worked with a number of high profile clients such as Larry Fitzgerald of the Arizona Cardinals and the Wall Street Journal. A few months ago, Sarah Gooding <a title="http://wptavern.com/how-to-install-wordpress-plugins-directly-from-github" href="http://wptavern.com/how-to-install-wordpress-plugins-directly-from-github">profiled a plugin</a> created by Paul Clark called <a title="https://github.com/brainstormmedia/github-plugin-search" href="https://github.com/brainstormmedia/github-plugin-search">Github Plugin Search</a> that enables users to access and install WordPress plugins directly from your dashboard.</p>
<p>However, Paul is most widely known throughout the WordPress community for his presentation on how <a title="http://pdclark.com/wordpress-saves-lives-moves-governments-lightning-talk/" href="http://pdclark.com/wordpress-saves-lives-moves-governments-lightning-talk/">WordPress Saves Lives and Moves Governments</a>. I&#8217;ve been told by those who have attended his sessions that he always receives a standing ovation.</p>
<p>This acquisition is similar to the one we <a title="http://wptavern.com/crowd-favorite-acquired-by-velomedia" href="http://wptavern.com/crowd-favorite-acquired-by-velomedia">reported on</a> in the middle of November when VeloMedia acquired Crowd Favorite. When I spoke with Jake Goldman, President of 10up, and asked him why they acquired the company, he replied:</p>
<blockquote><p>I&#8217;ve been impressed with Brainstorm since Paul, Taylor, and I met at WordCamp LA more than 2 years ago. Paul is a very unique mix of skilled software engineer, smart business leader, and inspiring speaker. Taylor&#8217;s gravitas and depth &#8211; more than two decades worth &#8211; when it comes to design is very apparent, and I&#8217;m inspired by his genuine values. Our teams share common values around contribution, quality, and work ethic, and our capacity to effectively collaborate was validated with a trial engagement. Everyone at 10up feels very lucky and excited to be joining forces with this team.</p></blockquote>
<h3>WordPress Has A Healthy Ecosystem</h3>
<p>This acquisition is a sign that the WordPress community as a whole is maturing. WordPress companies acquiring other WordPress companies is a signal that the WordPress ecosystem is healthy. Within the next 2-4 years, I think these acquisitions will be common place. The ecosystem is filled with WordPress development agencies that are one to ten person operations. Any of these development agencies that become mildly successful will most likely become an acquisition of talent more than anything else.</p>
<h3>Watch Paul Clark&#8217;s WordCamp Presentation</h3>
<div class="aligncenter"></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 24 Dec 2013 20:24:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WPTavern: WordCamp Miami to Celebrate 5th Anniversary in May 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=13775";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wptavern.com/wordcamp-miami-to-celebrate-5th-anniversary-in-may-2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4108:"<p><a href="http://wptavern.com/wp-content/uploads/2013/12/miami-header.jpg" rel="prettyphoto[13775]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/miami-header.jpg" alt="http://www.dreamstime.com/-image11969050" width="1000" height="288" class="aligncenter size-full wp-image-13779" /></a></p>
<p><a href="http://www.davidbisset.com/" target="_blank">David Bisset</a> has been organizing <a href="http://2014.miami.wordcamp.org/" target="_blank">WordCamp Miami</a> for the past five years. That&#8217;s a long time in WordPress years! WordCamp Miami will celebrate its five year anniversary May 23-25, 2014. </p>
<p>The first WordCamp Miami was held in 2010, spreading the phenomenon of WordCamps to one of the largest metropolitan areas in the US. Every single year the event has sold out and attendance has steadily increased:</p>
<ul>
<li>2010 attendance: 250 people (sold out)</li>
<li>2011 attendance: 340 people (sold out)</li>
<li>2012 attendance: 420 people (sold out)</li>
<li>2013 attendance: 500 people (sold out), 1500 unique visitors via livestream</li>
</ul>
<p>This year the team anticipates 600 &#8211; 700 attendees. Now that the official dates have been announced, they&#8217;ve opened the event up for <a href="http://2014.miami.wordcamp.org/call-for-speakers/" target="_blank">speaker submissions</a> and <a href="http://2014.miami.wordcamp.org/become-a-sponsor/" target="_blank">sponsors</a>. They&#8217;ve also put together a <a href="http://miami.wordcamp.org/" target="_blank">photo contest</a> to celebrate the 5th anniversary. Contestants are urged to take a unique WordPress or WCMIA photo and submit for a chance to win prizes from the organizers.</p>
<p>WordCamp Miami is a fantastic example of a WordPress event done right. It&#8217;s not easy to nail down why it&#8217;s been such a successful event, because so many factors come into play. Bisset says that he doesn&#8217;t have a formula for other WordCamps to follow: </p>
<blockquote><p>WordCamps are not all clones of each other, they each have their own mood and personality. For Miami, we&#8217;ve been wild and experimental in what we do to see what works well and what doesn&#8217;t. But we&#8217;ve always held in high regard that WordCamps in general should be about education, the social element, and networking. You don&#8217;t truly appreciate the WordPress community until you&#8217;re literally surrounded by people at a WordCamp or WordPress social event, and it&#8217;s something that you can&#8217;t fully pick up online.</p></blockquote>
<p>Putting together a massive event like WordCamp Miami is quite a feat, but Bisset has help from his local community. The organization committee he works with has different people to help handle various aspects of the event. The team also holds a special relationship with local people from the University of Miami LaunchPad and RefreshMiami, two local tech groups that have also pitched in to help. </p>
<p>I asked Bisset if he&#8217;ll be down for the next five years of organizing WordCamp Miami. He said he&#8217;s taking it one year at a time. &#8220;I wasn&#8217;t expecting to be planning a WordCamp for this long. So, yes definitely taking it one year at a time. I think every year I say &#8220;that&#8217;s it&#8221; but that passes after a few months.&#8221; </p>
<p>If past years are any indication, this event is bound to sell out quickly so get your tickets early if you plan to go. First time attendees are also welcome to get in on the <a href="http://miami.wordcamp.org/" target="_blank">photo contest</a> for a chance to win tickets and prizes. The event will be stocked with goodies for attendees when they arrive in May in order to say thanks to the thousands of people that have supported WordCamp Miami throughout the years. The organizers have planned an amazing after party, even more exciting than last year&#8217;s dance-off that boasted an iPad as the grand prize. <a href="http://2014.miami.wordcamp.org/" target="_blank">WordCamp Miami 2014</a> is ramping up to be the best event the team has put on so far. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 24 Dec 2013 20:13:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WordPress.tv: Rob La Gatta: Managing Support for a Premium WordPress Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24127";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://wordpress.tv/2013/12/24/rob-la-gatta-managing-support-for-a-premium-wordpress-plugin/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:705:"<div id="v-EAYGoGFs-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24127/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24127/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24127&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/24/rob-la-gatta-managing-support-for-a-premium-wordpress-plugin/"><img alt="Rob La Gatta: Managing Support for a Premium WordPress Plugin" src="http://videos.videopress.com/EAYGoGFs/video-c2fcdad95c_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 24 Dec 2013 13:12:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WordPress.tv: Media: We Are Here And Where Are We Going?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24113";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wordpress.tv/2013/12/23/media-we-are-here-and-where-are-we-going/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:666:"<div id="v-F7oFtUCY-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24113/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24113/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24113&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/23/media-we-are-here-and-where-are-we-going/"><img alt="Media: We Are Here And Where Are We Going?" src="http://videos.videopress.com/F7oFtUCY/video-4121a9b346_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Dec 2013 16:33:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"WordPress.tv: Sara Cannon: Be The Unicorn";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24093";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.tv/2013/12/23/sara-cannon-be-the-unicorn/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:637:"<div id="v-IFtiBqnk-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24093/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24093/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24093&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/23/sara-cannon-be-the-unicorn/"><img alt="Sara Cannon: Be The Unicorn" src="http://videos.videopress.com/IFtiBqnk/video-1c9ede7244_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Dec 2013 16:20:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WPTavern: Edit Flow Plugin Fixes Numerous Bugs In New Update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=13570";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wptavern.com/edit-flow-plugin-fixes-numerous-bugs-in-new-update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3302:"<p>On December 19th, an update to <a title="http://wordpress.org/plugins/edit-flow/" href="http://wordpress.org/plugins/edit-flow/">Edit Flow</a>, a popular plugin used on multi-author blogs was released. Prior to December 19th, the most recent update was on January 30th, 2013. In <a title="http://wptavern.com/edit-flow-jetpack-and-mp6" href="http://wptavern.com/edit-flow-jetpack-and-mp6">previous articles</a>, I outlined a number of issues that nearly forced me to stop using the plugin. The latest version fixes those problems and adds a few new features.</p>
<p>The <a title="http://wordpress.org/plugins/edit-flow/changelog/" href="http://wordpress.org/plugins/edit-flow/changelog/">changelog</a> for this release is a mile long but that&#8217;s a good thing. One of the most annoying bugs that has been addressed is that posts, pages, and custom post types can now be previewed correctly. This version also includes a new feature named <strong>Dashboard Notepad</strong>. The new dashboard widget provides an easy way to leave instructions or notes to other administrators or users of the site.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/EditFlowDashboardNotes.jpg" rel="prettyphoto[13570]" rel="thumbnail"><img class="aligncenter size-full wp-image-13702" alt="Edit Flow Dashboard Notes" src="http://wptavern.com/wp-content/uploads/2013/12/EditFlowDashboardNotes.jpg" width="491" height="183" /></a></p>
<p>For those that extensively use the editorial comments functionality within Edit Flow, you&#8217;ll be pleased to know that subscriptions are now saved via AJAX, which means you can add or remove subscribers without hitting &#8220;<strong>Save Post</strong>&#8220;. This release also contains updates to the Japanese and Dutch localizations. Some other notable changes include:</p>
<ul>
<li>You can now double-click to create a new post on the calendar or edit details associated with an existing post</li>
<li>Subscribe to a post&#8217;s updates using a quick &#8220;Follow&#8221; link on Manage Posts, the Calendar, or Story Budget</li>
<li>Assign a date and time to editorial metadata&#8217;s date field</li>
<li>Modify which filters are used on the calendar and story budget, or add your own</li>
<li>Scheduled publication time is now included in relevant email notifications</li>
<li>Calendar and story budget module descriptions link to their respective pages in the admin for usability.</li>
</ul>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/EditFlowIconTooDark.jpg" rel="prettyphoto[13570]" rel="thumbnail"><img class="alignright size-full wp-image-13700" alt="Edit Flow Icon Too Dark" src="http://wptavern.com/wp-content/uploads/2013/12/EditFlowIconTooDark.jpg" width="152" height="140" /></a>Since WPTavern became a multi-authored blog, Edit Flow has become an important plugin that helps manage the workflow and communication between authors. I’ve spoken to a number of people via email who love using Edit Flow. However, most of them stopped using it because of bugs and no sign of active development during 2013. One minor suggestion I have for a future update is to change the Edit Flow menu icon. It&#8217;s too hard to see when using a dark-colored admin color scheme.</p>
<p>I hope this update is a sign of great things to come.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Dec 2013 15:00:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"WPTavern: 22 Beautiful Free WordPress Themes From 2013";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=13671";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wptavern.com/22-beautiful-free-wordpress-themes-from-2013";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14619:"<p>2013 was an excellent year for finding beautiful themes in the official <a href="http://wordpress.org/themes/" target="_blank">WordPress Themes Directory</a>. The Theme Review Team has been breaking all kinds of records lately, averaging more than 80 new themes approved per month, <a href="http://make.wordpress.org/themes/2013/11/21/new-wptrt-admin-justin-tadlock/" target="_blank">according to Chip Bennett</a>. With so many themes available, it can be difficult to sort through them all to find the best ones.</p>
<p>We&#8217;ve hand-selected a few favorites from those that gained admission to the directory this year. These themes represent some of the most outstanding, well-designed themes created in 2013. Each theme has passed the Theme Review Team&#8217;s rigorous <a href="http://make.wordpress.org/themes/guidelines/" target="_blank">guidelines</a> for admission to the WordPress.org directory, so you know it&#8217;s safe to install and free from malicious code. Grab a cup of coffee and start bookmarking your favorites.<span id="more-13671"></span></p>
<h2>Snaps</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/snaps.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/snaps.png" alt="Snaps WordPress theme" width="600" height="450" class="aligncenter size-full wp-image-13686" /></a></p>
<p>Snaps is a popular portfolio theme created by the folks at <a href="http://graphpaperpress.com/themes/snaps/" target="_blank">Graph Paper Press</a>. The homepage and archives pages have a grid layout that is ideal for showcasing portrait images and galleries.</p>
<p><a href="http://wordpress.org/themes/snaps" target="_blank">View Demo &#038; Download</a></p>
<h2>Ryu</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/ryu.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/ryu.png" alt="ryu WordPress Theme" width="600" height="450" class="aligncenter size-full wp-image-13693" /></a></p>
<p>Ryu is a minimalist blogging theme from Automattic that focuses on large, readable typography. The top panel has a hidden widget area and the background of image posts automatically changes to match the colors of the image.</p>
<p><a href="http://wordpress.org/themes/ryu" target="_blank">View Demo &#038; Download</a></p>
<h2>Hueman</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/hueman.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/hueman.png" alt="Hueman WordPress Theme" width="600" height="450" class="aligncenter size-full wp-image-13695" /></a></p>
<p>Hueman is a magazine style theme that has quickly become a favorite on WordPress.org with more than 50,000 downloads already. On smaller devices the sidebars toggle for a great mobile viewing experience. This theme supports 10 post formats, has unlimited widget areas, social links and much more.</p>
<p><a href="http://wordpress.org/themes/hueman" target="_blank">View Demo &#038; Download</a></p>
<h2>WP Jurist</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/wpjurist.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/wpjurist.png" alt="WP Jurist WordPress Theme" width="600" height="450" class="aligncenter size-full wp-image-13696" /></a></p>
<p>WP Jurist is a bold, responsive theme designed for law firms. The theme is bundled with a &#8220;People&#8221; plugin for displaying staff profiles.</p>
<p><a href="http://wordpress.org/themes/wp-jurist" target="_blank">View Demo &#038; Download</a></p>
<h2>Untitled</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/untitled.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/untitled.png" alt="untitled" width="600" height="450" class="aligncenter size-full wp-image-13705" /></a></p>
<p>The Untitled theme was created by the Theme Team at Automattic and features a full-bleed homepage slider. It was designed to showcase photos and videos. Although Untitled looks best without widgets, the theme does support a right sidebar.</p>
<p><a href="http://wordpress.org/themes/untitled" target="_blank">View Demo &#038; Download</a></p>
<h2>Nictitate-free</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/Nictitate-free.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/Nictitate-free.png" alt="Nictitate-free" width="600" height="450" class="aligncenter size-full wp-image-13710" /></a></p>
<p>Nictitate is a more corporate style WordPress theme. It includes a layout manager for creating custom layout options on each page.</p>
<p><a href="http://wordpress.org/themes/nictitate-free" target="_blank">View Demo &#038; Download</a></p>
<h2>Flounder</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/flounder.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/flounder.png" alt="Flounder WordPress theme" width="600" height="450" class="aligncenter size-full wp-image-13712" /></a></p>
<p>Flounder is a flat style blogging theme with support for post formats, including color and icons for each. It&#8217;s based on the <a href="http://underscores.me/" target="_blank">Underscores</a> theme, which is used by the Theme Team at WordPress.com. </p>
<p><a href="http://wordpress.org/themes/flounder" target="_blank">View Demo &#038; Download</a></p>
<h2>Celebrate</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/celebrate.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/celebrate.png" alt="celebrate" width="600" height="450" class="aligncenter size-full wp-image-13714" /></a></p>
<p>Celebrate is built on top of the Hybrid Core framework. It features a responsive masonry layout, support for post formats and a custom header and background.</p>
<p><a href="http://wordpress.org/themes/celebrate" target="_blank">View Demo &#038; Download</a></p>
<h2>Bearded</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/bearded.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/bearded.png" alt="bearded" width="600" height="450" class="aligncenter size-full wp-image-13716" /></a></p>
<p>Bearded is a unique responsive theme that is well-suited to being used as a portfolio or an agency website. It supports the Custom Content Portfolio plugin to help you showcase your work.</p>
<p><a href="http://wordpress.org/themes/bearded" target="_blank">View Demo &#038; Download</a></p>
<h2>Serene</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/serene.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/serene.png" alt="serene" width="600" height="450" class="aligncenter size-full wp-image-13718" /></a></p>
<p>Serene is a beautiful, minimalist blogging theme created by the folks at <a href="http://www.elegantthemes.com/" target="_blank">Elegant Themes</a>. The theme supports post formats and was designed to be easy on the eyes.</p>
<p><a href="http://wordpress.org/themes/serene" target="_blank">View Demo &#038; Download</a></p>
<h2>Gridster-Lite</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/gridster.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/gridster.png" alt="gridster" width="600" height="450" class="aligncenter size-full wp-image-13720" /></a></p>
<p>Created by the folks at <a href="http://themefurnace.com/" target="_blank">Themefurnace</a>, Gridster-lite is a grid-based portfolio theme. The theme sports a left sidebar and is responsive so it looks great on all screen sizes.</p>
<p><a href="http://wordpress.org/themes/gridster-lite" target="_blank">View Demo &#038; Download</a></p>
<h2>Trvl</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/trvl.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/trvl.png" alt="trvl" width="600" height="450" class="aligncenter size-full wp-image-13722" /></a></p>
<p>Trvl is a minimalist tumblelog theme with support for eight post formats. This theme was created by Automattic. It includes a custom header, menu and widgets above the footer.</p>
<p><a href="http://wordpress.org/themes/trvl" target="_blank">View Demo &#038; Download</a></p>
<h2>Inkness</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/inkness.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/inkness.png" alt="inkness" width="600" height="450" class="aligncenter size-full wp-image-13724" /></a></p>
<p>Inkness is a responsive theme created by <a href="http://inkhive.com/product/inkness/" target="_blank">InkHive</a>. The theme features a three column homepage, multiple page layouts, configurable sidebar locations, footer widgets and more.</p>
<p><a href="http://wordpress.org/themes/inkness" target="_blank">View Demo &#038; Download</a></p>
<h2>Houston</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/houston.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/houston.png" alt="houston" width="600" height="450" class="aligncenter size-full wp-image-13726" /></a></p>
<p>Houston is a child theme for the <a href="http://wordpress.org/themes/p2" target="_blank">P2</a> blogging / collaboration theme. The layout responds nicely to devices and adds a new widget area under the posting box.</p>
<p><a href="http://wordpress.org/themes/houston" target="_blank">View Demo &#038; Download</a></p>
<h2>Writr</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/writr.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/writr.png" alt="writr" width="600" height="450" class="aligncenter size-full wp-image-13728" /></a></p>
<p>Writr is a beautiful blogging theme from Automattic. This tumblelog theme includes six different color schemes and support for all post formats.</p>
<p><a href="http://wordpress.org/themes/writr" target="_blank">View Demo &#038; Download</a></p>
<h2>Sublime Press</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/sublime.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/sublime.png" alt="sublime" width="600" height="450" class="aligncenter size-full wp-image-13730" /></a></p>
<p>Sublime is an ultra-minimalist responsive blogging theme designed for writers. This theme has a content-oriented, centered layout and it does not include any widget areas.</p>
<p><a href="http://wordpress.org/themes/sublime-press" target="_blank">View Demo &#038; Download</a></p>
<h2>Mixfolio</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/mixfolio.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/mixfolio.png" alt="mixfolio" width="600" height="450" class="aligncenter size-full wp-image-13732" /></a></p>
<p>Mixfolio is a grid-style portfolio theme developed by Graph Paper Press. The theme is responsive, supports post formats and includes an options panel for customizing details.</p>
<p><a href="http://wordpress.org/themes/mixfolio" target="_blank">View Demo &#038; Download</a></p>
<h2>Stargazer</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/stargazer.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/stargazer.png" alt="stargazer" width="600" height="450" class="aligncenter size-full wp-image-13735" /></a></p>
<p>Stargazer is a parent theme built on the Hybrid Core theme framework created by <a href="http://themehybrid.com/themes/stargazer" target="_blank">Justin Tadlock</a>. It&#8217;s fully responsive, includes a custom background, custom header and more features for customizing the design.</p>
<p><a href="http://wordpress.org/themes/stargazer" target="_blank">View Demo &#038; Download</a></p>
<h2>Asteria Lite</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/asteria.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/asteria.png" alt="asteria" width="600" height="450" class="aligncenter size-full wp-image-13739" /></a></p>
<p>Asteria Lite is a responsive theme with an eye catching slider and a narrow/wide optional layout. It includes support for custom fonts, a maintenance mode feature, three page templates, social icons and more.</p>
<p><a href="http://wordpress.org/themes/asteria-lite" target="_blank">View Demo &#038; Download</a></p>
<h2>Superhero</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/superhero.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/superhero.png" alt="superhero" width="600" height="450" class="aligncenter size-full wp-image-13742" /></a></p>
<p>Superhero is another theme from Automattic. It features a sticky/fixed top menu, full-bleed featured Content area and images and subtle CSS3 transitions.</p>
<p><a href="http://wordpress.org/themes/superhero" target="_blank">View Demo &#038; Download</a></p>
<h2>Adamos</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/adamos.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/adamos.png" alt="adamos" width="600" height="450" class="aligncenter size-full wp-image-13748" /></a></p>
<p>Adamos is a responsive theme that features a full-width slider. It includes an easy way to add your logo, custom header, featured areas and more.</p>
<p><a href="http://wordpress.org/themes/adamos" target="_blank">View Demo &#038; Download</a></p>
<h2>Twenty Fourteen</h2>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/twentyfourteen.png" rel="prettyphoto[13671]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/twentyfourteen.png" alt="twentyfourteen" width="880" height="660" class="aligncenter size-full wp-image-13752" /></a></p>
<p>Twenty Fourteen is the latest default theme for WordPress. This theme features a magazine style layout with featured content areas arranged in a grid or a slider. Customize the theme with three different widget areas, a full-width page template and a nicely designed contributor page.</p>
<p><a href="http://wordpress.org/themes/twentyfourteen" target="_blank">View Demo &#038; Download</a></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Dec 2013 13:03:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: Create Custom Admin Color Schemes Directly Within WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=13646";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wptavern.com/create-custom-admin-color-schemes-directly-within-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2480:"<p>The new WordPress admin design released in 3.8 was created in such a way that it&#8217;s easy for developers to extend the feature and write their own color schemes. But for your average user who doesn&#8217;t know how to work with Sass, creating color schemes is probably not going to happen. Fortunately, someone has created a plugin that makes custom admin color schemes available to everyone.</p>
<p><a href="http://wordpress.org/plugins/hs-custom-admin-themes/" target="_blank">HS Custom Admin Theme</a> is a new free plugin that lets you create your own admin color schemes in its settings panel via a user-friendly color picker. Up until now, the only way to get alternative color schemes was to <a href="http://wptavern.com/get-more-admin-color-schemes-for-wordpress-3-8" target="_blank">use a plugin</a> or go through the process of <a href="http://mattcromwell.com/create-custom-wordpress-admin-color-scheme/" target="_blank">rolling your own</a>.</p>
<p>The HS Custom Admin Theme plugin makes it easy to design your own color palettes for the WordPress admin area, without knowing any CSS. Here&#8217;s an example of a custom color scheme I created on a test site:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/customcolors.png" rel="prettyphoto[13646]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/customcolors.png" alt="customcolors" width="900" height="654" class="aligncenter size-full wp-image-13649" /></a></p>
<p>The plugin records all of the color schemes you create and test so that you can always return to one made previously. You can essentially create a library of your favorite color palettes and change the admin according to your mood. </p>
<h3>A few suggestions</h3>
<p>There are a few things I would change about how this plugin works. The most important one is the non-native placement of its settings panel. I would prefer the plugin placed its settings under the &#8220;Edit My Profile&#8221; screen where users are already trained to look for admin color schemes. It would also be really cool if each color selection updated live while editing. Other than that, the plugin works well for allowing users to make their own color selections and store them as a custom theme.</p>
<p><a href="http://wordpress.org/plugins/hs-custom-admin-themes/" target="_blank">HS Custom Admin Theme</a> is the first plugin of its kind, but I anticipate there will be many more like it hitting the repository soon. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Dec 2013 11:03:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:97:"WordPress.tv: Kurt Hansen: Are You Nuts? You Want People to Pay You to Create WordPress Websites?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=23004";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:112:"http://wordpress.tv/2013/12/22/kurt-hansen-are-you-nuts-you-want-people-to-pay-you-to-create-wordpress-websites/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:747:"<div id="v-z1tXyrxw-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/23004/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/23004/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=23004&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/22/kurt-hansen-are-you-nuts-you-want-people-to-pay-you-to-create-wordpress-websites/"><img alt="Kurt Hansen: Are You Nuts? You Want People to Pay You to Create WordPress Websites?" src="http://videos.videopress.com/z1tXyrxw/video-3bdb195f6b_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 22 Dec 2013 16:11:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:87:"WordPress.tv: D’nelle Dowis: Intermediate Intro To WordPress: Images, Widgets, Themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24558";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://wordpress.tv/2013/12/22/dnelle-dowis-intermediate-intro-to-wordpress-images-widgets-themes/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:717:"<div id="v-6tqXpSEq-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24558/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24558/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24558&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/22/dnelle-dowis-intermediate-intro-to-wordpress-images-widgets-themes/"><img alt="D’nelle Dowis: Intermediate Intro To WordPress: Images, Widgets, Themes" src="http://videos.videopress.com/6tqXpSEq/video-a408eb6cbb_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 22 Dec 2013 16:09:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"Alex King: Spam Comment Generator Script";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=18969";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://alexking.org/blog/2013/12/22/spam-comment-generator-script";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:360:"<p>Someone recently posted the entire contents of their SPAM comment generator script into my comments; I assume by mistake. It&#8217;s pretty interesting to look at. It appears that each line is a different comment with replacement clauses that would be randomly selected.</p>
<p><p>View the code on <a href="https://gist.github.com/8084666">Gist</a>.</p></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 22 Dec 2013 16:09:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"Alex King: CF Colors v 2.1, Post Formats Admin UI v1.3.1, and Social v2.10";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=18966";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://alexking.org/blog/2013/12/21/cf-colors-post-formats-admin-ui-social-updated";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:852:"<p>We&#8217;ve updated our <a href="http://crowdfavorite.com/blog/2013/12/cf-colors-v2-1/">CF Colors</a> and <a href="http://crowdfavorite.com/blog/2013/12/post-formats-admin-ui-v1-3-1/">Post Formats Admin UI</a> WordPress developer libraries to be compatible with the admin UI refresh in WordPress 3.8.</p>
<p>We&#8217;ve also update the <a href="http://wordpress.org/plugins/social/">Social plugin</a> to address a change in the comment walker class in WordPress 3.8 (comments are shown as threaded again) as well as updates for the admin UI refresh.</p>
<p>Enjoy!</p>
<p class="threads-post-notice">This post is part of the following projects: <a href="http://alexking.org/project/post-formats-admin-ui">Post Formats Admin UI</a>, <a href="http://alexking.org/project/social">Social</a>. View the project timelines for more context on this post.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 21 Dec 2013 23:51:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WordPress.tv: Advanced WordPress San Diego Meetup";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=22836";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wordpress.tv/2013/12/21/advanced-wordpress-san-diego-meetup/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:648:"<div id="v-jgZTG6Pt-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/22836/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/22836/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=22836&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/21/advanced-wordpress-san-diego-meetup/"><img alt="Advanced WordPress San Diego Meetup" src="http://videos.videopress.com/jgZTG6Pt/video-e1994aeca0_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 21 Dec 2013 23:02:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:100:"WordPress.tv: Jimba Tamang: 5 Reasons Why “Parallax Websites” Are Awesome And How To Create Them";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=26856";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:111:"http://wordpress.tv/2013/12/21/jimba-tamang-5-reasons-why-parallax-websites-are-awesome-and-how-to-create-them/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:775:"<div id="v-RHgeiQpm-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/26856/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/26856/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=26856&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/21/jimba-tamang-5-reasons-why-parallax-websites-are-awesome-and-how-to-create-them/"><img alt="Jimba Tamang: 5 reJimba Tamang: 5 Reasons Why &#8220;Parallax Websites&#8221; Are Awesome And How To Create Them" src="http://videos.videopress.com/RHgeiQpm/video-06112df7ae_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 21 Dec 2013 14:16:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: WPWeekly Episode 132 – Not The Kris Kringle Of WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wptavern.com?p=13639&preview_id=13639";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wptavern.com/wpweekly-episode-132-not-the-kris-kringle-of-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2307:"<p><a href="http://www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2.jpg" rel="prettyphoto[13639]" rel="thumbnail"><img src="http://www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2-150x150.jpg" alt="WordPress Weekly Cover Art" width="150" height="150" class="alignright size-thumbnail wp-image-8715" /></a> In this information packed episode of WordPress Weekly, we were joined by <a href="http://chrislema.com/" title="http://chrislema.com/">Chris Lema</a>. We discussed a number of topics on the show including the headlines of the week, WordPress in the enterprise, contributing to WordPress, approachable WordPress, and last but not least, whether Chris was actually the Kris Kringle of WordPress. We had a blast interviewing Chris Lema and I think there are more than a few nuggets of wisdom to take away from this episode. </p>
<h2>Stories Discussed:</h2>
<p><a href="http://wptavern.com/wptavern-gets-responsive-with-new-design" title="http://wptavern.com/wptavern-gets-responsive-with-new-design">WPTavern Gets Redesigned</a><br />
<a href="http://wptavern.com/buddypress-1-9-sammy-released-with-new-notifications-component" title="http://wptavern.com/buddypress-1-9-sammy-released-with-new-notifications-component">BuddyPress 1.9 Released</a><br />
<a href="http://wptavern.com/jetpack-is-now-available-on-github" title="http://wptavern.com/jetpack-is-now-available-on-github">Jetpack Now On Github</a><br />
<a href="http://wptavern.com/10-great-gift-ideas-for-wordpress-geeks" title="http://wptavern.com/10-great-gift-ideas-for-wordpress-geeks">10 Great Gift Ideas for WordPress Geeks</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, January 3rd 3 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #132:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 21 Dec 2013 08:37:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WPTavern: Planning For Upcoming WordCamps in 2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=13622";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wptavern.com/planning-for-upcoming-wordcamps-in-2014";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2947:"<div id="attachment_13628" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2013/12/wcsf.jpg" rel="prettyphoto[13622]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/wcsf.jpg" alt="WordCamp San Francisco" width="1300" height="479" class="size-full wp-image-13628" /></a><p class="wp-caption-text">photo credit: <a href="https://ma.tt/2013/07/wordcamp-san-francisco-2013/wordcamp-san-francisco-crowd/">matt mullenweg</a></p></div>
<p>We&#8217;re entering the time of year when everyone opens their calendars and starts planning for the new year. The dates for WordCamp San Francisco 2014 were just announced this week to be set for October 25-26. The dates and times for pre and post-WordCamp events have not yet been decided, so the organizers urge you to hold off booking non-refundable travel until the full schedule is announced. Follow  <a href="http://twitter.com/wordcampsf" target="_blank">@wordcampsf</a> on Twitter for all the latest updates on the event.</p>
<h3>The List of Upcoming WordCamps is Growing</h3>
<p>In addition to WordCamp San Francisco, Andrea Middleton <a href="http://make.wordpress.org/community/2013/12/19/wordcamps-update-december-19-2013/" target="_blank">posted</a> on the make.wordpress.org Community blog that dates have been published for seven upcoming WordCamps, including Dayton, Asheville, Miami, Atlanta, Norway, Prague, and St. Louis.  These dates for <a href="http://central.wordcamp.org/" target="_blank">upcoming events</a> can be found on the <a href="http://central.wordcamp.org/" target="_blank">WordCamp Central</a> site, along with links to the websites for each event. Middleton also noted that five WordCamps have now been added to the pre-planning list: Connecticut, Nashville, Hamburg, Netherlands, and Slovakia. Hopefully that information will help you to plan your travels, especially if you intend to go to multiple events in 2014.</p>
<p>If you can&#8217;t see yourself getting out to a WordCamp this next year, the next best thing is to <a href="http://wptavern.com/monitor-wordcamps-online-with-wp-armchair" target="_blank">monitor the camps online with WP Armchair</a> or catch up on presentations via <a href="http://wordpress.tv/" target="_blank">WordPress.tv</a>. 151 WordCamp presentation videos have recently been published to the site, which is quickly becoming a massive library of WordPress-related videos. </p>
<h3>Buy Tickets Early</h3>
<p>If you&#8217;re a WordPress fan who has never been to a WordCamp, here&#8217;s a bit of advice: Buy tickets to the event as soon as you commit to go. During 2013 many WordCamps sold out far in advance of the event. If you&#8217;re intent on attending a certain event, grab those tickets and plan your travel early. Expect to get addicted. Connecting with other WordPress fans is an exciting experience that never gets old. </p>
<p>Which WordCamps will you be attending in 2014?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 21 Dec 2013 00:38:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:75:"WordPress.tv: Paul Tela: Keeping WordPress Under [Version] Control With Git";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=27525";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://wordpress.tv/2013/12/20/paul-tela-keeping-wordpress-under-version-control-with-git/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:703:"<div id="v-UD5M2W6b-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/27525/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/27525/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=27525&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/20/paul-tela-keeping-wordpress-under-version-control-with-git/"><img alt="Paul Tela: Keeping WordPress Under [Version] Control With Git" src="http://videos.videopress.com/UD5M2W6b/video-ff607b3c88_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 20 Dec 2013 23:51:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: An Alternative Admin Interface for WordPress 3.8";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=13572";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wptavern.com/an-alternative-admin-interface-for-wordpress-3-8";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4821:"<p>By and large, most WordPress users are in love with the new admin interface. However, there are some who have been resistant to the changes in the design, as evidenced by the creation of the <a href="http://wordpress.org/plugins/wp-admin-classic/" target="_blank">wp-admin classic</a>, a plugin that actually goes so far as to conjure up the old, unresponsive admin from the dead. While I find this kind of resistance perplexing, given the overwhelmingly positive reaction to WordPress 3.8&#8242;s new design, it&#8217;s interesting to examine where opponents are coming from. </p>
<h3>Go ahead and paint the walls</h3>
<div id="attachment_13592" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2013/12/paint.jpg" rel="prettyphoto[13572]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/paint.jpg" alt="photo credit: spo0nman - cc" width="1024" height="406" class="size-full wp-image-13592" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/pankaj/2774373164/">spo0nman</a> &#8211; <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a></p></div>
<p>The fact that you can do anything you want to customize the frontend and the backend is why so many people enjoy WordPress in the first place. So if you want to make a plugin that removes the new admin design or changes it in some way to suit your needs, by all means, go for it! Add <a href="http://wptavern.com/get-more-admin-color-schemes-for-wordpress-3-8" target="_blank">more color schemes</a> to WordPress 3.8, <a href="http://wordpress.org/plugins/grey-admin-color-schemes/" target="_blank">make the admin 50 shades of grey</a>, or <a href="http://wordpress.org/plugins/wp-admin-classic/" target="_blank">nuke it</a> entirely and go back to the old admin design. If a different style of backend inspires you to publish great content, do whatever it takes. </p>
<h3>Avenue Factory&#8217;s Alternative Admin Interface</h3>
<p>WordPress designer and developer <a href="http://www.avenuefactory.com/" target="_blank">Haseeb Qureshi</a> created a plugin  called <a href="http://wordpress.org/plugins/admin-interface-by-avenue-factory/" target="_blank">Admin Interface by Avenue Factory</a> that he claims <strong>&#8220;restores visual balance and tactility to WordPress 3.8.&#8221;</strong> Although he sees the admin design as a giant leap forward, Quereshi says, &#8220;It appears to be chaotic and with no balance, right out of the box.&#8221;</p>
<p>His plugin loads a <a href="http://plugins.svn.wordpress.org/admin-interface-by-avenue-factory/trunk/av-assets/av-admin-interface.css" target="_blank">CSS file</a> to override some of the styles in the new WordPress admin. Qureshi&#8217;s changes address his main concern: &#8220;Looking at WordPress 3.8 now, it just seems that the sidebar, widefat table elements, and the general type size are fighting for attention.&#8221; </p>
<p>Can you spot the differences in the screenshot below? The plugin adds a more tactile view to the sidebar and makes some subtle changes in typography and spacing. </p>
<div id="attachment_13579" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2013/12/admin-interface-avenue-factory.png" rel="prettyphoto[13572]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/admin-interface-avenue-factory.png" alt="Admin Interface by Avenue Factory" width="491" height="575" class="size-full wp-image-13579" /></a><p class="wp-caption-text">Admin Interface by Avenue Factory</p></div>
<p>His plugin also makes some broad stroke changes to the <em>.widefat</em> class, as you can see on the posts screen:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/posts-screen.png" rel="prettyphoto[13572]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/posts-screen.png" alt="posts-screen" width="770" height="540" class="aligncenter size-full wp-image-13596" /></a></p>
<p>If you&#8217;ve had similar thoughts about the new admin design, the <a href="http://wordpress.org/plugins/admin-interface-by-avenue-factory/" target="_blank">Admin Interface by Avenue Factory</a> might be an option to explore for housing some of your own custom tweaks. </p>
<p>Even if you don&#8217;t think that the WordPress admin needs a more tactile appearance, it&#8217;s cool to see the freedom designers and developers have to make changes with just a simple CSS file. Since millions of people are using WordPress, it&#8217;s likely that more alternatives to the admin design will pop up. Personally, I prefer the default interface as it currently ships with 3.8, but not everyone perceives colors, space and balance in the same way. We&#8217;re lucky that with WordPress you&#8217;re never locked into the default.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 20 Dec 2013 22:10:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WordPress.tv: Connie Oswald Stofko: How To Get Ideas For Blog Posts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25309";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://wordpress.tv/2013/12/20/connie-oswald-stofko-how-to-get-ideas-for-blog-posts/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:683:"<div id="v-2jCPUXXK-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25309/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25309/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25309&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/20/connie-oswald-stofko-how-to-get-ideas-for-blog-posts/"><img alt="Connie Oswald Stofko: How To Get Ideas For Blog Posts" src="http://videos.videopress.com/2jCPUXXK/video-31666eb4e2_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 20 Dec 2013 20:00:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WPTavern: How to Use Ghostery to Find Trackers Added by WordPress Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=13386";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://wptavern.com/how-to-use-ghostery-to-find-trackers-added-by-wordpress-plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5791:"<div id="attachment_13548" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2013/12/nazgul.jpg" rel="prettyphoto[13386]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/nazgul.jpg" alt="photo credit: CosContopia" width="1024" height="507" class="size-full wp-image-13548" /></a><p class="wp-caption-text">photo credit: <a href="http://coscontopia.com/?attachment_id=6274" target="_blank">CosContopia</a></p></div>
<p>A few days ago, Jeff wrote a <a href="http://wptavern.com/wordpress-plugin-authors-be-up-front-and-honest-with-users-about-tracking" target="_blank">post</a> encouraging WordPress plugin developers to be more transparent about trackers they apply to your website via their extensions. He referenced Pooria Asteraky&#8217;s <a href="http://pooriast.wordpress.com/2013/12/15/trackers-wordpress-plugin/" target="_blank">discovery</a> that a social sharing plugin had applied 13 trackers on a vanilla installation. This is no surprise, really, as a site owner installs social sharing plugins with the express purpose of sending information out from the website via Javascript or some other means.</p>
<p>Otto left a <a href="http://pooriast.wordpress.com/2013/12/15/trackers-wordpress-plugin/comment-page-1/#comment-1384" target="_blank">comment</a> on the original post, clarifying which trackers might indeed be harmful or unwanted. He said, <span class="pullquote alignleft">&#8220;Our primary concern in this regard would be plugins that do things without the consent or without the knowledge of the website owner.&#8221;</span> This is an important distinction to make, as many trackers perform a welcome and valuable service, such as Jetpack stats, Gravatar or Google Analytics. The trackers you want to hunt down are those that collect information about users or activities on the site without consent.<span id="more-13386"></span></p>
<h3>Let&#8217;s hunt trackers!</h3>
<p>Since plugin authors may not always be transparent about what kinds of trackers their plugins install, especially if they&#8217;re not hosted on WordPress.org, site owners need some way to sniff these out. That&#8217;s where a free tool like <a href="http://www.ghostery.com/" target="_blank">Ghostery</a> comes in handy for finding out what services might be communicating to and from a website. It operates as a browser extension and there are versions available for Firefox, Opera, Safari, IE, iOS and Firefox for Android.</p>
<p>Here&#8217;s an example of what it looks like when I installed it to Chrome, which was painless and instant.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/ghostery-chrome.png" rel="prettyphoto[13386]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/ghostery-chrome.png" alt="ghostery-chrome" width="453" height="202" class="aligncenter size-full wp-image-13499" /></a></p>
<p>Once installed, the extension looks for third-party page elements (or &#8220;trackers&#8221;) on the web pages you visit and displays them in the corner of your browser. It verifies these trackers against Ghostery&#8217;s extensive library of more than  1,700 trackers and 3,400 tracking patterns, including beacons, advertisements, analytics services, page widgets, and other third-party page elements.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/ghostery-in-action.png" rel="prettyphoto[13386]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/ghostery-in-action.png" alt="ghostery-in-action" width="594" height="193" class="aligncenter size-full wp-image-13501" /></a></p>
<h3>Get the Details Behind the Trackers</h3>
<p>If you suspect that a plugin might be &#8220;phoning home&#8221; from your website, inserting ads or invisible pixels for tracking, Ghostery gives you a quick way to track down the tracker and find out who is behind it. It&#8217;s not just for use on your own website &#8211; you can check out other sites as well. Here&#8217;s a quick example run on a WordPress.org plugin page:</p>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/trackers1.jpg" rel="prettyphoto[13386]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/trackers1.jpg" alt="trackers" width="682" height="499" class="aligncenter size-full wp-image-13557" /></a></p>
<p>You can click on each individual tracker to see the URL and find out more information. For the most part, you&#8217;ll see a harmless list like the one above. The Ghostery tool comes in handy if you feel that you may have been hacked or have noticed some suspicious activity on your site. The information Ghostery provides will help you to investigate your plugins and/or themes to find the culprit. It&#8217;s also useful for inspecting other sites for a small window into their third-party connections.</p>
<h3>Block Unwanted Trackers</h3>
<p>Ghostery also lets visitors block trackers based on the type of function they perform or on an individual basis. This is particularly useful if you want to block trackers that violate your privacy by collecting your behavioral data.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/block.png" rel="prettyphoto[13386]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/block.png" alt="block" width="787" height="434" class="aligncenter size-full wp-image-13505" /></a></p>
<p>The ultimate goal here is to use <a href="http://www.ghostery.com/" target="_blank">Ghostery</a> to find more information about invisible trackers and control your privacy online. Though it has a broad use outside of WordPress, Ghostery provides a first line of defense for finding plugins that &#8220;phone home&#8221; and using that knowledge to disable them and report on their activities.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 19 Dec 2013 21:26:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WPTavern: Edit Posts From Within The Preview Screen With Post Customizer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wptavern.com/?p=13533";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wptavern.com/edit-posts-from-within-the-preview-screen-with-post-customizer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6803:"<p>There are all sorts of frontend editors being created for WordPress. We&#8217;ve already covered <a title="http://wptavern.com/barley-for-wordpress-a-revolutionary-inline-content-editor" href="http://wptavern.com/barley-for-wordpress-a-revolutionary-inline-content-editor">Barley</a>, <a title="http://wptavern.com/an-interesting-concept-for-front-end-editing-inline-access" href="http://wptavern.com/an-interesting-concept-for-front-end-editing-inline-access">Inline Access</a>, and <a title="http://wptavern.com/prettypress-plugin-reinvents-wordpress-post-editing-with-live-preview" href="http://wptavern.com/prettypress-plugin-reinvents-wordpress-post-editing-with-live-preview">PrettyPress</a>. Each plugin takes a different approach to solving the problem.</p>
<p><a title="http://wordpress.org/plugins/post-customizer/" href="http://wordpress.org/plugins/post-customizer/">Post Customizer</a>, developed by <a title="http://profiles.wordpress.org/10up/" href="http://profiles.wordpress.org/10up/">10up</a> continues the trend of taking a different approach to solving the problem of live editing. Post Customizer works in a similar fashion to the theme customizer. When a user previews a page or a post, an interface is loaded that looks just like the theme customizer. From this interface, you can edit the post excerpt, post thumbnail, save changes to the post or close the interface without saving. Selecting text within the post displays a simple editor that makes it easy to style words, apply unordered lists etc.</p>
<div id="attachment_13538" class="wp-caption aligncenter"><a href="http://wptavern.com/wp-content/uploads/2013/12/PostCustomizer.jpg" rel="prettyphoto[13533]" rel="thumbnail"><img class="size-large wp-image-13538" alt="Customizing a post" src="http://wptavern.com/wp-content/uploads/2013/12/PostCustomizer-500x166.jpg" width="500" height="166" /></a><p class="wp-caption-text">Simple editor to edit posts</p></div>
<h3>Idea Turned Into Reality</h3>
<p>I got in touch with John James Jacoby, one of several developers for the plugin (along with Carl Danley, John Bloch, Taylor Lovett, and Drew Jaynes). I found out why the plugin was created, the decision to use the customizer interface and whether or not this is just a prototype or something they want people to use on a routine basis.</p>
<p><strong>Tavern</strong> &#8211; <em>Is this plugin a prototype of an idea to edit posts or does 10up plan on improving the plugin? Does 10up want people to use it?</em></p>
<p><strong>JJJ</strong> &#8211; Both! It was an idea I&#8217;ve had in my head for a while, and we threw it together at our company meetup and then it sat mostly unloved for a few months. We spent a few hours getting it to a workable state, and open sourced it for improvements and feedback. We actually built the majority of it over the course of two evenings, just hacking together and rapidly prototyping.</p>
<p><strong>Tavern</strong> &#8211; <em>When it comes to the post customizer, does it not make sense to be able to have the category and tags be editable from within the customizer? At that point, you&#8217;re sort of substituting the post writing screen although you don&#8217;t see the customizing interface until after you hit preview.</em></p>
<p><strong>JJJ</strong> &#8211; Sure. Pretty much any metabox is game for inclusion. We specifically wanted to provide an interface for editing post content after the original post was written. We’d like to work <strong>Revisions</strong> into the sidebar, so authors can scroll through updates live.</p>
<h3>Nice Idea But Needs A Lot Of Elbow Grease</h3>
<p>While the idea is great, the implementation and experience needs to be improved before users can feel comfortable with using this plugin. Here are some things I noticed.</p>
<p><strong>Update Or Save</strong> &#8211; The theme customizer that the interface is based on does not feel natural when editing posts. When editing themes, I realize an update will save the changes I made to the theme. For posts however, I&#8217;m used to clicking a save button. While the update button does the same thing, it just doesn&#8217;t seem right.</p>
<p><strong>Exiting The Interface</strong> &#8211; I&#8217;m used to closing interfaces with an X on the top right portion of the screen. Despite the post customizer using a familiar layout, I keep looking to the right of the screen for a way to close the editing panel. It&#8217;s as simple as clicking the close button but I&#8217;m always looking somewhere else to get out of the editing interface.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/PostCustomizerExiting.jpg" rel="prettyphoto[13533]" rel="thumbnail"><img class="aligncenter size-large wp-image-13542" alt="Exiting The Post Customizer" src="http://wptavern.com/wp-content/uploads/2013/12/PostCustomizerExiting-500x189.jpg" width="500" height="189" /></a></p>
<p>It&#8217;s also weird that upon closing the editing panel, I&#8217;m taken back to the WordPress editing screen that&#8217;s missing the right sidebar. It&#8217;s here that I have to click an X to completely close the editing interface. Clicking close and then the X feels redundant. I&#8217;d rather see the close button take the role of doing both tasks and returning me to the normal editing panel without any additional steps.</p>
<p><strong>Editor Toolbar Sticks To The Top Of The Post</strong> &#8211; When the editing toolbar is enabled, it sticks to the top of the page. While I could use keyboard shortcuts, I&#8217;d rather see the editor appear above the text I&#8217;m highlighting so I don&#8217;t have to scroll or move my mouse so much. When the edited text is not highlighted, the toolbar should disappear.</p>
<p><strong>Excerpts Reload The Entire Page</strong> &#8211; The first time you try to edit the excerpt in the sidebar, it reloads the entire page along with the interface. I found this to be a jarring experience and would like to see the excerpt loaded without having to reload the entire page.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/PostCustomizerExcerpts.jpg" rel="prettyphoto[13533]" rel="thumbnail"><img class="aligncenter size-full wp-image-13541" alt="PostCustomizer Excerpts" src="http://wptavern.com/wp-content/uploads/2013/12/PostCustomizerExcerpts.jpg" width="297" height="305" /></a></p>
<h3>Interesting Take On The Post Editing Idea</h3>
<p>I never would have thought that the theme customizer interface could be used to edit posts. Post Customizer proves the idea has merit. It will be interesting to see how this plugin evolves over time. If you&#8217;re interested in contributing back to the plugin, you can <a title="https://github.com/10up/Post-Customizer" href="https://github.com/10up/Post-Customizer">fork it on Github</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 19 Dec 2013 19:44:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WordPress.tv: Charlie Craine: SEO Beyond Beginner";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25317";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.tv/2013/12/19/charlie-craine-seo-beyond-beginner/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:653:"<div id="v-y0tC0AZk-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25317/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25317/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25317&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/19/charlie-craine-seo-beyond-beginner/"><img alt="Charlie Craine: SEO Beyond Beginner" src="http://videos.videopress.com/y0tC0AZk/video-83e037952d_scruberthumbnail_2.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 19 Dec 2013 19:41:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:97:"WordPress.tv: Jordan Quintal: WordPress Accessibility – Building Websites That Everyone Can Use";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=26850";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:110:"http://wordpress.tv/2013/12/19/jordan-quintal-wordpress-accessibility-building-websites-that-everyone-can-use/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:739:"<div id="v-asU7f4NH-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/26850/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/26850/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=26850&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/19/jordan-quintal-wordpress-accessibility-building-websites-that-everyone-can-use/"><img alt="Jordan Quintal: WordPress Accessibility – Building Websites That Everyone Can Use" src="http://videos.videopress.com/asU7f4NH/video-499c5b9464_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 19 Dec 2013 16:40:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WPTavern: Romangie: A Free Responsive WordPress Theme Based on Bootstrap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=13312";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:89:"http://wptavern.com/romangie-a-free-responsive-wordpress-theme-based-on-twitter-bootstrap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3021:"<p>WordPress themes that integrate well-known front-end frameworks, such as <a href="http://getbootstrap.com/" target="_blank">Twitter Bootstrap</a> and <a href="http://wptavern.com/10-free-wordpress-themes-based-on-the-foundation-framework" target="_blank">Foundation</a>, offer a full range of UI tools to help users quickly customize their websites. Not having to style a ton of UI components can be quite liberating when creating a new site, especially when you combine that with the publishing power of WordPress.</p>
<p><a href="http://wordpress.org/themes/romangie" target="_blank">Romangie</a> is a new theme in the WordPress Theme Directory and is one of only a handful to support the latest <a href="http://wptavern.com/ http://blog.getbootstrap.com/2013/08/19/bootstrap-3-released/" target="_blank">Bootstrap 3</a> release. The theme is fully responsive and, although it is based on Bootstrap, it&#8217;s not heavy-handed with the styling, nor does it look like your typical Bootstrap site.</p>
<p><a href="http://wptavern.com/wp-content/uploads/2013/12/romangie.png" rel="prettyphoto[13312]" rel="thumbnail"><img src="http://wptavern.com/wp-content/uploads/2013/12/romangie.png" alt="romangie" width="905" height="884" class="aligncenter size-full wp-image-13516" /></a></p>
<p>Romangie was created to have a simple design with a focus on content and performance. The theme supports all the WordPress post formats out of the box and includes styles for videos, music, chat, logs, quotes, galleries,  etc.<span id="more-13312"></span></p>
<p>In addition to its responsive design, Romangie is also retina ready, which means it will look great on small devices and larger formats, all the way up to 27&#8243; Full HD displays. The theme uses scalable fonts as icons, instead of jpg images, so it won&#8217;t go blurry on high definition displays. </p>
<h4>Romangie features at a glance:</h4>
<ul>
<li>Built with Bootstrap 3 at its base</li>
<li>Retina ready</li>
<li>Includes full width page template</li>
<li>Fully styled post formats</li>
<li>Sidebar and multiple footer widget areas</li>
</ul>
<p>View a <a href="http://themes.tobscore.com/romangie/demo/" target="_blank">live demo</a> to see it in action. </p>
<p>Because Romangie is built on Bootstrap 3, you&#8217;ll be able to take advantage of all the new features of the framework, including the improved grid system, Glyphicons, new panels and list group components, a mobile-first design approach and much more. </p>
<p>A lot of work has gone into this theme to ensure a modern browsing experience for users on all devices. If you want to combine WordPress with all that Bootstrap 3 has to offer, this theme is a great starting place.</p>
<p>You can download <a href="http://wordpress.org/themes/romangie" target="_blank">Romangie</a> for free through your WordPress themes panel. For more information or to contact the theme&#8217;s developer, visit the <a href="http://themes.tobscore.com/romangie/" target="_blank">Romangie theme homepage</a>. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 19 Dec 2013 11:15:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: I Contributed To The Core Of WordPress and You Can Too";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=13159";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wptavern.com/i-contributed-to-the-core-of-wordpress-and-you-can-too";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6885:"<p><a href="http://www.wptavern.com/wp-content/uploads/2013/12/WordPress38Contributors.jpg" rel="prettyphoto[13159]" rel="thumbnail"><img src="http://www.wptavern.com/wp-content/uploads/2013/12/WordPress38Contributors.jpg" alt="WordPress 3.8 Contributors" width="258" height="139" class="alignright size-full wp-image-13495" /></a>WordPress 3.8 <a title="http://wordpress.org/news/2013/12/parker/" href="http://wordpress.org/news/2013/12/parker/">was released</a> just a few days ago. There were 188 contributors that helped make WordPress 3.8 a reality. I&#8217;m proud to say that <a title="http://profiles.wordpress.org/jeffr0" href="http://profiles.wordpress.org/jeffr0">I</a> was among those 188 contributors. I never thought I&#8217;d be able to make the list but thanks to some help, I was able to contribute in my own way. The following is my experience contributing to WordPress. <span id="more-13159"></span></p>
<p>During the development of WordPress 3.8, I used the <a title="http://wordpress.org/plugins/wordpress-beta-tester/" href="http://wordpress.org/plugins/wordpress-beta-tester/">WordPress Beta Testing</a> plugin to keep up with changes on my local server. While testing the default theme TwentyFourteen, I noticed a typo within the theme details. I could have reported the typo to a default theme team member and it would have been fixed immediately. However, once I discovered the typo I knew it was an opportunity to contribute to the core and make it on the contributors list.</p>
<h3>Is Fixing A Typo Really A Contribution?</h3>
<p>Before I reported the typo, I thought about whether fixing a typo would classify as a contribution. It was a small change that involved adding one letter to a word. I asked my followers on Twitter what they thought.</p>
<blockquote class="twitter-tweet" width="550"><p>Curiosity question. If I fix a typo in WordPress core, is that enough to get a credit link for a contribution or is that not enough?</p>
<p>&mdash; Jeff (@jeffr0) <a href="https://twitter.com/jeffr0/statuses/410575551905030144">December 11, 2013</a></p></blockquote>
<p></p>
<p>What I learned is that some people have contributed to WordPress simply by removing white space from code. Konstantin Obenland contributed to WordPress by adding an underscore where it was appropriate. The moral of the story is that no matter how small the contribution, every little bit counts and helps to improve the software. There is no need to feel guilty or unworthy of being listed as a contributor if all you did was fix a typo.</p>
<h3>Getting My Patch Into Core</h3>
<p>After discovering the typo, I immediately reached out to Konstantin Obenland who was a member of the team responsible for TwentyFourteen. I reported the typo to him and he recommended that I create a new ticket on <a title="http://core.trac.wordpress.org/" href="http://core.trac.wordpress.org/">Trac</a>. Bug reports along with their associated patches go through Trac in the form of tickets. Trac is not for the faint of heart. It&#8217;s an intimidating website for those that don&#8217;t frequent it often. Even though I&#8217;ve participated in the WordPress community for years, Trac still rattles my nerves when I create a ticket.</p>
<p><a href="http://www.wptavern.com/wp-content/uploads/2013/12/ContributionTicketFor38.jpg" rel="prettyphoto[13159]" rel="thumbnail"><img src="http://www.wptavern.com/wp-content/uploads/2013/12/ContributionTicketFor38-500x205.jpg" alt="The Ticket I Created For WordPress 3.8" width="500" height="205" class="aligncenter size-large wp-image-13496" /></a></p>
<p>Using Konstantin as a mentor, he walked me through the process of <a title="http://core.trac.wordpress.org/ticket/26528" href="http://core.trac.wordpress.org/ticket/26528">creating the ticket</a>. He also created the diff file for me that I uploaded as a patch. I didn&#8217;t know how to create diff files so it was nice of Konstantin to create one for me. Once the patch was uploaded, the ticket was out of my hands. After some edits to the ticket, the right people saw the patch and applied the fix to WordPress 3.8 before it was released.</p>
<h3>WordPress Needs Core Contributor Mentors</h3>
<p>WordPress would benefit from having a list of people that act as mentors for those contributing to WordPress for the first time via Trac. Drupal has gone through great lengths to make core contributing mentorship a priority. They have <a title="http://drupalmentoring.org/" href="http://drupalmentoring.org/">an entire site</a> dedicated to mentoring new contributors. Even if it were not as organized as Drupal, I&#8217;d like to see a list of mentors I could get in touch with to walk me through the process of patching a bug or fixing a typo in core.</p>
<p>A few years ago, WordPress tried to create a core mentorship program but it didn&#8217;t take off. The contributor team was much smaller than it is today and WordPress didn&#8217;t have regular working teams. I asked Jen Mylo if there are any plans to try and create a mentorship program now that there are a lot more people involved with the core development of WordPress. She tells me that she is currently working on a proposal for a formalized mentorship program across all of the contributor teams. </p>
<blockquote><p>We didn&#8217;t really have regular working teams then, and even the core team back then was much smaller active group. We&#8217;re in a much better place now to support formal mentorship programs since we now have regularly meeting teams, team reps posting weekly updates, etc.</p></blockquote>
<p>Jen says the proposal will be posted sometime before the end of the year.</p>
<h3>Contributing Was Awesome</h3>
<p>Despite it only being a typo, contributing to the core of WordPress was exhilarating. For a brief moment, I felt like learning PHP and MySQL to contribute everything I could to WordPress. After the excitement went away, I came back to my senses. Special thanks to Konstantin Obenland for holding my hand during the process of contributing. The last thing I want to do on Trac is make the core WordPress developers job harder by improperly filing tickets. Instead of screwing up, it&#8217;s better to not mess with Trac at all. At least that&#8217;s the way I&#8217;ve approached it.</p>
<p>While there is a <a title="http://make.wordpress.org/core/handbook/" href="http://make.wordpress.org/core/handbook/">handbook devoted entirely to contributing to WordPress</a>, it&#8217;s not the same as being guided through the process with an experienced individual. Thankfully, most of the <a title="http://chrislema.com/approachable-wordpress/" href="http://chrislema.com/approachable-wordpress/">WordPress community is approachable</a> and getting help is as easy as tweeting, skypeing, or emailing someone.</p>
<p><strong>At the end of the day, I contributed to WordPress and you can too.</strong></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 18 Dec 2013 23:30:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:80:"WPTavern: Piwik Redesigned: Open Source Web Analytics Software Gets a Fresh Look";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=13440";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:89:"http://wptavern.com/piwik-redesigned-open-source-web-analytics-software-gets-a-fresh-look";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5663:"<p><a href="http://piwik.org/" target="_blank">Piwik</a> is leading the way when it comes to open source web analytics software. More than 1,000,000 websites are using Piwik for analytics, according to the current <a href="http://trends.builtwith.com/analytics/Piwik-Web-Analytics" target="_blank">Builtwith assessment</a>. The team has just launched its 2.0 release with a brand new website and redesigned mobile app. This release is the culmination of seven months of work from the Piwik team and community.</p>
<p><a href="http://www.wptavern.com/wp-content/uploads/2013/12/piwik_app.jpg" rel="prettyphoto[13440]" rel="thumbnail"><img src="http://www.wptavern.com/wp-content/uploads/2013/12/piwik_app.jpg" alt="piwik_app" width="1214" height="726" class="aligncenter size-full wp-image-13464" /></a></p>
<p>Haven&#8217;t heard of Piwik? That&#8217;s probably due to the fact that Google Analytics thoroughly dominates this space. But there&#8217;s something exceptional that sets Piwik apart from Google Analytics. <strong>Piwik is free and open source, affording you privacy and full control over your data.</strong> Piwik takes about five minutes to install on your server. You can track multiple websites and keep all your data in the same place on your own server, away from prying eyes. </p>
<h3>Piwik: An Open Source Alternative to Google Analytics</h3>
<p>The Piwik dashboard has everything you&#8217;d expect from a comprehensive web analytics platform, including recent visits, keyword information, visitor location map, browser information, referrer information, and real-time visitor stats, and more available via widgets.</p>
<p>I had the chance to chat with Piwik founder and lead developer Matthieu Aubry. Given that Google Analytics is considered the default choice for the vast majority of websites, I asked him what is the number one reason people choose Piwik over its more popular competitor. He replied, &#8220;There are many reasons but <span class="pullquote alignleft">I think the number one reason for many choosing Piwik over Google Analytics is privacy and keeping control over sensitive user data.</span> This is becoming all too important. Another good reason may be that people like the simplicity of the UI and the openness of the platform.&#8221;</p>
<p>Part of that openness is that developers are encouraged to extend the platform using the Piwik APIs and many are already doing some creative things.<strong> &#8220;There are several businesses using the API to provide web analytics to many of their customers&#8217; websites automatically (by creating website users and scheduled reports using the API),&#8221;</strong> Aubry said. &#8220;Others use the API to request data and display it elsewhere. The tracking API is also used to implement custom app usage tracking within Mobile apps. Finally, what we hope to help developers build 3rd party plugins similar to WordPress or other popular open source frameworks. This will be our chance to bring a lot of innovation in analytics!&#8221;</p>
<h3>How to Use Piwik With WordPress</h3>
<p>Piwik is <a href="http://piwik.org/faq/new-to-piwik/#faq_45" target="_blank">licensed under the GPL</a>, just like WordPress. The WP-Piwik plugin integrates Piwik into your WordPress site, adds the tracking code and displays a summary of stats in your admin panel.</p>
<p><a href="http://www.wptavern.com/wp-content/uploads/2013/12/piwik_wp.jpg" rel="prettyphoto[13440]" rel="thumbnail"><img src="http://www.wptavern.com/wp-content/uploads/2013/12/piwik_wp.jpg" alt="piwik_wp" width="1024" height="596" class="aligncenter size-full wp-image-13478" /></a></p>
<p>Instructions for setting up WP-Piwik can be found on the <a href="http://wordpress.org/plugins/wp-piwik/" target="_blank">WordPress Integration</a> page and the the <a href="http://wordpress.org/plugins/wp-piwik/" target="_blank">plugin</a> is available in the WordPress repository. </p>
<h3>What&#8217;s New in Piwik 2.0?</h3>
<p>In addition to the new website, Piwik users will enjoy a host of new features with this <a href="http://piwik.org/changelog/piwik-2-0/" target="_blank">2.0 release</a>:</p>
<ul>
<li>Launch of the Piwik <a href="http://plugins.piwik.org/" target="_blank">marketplace</a> for plugins and themes</li>
<li>Browse and install plugins and themes directly from within Piwik</li>
<li>New completely redesigned mobile app, allowing users to monitor web traffic on the go</li>
<li>Piwik 2.0 has now been translated by volunteers into 53 different languages</li>
</ul>
<p>The team has also launched a new <a href="http://piwik.pro/" target="_blank">Piwik Pro</a> service that will offer professional analytics services for businesses, NGOs and governments, as well as cloud hosting and enterprise deployments. The service also includes custom integrations and support. </p>
<p>If you&#8217;re curious about Piwik but would rather try it before installing on your own server, check out the <a href="http://demo.piwik.org/index.php?module=CoreHome&action=index&idSite=7&period=day&date=yesterday#module=Dashboard&action=embeddedIndex&idSite=7&period=day&date=yesterday&idDashboard=1" target="_blank">live demo</a>. Piwik is not just for web analytics &#8211; you can also use it to track e-commerce, server logs and intranet analytics.</p>
<p>Many website owners are willing to trade privacy for the convenience of Google Analytics. But if you&#8217;re serious about owning your own data and protecting sensitive information, it&#8217;s nice to know that there are open source options like <a href="http://piwik.org/" target="_blank">Piwik</a> that can provide the same comprehensive level of analytics.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 18 Dec 2013 20:53:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"WPTavern: WPTavern Gets Responsive With New Design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=13443";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wptavern.com/wptavern-gets-responsive-with-new-design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2545:"<p>It&#8217;s been a long time since the Tavern has received a new coat of paint. I&#8217;d like to introduce you to the <strong>new WordPress Tavern</strong>. This design is a child theme that we created, based on <a href="http://www.wptavern.com/stargazer-a-free-design-specific-parent-theme-for-wordpress" title="http://www.wptavern.com/stargazer-a-free-design-specific-parent-theme-for-wordpress">Stargazer</a>, a new parent theme from <a href="http://themehybrid.com/" title="http://themehybrid.com/">Theme Hybrid</a>. WPTavern is now responsive and looks good on any mobile device without the need to use a special mobile theme. If the font used for the content looks familiar to you, it&#8217;s because it&#8217;s <a href="http://opensans.com/" title="http://opensans.com/">the same one</a> used within the <a href="http://www.wptavern.com/wordpress-3-8-parker-released" title="http://www.wptavern.com/wordpress-3-8-parker-released">newly redesigned backend of WordPress</a>. </p>
<div id="attachment_12155" class="wp-caption aligncenter"><a href="http://www.wptavern.com/wp-content/uploads/2013/11/stargazer.png" rel="prettyphoto[13443]" rel="thumbnail"><img src="http://www.wptavern.com/wp-content/uploads/2013/11/stargazer-500x375.png" alt="Stargazer Theme By Justin Tadlock" width="500" height="375" class="size-large wp-image-12155" /></a><p class="wp-caption-text">Stargazer Theme By Justin Tadlock</p></div>
<p>We&#8217;ve tried to maintain some of the personality unique to WordPress Tavern such as the wooden floor. This time however, the wood is a lighter shade which brightens the website. I&#8217;d like to take this opportunity to thank <a href="http://angiemeekerdesigns.com/" title="http://angiemeekerdesigns.com/">Angie Meeker</a> for the inspiration behind the new Tavern header logo and <a href="http://profiles.wordpress.org/users/coffee2code/" title="http://profiles.wordpress.org/users/coffee2code/">Scott Reilly</a> for playing the role of guinea pig. The beer mug in the header will be used as our brand image across the various social networking sites. </p>
<p>This is the first of many big changes on the way. With the redesign in place, keep an eye out for the WordPress Tavern forum to make a return. If you come across a  bug while browsing the site, please <a href="http://wptavern.com/ http://www.wptavern.com/contact-me" title=" http://www.wptavern.com/contact-me">get in touch with us</a>. When providing a bug report, tell us what browser and version you&#8217;re using. Be as descriptive as possible.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 18 Dec 2013 18:41:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"WordPress.tv: Raushan Jaiswal: WordPress For Beginners";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=26813";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.tv/2013/12/18/raushan-jaiswal-wordpress-for-beginners/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:657:"<div id="v-X0xsFBFP-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/26813/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/26813/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=26813&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/18/raushan-jaiswal-wordpress-for-beginners/"><img alt="Raushan Jaiswal: WordPress For Beginners" src="http://videos.videopress.com/X0xsFBFP/video-054ebd5cd3_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 18 Dec 2013 16:21:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WordPress.tv: Tom Harrigan: Sliders: The Good, The Bad And The Technical";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=26078";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://wordpress.tv/2013/12/18/tom-harrigan-sliders-the-good-the-bad-and-the-technical/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:697:"<div id="v-T6EOKfY3-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/26078/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/26078/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=26078&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/18/tom-harrigan-sliders-the-good-the-bad-and-the-technical/"><img alt="Tom Harrigan: Sliders: The Good, The Bad And The Technical" src="http://videos.videopress.com/T6EOKfY3/video-dfff790351_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 18 Dec 2013 15:18:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WPTavern: 10 Great Gift Ideas for WordPress Geeks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=12551";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wptavern.com/10-great-gift-ideas-for-wordpress-geeks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8858:"<p>Many people around the world are already in the thick of celebrating a host of international holidays, including Christmas, Hanukkah, Kwanzaa, and more. If you&#8217;re celebrating a holiday involving gifts and you&#8217;re not sure what to buy the beloved WordPress geek in your life, we have a few suggestions. Even if you don&#8217;t celebrate any holidays, you may want to stash these ideas away for birthdays. After conducting a quick poll on Twitter, it turns out there are many ways to make your favorite WordPress fan happy. Here are a few suggestions based on the replies I received:</p>
<h3>WordPress Coffee Mug</h3>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/wpcoffeemug.jpg" rel="prettyphoto[12551]" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/wpcoffeemug.jpg?resize=150%2C150" alt="wpcoffeemug" class="alignleft size-full wp-image-13394" /></a>The new <a href="http://hellomerch.com/collections/wordpress/products/wp-powered-by-coffee-mug" target="_blank">WordPress coffee mug</a> is available from the WordPress swag store. I gifted one to myself and can say that it&#8217;s just as handsome and shiny as it appears to be in the picture. The back says, &#8220;Proudly Powered by Coffee.&#8221; This cup is the perfect size &#8211; it contains the exact amount of coffee I can drink before it gets cold.<span id="more-12551"></span></p>
<h3>A License to Sublime Text</h3>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/12/sublime.jpg" rel="prettyphoto[12551]" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/12/sublime.jpg?resize=150%2C150" alt="sublime" class="alignleft size-thumbnail wp-image-13402" /></a>The <a href="http://www.sublimetext.com/" target="_blank">Sublime Text</a> editor is a best friend to many people who write code. Many developers consider it to be the holy grail of text editing tools. </p>
<p>If you can sneak around and verify that your friend is using an unlicensed copy, a surprise <a href="https://www.sublimetext.com/buy" target="_blank">license</a> given as a gift will delight the socks off of him or her. </p>
<h3>Jetpack Battery Pack</h3>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/12/jetpack-battery-pack.jpg" rel="prettyphoto[12551]" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/12/jetpack-battery-pack.jpg?resize=150%2C150" alt="jetpack-battery-pack" class="alignleft size-thumbnail wp-image-13411" /></a>The <a href="http://hellomerch.com/collections/wordpress/products/jetpack-battery-pack" target="_blank">Jetpack Battery Pack</a> is a fancy, portable external battery charger. Emblazoned with the Jetpack logo, this unique gift provides a quick charge to cell phones and other mobile devices. The Jetpack Battery Pack is only available from the WordPress Swag Store.</p>
<h3>A Treehouse Membership</h3>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/12/treehouse.jpg" rel="prettyphoto[12551]" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/12/treehouse.jpg?resize=150%2C150" alt="treehouse" class="alignleft size-thumbnail wp-image-13410" /></a><a href="https://teamtreehouse.com/" target="_blank">Treehouse</a> is a place where the WordPress fan in your life can pick up new skills by enrolling in courses that teach everything from design to mobile development to business skills. Technology enthusiasts love to learn new things and a gift <a href="https://teamtreehouse.com/subscribe/plans?trial=yes" target="_blank">membership</a> might be just the right avenue. Also, Treehouse donates an account to a public school student for every new Gold account purchased. </p>
<h3>BuddyPress Theme Development</h3>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/bpthemedev.jpg" rel="prettyphoto[12551]" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/bpthemedev.jpg?resize=150%2C150" alt="bpthemedev" class="alignleft size-thumbnail wp-image-13417" /></a><a href="http://www.wptavern.com/buddypress-theming-book-now-available-on-amazon" target="_blank">BuddyPress Theme Development</a> is a book that will teach you how to create BuddyPress themes from start to finish. You couldn&#8217;t find a better gift for the BuddyPress designer, developer or enthusiast in your life. BuddyPress Theme Development is <a href="http://www.amazon.co.uk/BuddyPress-Theme-Development-Tammie-Lister-ebook/dp/B00G395ORG/ref=sr_1_2?ie=UTF8&qid=1382456253&sr=8-2&keywords=tammie+lister" target="_blank">available on Amazon</a> in paperback or kindle version.</p>
<h3>Gravity Forms</h3>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/12/gf.jpg" rel="prettyphoto[12551]" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/12/gf.jpg?resize=150%2C150" alt="gf" class="alignleft size-thumbnail wp-image-13415" /></a><a href="http://www.gravityforms.com/" target="_blank">Gravity Forms</a> is the beloved form-builder of choice for many WordPress users. These days Gravity Forms is going far beyond just building forms with their <a href="http://www.wptavern.com/gravityforms-1-8-beta-released-introduces-api" target="_blank">latest release</a> introducing a complete API. The WordPress person in your life may already have a Gravity Forms <a href="http://www.gravityforms.com/purchase-gravity-forms/" target="_blank">license</a>, so you may need to engage in a little bit of creative questioning to find out.</p>
<h3>Professional WordPress Plugin Development</h3>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/pwpd.jpg" rel="prettyphoto[12551]" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/pwpd.jpg?resize=150%2C150" alt="pwpd" class="alignleft size-thumbnail wp-image-13423" /></a>If you&#8217;ve got an aspiring WordPress plugin developer on your gift list, the Professional WordPress Plugin Development book is an excellent choice. There&#8217;s certainly a lot to learn for free online but sometimes it helps to have information in a book to take you through different topics in an organized way. Professional WordPress Plugin Development is <a href="http://www.amazon.com/Professional-WordPress-Plugin-Development-Williams/dp/0470916222/ref=sr_1_1?ie=UTF8&qid=1387319815&sr=8-1&keywords=professional+wordpress+plugin+development" target="_blank">available on Amazon</a> via paperback or kindle. </p>
<h3>A CodePen Account</h3>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/codepen.jpg" rel="prettyphoto[12551]" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/codepen.jpg?resize=150%2C150" alt="codepen" class="alignleft size-thumbnail wp-image-13427" /></a><a href="https://codepen.io/" target="_blank">CodePen</a> is a site where developers can edit HTML, CSS, and JavaScript code in the browser and see instant previews of its output. It&#8217;s a fun place to play with code and share your creations. A <a href="https://codepen.io/signup" target="_blank">CodePen Pro</a> account allows the user unlimited private pens, asset hosting, collaboration mode and more.</p>
<h3>WordPress T-Shirt</h3>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/12/wptshirt.jpg" rel="prettyphoto[12551]" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/12/wptshirt.jpg?resize=150%2C150" alt="wptshirt" class="alignleft size-thumbnail wp-image-13429" /></a>You can never go wrong with a WordPress T-shirt as a gift. T-shirts and hoodies are pretty much the standard uniform of many tech professionals. The <a href="http://hellomerch.com/collections/wordpress" target="_blank">WordPress Swag Store</a> has a nice assortment of t-shirts and hoodies in both men&#8217;s and women&#8217;s fits.</p>
<h3>The Gift of Time</h3>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/12/time.jpg" rel="prettyphoto[12551]" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/12/time.jpg?resize=150%2C150" alt="time" class="alignleft size-thumbnail wp-image-13433" /></a>One of the most common replies I received to my WordPress gifts survey was time. Everyone needs more time in the day. For those who have families, it can be particularly tough to fit in a full-time job, time with the kids and contributions to open source projects. Giving someone the gift of time is nearly impossible, but there are ways to approximate it. Offer to babysit, make a meal, perform some car maintenance or time-consuming chores. Efforts to help your friend or family member free up time could be far more meaningful than any gift you could buy. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 18 Dec 2013 00:02:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"WPTavern: Jetpack is Now Available on Github";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=13357";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wptavern.com/jetpack-is-now-available-on-github";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3632:"<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/12/jetpack.jpg" rel="prettyphoto[13357]" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/12/jetpack.jpg?resize=800%2C259" alt="jetpack" class="aligncenter size-full wp-image-13381" /></a><br />
The <a href="http://wordpress.org/plugins/jetpack/" target="_blank">Jetpack</a> plugin code is now available on <a href="https://github.com/Automattic/Jetpack" target="_blank">github</a> and the team <a href="https://twitter.com/Viper007Bond/status/412731744962359296" target="_blank">welcomes</a> your pull requests. With the addition of Jetpack, Automattic now has <a href="https://github.com/Automattic" target="_blank">106 public repositories</a> on github. That&#8217;s a lot of shared code! </p>
<p>Jetpack has been downloaded nearly eight million times since its debut on WordPress.org. If you&#8217;ve enjoyed using Jetpack and have some ideas for improving it, github is a great way to contribute back to the plugin. Your code will improve the Jetpack experience on millions of websites. There are also other ways to contribute without writing any code:<span id="more-13357"></span></p>
<ul>
<li><a href="http://jetpack.me/contact-support/" target="_blank">Join</a> the Jetpack Beta Test group</li>
<li>Lend a hand answering questions in the Jetpack <a href="http://wordpress.org/support/plugin/jetpack" target="_blank">support forum</a></li>
<li>Report bugs, with reproduction steps, or post patches on Jetpack&#8217;s <a href="http://plugins.trac.wordpress.org/newticket?component=jetpack" target="_blank">trac</a></li>
</ul>
<h3>Learn the Basics of Contributing to Open Source Software with Jetpack</h3>
<p>Jetpack probably has one of the most organized <a href="http://jetpack.me/contribute/" target="_blank">guides to contribution</a> that I have ever seen for an open source plugin project. The team has created contribution opportunities for users and developers at all levels. The guide outlines ways to <a href="http://jetpack.me/contribute/#contribute" target="_blank">contribute at beginner, intermediate, and advanced levels</a>. </p>
<p>What really stands out about the Jetpack contribution guide is that it actually teaches you the basics of contributing to an open source project, including topics such as:</p>
<ul>
<li><a href="http://jetpack.me/contribute/#source" target="_blank">How to check out the source code</a> &#8211; Learn how to install and navigate subversion</li>
<li><a href="http://jetpack.me/contribute/#bugs" target="_blank">How to create a great bug report</a> &#8211; Learn the anatomy of a Trac ticket and how to submit tickets</li>
<li><a href="http://jetpack.me/contribute/#patch" target="_blank">How to write and submit a patch</a> &#8211; Get step-by-step instructions for submitting a patch</li>
<li><a href="http://jetpack.me/contribute/#practices" target="_blank">Best practices for WordPress development</a> &#8211; Get more information on PHP, HTML, CSS and JavaScript coding standards</li>
</ul>
<p>Let&#8217;s face it. Nobody springs from the womb understanding how to create a good bug report or submit a patch. That&#8217;s why guides like this are so important. Getting involved on a smaller project like Jetpack is an opportunity to test your wings in an area where you have an interest. If you have an open source project where you want to attract more contributors, consider creating a detailed, organized guide in the same way Jetpack has outlined contribution opportunities. That little extra effort in documentation might open up the floodgates to contributions. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Dec 2013 19:49:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WPTavern: WordPress Plugin Authors: Be Up Front and Honest With Users About Tracking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=13276";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://wptavern.com/wordpress-plugin-authors-be-up-front-and-honest-with-users-about-tracking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:5656:"<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/TrackerTransparency.jpg" rel="prettyphoto[13276]" rel="thumbnail"><img class="alignright size-full wp-image-13356" alt="Tracker Transparency" src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/TrackerTransparency.jpg?resize=148%2C93" /></a>Plugins collecting information and phoning home to a third-party without the user’s consent is a serious issue in the WordPress community. The <a title="http://wordpress.org/plugins/about/guidelines/" href="http://wordpress.org/plugins/about/guidelines/">WordPress plugin repository guidelines</a> are clear on this matter specifically, <strong>point number seven</strong> and its sub points. Pooria Asteraky has <a title="http://pooriast.wordpress.com/2013/12/15/trackers-wordpress-plugin/" href="http://pooriast.wordpress.com/2013/12/15/trackers-wordpress-plugin/">published a post</a> that explains why there needs to be more transparency across the WordPress community as a whole as it relates to &#8216;<em>trackers</em>&#8216; being installed on users sites via WordPress plugins. <span id="more-13276"></span></p>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/Ghosterylogo.jpg" rel="prettyphoto[13276]" rel="thumbnail"><img class="alignright size-full wp-image-13367" alt="Ghosterylogo" src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/Ghosterylogo.jpg?resize=219%2C75" /></a>According to Pooria, trackers are referred to as tracking codes that collect information such as statistics. After installing a WordPress plugin that provided social sharing buttons, he discovered through the use of <a title="http://www.ghostery.com/" href="http://www.ghostery.com/">Ghostery</a>, that there were thirteen trackers installed on the website. Five of which had nothing to do with social networks. The rest of the post goes on to explain why this is not a good thing for the WordPress community and calls on webmasters, plugin authors, and everyone else on the web to be completely transparent regarding the trackers that are being used on their sites.</p>
<h3>The Community Does A Good Job Policing Itself</h3>
<p>WordPress is open source and so are all of the plugins hosted within the plugin repository. While there are plugin reviewers that voluntarily do their best to make sure nothing malicious ends up in the repository, some plugins slip through the cracks. However, because of the size of the WordPress userbase and how easy it is to look at the plugin&#8217;s code, those plugins usually don&#8217;t last long in the wild. If you come across a plugin that you think is doing something malicious and it&#8217;s on the WordPress plugin repository, contact <em>plugins at wordpress.org</em>. Someone from the review team will take a look at the issue and act accordingly.</p>
<h3>Complete Transparency Is A Pipe Dream</h3>
<p>Near the end of the post, Pooria outlines the final goal of transparency.</p>
<blockquote><p>The final goal of transparency is to encourage all WordPress Users ( Webmasters) to publicly announce all the trackers and cookies of their sites to the public ( visitors and viewers of WordPress Sites).</p></blockquote>
<p>This is a goal that in my opinion, will never be realized. Otto makes a <a title="http://pooriast.wordpress.com/2013/12/15/trackers-wordpress-plugin/comment-page-1/#comment-1391" href="http://pooriast.wordpress.com/2013/12/15/trackers-wordpress-plugin/comment-page-1/#comment-1391">number of points I agree with</a>. I think it&#8217;s asking too much for webmasters to list out ad scripts, cookies, trackers, analytics, etc to their website for public display. In fact, it should be assumed that any webpage a user visits will be running some sort of statistic gathering software or leave cookies behind in the browser. This is the nature of the web. It&#8217;s not like users don&#8217;t have an option to combat these assumptions. There are a myriad of tools available such as browser extensions, desktop software, and privacy settings within the browser.</p>
<h3>The Correct Way To Gather Usage Info Within Plugins</h3>
<p>If you&#8217;re going to track users of your plugin, I highly suggest going about it the same way as Joost de Valk. <a title="http://yoast.com/wordpress/seo/" href="http://yoast.com/wordpress/seo/">WordPress SEO</a> developed by Joost de Valk will ask users after they have activated the plugin for the first time whether or not they want to enable tracking.</p>
<div id="attachment_13369" class="wp-caption aligncenter"><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/12/YoastSEOTracking.jpg" rel="prettyphoto[13276]" rel="thumbnail"><img class="size-full wp-image-13369" alt="Yoast SEO Tracking" src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/12/YoastSEOTracking.jpg?resize=327%2C235" /></a><p class="wp-caption-text">Tracking Done The Right Way</p></div>
<p>This is an acceptable method within the WordPress plugin repository guidelines as it&#8217;s asking for the users consent.</p>
<h3>Be Up Front and Honest With Users</h3>
<p>Between the plugin review team and the WordPress community, most users don&#8217;t have anything to worry about. It&#8217;s not that gathering usage information is bad as it&#8217;s a wonderful way to track data to improve software. What&#8217;s bad is gathering that information without anyone knowing it&#8217;s taking place. As a plugin author, do the right thing. Be up front and honest about gathering usage data. Give users the choice and for those users that enable tracking, don&#8217;t give them a reason to lose their trust.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Dec 2013 18:56:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Matt: XFN 10th Anniversary";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43245";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:42:"http://ma.tt/2013/12/xfn-10th-anniversary/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:117:"<p>Tantek writes on the <a href="http://tantek.com/2013/349/b1/xfn-10th-anniversary">10th Anniversary of XFN</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Dec 2013 18:31:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"WordPress.tv: Chris Van Patten: The Code Is Written: Now What?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=26075";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.tv/2013/12/17/chris-van-patten-the-code-is-written-now-what/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:677:"<div id="v-7ooEjg9X-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/26075/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/26075/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=26075&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/17/chris-van-patten-the-code-is-written-now-what/"><img alt="Chris Van Patten: The Code Is Written: Now What?" src="http://videos.videopress.com/7ooEjg9X/video-2229799521_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Dec 2013 14:56:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WordPress.tv: Ujwal Thapa: WordPress As A Blogging Platform";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=26761";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://wordpress.tv/2013/12/17/ujwal-thapa-wordpress-as-a-blogging-platform/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:673:"<div id="v-wwl4y5zP-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/26761/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/26761/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=26761&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/12/17/ujwal-thapa-wordpress-as-a-blogging-platform/"><img alt="Ujwal Thapa: WordPress As A Blogging Platform" src="http://videos.videopress.com/wwl4y5zP/video-490e934315_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Dec 2013 14:51:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WPTavern: BuddyPress 1.9 “Sammy” Released With New Notifications Component";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=12892";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wptavern.com/buddypress-1-9-sammy-released-with-new-notifications-component";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4659:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/12/sammys.png" rel="prettyphoto[12892]" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/12/sammys.png?resize=296%2C300" alt="sammys" class="alignright size-medium wp-image-13360" /></a>BuddyPress 1.9 was <a href="http://buddypress.org/2013/12/buddypress-1-9-sammy/" target="_blank">released</a> to the world today thanks to many volunteer contributors who worked hard to make it happen. This release pays tribute to Sammy&#8217;s Pizza in Providence, Rhode Island, where lead developer John James Jacoby has enjoyed many fine pizza pies.</p>
<p>Here&#8217;s a quick tour of the three main highlights of this release.</p>
<h3>New Notifications Component</h3>
<p>BuddyPress is introducing a new component for the first time in two years. The 1.9 release has moved notifications to its own component so that they&#8217;re all centralized in one place.<span id="more-12892"></span></p>
<div id="attachment_13294" class="wp-caption aligncenter"><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/notifications.jpg" rel="prettyphoto[12892]" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/12/notifications.jpg?resize=646%2C498" alt="BuddyPress Notifications" class="size-full wp-image-13294" /></a><p class="wp-caption-text">BuddyPress Notifications</p></div>
<p>Notifications also have an improved API in 1.9 so that developers can easily tie their extensions into them. </p>
<h3>Dynamic Menu Items</h3>
<p>BuddyPress site admins will be thrilled to find that 1.9 includes <a href="http://www.wptavern.com/buddypress-1-9-will-include-dynamic-menu-links" target="_blank">dynamic menu links</a>. It&#8217;s now easier than ever to build menus with dynamic links such as &#8220;My Profile&#8221; or &#8220;Settings&#8221; that are specific to logged-in users. Dynamic menu items are separated into logged-in and logged-out user links. </p>
<div id="attachment_9961" class="wp-caption aligncenter"><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/10/bp-menus.jpg" rel="prettyphoto[12892]" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/10/bp-menus.jpg?resize=732%2C715" alt="Dynamic BuddyPress Menus" class="size-full wp-image-9961" /></a><p class="wp-caption-text">Dynamic BuddyPress Menus</p></div>
<p>If you previously used a plugin to generate dynamic menu items, you can now delete it and use the built-in BuddyPress links at <strong>Dashboard > Appearance > Menus</strong>.</p>
<h3>New Widgets</h3>
<p>BuddyPress 1.9 introduces three new core widgets to help you customize your social network:</p>
<p><div id="attachment_13296" class="wp-caption alignright"><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/12/friends-widget.jpg" rel="prettyphoto[12892]" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/12/friends-widget.jpg?resize=225%2C274" alt="Friends Widget" class="size-full wp-image-13296" /></a><p class="wp-caption-text">Friends Widget</p></div>
<ul>
<li><strong>Friends Widget:</strong> A list of recently active, popular and newest friends of the displayed member.</li>
<li><strong>Log In Widget:</strong> Adds a simple “Log In” form and/or &#8220;Log Out&#8221; link</li>
<li><strong>Sitewide Notices Widget:</strong> Displays Sitewide Notices from the Private Messaging component.</li>
</ul>
<h4>Developer Goodies</h4>
<p>BuddyPress 1.9 reinstates the bp_redirect_canonical() functionality. phpDoc inline documentation has been improved as well as compatibility with the develop.svn.wordpress.org unit-test suite. </p>
<p>On top of all that, the <a href="http://www.wptavern.com/buddypress-codex-completely-revamped-with-new-design-tutorials-and-guides" target="_blank">BuddyPress Codex has been completely revamped</a> with a design refresh and loads of new tutorials and guides.</p>
<p>The BuddyPress core team is already cooking up new ideas for the 2.0 release but will take some time off for the holidays before getting started. The team will be sending out a brief questionnaire after the beginning of the new year to get community input before setting the goals for BuddyPress 2.0. If you&#8217;re keen on shaping the future of BuddyPress, watch for that questionnaire and make sure to voice your opinion. In the meantime, enjoy all the <a href="http://codex.buddypress.org/developer/releases/version-1-9/" target="_blank">new goodies packaged into 1.9</a>. It&#8217;s already fully compatible with WordPress 3.8 so you&#8217;re safe to upgrade to the very latest.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 17 Dec 2013 05:47:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 29 Dec 2013 13:08:04 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"167054";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Sun, 29 Dec 2013 12:45:18 GMT";s:4:"x-nc";s:11:"HIT lax 249";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20131111121622";}', 'no') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Wednesday 15. January 2014 12:39 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=345 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (325 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2, 27, '_wp_attached_file', '2013/09/Jam.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3, 27, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:487;s:6:"height";i:452;s:4:"file";s:15:"2013/09/Jam.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"Jam-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:15:"Jam-300x278.jpg";s:5:"width";i:300;s:6:"height";i:278;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4, 27, '_edit_lock', '1378732011:1') ; 
INSERT INTO `wp_postmeta` VALUES (5, 27, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (6, 28, '_wp_attached_file', '2013/09/cropped-football_generic.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (7, 28, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (8, 28, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1050;s:6:"height";i:250;s:4:"file";s:36:"2013/09/cropped-football_generic.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"cropped-football_generic-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:35:"cropped-football_generic-300x71.jpg";s:5:"width";i:300;s:6:"height";i:71;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:37:"cropped-football_generic-1024x243.jpg";s:5:"width";i:1024;s:6:"height";i:243;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (9, 28, '_wp_attachment_is_custom_header', 'tigertheme') ; 
INSERT INTO `wp_postmeta` VALUES (10, 30, '_wp_attached_file', '2013/10/football_generic.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (11, 30, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:864;s:6:"height";i:100;s:4:"file";s:28:"2013/10/football_generic.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"football_generic-150x100.jpg";s:5:"width";i:150;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"football_generic-300x34.jpg";s:5:"width";i:300;s:6:"height";i:34;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:27:"football_generic-624x72.jpg";s:5:"width";i:624;s:6:"height";i:72;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (12, 29, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (13, 29, '_edit_lock', '1384650431:1') ; 
INSERT INTO `wp_postmeta` VALUES (14, 32, '_wp_attached_file', '2013/10/map-malaysia600.gif') ; 
INSERT INTO `wp_postmeta` VALUES (15, 32, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:236;s:4:"file";s:27:"2013/10/map-malaysia600.gif";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"map-malaysia600-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:6:"medium";a:4:{s:4:"file";s:27:"map-malaysia600-300x118.gif";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/gif";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (16, 32, '_edit_lock', '1382239092:1') ; 
INSERT INTO `wp_postmeta` VALUES (19, 34, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (18, 34, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (17, 32, '_wp_attachment_backup_sizes', 'a:10:{s:9:"full-orig";a:3:{s:5:"width";i:600;s:6:"height";i:236;s:4:"file";s:19:"map-malaysia600.gif";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:27:"map-malaysia600-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:11:"medium-orig";a:4:{s:4:"file";s:27:"map-malaysia600-300x118.gif";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/gif";}s:18:"full-1382239246960";a:3:{s:5:"width";i:600;s:6:"height";i:236;s:4:"file";s:34:"map-malaysia600-e1382239226939.gif";}s:23:"thumbnail-1382239246960";a:4:{s:4:"file";s:42:"map-malaysia600-e1382239226939-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:20:"medium-1382239246960";a:4:{s:4:"file";s:42:"map-malaysia600-e1382239226939-300x118.gif";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/gif";}s:18:"full-1382239301503";a:3:{s:5:"width";i:183;s:6:"height";i:165;s:4:"file";s:34:"map-malaysia600-e1382239246960.gif";}s:18:"full-1382239307312";a:3:{s:5:"width";i:60;s:6:"height";i:54;s:4:"file";s:34:"map-malaysia600-e1382239301503.gif";}s:23:"thumbnail-1382239307312";a:4:{s:4:"file";s:42:"map-malaysia600-e1382239246960-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:20:"medium-1382239307312";a:4:{s:4:"file";s:42:"map-malaysia600-e1382239226939-300x118.gif";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/gif";}}') ; 
INSERT INTO `wp_postmeta` VALUES (20, 34, '_menu_item_object_id', '34') ; 
INSERT INTO `wp_postmeta` VALUES (21, 34, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (22, 34, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (23, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (24, 34, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (25, 34, '_menu_item_url', 'http://localhost/tigers/') ; 
INSERT INTO `wp_postmeta` VALUES (26, 34, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (27, 35, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (28, 35, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (29, 35, '_menu_item_object_id', '4') ; 
INSERT INTO `wp_postmeta` VALUES (30, 35, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (31, 35, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (32, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (33, 35, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (34, 35, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (35, 35, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (36, 36, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (37, 36, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (38, 36, '_menu_item_object_id', '6') ; 
INSERT INTO `wp_postmeta` VALUES (39, 36, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (40, 36, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (41, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (42, 36, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (43, 36, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (44, 36, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (45, 37, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (46, 37, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (47, 37, '_menu_item_object_id', '10') ; 
INSERT INTO `wp_postmeta` VALUES (48, 37, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (49, 37, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (50, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (51, 37, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (52, 37, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (53, 37, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (54, 38, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (55, 38, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (56, 38, '_menu_item_object_id', '12') ; 
INSERT INTO `wp_postmeta` VALUES (57, 38, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (58, 38, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (59, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (60, 38, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (61, 38, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (62, 38, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (63, 39, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (64, 39, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (65, 39, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (66, 39, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (67, 39, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (68, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (69, 39, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (70, 39, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (71, 39, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (72, 40, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (73, 40, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (74, 40, '_menu_item_object_id', '16') ; 
INSERT INTO `wp_postmeta` VALUES (75, 40, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (76, 40, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (77, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (78, 40, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (79, 40, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (80, 40, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (81, 41, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (82, 41, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (83, 41, '_menu_item_object_id', '18') ; 
INSERT INTO `wp_postmeta` VALUES (84, 41, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (85, 41, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (86, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (87, 41, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (88, 41, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (89, 41, '_menu_item_orphaned', '1384261458') ; 
INSERT INTO `wp_postmeta` VALUES (90, 42, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (91, 42, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (92, 42, '_menu_item_object_id', '20') ; 
INSERT INTO `wp_postmeta` VALUES (93, 42, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (94, 42, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (95, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (96, 42, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (97, 42, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (98, 42, '_menu_item_orphaned', '1384261458') ; 
INSERT INTO `wp_postmeta` VALUES (99, 43, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (100, 43, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (101, 43, '_menu_item_object_id', '22') ; 
INSERT INTO `wp_postmeta` VALUES (102, 43, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (103, 43, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (104, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (105, 43, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (106, 43, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (107, 43, '_menu_item_orphaned', '1384261458') ; 
INSERT INTO `wp_postmeta` VALUES (108, 44, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (109, 44, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (110, 44, '_menu_item_object_id', '24') ; 
INSERT INTO `wp_postmeta` VALUES (111, 44, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (112, 44, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (113, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (114, 44, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (115, 44, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (116, 44, '_menu_item_orphaned', '1384261458') ; 
INSERT INTO `wp_postmeta` VALUES (285, 85, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (286, 85, '_edit_lock', '1387193001:1') ; 
INSERT INTO `wp_postmeta` VALUES (284, 85, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (123, 48, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (124, 48, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (125, 48, '_menu_item_object_id', '48') ; 
INSERT INTO `wp_postmeta` VALUES (126, 48, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (127, 48, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (128, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (129, 48, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (130, 48, '_menu_item_url', 'http://localhost/tigers/') ; 
INSERT INTO `wp_postmeta` VALUES (131, 48, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (132, 49, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (133, 49, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (134, 49, '_menu_item_object_id', '4') ; 
INSERT INTO `wp_postmeta` VALUES (135, 49, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (136, 49, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (137, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (138, 49, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (139, 49, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (140, 49, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (141, 50, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (142, 50, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (143, 50, '_menu_item_object_id', '6') ; 
INSERT INTO `wp_postmeta` VALUES (144, 50, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (145, 50, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (146, 50, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (147, 50, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (148, 50, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (149, 50, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (150, 51, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (151, 51, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (152, 51, '_menu_item_object_id', '10') ; 
INSERT INTO `wp_postmeta` VALUES (153, 51, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (154, 51, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (155, 51, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (156, 51, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (157, 51, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (158, 51, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (159, 52, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (160, 52, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (161, 52, '_menu_item_object_id', '12') ; 
INSERT INTO `wp_postmeta` VALUES (162, 52, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (163, 52, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (164, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (165, 52, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (166, 52, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (167, 52, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (168, 53, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (169, 53, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (170, 53, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (171, 53, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (172, 53, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (173, 53, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (174, 53, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (175, 53, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (176, 53, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (177, 54, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (178, 54, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (179, 54, '_menu_item_object_id', '16') ; 
INSERT INTO `wp_postmeta` VALUES (180, 54, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (181, 54, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (182, 54, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (183, 54, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (184, 54, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (185, 54, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (186, 55, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (187, 55, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (188, 55, '_menu_item_object_id', '18') ; 
INSERT INTO `wp_postmeta` VALUES (189, 55, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (190, 55, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (191, 55, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (192, 55, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (193, 55, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (194, 55, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (195, 56, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (196, 56, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (197, 56, '_menu_item_object_id', '20') ; 
INSERT INTO `wp_postmeta` VALUES (198, 56, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (199, 56, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (200, 56, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (201, 56, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (202, 56, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (203, 56, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (204, 57, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (205, 57, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (206, 57, '_menu_item_object_id', '22') ; 
INSERT INTO `wp_postmeta` VALUES (207, 57, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (208, 57, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (209, 57, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (210, 57, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (211, 57, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (212, 57, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (213, 58, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (214, 58, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (215, 58, '_menu_item_object_id', '24') ; 
INSERT INTO `wp_postmeta` VALUES (216, 58, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (217, 58, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (218, 58, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (219, 58, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (220, 58, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (221, 58, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (222, 59, '_form', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit "Send"]</p>') ; 
INSERT INTO `wp_postmeta` VALUES (223, 59, '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:200:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://localhost/tigers)";s:9:"recipient";s:22:"andy.tan2624@gmail.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (224, 59, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:142:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://localhost/tigers)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (225, 59, '_messages', 'a:6:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";}') ; 
INSERT INTO `wp_postmeta` VALUES (226, 59, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (227, 59, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (228, 60, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (229, 60, '_edit_lock', '1387196183:1') ; 
INSERT INTO `wp_postmeta` VALUES (230, 60, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (231, 62, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (232, 62, '_edit_lock', '1384474783:1') ; 
INSERT INTO `wp_postmeta` VALUES (234, 4, '_edit_lock', '1384426417:1') ; 
INSERT INTO `wp_postmeta` VALUES (235, 4, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (236, 4, '_wp_page_template', 'page-templates/template-full-width.php') ; 
INSERT INTO `wp_postmeta` VALUES (237, 64, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (238, 64, '_edit_lock', '1384428887:1') ; 
INSERT INTO `wp_postmeta` VALUES (240, 66, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (241, 66, '_edit_lock', '1384474730:1') ; 
INSERT INTO `wp_postmeta` VALUES (243, 68, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (244, 68, '_edit_lock', '1384429055:1') ; 
INSERT INTO `wp_postmeta` VALUES (245, 69, '_wp_attached_file', '2013/11/les-miserables-image08.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (246, 69, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:34:"2013/11/les-miserables-image08.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:34:"les-miserables-image08-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:34:"les-miserables-image08-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:36:"les-miserables-image08-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:34:"les-miserables-image08-220x126.jpg";s:5:"width";i:220;s:6:"height";i:126;s:9:"mime-type";s:10:"image/jpeg";}s:16:"expound-featured";a:4:{s:4:"file";s:34:"les-miserables-image08-460x260.jpg";s:5:"width";i:460;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:12:"expound-mini";a:4:{s:4:"file";s:32:"les-miserables-image08-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (248, 71, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (249, 71, '_edit_lock', '1384474707:1') ; 
INSERT INTO `wp_postmeta` VALUES (252, 74, '_wp_attached_file', '2013/11/football_generic.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (253, 74, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (254, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:864;s:6:"height";i:100;s:4:"file";s:28:"2013/11/football_generic.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"football_generic-150x100.jpg";s:5:"width";i:150;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"football_generic-300x34.jpg";s:5:"width";i:300;s:6:"height";i:34;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"football_generic-220x100.jpg";s:5:"width";i:220;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:16:"expound-featured";a:4:{s:4:"file";s:28:"football_generic-460x100.jpg";s:5:"width";i:460;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"expound-mini";a:4:{s:4:"file";s:26:"football_generic-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (255, 74, '_wp_attachment_is_custom_background', 'expound') ; 
INSERT INTO `wp_postmeta` VALUES (256, 29, '_thumbnail_id', '69') ; 
INSERT INTO `wp_postmeta` VALUES (261, 76, 'ml-slider_settings', 'a:32:{s:4:"type";s:4:"flex";s:6:"random";s:5:"false";s:8:"cssClass";s:0:"";s:8:"printCss";s:4:"true";s:7:"printJs";s:4:"true";s:5:"width";s:3:"800";s:6:"height";s:3:"300";s:3:"spw";i:7;s:3:"sph";i:5;s:5:"delay";s:4:"3000";s:6:"sDelay";i:30;s:7:"opacity";d:0.6999999999999999555910790149937383830547332763671875;s:10:"titleSpeed";i:500;s:6:"effect";s:4:"fade";s:10:"navigation";s:4:"true";s:5:"links";s:4:"true";s:10:"hoverPause";s:4:"true";s:5:"theme";s:7:"default";s:9:"direction";s:10:"horizontal";s:7:"reverse";s:5:"false";s:14:"animationSpeed";s:3:"600";s:8:"prevText";s:1:"<";s:8:"nextText";s:1:">";s:6:"slices";i:15;s:6:"center";s:4:"true";s:9:"smartCrop";s:4:"true";s:12:"carouselMode";s:5:"false";s:6:"easing";s:6:"linear";s:8:"autoPlay";s:4:"true";s:11:"thumb_width";i:150;s:12:"thumb_height";i:100;s:12:"smoothHeight";s:5:"false";}') ; 
INSERT INTO `wp_postmeta` VALUES (262, 30, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (263, 30, '_wp_attachment_backup_sizes', 'a:3:{s:15:"resized-150x150";a:5:{s:4:"path";s:89:"/home/andytann/public_html/tigers/wp-content/uploads/2013/10/football_generic-150x150.jpg";s:4:"file";s:28:"football_generic-150x150.jpg";s:5:"width";i:150;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:15:"resized-233x100";a:5:{s:4:"path";s:89:"/home/andytann/public_html/tigers/wp-content/uploads/2013/10/football_generic-233x100.jpg";s:4:"file";s:28:"football_generic-233x100.jpg";s:5:"width";i:233;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:15:"resized-266x100";a:5:{s:4:"path";s:89:"/home/andytann/public_html/tigers/wp-content/uploads/2013/10/football_generic-266x100.jpg";s:4:"file";s:28:"football_generic-266x100.jpg";s:5:"width";i:266;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}') ; 
INSERT INTO `wp_postmeta` VALUES (264, 27, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (265, 69, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (266, 27, '_wp_attachment_backup_sizes', 'a:2:{s:15:"resized-487x208";a:5:{s:4:"path";s:76:"/home/andytann/public_html/tigers/wp-content/uploads/2013/09/Jam-487x208.jpg";s:4:"file";s:15:"Jam-487x208.jpg";s:5:"width";i:487;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}s:15:"resized-487x182";a:5:{s:4:"path";s:76:"/home/andytann/public_html/tigers/wp-content/uploads/2013/09/Jam-487x182.jpg";s:4:"file";s:15:"Jam-487x182.jpg";s:5:"width";i:487;s:6:"height";i:182;s:9:"mime-type";s:10:"image/jpeg";}}') ; 
INSERT INTO `wp_postmeta` VALUES (267, 69, '_wp_attachment_backup_sizes', 'a:2:{s:15:"resized-700x300";a:5:{s:4:"path";s:95:"/home/andytann/public_html/tigers/wp-content/uploads/2013/11/les-miserables-image08-700x300.jpg";s:4:"file";s:34:"les-miserables-image08-700x300.jpg";s:5:"width";i:700;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:15:"resized-800x300";a:5:{s:4:"path";s:95:"/home/andytann/public_html/tigers/wp-content/uploads/2013/11/les-miserables-image08-800x300.jpg";s:4:"file";s:34:"les-miserables-image08-800x300.jpg";s:5:"width";i:800;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}') ; 
INSERT INTO `wp_postmeta` VALUES (268, 77, 'ml-slider_settings', 'a:32:{s:4:"type";s:4:"flex";s:6:"random";s:5:"false";s:8:"cssClass";s:0:"";s:8:"printCss";s:4:"true";s:7:"printJs";s:4:"true";s:5:"width";s:3:"700";s:6:"height";s:3:"300";s:3:"spw";i:7;s:3:"sph";i:5;s:5:"delay";s:4:"3000";s:6:"sDelay";i:30;s:7:"opacity";d:0.6999999999999999555910790149937383830547332763671875;s:10:"titleSpeed";i:500;s:6:"effect";s:4:"fade";s:10:"navigation";s:4:"true";s:5:"links";s:4:"true";s:10:"hoverPause";s:4:"true";s:5:"theme";s:7:"default";s:9:"direction";s:10:"horizontal";s:7:"reverse";s:5:"false";s:14:"animationSpeed";s:3:"600";s:8:"prevText";s:1:"<";s:8:"nextText";s:1:">";s:6:"slices";i:15;s:6:"center";s:5:"false";s:9:"smartCrop";s:4:"true";s:12:"carouselMode";s:5:"false";s:6:"easing";s:6:"linear";s:8:"autoPlay";s:4:"true";s:11:"thumb_width";i:150;s:12:"thumb_height";i:100;s:12:"smoothHeight";s:5:"false";}') ; 
INSERT INTO `wp_postmeta` VALUES (271, 80, '_wp_attached_file', '2013/11/grass.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (272, 80, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (273, 80, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1725;s:6:"height";i:1159;s:4:"file";s:17:"2013/11/grass.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"grass-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"grass-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:18:"grass-1024x688.jpg";s:5:"width";i:1024;s:6:"height";i:688;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"grass-220x126.jpg";s:5:"width";i:220;s:6:"height";i:126;s:9:"mime-type";s:10:"image/jpeg";}s:16:"expound-featured";a:4:{s:4:"file";s:17:"grass-460x260.jpg";s:5:"width";i:460;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:12:"expound-mini";a:4:{s:4:"file";s:15:"grass-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:31:"Bowling green grass background.";}}') ; 
INSERT INTO `wp_postmeta` VALUES (274, 80, '_wp_attachment_is_custom_background', 'expound') ; 
INSERT INTO `wp_postmeta` VALUES (275, 81, '_wp_attached_file', '2013/11/grass1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (276, 81, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (277, 81, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1725;s:6:"height";i:1159;s:4:"file";s:18:"2013/11/grass1.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"grass1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"grass1-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"grass1-1024x688.jpg";s:5:"width";i:1024;s:6:"height";i:688;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:18:"grass1-220x126.jpg";s:5:"width";i:220;s:6:"height";i:126;s:9:"mime-type";s:10:"image/jpeg";}s:16:"expound-featured";a:4:{s:4:"file";s:18:"grass1-460x260.jpg";s:5:"width";i:460;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:12:"expound-mini";a:4:{s:4:"file";s:16:"grass1-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:31:"Bowling green grass background.";}}') ; 
INSERT INTO `wp_postmeta` VALUES (278, 81, '_wp_attachment_is_custom_background', 'expound') ; 
INSERT INTO `wp_postmeta` VALUES (279, 30, 'ml-slider_url', 'http://www.imdb.com') ; 
INSERT INTO `wp_postmeta` VALUES (280, 82, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (281, 82, '_edit_lock', '1384650311:1') ; 
INSERT INTO `wp_postmeta` VALUES (282, 82, '_thumbnail_id', '27') ; 
INSERT INTO `wp_postmeta` VALUES (287, 87, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (288, 87, '_edit_lock', '1387193025:1') ; 
INSERT INTO `wp_postmeta` VALUES (289, 87, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (290, 89, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (291, 89, '_edit_lock', '1387193035:1') ; 
INSERT INTO `wp_postmeta` VALUES (292, 89, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (293, 14, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (294, 14, '_wp_trash_meta_time', '1387193073') ; 
INSERT INTO `wp_postmeta` VALUES (295, 16, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (296, 16, '_wp_trash_meta_time', '1387193078') ; 
INSERT INTO `wp_postmeta` VALUES (297, 91, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (298, 91, '_edit_lock', '1387193188:1') ; 
INSERT INTO `wp_postmeta` VALUES (299, 91, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (300, 93, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (301, 93, '_edit_lock', '1387193544:1') ; 
INSERT INTO `wp_postmeta` VALUES (302, 93, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (303, 95, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (304, 95, '_edit_lock', '1387194399:1') ; 
INSERT INTO `wp_postmeta` VALUES (305, 95, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (306, 97, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (307, 97, '_edit_lock', '1387194421:1') ; 
INSERT INTO `wp_postmeta` VALUES (308, 97, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (309, 99, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (310, 99, '_edit_lock', '1387194443:1') ; 
INSERT INTO `wp_postmeta` VALUES (311, 99, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (312, 101, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (313, 101, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (314, 101, '_edit_lock', '1387195091:1') ; 
INSERT INTO `wp_postmeta` VALUES (315, 103, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (316, 103, '_edit_lock', '1387195112:1') ; 
INSERT INTO `wp_postmeta` VALUES (317, 103, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (318, 20, '_edit_lock', '1387195167:1') ; 
INSERT INTO `wp_postmeta` VALUES (319, 20, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (320, 20, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (321, 10, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (322, 10, '_edit_lock', '1387195187:1') ; 
INSERT INTO `wp_postmeta` VALUES (323, 22, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (324, 22, '_wp_trash_meta_time', '1387195197') ; 
INSERT INTO `wp_postmeta` VALUES (325, 105, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (326, 105, '_edit_lock', '1387196056:1') ; 
INSERT INTO `wp_postmeta` VALUES (327, 105, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (328, 107, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (329, 107, '_edit_lock', '1387196065:1') ; 
INSERT INTO `wp_postmeta` VALUES (330, 107, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (331, 109, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (332, 109, '_edit_lock', '1387196090:1') ; 
INSERT INTO `wp_postmeta` VALUES (333, 109, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (334, 111, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (335, 111, '_edit_lock', '1387196118:1') ; 
INSERT INTO `wp_postmeta` VALUES (336, 111, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (337, 119, '_wp_attached_file', 'claw.png') ; 
INSERT INTO `wp_postmeta` VALUES (338, 119, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:247;s:6:"height";i:248;s:4:"file";s:8:"claw.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"claw-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:16:"claw-220x126.png";s:5:"width";i:220;s:6:"height";i:126;s:9:"mime-type";s:9:"image/png";}s:12:"expound-mini";a:4:{s:4:"file";s:14:"claw-50x50.png";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (339, 119, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (340, 119, '_wp_attachment_backup_sizes', 'a:1:{s:14:"resized-247x92";a:5:{s:4:"path";s:67:"/Applications/MAMP/htdocs/tigers/wp-content/uploads/claw-247x92.png";s:4:"file";s:15:"claw-247x92.png";s:5:"width";i:247;s:6:"height";i:92;s:9:"mime-type";s:9:"image/png";}}') ; 
INSERT INTO `wp_postmeta` VALUES (341, 121, '_wp_attached_file', 'grass1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (342, 121, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (343, 121, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1725;s:6:"height";i:1159;s:4:"file";s:10:"grass1.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"grass1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"grass1-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"grass1-1024x688.jpg";s:5:"width";i:1024;s:6:"height";i:688;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:18:"grass1-220x126.jpg";s:5:"width";i:220;s:6:"height";i:126;s:9:"mime-type";s:10:"image/jpeg";}s:16:"expound-featured";a:4:{s:4:"file";s:18:"grass1-460x260.jpg";s:5:"width";i:460;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:12:"expound-mini";a:4:{s:4:"file";s:16:"grass1-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:31:"Bowling green grass background.";}}') ; 
INSERT INTO `wp_postmeta` VALUES (344, 121, '_wp_attachment_is_custom_background', 'expound') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Wednesday 15. January 2014 12:39 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (111 records)
#
 
INSERT INTO `wp_posts` VALUES (85, 1, '2013-12-16 11:23:21', '2013-12-16 11:23:21', '', 'People', '', 'publish', 'open', 'open', '', 'people', '', '', '2013-12-16 11:23:21', '2013-12-16 11:23:21', '', 0, 'http://localhost/tigers/?page_id=85', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2013-09-08 16:02:54', '2013-09-08 16:02:54', 'This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'trash', 'open', 'open', '', 'about', '', '', '2013-09-08 06:20:36', '2013-09-08 06:20:36', '', 0, 'http://localhost/tigers/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (86, 1, '2013-12-16 11:23:21', '2013-12-16 11:23:21', '', 'People', '', 'inherit', 'open', 'open', '', '85-revision-v1', '', '', '2013-12-16 11:23:21', '2013-12-16 11:23:21', '', 85, 'http://localhost/tigers/tigers/85-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (30, 1, '2013-10-20 03:16:32', '2013-10-20 03:16:32', '', 'Football', 'Great', 'inherit', 'open', 'open', '', 'football_generic', '', '', '2013-10-20 03:16:32', '2013-10-20 03:16:32', '', 29, 'http://localhost/tigers/wp-content/uploads/2013/10/football_generic.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2013-09-08 06:17:57', '2013-09-08 06:17:57', '', 'Game On', '', 'publish', 'open', 'open', '', 'game-on', '', '', '2013-11-14 10:55:28', '2013-11-14 10:55:28', '', 0, 'http://localhost/tigers/?page_id=4', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2013-09-08 06:17:57', '2013-09-08 06:17:57', '', 'Game On', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2013-09-08 06:17:57', '2013-09-08 06:17:57', '', 4, 'http://localhost/tigers/uncategorized/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6, 1, '2013-09-08 06:18:16', '2013-09-08 06:18:16', '', 'Teams', '', 'publish', 'open', 'open', '', 'teams', '', '', '2013-09-08 06:18:42', '2013-09-08 06:18:42', '', 0, 'http://localhost/tigers/?page_id=6', 1, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2013-09-08 06:18:16', '2013-09-08 06:18:16', '', 'Teams', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-09-08 06:18:16', '2013-09-08 06:18:16', '', 6, 'http://localhost/tigers/uncategorized/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2013-09-08 06:18:28', '2013-09-08 06:18:28', '', 'Registration', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-09-08 06:18:28', '2013-09-08 06:18:28', '', 6, 'http://localhost/tigers/uncategorized/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2013-09-08 06:18:42', '2013-09-08 06:18:42', '', 'Teams', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-09-08 06:18:42', '2013-09-08 06:18:42', '', 6, 'http://localhost/tigers/uncategorized/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2013-09-08 06:18:52', '2013-09-08 06:18:52', '', 'Registration', '', 'publish', 'open', 'closed', '', 'registration', '', '', '2013-12-16 11:59:47', '2013-12-16 11:59:47', '', 101, 'http://localhost/tigers/?page_id=10', 2, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2013-09-08 06:18:52', '2013-09-08 06:18:52', '', 'Registration', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2013-09-08 06:18:52', '2013-09-08 06:18:52', '', 10, 'http://localhost/tigers/uncategorized/10-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2013-09-08 06:19:07', '2013-09-08 06:19:07', '', 'Resources', '', 'publish', 'open', 'open', '', 'resources', '', '', '2013-09-08 06:19:07', '2013-09-08 06:19:07', '', 0, 'http://localhost/tigers/?page_id=12', 3, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2013-09-08 06:19:07', '2013-09-08 06:19:07', '', 'Resources', '', 'inherit', 'open', 'open', '', '12-revision-v1', '', '', '2013-09-08 06:19:07', '2013-09-08 06:19:07', '', 12, 'http://localhost/tigers/uncategorized/12-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2013-09-08 06:19:21', '2013-09-08 06:19:21', '', 'Tiger Committee', '', 'trash', 'open', 'open', '', 'tiger-committee', '', '', '2013-12-16 11:24:33', '2013-12-16 11:24:33', '', 12, 'http://localhost/tigers/?page_id=14', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2013-09-08 06:19:21', '2013-09-08 06:19:21', '', 'Tiger Committee', '', 'inherit', 'open', 'open', '', '14-revision-v1', '', '', '2013-09-08 06:19:21', '2013-09-08 06:19:21', '', 14, 'http://localhost/tigers/uncategorized/14-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (16, 1, '2013-09-08 06:19:34', '2013-09-08 06:19:34', '', 'Tiger Business', '', 'trash', 'open', 'open', '', 'tiger-business', '', '', '2013-12-16 11:24:38', '2013-12-16 11:24:38', '', 12, 'http://localhost/tigers/?page_id=16', 1, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2013-09-08 06:19:34', '2013-09-08 06:19:34', '', 'Tiger Business', '', 'inherit', 'open', 'open', '', '16-revision-v1', '', '', '2013-09-08 06:19:34', '2013-09-08 06:19:34', '', 16, 'http://localhost/tigers/uncategorized/16-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (18, 1, '2013-09-08 06:19:45', '2013-09-08 06:19:45', '', 'Ground Locations', '', 'publish', 'open', 'open', '', 'ground-locations', '', '', '2013-09-08 06:19:45', '2013-09-08 06:19:45', '', 0, 'http://localhost/tigers/?page_id=18', 5, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (19, 1, '2013-09-08 06:19:45', '2013-09-08 06:19:45', '', 'Ground Locations', '', 'inherit', 'open', 'open', '', '18-revision-v1', '', '', '2013-09-08 06:19:45', '2013-09-08 06:19:45', '', 18, 'http://localhost/tigers/uncategorized/18-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (20, 1, '2013-09-08 06:19:56', '2013-09-08 06:19:56', '', 'Trophy Room', '', 'publish', 'open', 'open', '', 'trophy-room', '', '', '2013-12-16 11:59:27', '2013-12-16 11:59:27', '', 101, 'http://localhost/tigers/?page_id=20', 6, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2013-09-08 06:19:56', '2013-09-08 06:19:56', '', 'Trophy Room', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2013-09-08 06:19:56', '2013-09-08 06:19:56', '', 20, 'http://localhost/tigers/uncategorized/20-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2013-09-08 06:20:08', '2013-09-08 06:20:08', '', 'Sponsors', '', 'trash', 'open', 'open', '', 'sponsors', '', '', '2013-12-16 11:59:57', '2013-12-16 11:59:57', '', 0, 'http://localhost/tigers/?page_id=22', 7, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (23, 1, '2013-09-08 06:20:08', '2013-09-08 06:20:08', '', 'Sponsors', '', 'inherit', 'open', 'open', '', '22-revision-v1', '', '', '2013-09-08 06:20:08', '2013-09-08 06:20:08', '', 22, 'http://localhost/tigers/uncategorized/22-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2013-09-08 06:20:19', '2013-09-08 06:20:19', '', 'Shop', '', 'publish', 'open', 'open', '', 'shop', '', '', '2013-09-08 06:20:19', '2013-09-08 06:20:19', '', 0, 'http://localhost/tigers/?page_id=24', 8, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2013-09-08 06:20:19', '2013-09-08 06:20:19', '', 'Shop', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2013-09-08 06:20:19', '2013-09-08 06:20:19', '', 24, 'http://localhost/tigers/uncategorized/24-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2013-09-08 06:20:36', '2013-09-08 06:20:36', 'This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2013-09-08 06:20:36', '2013-09-08 06:20:36', '', 2, 'http://localhost/tigers/uncategorized/2-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2013-09-09 13:06:15', '2013-09-09 13:06:15', '', 'Jam', 'Michael Jackson and Michael Jordan', 'inherit', 'open', 'open', '', 'jam', '', '', '2013-09-09 13:06:15', '2013-09-09 13:06:15', '', 62, 'http://localhost/tigers/wp-content/uploads/2013/09/Jam.jpg', 1, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2013-09-09 13:16:00', '2013-09-09 13:16:00', 'http://localhost/tigers/wp-content/uploads/2013/09/cropped-football_generic.jpg', 'cropped-football_generic.jpg', '', 'inherit', 'closed', 'open', '', 'cropped-football_generic-jpg', '', '', '2013-09-09 13:16:00', '2013-09-09 13:16:00', '', 0, 'http://localhost/tigers/wp-content/uploads/2013/09/cropped-football_generic.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (29, 1, '2013-11-13 12:17:54', '2013-11-13 12:17:54', '&nbsp;

[caption id="attachment_69" align="aligncenter" width="300"]<a href="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08.jpg"><img class="size-medium wp-image-69 " alt="Dechen Gunden = Hugh Jackman" src="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08-300x300.jpg" width="300" height="300" /></a> Dechen Gunden = Hugh Jackman[/caption]', 'Test Hee Hee', '', 'publish', 'open', 'open', '', 'test-hee-hee', '', '', '2013-11-14 13:22:43', '2013-11-14 13:22:43', '', 0, 'http://localhost/tigers/?p=29', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2013-10-20 03:16:43', '2013-10-20 03:16:43', '<a href="http://localhost/tigers/wp-content/uploads/2013/10/football_generic.jpg"><img class="alignnone size-medium wp-image-30" alt="football_generic" src="http://localhost/tigers/wp-content/uploads/2013/10/football_generic-300x34.jpg" width="300" height="34" /></a>', '', '', 'inherit', 'open', 'open', '', '29-revision-v1', '', '', '2013-10-20 03:16:43', '2013-10-20 03:16:43', '', 29, 'http://localhost/tigers/uncategorized/29-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (32, 1, '2013-10-20 03:17:58', '2013-10-20 03:17:58', '', 'map-malaysia600', '', 'inherit', 'open', 'open', '', 'map-malaysia600', '', '', '2013-10-20 03:17:58', '2013-10-20 03:17:58', '', 29, 'http://localhost/tigers/wp-content/uploads/2013/10/map-malaysia600.gif', 0, 'attachment', 'image/gif', 0) ; 
INSERT INTO `wp_posts` VALUES (34, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=34', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (35, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=35', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (36, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=36', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (37, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=37', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (38, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=38', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (39, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 12, 'http://localhost/tigers/?p=39', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (40, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 12, 'http://localhost/tigers/?p=40', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=41', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (42, 1, '2013-11-12 13:04:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:18', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=42', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (43, 1, '2013-11-12 13:04:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:18', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=43', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (44, 1, '2013-11-12 13:04:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:18', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=44', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (87, 1, '2013-12-16 11:23:44', '2013-12-16 11:23:44', '', 'Committee', '', 'publish', 'open', 'open', '', 'committee', '', '', '2013-12-16 11:23:44', '2013-12-16 11:23:44', '', 85, 'http://localhost/tigers/?page_id=87', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (47, 1, '2013-11-13 12:17:54', '2013-11-13 12:17:54', '<a href="http://localhost/tigers/wp-content/uploads/2013/10/football_generic.jpg"><img class="alignnone size-medium wp-image-30" alt="football_generic" src="http://localhost/tigers/wp-content/uploads/2013/10/football_generic-300x34.jpg" width="300" height="34" /></a>', 'Test Hee Hee', '', 'inherit', 'open', 'open', '', '29-revision-v1', '', '', '2013-11-13 12:17:54', '2013-11-13 12:17:54', '', 29, 'http://localhost/tigers/uncategorized/29-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (48, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=48', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (49, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=49', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (50, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=50', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (51, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=51', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (52, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=52', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (53, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 12, 'http://localhost/tigers/?p=53', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (54, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 12, 'http://localhost/tigers/?p=54', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (55, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=55', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (56, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=56', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (57, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=57', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (58, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=58', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (59, 1, '2013-11-13 12:28:25', '2013-11-13 12:28:25', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit "Send"]</p>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://localhost/tigers)
andy.tan2624@gmail.com


0

[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://localhost/tigers)
[your-email]


0
Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.', 'Contact form 1', '', 'publish', 'open', 'open', '', 'contact-form-1', '', '', '2013-11-13 12:28:25', '2013-11-13 12:28:25', '', 0, 'http://localhost/tigers/?post_type=wpcf7_contact_form&p=59', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (60, 1, '2013-11-13 12:29:57', '2013-11-13 12:29:57', '[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'draft', 'open', 'open', '', 'contact', '', '', '2013-12-16 12:16:23', '2013-12-16 12:16:23', '', 0, 'http://localhost/tigers/?page_id=60', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (61, 1, '2013-11-13 12:29:57', '2013-11-13 12:29:57', '[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '60-revision-v1', '', '', '2013-11-13 12:29:57', '2013-11-13 12:29:57', '', 60, 'http://localhost/tigers/uncategorized/60-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (62, 1, '2013-11-13 12:43:11', '2013-11-13 12:43:11', 'Bloody Akiva Goldsman, you ruined Batman

[caption id="attachment_27" align="alignnone" width="300"]<a href="http://localhost/tigers/wp-content/uploads/2013/09/Jam.jpg"><img class="size-medium wp-image-27" alt="Michael Jackson and Michael Jordan" src="http://localhost/tigers/wp-content/uploads/2013/09/Jam-300x278.jpg" width="300" height="278" /></a> Michael Jackson and Michael Jordan[/caption]', 'The Second Post', '', 'publish', 'open', 'open', '', 'the-second-post', '', '', '2013-12-20 14:31:07', '2013-12-20 14:31:07', '', 0, 'http://localhost/tigers/?p=62', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (63, 1, '2013-11-13 12:43:11', '2013-11-13 12:43:11', 'Bloody Akiva Goldsman, you ruined Batman

[caption id="attachment_27" align="alignnone" width="300"]<a href="http://localhost/tigers/wp-content/uploads/2013/09/Jam.jpg"><img class="size-medium wp-image-27" alt="Michael Jackson and Michael Jordan" src="http://localhost/tigers/wp-content/uploads/2013/09/Jam-300x278.jpg" width="300" height="278" /></a> Michael Jackson and Michael Jordan[/caption]', 'The Second Post', '', 'inherit', 'open', 'open', '', '62-revision-v1', '', '', '2013-11-13 12:43:11', '2013-11-13 12:43:11', '', 62, 'http://localhost/tigers/uncategorized/62-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (64, 1, '2013-11-14 11:36:37', '2013-11-14 11:36:37', 'Mary J blige', 'Just Fine', '', 'publish', 'open', 'open', '', 'just-fine', '', '', '2013-11-14 11:36:37', '2013-11-14 11:36:37', '', 0, 'http://localhost/tigers/?p=64', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (65, 1, '2013-11-14 11:36:37', '2013-11-14 11:36:37', 'Mary J blige', 'Just Fine', '', 'inherit', 'open', 'open', '', '64-revision-v1', '', '', '2013-11-14 11:36:37', '2013-11-14 11:36:37', '', 64, 'http://localhost/tigers/uncategorized/64-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (66, 1, '2013-11-14 11:37:42', '2013-11-14 11:37:42', 'They are the best team in the world', 'Canberra Raiders', '', 'publish', 'open', 'open', '', 'canberra-raiders', '', '', '2013-11-15 00:20:41', '2013-11-15 00:20:41', '', 0, 'http://localhost/tigers/?p=66', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (67, 1, '2013-11-14 11:37:42', '2013-11-14 11:37:42', 'They are the best team in the world', 'Canberra Raiders', '', 'inherit', 'open', 'open', '', '66-revision-v1', '', '', '2013-11-14 11:37:42', '2013-11-14 11:37:42', '', 66, 'http://localhost/tigers/tigers/66-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (68, 1, '2013-11-14 11:38:50', '2013-11-14 11:38:50', 'is the best dancer in the world

[caption id="attachment_69" align="alignnone" width="210"]<a href="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08.jpg"><img class=" wp-image-69 " alt="Dechen Gunden = Hugh Jackman" src="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08-300x300.jpg" width="210" height="210" /></a> Dechen Gunden = Hugh Jackman[/caption]', 'Dechen Gunden', '', 'publish', 'open', 'open', '', 'dechen-gunden', '', '', '2013-11-14 11:38:50', '2013-11-14 11:38:50', '', 0, 'http://localhost/tigers/?p=68', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (69, 1, '2013-11-14 11:38:17', '2013-11-14 11:38:17', '', 'Les Miserables', 'Dechen Gunden = Hugh Jackman', 'inherit', 'open', 'open', '', 'les-miserables-image08', '', '', '2013-11-14 11:38:17', '2013-11-14 11:38:17', '', 68, 'http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08.jpg', 2, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (70, 1, '2013-11-14 11:38:50', '2013-11-14 11:38:50', 'is the best dancer in the world

[caption id="attachment_69" align="alignnone" width="210"]<a href="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08.jpg"><img class=" wp-image-69 " alt="Dechen Gunden = Hugh Jackman" src="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08-300x300.jpg" width="210" height="210" /></a> Dechen Gunden = Hugh Jackman[/caption]', 'Dechen Gunden', '', 'inherit', 'open', 'open', '', '68-revision-v1', '', '', '2013-11-14 11:38:50', '2013-11-14 11:38:50', '', 68, 'http://localhost/tigers/tigers/68-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (71, 1, '2013-11-14 11:39:57', '2013-11-14 11:39:57', 'Which is the best dance studio? We tell you after these breaks', 'Crossover or Dancekool', '', 'publish', 'open', 'open', '', 'crossover-or-dancekool', '', '', '2013-11-15 00:20:13', '2013-11-15 00:20:13', '', 0, 'http://localhost/tigers/?p=71', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (72, 1, '2013-11-14 11:39:57', '2013-11-14 11:39:57', 'Which is the best dance studio? We tell you after these breaks', 'Crossover or Dancekool', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2013-11-14 11:39:57', '2013-11-14 11:39:57', '', 71, 'http://localhost/tigers/tigers/71-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (75, 1, '2013-11-14 13:22:43', '2013-11-14 13:22:43', '&nbsp;

[caption id="attachment_69" align="aligncenter" width="300"]<a href="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08.jpg"><img class="size-medium wp-image-69 " alt="Dechen Gunden = Hugh Jackman" src="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08-300x300.jpg" width="300" height="300" /></a> Dechen Gunden = Hugh Jackman[/caption]', 'Test Hee Hee', '', 'inherit', 'open', 'open', '', '29-revision-v1', '', '', '2013-11-14 13:22:43', '2013-11-14 13:22:43', '', 29, 'http://localhost/tigers/tigers/29-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (73, 1, '2013-11-14 13:00:50', '2013-11-14 13:00:50', '&nbsp;

[caption id="attachment_69" align="alignright" width="300"]<a href="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08.jpg"><img class="size-medium wp-image-69 " alt="Dechen Gunden = Hugh Jackman" src="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08-300x300.jpg" width="300" height="300" /></a> Dechen Gunden = Hugh Jackman[/caption]

<a href="http://localhost/tigers/wp-content/uploads/2013/10/football_generic.jpg"><img class="alignnone size-medium wp-image-30" alt="football_generic" src="http://localhost/tigers/wp-content/uploads/2013/10/football_generic-300x34.jpg" width="300" height="34" /></a>', 'Test Hee Hee', '', 'inherit', 'open', 'open', '', '29-revision-v1', '', '', '2013-11-14 13:00:50', '2013-11-14 13:00:50', '', 29, 'http://localhost/tigers/tigers/29-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (74, 1, '2013-11-14 13:07:51', '2013-11-14 13:07:51', '', 'football_generic', '', 'inherit', 'open', 'open', '', 'football_generic-2', '', '', '2013-11-14 13:07:51', '2013-11-14 13:07:51', '', 0, 'http://localhost/tigers/wp-content/uploads/2013/11/football_generic.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (76, 1, '2013-11-16 21:28:07', '2013-11-16 21:28:07', '', 'Home Page', '', 'publish', 'open', 'open', '', 'new-slider', '', '', '2013-11-17 01:04:44', '2013-11-17 01:04:44', '', 0, 'http://localhost/tigers/?post_type=ml-slider&#038;p=76', 0, 'ml-slider', '', 0) ; 
INSERT INTO `wp_posts` VALUES (77, 1, '2013-11-16 21:29:19', '2013-11-16 21:29:19', '', 'New Slider', '', 'publish', 'open', 'open', '', 'new-slider-2', '', '', '2013-11-16 21:29:19', '2013-11-16 21:29:19', '', 0, 'http://localhost/tigers/?post_type=ml-slider&p=77', 0, 'ml-slider', '', 0) ; 
INSERT INTO `wp_posts` VALUES (121, 1, '2014-01-02 12:39:47', '2014-01-02 12:39:47', '', 'Bowling green grass background.', '', 'inherit', 'open', 'open', '', 'bowling-green-grass-background-3', '', '', '2014-01-02 12:39:47', '2014-01-02 12:39:47', '', 0, 'http://localhost/tigers/wp-content/uploads/grass1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (88, 1, '2013-12-16 11:23:44', '2013-12-16 11:23:44', '', 'Committee', '', 'inherit', 'open', 'open', '', '87-revision-v1', '', '', '2013-12-16 11:23:44', '2013-12-16 11:23:44', '', 87, 'http://localhost/tigers/tigers/87-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (80, 1, '2013-11-16 22:24:53', '2013-11-16 22:24:53', '', 'Bowling green grass background.', '', 'inherit', 'open', 'open', '', 'bowling-green-grass-background', '', '', '2013-11-16 22:24:53', '2013-11-16 22:24:53', '', 0, 'http://localhost/tigers/wp-content/uploads/2013/11/grass.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (81, 1, '2013-11-16 22:25:05', '2013-11-16 22:25:05', '', 'Bowling green grass background.', '', 'inherit', 'open', 'open', '', 'bowling-green-grass-background-2', '', '', '2013-11-16 22:25:05', '2013-11-16 22:25:05', '', 0, 'http://localhost/tigers/wp-content/uploads/2013/11/grass1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (82, 1, '2013-11-17 01:06:38', '2013-11-17 01:06:38', 'Something somethingdsfsdfsd4sdfsd

sdfsdf

sdfsdf

sdfsd

fds', 'Be an umpire', '', 'publish', 'open', 'open', '', 'be-an-umpire', '', '', '2013-11-17 01:06:38', '2013-11-17 01:06:38', '', 0, 'http://localhost/tigers/?p=82', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (83, 1, '2013-11-17 01:06:38', '2013-11-17 01:06:38', 'Something somethingdsfsdfsd4sdfsd

sdfsdf

sdfsdf

sdfsd

fds', 'Be an umpire', '', 'inherit', 'open', 'open', '', '82-revision-v1', '', '', '2013-11-17 01:06:38', '2013-11-17 01:06:38', '', 82, 'http://localhost/tigers/tigers/82-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (89, 1, '2013-12-16 11:23:55', '2013-12-16 11:23:55', '', 'Coaches', '', 'publish', 'open', 'open', '', 'coaches', '', '', '2013-12-16 11:23:55', '2013-12-16 11:23:55', '', 85, 'http://localhost/tigers/?page_id=89', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (90, 1, '2013-12-16 11:23:55', '2013-12-16 11:23:55', '', 'Coaches', '', 'inherit', 'open', 'open', '', '89-revision-v1', '', '', '2013-12-16 11:23:55', '2013-12-16 11:23:55', '', 89, 'http://localhost/tigers/tigers/89-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (91, 1, '2013-12-16 11:26:28', '2013-12-16 11:26:28', '', 'Volunteer Positions', '', 'publish', 'open', 'open', '', 'volunteer-positions', '', '', '2013-12-16 11:26:28', '2013-12-16 11:26:28', '', 12, 'http://localhost/tigers/?page_id=91', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (92, 1, '2013-12-16 11:26:28', '2013-12-16 11:26:28', '', 'Volunteer Positions', '', 'inherit', 'open', 'open', '', '91-revision-v1', '', '', '2013-12-16 11:26:28', '2013-12-16 11:26:28', '', 91, 'http://localhost/tigers/tigers/91-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (93, 1, '2013-12-16 11:32:24', '2013-12-16 11:32:24', '', 'Forms and Documents', '', 'publish', 'open', 'open', '', 'forms-and-documents', '', '', '2013-12-16 11:32:24', '2013-12-16 11:32:24', '', 12, 'http://localhost/tigers/?page_id=93', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (94, 1, '2013-12-16 11:32:24', '2013-12-16 11:32:24', '', 'Forms and Documents', '', 'inherit', 'open', 'open', '', '93-revision-v1', '', '', '2013-12-16 11:32:24', '2013-12-16 11:32:24', '', 93, 'http://localhost/tigers/tigers/93-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (95, 1, '2013-12-16 11:46:39', '2013-12-16 11:46:39', '', 'Mission Statement', '', 'publish', 'open', 'open', '', 'mission-statement', '', '', '2013-12-16 11:46:39', '2013-12-16 11:46:39', '', 12, 'http://localhost/tigers/?page_id=95', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (96, 1, '2013-12-16 11:46:39', '2013-12-16 11:46:39', '', 'Mission Statement', '', 'inherit', 'open', 'open', '', '95-revision-v1', '', '', '2013-12-16 11:46:39', '2013-12-16 11:46:39', '', 95, 'http://localhost/tigers/tigers/95-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (97, 1, '2013-12-16 11:47:00', '2013-12-16 11:47:00', '', 'Ladder', '', 'publish', 'open', 'open', '', 'ladder', '', '', '2013-12-16 11:47:00', '2013-12-16 11:47:00', '', 4, 'http://localhost/tigers/?page_id=97', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (98, 1, '2013-12-16 11:47:00', '2013-12-16 11:47:00', '', 'Ladder', '', 'inherit', 'open', 'open', '', '97-revision-v1', '', '', '2013-12-16 11:47:00', '2013-12-16 11:47:00', '', 97, 'http://localhost/tigers/tigers/97-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (99, 1, '2013-12-16 11:47:23', '2013-12-16 11:47:23', '', 'Results', '', 'publish', 'open', 'open', '', 'results', '', '', '2013-12-16 11:47:23', '2013-12-16 11:47:23', '', 4, 'http://localhost/tigers/?page_id=99', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (100, 1, '2013-12-16 11:47:23', '2013-12-16 11:47:23', '', 'Results', '', 'inherit', 'open', 'open', '', '99-revision-v1', '', '', '2013-12-16 11:47:23', '2013-12-16 11:47:23', '', 99, 'http://localhost/tigers/tigers/99-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (101, 1, '2013-12-16 11:58:11', '2013-12-16 11:58:11', '', 'Tiger Den', '', 'publish', 'open', 'open', '', 'tiger-den', '', '', '2013-12-16 11:58:11', '2013-12-16 11:58:11', '', 0, 'http://localhost/tigers/?page_id=101', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (102, 1, '2013-12-16 11:58:11', '2013-12-16 11:58:11', '', 'Tiger Den', '', 'inherit', 'open', 'open', '', '101-revision-v1', '', '', '2013-12-16 11:58:11', '2013-12-16 11:58:11', '', 101, 'http://localhost/tigers/tigers/101-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (103, 1, '2013-12-16 11:58:31', '2013-12-16 11:58:31', '', 'Gallery', '', 'publish', 'open', 'open', '', 'gallery', '', '', '2013-12-16 11:58:31', '2013-12-16 11:58:31', '', 101, 'http://localhost/tigers/?page_id=103', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (104, 1, '2013-12-16 11:58:31', '2013-12-16 11:58:31', '', 'Gallery', '', 'inherit', 'open', 'open', '', '103-revision-v1', '', '', '2013-12-16 11:58:31', '2013-12-16 11:58:31', '', 103, 'http://localhost/tigers/tigers/103-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (105, 1, '2013-12-16 12:14:16', '2013-12-16 12:14:16', '', 'Song History', '', 'publish', 'open', 'open', '', 'song-history', '', '', '2013-12-16 12:14:16', '2013-12-16 12:14:16', '', 101, 'http://localhost/tigers/?page_id=105', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (106, 1, '2013-12-16 12:14:16', '2013-12-16 12:14:16', '', 'Song History', '', 'inherit', 'open', 'open', '', '105-revision-v1', '', '', '2013-12-16 12:14:16', '2013-12-16 12:14:16', '', 105, 'http://localhost/tigers/tigers/105-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (107, 1, '2013-12-16 12:14:25', '2013-12-16 12:14:25', '', 'Clearance', '', 'publish', 'open', 'open', '', 'clearance', '', '', '2013-12-16 12:14:25', '2013-12-16 12:14:25', '', 101, 'http://localhost/tigers/?page_id=107', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (108, 1, '2013-12-16 12:14:25', '2013-12-16 12:14:25', '', 'Clearance', '', 'inherit', 'open', 'open', '', '107-revision-v1', '', '', '2013-12-16 12:14:25', '2013-12-16 12:14:25', '', 107, 'http://localhost/tigers/tigers/107-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (109, 1, '2013-12-16 12:14:50', '2013-12-16 12:14:50', '', 'Tiger Premiership', '', 'publish', 'open', 'open', '', 'tiger-premiership', '', '', '2013-12-16 12:14:50', '2013-12-16 12:14:50', '', 101, 'http://localhost/tigers/?page_id=109', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (110, 1, '2013-12-16 12:14:50', '2013-12-16 12:14:50', '', 'Tiger Premiership', '', 'inherit', 'open', 'open', '', '109-revision-v1', '', '', '2013-12-16 12:14:50', '2013-12-16 12:14:50', '', 109, 'http://localhost/tigers/tigers/109-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (111, 1, '2013-12-16 12:15:18', '2013-12-16 12:15:18', '', 'Life Time Moniker', '', 'publish', 'open', 'open', '', 'life-time-moniker', '', '', '2013-12-16 12:15:18', '2013-12-16 12:15:18', '', 101, 'http://localhost/tigers/?page_id=111', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (112, 1, '2013-12-16 12:15:18', '2013-12-16 12:15:18', '', 'Life Time Moniker', '', 'inherit', 'open', 'open', '', '111-revision-v1', '', '', '2013-12-16 12:15:18', '2013-12-16 12:15:18', '', 111, 'http://localhost/tigers/tigers/111-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (114, 1, '2013-12-20 14:32:06', '2013-12-20 14:32:06', 'WORK GOD DAMN IT', 'LINZA POWER', '', 'publish', 'open', 'open', '', 'linza-power', '', '', '2013-12-20 14:32:06', '2013-12-20 14:32:06', '', 0, 'http://localhost/tigers/?p=114', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (115, 1, '2013-12-20 14:32:06', '2013-12-20 14:32:06', 'WORK GOD DAMN IT', 'LINZA POWER', '', 'inherit', 'open', 'open', '', '114-revision-v1', '', '', '2013-12-20 14:32:06', '2013-12-20 14:32:06', '', 114, 'http://localhost/tigers/tigers/114-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (116, 1, '2013-12-20 14:32:44', '2013-12-20 14:32:44', 'dsfsodjfosdjfoisdhfoisdhjoifsd', 'Something something', '', 'publish', 'open', 'open', '', 'something-something', '', '', '2013-12-21 00:35:12', '2013-12-21 00:35:12', '', 0, 'http://localhost/tigers/?p=116', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (117, 1, '2013-12-20 14:32:44', '2013-12-20 14:32:44', 'dsfsodjfosdjfoisdhfoisdhjoifsd', 'Something something', '', 'inherit', 'open', 'open', '', '116-revision-v1', '', '', '2013-12-20 14:32:44', '2013-12-20 14:32:44', '', 116, 'http://localhost/tigers/tigers/116-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (122, 1, '2014-01-12 11:25:26', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-01-12 11:25:26', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=122', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (119, 1, '2013-12-22 13:21:22', '2013-12-22 13:21:22', '', 'claw', '', 'inherit', 'open', 'open', '', 'claw', '', '', '2013-12-22 13:21:22', '2013-12-22 13:21:22', '', 0, 'http://localhost/tigers/wp-content/uploads/claw.png', 1, 'attachment', 'image/png', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Wednesday 15. January 2014 12:39 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (22 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (3, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (4, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (6, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (29, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (62, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (64, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (66, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (68, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (68, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (71, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (29, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (71, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (66, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (66, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (62, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (62, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (119, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (82, 1, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Wednesday 15. January 2014 12:39 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (8 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'link_category', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'post_format', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (6, 6, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (7, 7, 'ml-slider', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (8, 8, 'ml-slider', '', 0, 0) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Wednesday 15. January 2014 12:39 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (8 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Tigers', 'tigers', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Blogroll', 'blogroll', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'post-format-image', 'post-format-image', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'Raiders', 'raiders', 0) ; 
INSERT INTO `wp_terms` VALUES (5, 'Dechen', 'dechen', 0) ; 
INSERT INTO `wp_terms` VALUES (6, 'Gendun', 'gendun', 0) ; 
INSERT INTO `wp_terms` VALUES (7, '76', '76', 0) ; 
INSERT INTO `wp_terms` VALUES (8, '77', '77', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Wednesday 15. January 2014 12:39 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (22 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', 'Andy') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', 'Tan') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', 'I\'m a web developer') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'aim', '') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'yim', '') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'jabber', '') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '122') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_customize_current_theme_link,wp350_media,wp360_revisions') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'wp_user-settings', 'editor=tinymce&hidetb=1&libraryContent=browse&uploader=1') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'wp_user-settings-time', '1387716727') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}') ; 
INSERT INTO `wp_usermeta` VALUES (21, 1, 'meta-box-order_post', 'a:3:{s:4:"side";s:61:"submitdiv,formatdiv,categorydiv,tagsdiv-post_tag,postimagediv";s:6:"normal";s:96:"revisionsdiv,postexcerpt,trackbacksdiv,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}') ; 
INSERT INTO `wp_usermeta` VALUES (22, 1, 'screen_layout_post', '2') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Wednesday 15. January 2014 12:39 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'andy.tan2624', '$P$BIJNjFU5EZ3u/C/wMhI3gi1h/BfdvK1', 'admin', 'andy.tan2624@gmail.com', '', '2013-09-07 12:44:34', '', 0, 'andy.tan2624') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

