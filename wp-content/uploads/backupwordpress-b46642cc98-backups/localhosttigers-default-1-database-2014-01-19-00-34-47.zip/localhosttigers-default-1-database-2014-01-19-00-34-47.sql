# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Sunday 19. January 2014 00:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Sunday 19. January 2014 00:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (0 records)
#

#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Sunday 19. January 2014 00:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (7 records)
#
 
INSERT INTO `wp_links` VALUES (1, 'http://codex.wordpress.org/', 'Documentation', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (2, 'http://wordpress.org/development/', 'WordPress Blog', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', 'http://wordpress.org/development/feed/') ; 
INSERT INTO `wp_links` VALUES (3, 'http://wordpress.org/extend/ideas/', 'Suggest Ideas', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (4, 'http://wordpress.org/support/', 'Support Forum', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (5, 'http://wordpress.org/extend/plugins/', 'Plugins', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (6, 'http://wordpress.org/extend/themes/', 'Themes', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (7, 'http://planet.wordpress.org/', 'WordPress Planet', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ;
#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Sunday 19. January 2014 00:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=1906 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (190 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'Gosford Tigers Junior AFL', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'andy.tan2624@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'links_recently_updated_prepend', '<em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'links_recently_updated_append', '</em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'links_recently_updated_time', '120', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'comment_moderation', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'permalink_structure', '/%category%/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (36, 'active_plugins', 'a:9:{i:0;s:19:"akismet/akismet.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:3;s:36:"contact-form-7/wp-contact-form-7.php";i:4;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:5;s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";i:6;s:30:"lightbox-plus/lightboxplus.php";i:7;s:45:"limit-login-attempts/limit-login-attempts.php";i:8;s:23:"ml-slider/ml-slider.php";i:9;s:40:"twitter-widget-pro/wp-twitter-widget.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'home', 'http://localhost/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (41, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'recently_edited', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'template', 'expound', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'stylesheet', 'expound', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (49, 'comment_registration', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'db_version', '25824', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'uploads_use_yearmonth_folders', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'upload_path', 'wp-content/uploads', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'blog_public', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'avatar_default', 'retro', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'image_default_link_type', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'close_comments_for_old_posts', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'page_comments', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (83, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'embed_size_w', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'embed_size_h', '600', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'page_on_front', '4', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:4:"Yeah";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (101, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:5:{i:0;s:8:"search-2";i:1;s:6:"meta-2";i:2;s:10:"archives-2";i:3;s:12:"categories-2";i:4;s:17:"recent-comments-2";}s:9:"sidebar-1";a:2:{i:0;s:9:"twitter-2";i:1;s:14:"recent-posts-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (646, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (102, 'ftp_credentials', 'a:3:{s:8:"hostname";s:9:"localhost";s:8:"username";N;s:15:"connection_type";s:3:"ftp";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (103, 'uninstall_plugins', 'a:2:{s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";s:22:"hupso_plugin_uninstall";s:30:"lightbox-plus/lightboxplus.php";s:12:"UninstallLBP";}', 'no') ; 
INSERT INTO `wp_options` VALUES (104, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, 'link_manager_enabled', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, 'initial_db_version', '15260', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (108, 'cron', 'a:7:{i:1390099483;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1390099614;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1390101379;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1390114800;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1390172400;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1390518000;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (760, '_transient_timeout_feed_c809918297b2c893fd8504c06adcaf00', '1384557928', 'no') ; 
INSERT INTO `wp_options` VALUES (476, '_site_transient_timeout_browser_00760e848c8aef5785b4a3f89f42352c', '1384866155', 'yes') ; 
INSERT INTO `wp_options` VALUES (118, 'limit_login_retries', 'a:1:{s:15:"211.110.140.155";i:8;}', 'no') ; 
INSERT INTO `wp_options` VALUES (119, 'limit_login_retries_valid', 'a:1:{s:15:"211.110.140.155";i:1384911769;}', 'no') ; 
INSERT INTO `wp_options` VALUES (120, '_transient_random_seed', '6d3e0af83b1493a3c98f079a43ad6d71', 'yes') ; 
INSERT INTO `wp_options` VALUES (123, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:23:"http://localhost/tigers";s:4:"link";s:99:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://localhost/tigers/";s:3:"url";s:132:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://localhost/tigers/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:26:"http://wordpress.org/news/";s:3:"url";s:31:"http://wordpress.org/news/feed/";s:5:"title";s:14:"WordPress Blog";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:28:"http://planet.wordpress.org/";s:3:"url";s:33:"http://planet.wordpress.org/feed/";s:5:"title";s:20:"Other WordPress News";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1398, '_transient_timeout_feed_808390979aa7eed5a9c06ad6a9dd19d0', '1387234104', 'no') ; 
INSERT INTO `wp_options` VALUES (1399, '_transient_feed_808390979aa7eed5a9c06ad6a9dd19d0', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:4:"
  
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:33:"
    
    
    
    
    
    
  ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"link:http://localhost/tigers/ - Google Blog Search";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://www.google.com/search?ie=utf-8&q=link:http://localhost/tigers/&tbm=blg&tbs=sbd:1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:81:"Your search - <b>link:http://localhost/tigers/</b> - did not match any documents.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://a9.com/-/spec/opensearch/1.1/";a:3:{s:12:"totalResults";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:10:"startIndex";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:12:"itemsPerPage";a:1:{i:0;a:5:{s:4:"data";s:2:"10";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:28:"text/xml; charset=ISO-8859-1";s:4:"date";s:29:"Mon, 16 Dec 2013 10:48:14 GMT";s:7:"expires";s:2:"-1";s:13:"cache-control";s:18:"private, max-age=0";s:10:"set-cookie";a:2:{i:0;s:143:"PREF=ID=f870726bf488e2a9:FF=0:TM=1387190894:LM=1387190894:S=Rvy7K9i0V9ZZWxCl; expires=Wed, 16-Dec-2015 10:48:14 GMT; path=/; domain=.google.com";i:1;s:212:"NID=67=f5dsaSHM5EbIOdIBpIj7qywM0O597XrX8LNfytRe7aL4ouzmUox1qQt5tgVPvLOxDPWZjDfJUgDZID9SM_75Y0cxGFB0Am7gLJtqYrchxZfNCCfJsISq5QVOL382WeTP; expires=Tue, 17-Jun-2014 10:48:14 GMT; path=/; domain=.google.com; HttpOnly";}s:3:"p3p";s:122:"CP="This is not a P3P policy! See http://www.google.com/support/accounts/bin/answer.py?hl=en&answer=151657 for more info."";s:6:"server";s:3:"gws";s:16:"x-xss-protection";s:13:"1; mode=block";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20131111120855";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1400, '_transient_timeout_feed_mod_808390979aa7eed5a9c06ad6a9dd19d0', '1387234104', 'no') ; 
INSERT INTO `wp_options` VALUES (1401, '_transient_feed_mod_808390979aa7eed5a9c06ad6a9dd19d0', '1387190904', 'no') ; 
INSERT INTO `wp_options` VALUES (977, 'limit_login_lockouts', 'a:1:{s:15:"211.110.140.155";i:1384869769;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (853, 'ml-slider_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (761, '_transient_feed_c809918297b2c893fd8504c06adcaf00', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:50:"
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"WebDevStudios.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:24:"http://webdevstudios.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:40:"WordPress Website Development and Design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 20:25:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=3.6.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"WDS Welcomes Cristina Cannon!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://webdevstudios.com/2013/11/14/wds-welcomes-cristina-cannon/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:74:"http://webdevstudios.com/2013/11/14/wds-welcomes-cristina-cannon/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 20:25:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:13:"WebDevStudios";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7909";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:406:"WebDevStudios is happy to announce our newest member of the team, Cristina, who will be taking on the role of Project Manager! Cristina Cannon has over 6 years of experience in project management; running new business projects and full marketing &#8230; <a class="more-link" href="http://webdevstudios.com/2013/11/14/wds-welcomes-cristina-cannon/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1537:"<p>WebDevStudios is happy to announce our newest member of the team, Cristina, who will be taking on the role of Project Manager!</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2013/11/CMC2.png"><img class="alignleft size-full wp-image-7905" alt="CMC2" src="http://webdevstudios.com/wp-content/uploads/2013/11/CMC2.png" width="210" height="230" /></a><a title="Cristina Cannon" href="http://webdevstudios.com/team/cristina-cannon/">Cristina Cannon</a> has over 6 years of experience in project management; running new business projects and full marketing campaigns within digital media, SEO, email, website development and database management &#8211; across multiple industries. Cristina has demonstrated a unique ability for problem solving and her strong leadership skills bring passion, reliability, and innovation to WDS, which is imperative for project success. Because of her energetic and collaborative style, Cristina will be a great addition to the WDS team! Cristina is excited to expand on her website development knowledge and learn WordPress inside and out.</p>
<p>After living in NJ for over a decade she recently moved to St. Louis to be closer to family. She have a 17-month old son, Trystan and wonderful boyfriend Jason. In her spare time she likes to read, hike, snowboard, dabble in yoga and go to the park with her awesome son!</p>
<p>WDS is excited to welcome Cristina to our ever growing team. Project management is an extremely important part of our business and we know she is going to rock it!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:70:"http://webdevstudios.com/2013/11/14/wds-welcomes-cristina-cannon/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Products We Love: Sucuri Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://webdevstudios.com/2013/11/07/products-we-love-sucuri-security/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:78:"http://webdevstudios.com/2013/11/07/products-we-love-sucuri-security/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 18:56:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:16:"Products We Love";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"Sucuri";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7893";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:419:"Sucuri Security is a security-based company ran by Dre Armeda, Daniel Cid, and Tony Perez. They specialize in keeping websites secure and clean of hacks and offer services such as Monitoring, Alerting, and Removal. They also feature a Website Application &#8230; <a class="more-link" href="http://webdevstudios.com/2013/11/07/products-we-love-sucuri-security/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2798:"<p><img class="alignleft size-medium wp-image-7896" alt="Screenshot_on_11.7.2013_at_10.52.06_AM" src="http://webdevstudios.com/wp-content/uploads/2013/11/Screenshot_on_11.7.2013_at_10.52.06_AM-300x247.png" width="300" height="247" /><a title="Website Security Monitoring" href="http://sucuri.net/">Sucuri Security</a> is a security-based company ran by <a href="https://twitter.com/dremeda">Dre Armeda</a>, <a href="https://twitter.com/danielcid">Daniel Cid</a>, and <a href="https://twitter.com/perezbox">Tony Perez</a>. They specialize in keeping websites secure and clean of hacks and offer services such as Monitoring, Alerting, and Removal. They also feature a Website Application Firewall and Website Backups. You can find the complete details on what services they offer on their <a href="http://sucuri.net/services">Services page</a>.</p>
<p>We use their services for all of our websites including the one you are on right now- WebDevStudios.com. We know that our site is being monitored by <a href="http://sucuri.net/">Sucuri</a> 24/7, which gives us peace of mind. Also, if we were to be hacked, <a href="http://sucuri.net/">Sucuri</a> would alert us of the issue right away, and it&#8217;s good to know that we have that security bla<a href="http://webdevstudios.com/wp-content/uploads/2013/11/Screenshot_on_11.7.2013_at_11.10.35_AM.png"><img class="alignright size-medium wp-image-7897" alt="Screenshot_on_11.7.2013_at_11.10.35_AM" src="http://webdevstudios.com/wp-content/uploads/2013/11/Screenshot_on_11.7.2013_at_11.10.35_AM-250x300.png" width="250" height="300" /></a>nket in place.</p>
<p>Sucuri offers a free <a href="http://sitecheck.sucuri.net/scanner/">website security scanner</a> that everyone should take advantage of. This scanner allows you to check for blacklisting status, out-of-date software, known malware and website errors if your site is on WordPress or any other platform.</p>
<p>Anyone who has attended one of <a href="http://wordpress.tv/2013/06/24/brad-williams-security/">Brad Williams&#8217; security presentations</a> at WordCamp, know that he is extremely knowledgeable in the best practices of WordPress website security and he cannot say enough good things about using <a href="http://webdevstudios.com/go/sucuri">Sucuri</a> for your website. He says:</p>
<blockquote><p>&#8220;Sucuri is a service anyone serious about their website should have.&#8221;</p></blockquote>
<p>Here at WebDevStudios, we recommend to all of our clients that they sign up Sucuri monitoring services because we strongly trust in their capabilities as a company. If you&#8217;re looking to have affordable peace of mind for your website security, check out <a href="http://sucuri.net/">Sucuri Security</a> today. We promise you won&#8217;t be disappointed!</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:74:"http://webdevstudios.com/2013/11/07/products-we-love-sucuri-security/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"Announcing the PayPal Pro add-on for iThemes Exchange";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://webdevstudios.com/2013/11/01/announcing-the-paypal-pro-add-on-for-ithemes-exchange/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:99:"http://webdevstudios.com/2013/11/01/announcing-the-paypal-pro-add-on-for-ithemes-exchange/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 14:27:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:7:"Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"ecommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"Exchange";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:7:"iThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7878";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:427:"We are very excited to announce the release of our first iThemes Exchange premium add-on: PayPal Pro With the PayPal Pro Add-On, you can easily accept credit cards directly from your website with the iThemes Exchange eCommerce plugin. We all &#8230; <a class="more-link" href="http://webdevstudios.com/2013/11/01/announcing-the-paypal-pro-add-on-for-ithemes-exchange/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2762:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/10/paypalpro2-440x440.png"><img class="alignleft  wp-image-7879" alt="paypalpro2-440x440" src="http://webdevstudios.com/wp-content/uploads/2013/10/paypalpro2-440x440-150x150.png" width="65" height="65" /></a>We are very excited to announce the release of our first <a href="http://ithemes.com/exchange/" target="_blank">iThemes Exchange</a> premium add-on: <a href="http://ithemes.com/purchase/paypal-pro/" title="PayPal Pro for iThemes Exchange WordPress eCommerce" target="_blank">PayPal Pro</a></p>
<div id="attachment_7881" class="wp-caption alignright" style="width: 288px"><a href="http://webdevstudios.com/wp-content/uploads/2013/10/paypal-cc-input.png"><img class="size-medium wp-image-7881 " alt="paypal-cc-input" src="http://webdevstudios.com/wp-content/uploads/2013/10/paypal-cc-input-278x300.png" width="278" height="300" /></a><p class="wp-caption-text">PayPal Pro Credit Card Input</p></div>
<p>With the <a href="http://ithemes.com/purchase/paypal-pro/">PayPal Pro Add-On</a>, you can easily accept credit cards directly from your website with the <a href="http://ithemes.com/exchange/">iThemes Exchange</a> eCommerce plugin. We all know how wary we feel when we have to be directed off of a site to pay for what we&#8217;re purchasing. <a href="http://ithemes.com/purchase/paypal-pro/">PayPal Pro</a> takes that worry away by allowing you to stay on the site in which you&#8217;re purchasing from.</p>
<h2>Features of the PayPal Pro Add-On</h2>
<ul>
<li><em>Accept payments directly on your website.</em></li>
<li><em><a href="http://webdevstudios.com/wp-content/uploads/2013/10/paypal-pro-settings1.png"><img class="alignright  wp-image-7880" alt="paypal-pro-settings1" src="http://webdevstudios.com/wp-content/uploads/2013/10/paypal-pro-settings1.png" width="278" height="419" /></a>Support for PayPal’s transaction sale methods: authorize and capture the payment, charge the total to the credit card or authorize the payment amount and capture that amount via PayPal Pro’s admin later.</em></li>
<li><em>Enable or disable PayPal Pro Sandbox Mode for testing your payments.</em></li>
<li><em>Easily change the “Purchase” button text to whatever you want like “Pay with Card” or “Pay Like a Pro.”</em></li>
</ul>
<p>&nbsp;</p>
<p>Learn more about the iThemes Exchange plugin on their website at <a href="http://ithemes.com/exchange/" target="_blank"> http://ithemes.com/exchange</a> and the PayPal Pro add-on at <a href="http://ithemes.com/purchase/paypal-pro/" title="PayPal Pro WordPress eCommerce Exchange" target="_blank">http://ithemes.com/purchase/paypal-pro/</a>. We are very proud to be part of Exchange and will be releasing additional add-ons very soon!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:95:"http://webdevstudios.com/2013/11/01/announcing-the-paypal-pro-add-on-for-ithemes-exchange/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"WDS Helps To Improve Documentation in WordPress 3.7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://webdevstudios.com/2013/10/28/wds-helps-to-improve-documentation-in-wordpress-3-7/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:97:"http://webdevstudios.com/2013/10/28/wds-helps-to-improve-documentation-in-wordpress-3-7/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 28 Oct 2013 15:49:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7866";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:452:"For the 3.7 release, WebDevStudios&#8217; own Brian Richards and dozens of others turned their collective focus to documenting the many hooks that WordPress provides for developers. The hooks docs initiative was birthed from a conversation between Andrew Nacin and Jon &#8230; <a class="more-link" href="http://webdevstudios.com/2013/10/28/wds-helps-to-improve-documentation-in-wordpress-3-7/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3166:"<p>For the 3.7 release, WebDevStudios&#8217; own <a title="Brian Richards" href="http://webdevstudios.com/team/brian-richards/">Brian Richards</a> and dozens of others turned their collective focus to documenting the many hooks that WordPress provides for developers.</p>
<blockquote><p>The hooks docs initiative was birthed from a conversation between <a href="https://twitter.com/nacin">Andrew Nacin</a> and <a href="https://twitter.com/joncave">Jon Cave</a> that I overheard during the WordCamp San Francisco After Party. They were talking about something called a &#8220;hash notation&#8221; for easily documenting arrays in inline docs, and improving the documentation efforts of WordPress, and I wanted to know more. By the end of the night I was convinced this would be a perfect way to document the multitude of hooks littered throughout WordPress Core, and a perfect way for me (and others) to contribute to WordPress. &#8211; Brian Richards</p></blockquote>
<p>During WordCamp San Fransisco contributor day, Brian connected with <a href="https://twitter.com/nacin">Andrew Nacin</a>, <a href="https://twitter.com/joncave">Jon Cave</a>, <a href="https://twitter.com/ericandrewlewis">Eric Lewis</a>, and <a href="https://twitter.com/DrewAPicture">Drew Jaynes. </a>They sat down and began working out the logistics of updating the documentation together.</p>
<p>Fast-forward several weeks, <a href="https://twitter.com/DrewAPicture">Drew Jaynes</a> and <a href="https://twitter.com/kimparsell">Kim Parsell</a> put in a lot of hours writing and refining PHP Documentation Standards pages for the WordPress handbook. <a href="https://twitter.com/rzen">Brian Richards</a> helped define and create the Hook Documentation standards portion, and they wrote up a few leading posts for make.wordpress.org/core. After this they hit the ground running.</p>
<blockquote><p><a href="https://twitter.com/ericandrewlewis">Eric</a>, <a href="https://twitter.com/kimparsell">Kim</a>, <a href="https://twitter.com/DrewAPicture">Drew</a> and myself comprised the core hook docs team, and we&#8217;ve held meetings every week since the project started. Drew and Kim shouldered much of the work reviewing other peoples patches, and Drew was even granted temporary commit access to help make the process flow more smoothly (congrats, Drew!).</p>
<p>At this moment, 74 of the 185 files containing hooks have been documented. There is still much to be done, and this initiative will continue to thrive well into (and possibly through) WordPress 3.8. &#8211; Brian Richards</p></blockquote>
<p>We want to thank everyone who contributed to the release of WordPress 3.7 including WDS&#8217; <a title="Brian Richards" href="http://webdevstudios.com/team/brian-richards/">Brian Richards</a> and <a title="Michael Beckwith" href="http://webdevstudios.com/team/michael-beckwith/">Michael Beckwith</a>. There is still a lot more work to do and anyone looking to help can get involved by reading this post on make/core: <a href="http://make.wordpress.org/core/2013/09/05/add-inline-docs-for-hooks/" target="_blank">http://make.wordpress.org/core/2013/09/05/add-inline-docs-for-hooks/</a></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:93:"http://webdevstudios.com/2013/10/28/wds-helps-to-improve-documentation-in-wordpress-3-7/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Brian Messenlehner Speaking at WordCamp Sofia 2013";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://webdevstudios.com/2013/10/23/brian-messenlehner-speaking-at-wordcamp-sofia-2013/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:96:"http://webdevstudios.com/2013/10/23/brian-messenlehner-speaking-at-wordcamp-sofia-2013/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Oct 2013 17:37:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7842";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:410:"Brian Messenlehner is speaking at WordCamp Sofia this year! WordCamp Sofia 2013 is being held on Friday, October 26th at The Hall of Telerik Academy. Brian&#8217;s talk will be held in the general track at 2:30pm and he will be &#8230; <a class="more-link" href="http://webdevstudios.com/2013/10/23/brian-messenlehner-speaking-at-wordcamp-sofia-2013/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2320:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/10/Screenshot_on_10.17.2013_at_11.56.02_AM.png"><img class="aligncenter size-full wp-image-7843" alt="Screenshot_on_10.17.2013_at_11.56.02_AM" src="http://webdevstudios.com/wp-content/uploads/2013/10/Screenshot_on_10.17.2013_at_11.56.02_AM.png" width="856" height="184" /></a></p>
<p><a title="Brian Messenlehner" href="http://webdevstudios.com/team/brian-messenlehner/">Brian Messenlehner</a> is speaking at <a href="http://2013.sofia.wordcamp.org/">WordCamp Sofia</a> this year! <a href="http://2013.sofia.wordcamp.org/">WordCamp Sofia 2013</a> is being held on Friday, October 26th at The Hall of Telerik Academy.</p>
<p>Brian&#8217;s talk will be held in the general track at 2:30pm and he will be speaking (in English!) about: <a href="http://2013.sofia.wordcamp.org/session/wordpress-as-an-application-framework/">WordPress as an Application Framework</a>:</p>
<blockquote><p>Despite starting out as a blogging platform and currently existing primarily as a content management system, WordPress is powerful enough and flexible enough to run any type of web application. Whether you&#8217;re a novice WordPress user or an experienced web developer you can leverage WordPress in many non-traditional ways. We will go over how to rapidly build scalable and secure applications and how to save time and money doing so. We will also showcase some really cool applications and examples of building things with WordPress while thinking out of the box.</p></blockquote>
<p>This topic will be expanded on and explainied in depth in Brian&#8217;s upcoming book <a href="http://www.amazon.com/Building-Apps-WordPress-Brian-Messenlehner/dp/1449364071/ref=sr_1_1?ie=UTF8&amp;qid=1382548056&amp;sr=8-1&amp;keywords=Brian+messenlehner">Building Web Apps with WordPress</a>. The book will be available on Amazon in the next few weeks &#8211; but you are able to<a href="http://www.amazon.com/Building-Apps-WordPress-Brian-Messenlehner/dp/1449364071/ref=sr_1_1?ie=UTF8&amp;qid=1382548056&amp;sr=8-1&amp;keywords=Brian+messenlehner"> pre-order it right now</a>!</p>
<p>If you&#8217;re attending WordCamp Sofia, make sure you stop by and say hey to Brian! As always, he&#8217;s excited to meet new people and catch up with those he&#8217;s already met.</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:92:"http://webdevstudios.com/2013/10/23/brian-messenlehner-speaking-at-wordcamp-sofia-2013/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"WebDevStudios Welcomes Brad Parbs!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://webdevstudios.com/2013/10/21/webdevstudios-welcomes-brad-parbs/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:79:"http://webdevstudios.com/2013/10/21/webdevstudios-welcomes-brad-parbs/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Oct 2013 14:30:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7844";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:427:"WebDevStudios is proud to announce another great addition to our team &#8211; Welcome to Brad Parbs! Brad  is a WordPress fanatic. He is involved with the WordPress community in a number of ways including organizing various events, speaking about WordPress at &#8230; <a class="more-link" href="http://webdevstudios.com/2013/10/21/webdevstudios-welcomes-brad-parbs/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1593:"<p>WebDevStudios is proud to announce another great addition to our team &#8211; Welcome to <a href="http://webdevstudios.com/team/brad-parbs/">Brad Parbs</a>!</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2013/10/brad-parbs-profile-square.jpg"><img class="alignleft size-full wp-image-7849" alt="brad-parbs-profile-square" src="http://webdevstudios.com/wp-content/uploads/2013/10/brad-parbs-profile-square.jpg" width="253" height="253" /></a>Brad  is a WordPress fanatic. He is involved with the WordPress community in a number of ways including organizing various events, speaking about WordPress at conferences, contributing to WordPress core and writing and maintaining plugins.</p>
<p>Brad is co-organizer for both the <a href="http://www.wpmke.com/" target="_blank">WordPress Milwaukee</a> &amp; <a href="http://www.meetup.com/web414/" target="_blank">Web414</a> monthly meetups, as well as WordCamp Milwaukee <a href="http://2012.milwaukee.wordcamp.org/" target="_blank">2012</a> and <a href="http://2013.milwaukee.wordcamp.org/" target="_blank">2013</a>.</p>
<blockquote><p>I&#8217;m super excited to be joining Web Dev Studios. Ever since I first started freelancing, I&#8217;ve always looked up to WDS as a company I would one day work for. I can&#8217;t wait to work with some of the smartest people in the community, on some really fun projects. &#8211; Brad Parbs</p></blockquote>
<p>We are also very excited to have Brad joining the team! With his expertise and passion, we know he is going to be an excellent addition to our WDS family!</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:75:"http://webdevstudios.com/2013/10/21/webdevstudios-welcomes-brad-parbs/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:38:"Lisa Sabin-Wilson at PressNomics 2013!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://webdevstudios.com/2013/10/14/lisa-sabin-wilson-at-pressnomics-2013/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:83:"http://webdevstudios.com/2013/10/14/lisa-sabin-wilson-at-pressnomics-2013/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Oct 2013 18:46:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7833";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:424:"For those of you who don&#8217;t already know what PressNomics is &#8211; The conference for those that power the WordPress Economy There is a diverse group of passionate and very successful entrepreneurs creating the products and services that drive the &#8230; <a class="more-link" href="http://webdevstudios.com/2013/10/14/lisa-sabin-wilson-at-pressnomics-2013/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2060:"<p>For those of you who don&#8217;t already know what PressNomics is &#8211;</p>
<blockquote><p>The conference for those that power the WordPress Economy<br />
There is a diverse group of passionate and very successful entrepreneurs creating the products and services that drive the WordPress economy. PressNomics is a 3 day event for these folks to collaborate, learn, and relax.</p>
<p>&nbsp;</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2013/10/pressnomics-logos_06.png"><img class="aligncenter size-medium wp-image-7834" alt="pressnomics-logos_06" src="http://webdevstudios.com/wp-content/uploads/2013/10/pressnomics-logos_06-300x47.png" width="300" height="47" /></a></p></blockquote>
<p>An awesome thing about PressNomics is that it&#8217;s a <em>not-just-for-profit </em>event. The 2012 Event donated $5,126 to <a href="http://www.stjude.org">St. Jude Children&#8217;s Research Hospital</a>.</p>
<p>PressNomics is being held from Thursday, October 16th until Saturday, October 19th at the Tempe Mission Palms Hotel.</p>
<p>Lisa&#8217;s presentation begins on Friday, October 17th at 1:30pm</p>
<p>In her talk at PressNomics this year, Lisa Sabin-Wilson will be sharing the process and outcome of her decision to merge with WDS.  She is planning on talking about the decision making process and considerations for her to take her one-woman operation at <a href="http://ewebscapes.com">eWebscapes</a> and merge with a larger team, taking on not one, but two partners in the process.  What did it take to get there and reflections now, almost a year later, on how she has made the transition.</p>
<p>Lisa has been doing WordPress design/development since 2003 with the business she founded at <a href="http://ewebscapes.com">eWebscapes</a>. In 2012, Lisa, Brad and Brian began talks about merging eWebscapes with WebDevStudios to pull their collective brain power and resources together to form WD3, a.k.a. WebDevStudios.</p>
<p>If you are planning on being in Tempe, AZ for the PressNomics conference &#8211; find Lisa and say hello!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:79:"http://webdevstudios.com/2013/10/14/lisa-sabin-wilson-at-pressnomics-2013/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WebDevStudios Presents a Free WordPress Security Webinar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://webdevstudios.com/2013/09/25/webdevstudios-presents-a-free-wordpress-security-webinar/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:102:"http://webdevstudios.com/2013/09/25/webdevstudios-presents-a-free-wordpress-security-webinar/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 25 Sep 2013 15:00:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7808";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:451:"Brad  and Brian,two out of the three owners behind WebDevStudios, are hosting a webinar on WordPress security offered by SiteGround. Brad and Brian have extensive experience in dealing with website security and WordPress. This will be a great webinar to attend &#8230; <a class="more-link" href="http://webdevstudios.com/2013/09/25/webdevstudios-presents-a-free-wordpress-security-webinar/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1691:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/09/siteground.png"><img class="size-medium wp-image-7816 alignright" alt="siteground" src="http://webdevstudios.com/wp-content/uploads/2013/09/siteground-300x87.png" width="300" height="87" /></a><a href="http://webdevstudios.com/team/brad-williams/">Brad</a>  and <a title="Brian Messenlehner" href="http://webdevstudios.com/team/brian-messenlehner/">Brian</a>,two out of the three owners behind WebDevStudios, are hosting a webinar on WordPress security offered by <a href="http://www.siteground.com" target="_blank">SiteGround</a>. Brad and Brian have extensive experience in dealing with website security and WordPress. This will be a great webinar to attend if you want to learn how to beef up security on your WordPress website and to learn what to look out for to avoid security venerabilities. This event is taking place on <em>Thursday, September 26th</em> at <em>4pm EDT</em>. The session will include a 40 minute presentation followed by Q&amp;A.</p>
<h2 style="text-align: center"><a href="https://attendee.gotowebinar.com/register/2233504293348347905">Click Here to Register</a></h2>
<p>The WordPress Security webinar will include:</p>
<ul>
<li>WordPress Security Threats and trends</li>
<li>WordPress admin Security settings</li>
<li>Securing files, folders and databases</li>
<li>Bulletproof passwords</li>
<li>Web Server Vulnerabilities</li>
<li>Vulnerable WordPress extensions</li>
<li>Recommended Plugins and Services</li>
<li>Q &amp; A</li>
</ul>
<p>If you are interested in attending <a href="https://attendee.gotowebinar.com/register/2233504293348347905">click here</a> and sign up today!</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:98:"http://webdevstudios.com/2013/09/25/webdevstudios-presents-a-free-wordpress-security-webinar/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WordPress Web Design for Dummies (2nd edition) Giveaway!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://webdevstudios.com/2013/09/24/wordpress-web-design-for-dummies-2nd-edition-giveaway/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:99:"http://webdevstudios.com/2013/09/24/wordpress-web-design-for-dummies-2nd-edition-giveaway/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 24 Sep 2013 14:56:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Giveaway";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7804";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:469:"Lisa Sabin-Wilson; a co-owner here at WebDevStudios has written yet another helpful WordPress book.  WordPress Web Design for Dummies (2nd edition) is Lisa&#8217;s 11th dummies book based around WordPress! Updated, full-color guide to creating dynamic websites with WordPress 3.6 In &#8230; <a class="more-link" href="http://webdevstudios.com/2013/09/24/wordpress-web-design-for-dummies-2nd-edition-giveaway/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3529:"<p><a title="Lisa Sabin-Wilson" href="http://webdevstudios.com/team/lisa-sabin-wilson/">Lisa Sabin-Wilson</a>; a co-owner here at WebDevStudios has written yet another helpful WordPress book.  <a href="http://www.amazon.com/WordPress-Design-Dummies-Computer-Tech/dp/111854661X/ref=sr_1_1?s=books&amp;ie=UTF8&amp;qid=1380029870&amp;sr=1-1&amp;keywords=wordpress+web+design+for+dummies+2nd+edition">WordPress Web Design for Dummies (2nd edition)</a> is Lisa&#8217;s 11th dummies book based around WordPress!</p>
<blockquote>
<div id="outer_postBodyPS">
<div id="postBodyPS">
<div>
<p><b><a href="http://webdevstudios.com/wp-content/uploads/2013/09/Screen_Shot_2013-09-24_at_08.50.40.png"><img class="alignleft size-medium wp-image-7805" alt="Screen_Shot_2013-09-24_at_08.50.40" src="http://webdevstudios.com/wp-content/uploads/2013/09/Screen_Shot_2013-09-24_at_08.50.40-240x300.png" width="240" height="300" /></a>Updated, full-color guide to creating dynamic websites with WordPress 3.6</b></p>
<p>In this updated new edition, bestselling <i>For Dummies</i> author and WordPress expert Lisa Sabin-Wilson makes it easy for anyone with a basic knowledge of the WordPress software to create a custom site using complementary technologies such as CSS, HTML, PHP, and MySQL. You&#8217;ll not only get up to speed on essential tools and technologies and further advance your own design skills, this book also gives you pages of great case studies, so you can see just how other companies and individuals are creating compelling, customized, and cost-effective websites with WordPress.</p>
<ul>
<li>Shows you how to incorporate WordPress templates, graphic design principles, HTML, CSS, and PHP to build one-of-a-kind websites</li>
<li>Explains how to create an effective navigation system, choose the right color palette and fonts, and select different layouts</li>
<li>Reveals how you can tweak existing website designs with available themes, both free and premium</li>
<li>Provides numerous case studies to illustrate techniques and processes, and the effects you can achieve</li>
<li>Discusses how you can translate your design skills into paid work</li>
</ul>
<p>Want to create cost-effective and fantastic websites with WordPress? This do-it-yourself book will get you there.</p>
</div>
</div>
</div>
</blockquote>
<div id="outer_postBodyPS">
<div id="postBodyPS">
<div>
<p> We are giving away a copy of this awesome book!</p>
<h1>How to enter:</h1>
<ul>
<li>All you have to do is <strong>comment on this post</strong> about how one of Lisa&#8217;s books has helped you, or why you would like this book to help in your WordPress web design.</li>
<li>The giveaway with be running from 11 AM EDT today (Tuesday September 24th) until Thursday, September 26th at 3 PM EDT.</li>
<li>We will announce a winner at 4pm EDT on Thursday the 26th.</li>
<li>You will receive one copy of WordPress Web Design for Dummies (2nd edition) <strong>autographed</strong> by Lisa Sabin-Wilson.</li>
<li>US submissions only.</li>
<li>Employees and family members of WDS are encouraged to submit an entry, but are not eligible to win.</li>
</ul>
<p>We look forward to reading about how Lisa&#8217;s books have helped you or why this book would improve your WordPress web design!</p>
<p>Also, make sure to check out the entire list of books that WebDevStudios has under our belt (with more to come in the not so distant future!) <a href="http://webdevstudios.com/wordpress/books/">http://webdevstudios.com/wordpress/books/</a></p>
</div>
</div>
</div>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:95:"http://webdevstudios.com/2013/09/24/wordpress-web-design-for-dummies-2nd-edition-giveaway/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"14";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"WordCamp Baltimore 2013!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://webdevstudios.com/2013/09/19/wordcamp-baltimore-2013/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:69:"http://webdevstudios.com/2013/09/19/wordcamp-baltimore-2013/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 19 Sep 2013 14:14:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7797";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:386:"Add another WordCamp chalk line on the board for the WDS team &#8212; Brad Williams and Jayvie Canono will be attending WordCamp Baltimore 2013 this year! The event is happening on Saturday, September 21st and is being held at the &#8230; <a class="more-link" href="http://webdevstudios.com/2013/09/19/wordcamp-baltimore-2013/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2104:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/09/baltimore.png"><img class="alignleft size-full wp-image-7798" alt="baltimore" src="http://webdevstudios.com/wp-content/uploads/2013/09/baltimore.png" width="305" height="248" /></a>Add another WordCamp chalk line on the board for the WDS team &#8212; <a title="Brad Williams" href="http://webdevstudios.com/team/brad-williams/">Brad Williams</a> and <a title="Jayvie Canono" href="http://webdevstudios.com/team/jayvie-canono/">Jayvie Canono</a> will be attending <a href="http://2013.baltimore.wordcamp.org/">WordCamp Baltimore 2013</a> this year! The event is happening on Saturday, September 21st and is being held at the University of Baltimore in the Thumel Business Center. We would like to give a big round of applause to the organizers; <a href="https://twitter.com/theandystratton">Andy Stratton</a> and <a href="https://twitter.com/BmoreDrew">Drew Poland</a>, along with the <a href="http://2013.baltimore.wordcamp.org/sponsors/">sponsors</a>, for making this event possible!</p>
<p>Now, we already know that Brad Williams and Jayvie Canono of WDS will be going to this event, but make sure you check out the entire list of <a href="http://2013.baltimore.wordcamp.org/attendees/">attendees</a> and <a href="http://2013.baltimore.wordcamp.org/speakers/">speakers</a> that you will be learning from and getting to know. Also, have a look at the full <a href="http://2013.baltimore.wordcamp.org/schedule/">schedule</a> so you know which presentations you would like to attend and you can plan accordingly.</p>
<p>What would a WordCamp be without an after party? When you&#8217;re finished having a long day of cramming your brain full of WordPress knowledge, it&#8217;s time to relax. The after party is being held at the The Waterfront Hotel in Baltimore’s historic Fell’s Point starting at 7:30pm.</p>
<p>If you plan on attending WordCamp Baltimore 2013, make sure you find Brad and Jayvie in the crowd and say hey. As always, they are looking forward to meeting new people and reunited with the ones they have already met!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:65:"http://webdevstudios.com/2013/09/19/wordcamp-baltimore-2013/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:41:"http://feeds.feedburner.com/webdevstudios";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:3:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:13:"webdevstudios";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:14:"emailServiceId";a:1:{i:0;a:5:{s:4:"data";s:13:"webdevstudios";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:18:"feedburnerHostname";a:1:{i:0;a:5:{s:4:"data";s:28:"http://feedburner.google.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:13:"last-modified";s:29:"Fri, 15 Nov 2013 11:25:19 GMT";s:4:"etag";s:27:"ckZROX+iCad1haqhYYrTOh5TsbE";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"date";s:29:"Fri, 15 Nov 2013 11:25:19 GMT";s:7:"expires";s:29:"Fri, 15 Nov 2013 11:25:19 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20131111120855";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1890, '_transient_timeout_plugin_slugs', '1390149522', 'no') ; 
INSERT INTO `wp_options` VALUES (1891, '_transient_plugin_slugs', 'a:11:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:19:"akismet/akismet.php";i:2;s:35:"backupwordpress/backupwordpress.php";i:3;s:36:"contact-form-7/wp-contact-form-7.php";i:4;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:5;s:9:"hello.php";i:6;s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";i:7;s:30:"lightbox-plus/lightboxplus.php";i:8;s:45:"limit-login-attempts/limit-login-attempts.php";i:9;s:23:"ml-slider/ml-slider.php";i:10;s:40:"twitter-widget-pro/wp-twitter-widget.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (1892, '_transient_timeout_dash_de3249c4736ad3bd2cd29147c4a0d43e', '1390106322', 'no') ; 
INSERT INTO `wp_options` VALUES (1893, '_transient_dash_de3249c4736ad3bd2cd29147c4a0d43e', '', 'no') ; 
INSERT INTO `wp_options` VALUES (1775, '_site_transient_timeout_browser_8b7535adeddc223aa9c8b2b378cdf189', '1390130723', 'yes') ; 
INSERT INTO `wp_options` VALUES (1776, '_site_transient_browser_8b7535adeddc223aa9c8b2b378cdf189', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"31.0.1650.63";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1884, '_transient_timeout_dash_20494a3d90a6669585674ed0eb8dcd8f', '1390106321', 'no') ; 
INSERT INTO `wp_options` VALUES (1885, '_transient_dash_20494a3d90a6669585674ed0eb8dcd8f', '<p><strong>RSS Error</strong>: WP HTTP Error: Couldn\'t resolve host \'blogsearch.google.com\'</p>', 'no') ; 
INSERT INTO `wp_options` VALUES (1886, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1390106321', 'no') ; 
INSERT INTO `wp_options` VALUES (1887, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><p><strong>RSS Error</strong>: WP HTTP Error: Couldn\'t resolve host \'wordpress.org\'</p></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (1591, '_site_transient_timeout_browser_c4e86ff1b653ad5eff93e52bc1c6434d', '1388931128', 'yes') ; 
INSERT INTO `wp_options` VALUES (1592, '_site_transient_browser_c4e86ff1b653ad5eff93e52bc1c6434d', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"31.0.1650.63";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (978, 'limit_login_logged', 'a:1:{s:15:"211.110.140.155";a:2:{s:5:"admin";i:1;s:4:"Page";i:1;}}', 'no') ; 
INSERT INTO `wp_options` VALUES (979, 'limit_login_lockouts_total', '2', 'no') ; 
INSERT INTO `wp_options` VALUES (1303, '_site_transient_timeout_browser_6f7c62fdea85348b09138021703fd1a5', '1387254559', 'yes') ; 
INSERT INTO `wp_options` VALUES (1304, '_site_transient_browser_6f7c62fdea85348b09138021703fd1a5', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"31.0.1650.63";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1888, '_transient_timeout_dash_aa95765b5cc111c56d5993d476b1c2f0', '1390106322', 'no') ; 
INSERT INTO `wp_options` VALUES (1889, '_transient_dash_aa95765b5cc111c56d5993d476b1c2f0', '<div class="rss-widget"><p><strong>RSS Error</strong>: WP HTTP Error: Couldn\'t resolve host \'planet.wordpress.org\'</p></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (1904, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1390091683;s:7:"checked";a:5:{s:7:"expound";s:3:"1.8";s:4:"roar";s:3:"1.8";s:10:"tigertheme";s:1:"1";s:14:"twentythirteen";s:3:"1.1";s:12:"twentytwelve";s:3:"1.3";}s:8:"response";a:1:{s:7:"expound";a:3:{s:11:"new_version";s:3:"1.9";s:3:"url";s:36:"https://wordpress.org/themes/expound";s:7:"package";s:53:"https://wordpress.org/themes/download/expound.1.9.zip";}}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1905, '_site_transient_update_plugins', 'O:8:"stdClass":3:{s:12:"last_checked";i:1390091683;s:8:"response";a:5:{s:30:"advanced-custom-fields/acf.php";O:8:"stdClass":5:{s:2:"id";s:5:"21367";s:4:"slug";s:22:"advanced-custom-fields";s:11:"new_version";s:5:"4.3.4";s:3:"url";s:53:"https://wordpress.org/plugins/advanced-custom-fields/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/advanced-custom-fields.zip";}s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":5:{s:2:"id";s:3:"885";s:4:"slug";s:15:"backupwordpress";s:11:"new_version";s:5:"2.4.1";s:3:"url";s:46:"https://wordpress.org/plugins/backupwordpress/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.2.4.1.zip";}s:36:"contact-form-7/wp-contact-form-7.php";O:8:"stdClass":5:{s:2:"id";s:3:"790";s:4:"slug";s:14:"contact-form-7";s:11:"new_version";s:3:"3.6";s:3:"url";s:45:"https://wordpress.org/plugins/contact-form-7/";s:7:"package";s:61:"https://downloads.wordpress.org/plugin/contact-form-7.3.6.zip";}s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";O:8:"stdClass":5:{s:2:"id";s:5:"35054";s:4:"slug";s:47:"hupso-share-buttons-for-twitter-facebook-google";s:11:"new_version";s:6:"3.9.24";s:3:"url";s:78:"https://wordpress.org/plugins/hupso-share-buttons-for-twitter-facebook-google/";s:7:"package";s:97:"https://downloads.wordpress.org/plugin/hupso-share-buttons-for-twitter-facebook-google.3.9.24.zip";}s:23:"ml-slider/ml-slider.php";O:8:"stdClass":5:{s:2:"id";s:5:"38583";s:4:"slug";s:9:"ml-slider";s:11:"new_version";s:5:"2.6.2";s:3:"url";s:40:"https://wordpress.org/plugins/ml-slider/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/ml-slider.2.6.2.zip";}}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1631, 'theme_mods_roar', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1389525932;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:8:"search-2";i:1;s:6:"meta-2";i:2;s:10:"archives-2";i:3;s:12:"categories-2";i:4;s:17:"recent-comments-2";}s:18:"orphaned_widgets_1";a:2:{i:0;s:9:"twitter-2";i:1;s:14:"recent-posts-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1795, '_transient_is_multi_author', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (857, 'wp_cart_title', 'Your Shopping Cart', 'yes') ; 
INSERT INTO `wp_options` VALUES (858, 'wp_cart_empty_text', 'Your cart is empty', 'yes') ; 
INSERT INTO `wp_options` VALUES (859, 'cart_return_from_paypal_url', 'http://localhost/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (843, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1384647424', 'yes') ; 
INSERT INTO `wp_options` VALUES (844, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3898";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2456";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2344";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1930";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1856";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1583";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1329";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1325";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1310";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1260";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1225";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1121";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1000";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"982";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"974";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"950";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"844";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"821";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"780";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"722";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"686";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"681";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"678";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"623";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"615";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"595";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"572";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"570";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"541";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"539";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"530";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"522";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"506";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"505";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"471";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"458";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"453";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"452";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"436";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"432";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (530, 'twp_version', '2.6.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (236, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (253, '_transient_update_plugins', 'O:8:"stdClass":1:{s:12:"last_checked";i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (254, '_transient_update_themes', 'O:8:"stdClass":1:{s:12:"last_checked";i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (297, 'hmbkp_default_path', '/Applications/MAMP/htdocs/tigers/wp-content/uploads/backupwordpress-b46642cc98-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (298, 'hmbkp_path', '/Applications/MAMP/htdocs/tigers/wp-content/uploads/backupwordpress-b46642cc98-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (299, 'hmbkp_schedule_default-1', 'a:3:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (300, 'hmbkp_schedule_default-2', 'a:3:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (301, 'hmbkp_plugin_version', '2.3.3', 'yes') ; 
INSERT INTO `wp_options` VALUES (559, 'wpcf7', 'a:1:{s:7:"version";s:5:"3.5.4";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (759, 'rewrite_rules', 'a:73:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=4&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:31:".+?/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:".+?/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:".+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"(.+?)/([^/]+)/trackback/?$";s:57:"index.php?category_name=$matches[1]&name=$matches[2]&tb=1";s:46:"(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:41:"(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:34:"(.+?)/([^/]+)/page/?([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&paged=$matches[3]";s:41:"(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&cpage=$matches[3]";s:26:"(.+?)/([^/]+)(/[0-9]+)?/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&page=$matches[3]";s:20:".+?/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:".+?/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:".+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:26:"(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:33:"(.+?)/comment-page-([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&cpage=$matches[2]";s:8:"(.+?)/?$";s:35:"index.php?category_name=$matches[1]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (698, '_site_transient_timeout_browser_202665350ff96275d5f63aa102c7a322', '1385072848', 'yes') ; 
INSERT INTO `wp_options` VALUES (699, '_site_transient_browser_202665350ff96275d5f63aa102c7a322', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"30.0.1599.101";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (193, 'theme_mods_twentythirteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1378623403;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:0:{}s:19:"primary-widget-area";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:21:"secondary-widget-area";a:0:{}s:24:"first-footer-widget-area";a:0:{}s:25:"second-footer-widget-area";a:0:{}s:24:"third-footer-widget-area";a:0:{}s:25:"fourth-footer-widget-area";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (194, 'current_theme', 'Expound', 'yes') ; 
INSERT INTO `wp_options` VALUES (195, 'theme_mods_tigertheme', 'a:5:{i:0;b:0;s:12:"header_image";s:79:"http://localhost/tigers/wp-content/uploads/2013/09/cropped-football_generic.jpg";s:17:"header_image_data";a:5:{s:13:"attachment_id";i:28;s:3:"url";s:79:"http://localhost/tigers/wp-content/uploads/2013/09/cropped-football_generic.jpg";s:13:"thumbnail_url";s:79:"http://localhost/tigers/wp-content/uploads/2013/09/cropped-football_generic.jpg";s:5:"width";i:1050;s:6:"height";i:250;}s:16:"header_textcolor";s:6:"e9e0e1";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1389617407;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:1:{i:0;s:9:"twitter-2";}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (196, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (477, '_site_transient_browser_00760e848c8aef5785b4a3f89f42352c', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"30.0.1599.101";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (304, '_transient_timeout_hmbkp_schedule_default-1_filesize', '2758062890', 'no') ; 
INSERT INTO `wp_options` VALUES (305, '_transient_hmbkp_schedule_default-1_filesize', '418160', 'no') ; 
INSERT INTO `wp_options` VALUES (484, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:2:{i:0;O:8:"stdClass":10:{s:8:"response";s:7:"upgrade";s:8:"download";s:39:"https://wordpress.org/wordpress-3.8.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:39:"https://wordpress.org/wordpress-3.8.zip";s:10:"no_content";s:50:"https://wordpress.org/wordpress-3.8-no-content.zip";s:11:"new_bundled";s:51:"https://wordpress.org/wordpress-3.8-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"3.8";s:7:"version";s:3:"3.8";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}i:1;O:8:"stdClass":10:{s:8:"response";s:10:"autoupdate";s:8:"download";s:39:"https://wordpress.org/wordpress-3.8.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:39:"https://wordpress.org/wordpress-3.8.zip";s:10:"no_content";s:50:"https://wordpress.org/wordpress-3.8-no-content.zip";s:11:"new_bundled";s:51:"https://wordpress.org/wordpress-3.8-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"3.8";s:7:"version";s:3:"3.8";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.8";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1390091682;s:15:"version_checked";s:5:"3.7.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (485, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (1894, '_site_transient_timeout_wporg_theme_feature_list', '1390073934', 'yes') ; 
INSERT INTO `wp_options` VALUES (1895, '_site_transient_wporg_theme_feature_list', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1898, '_transient_doing_cron', '1390091678.7247159481048583984375', 'yes') ; 
INSERT INTO `wp_options` VALUES (508, 'theme_mods_expound', 'a:8:{i:0;b:0;s:16:"header_textcolor";s:6:"000000";s:16:"background_color";s:6:"ffffff";s:16:"background_image";s:53:"http://localhost/tigers/wp-content/uploads/grass1.jpg";s:17:"background_repeat";s:9:"no-repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";s:14:"rateme-dismiss";b:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (376, 'theme_mods_wingchun', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1384261449;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";N;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (535, 'twp', 'a:16:{s:12:"consumer-key";s:19:"jsu4vXpRoHzNdRdrsrw";s:15:"consumer-secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:8:"username";s:0:"";s:4:"list";s:0:"";s:5:"title";s:0:"";s:5:"items";s:2:"10";s:6:"avatar";s:0:"";s:6:"errmsg";s:0:"";s:6:"showts";s:5:"86400";s:10:"dateFormat";s:14:"h:i:s A F d, Y";s:12:"showretweets";s:4:"true";s:11:"hidereplies";s:5:"false";s:8:"hidefrom";s:5:"false";s:11:"showintents";s:4:"true";s:10:"showfollow";s:4:"true";s:11:"targetBlank";s:5:"false";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (541, 'twp-authed-users', 'a:1:{s:15:"ash_skywalker10";a:4:{s:11:"oauth_token";s:50:"399730397-UUaCZnrCulookeadOgPWcpkEclDv2vZ6IMw9wf8t";s:18:"oauth_token_secret";s:45:"nHgo0EzVefbEbsp5L7FoTlcXaWjSLsu6i0gGOISYFWS7f";s:7:"user_id";s:9:"399730397";s:11:"screen_name";s:15:"ash_skywalker10";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (542, 'widget_twitter', 'a:2:{i:2;a:18:{s:12:"consumer-key";s:19:"jsu4vXpRoHzNdRdrsrw";s:15:"consumer-secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:5:"title";s:0:"";s:6:"errmsg";s:0:"";s:8:"username";s:15:"ash_skywalker10";s:4:"list";s:0:"";s:13:"http_vs_https";s:5:"https";s:11:"hidereplies";s:5:"false";s:12:"showretweets";s:4:"true";s:8:"hidefrom";s:5:"false";s:11:"showintents";s:4:"true";s:10:"showfollow";s:4:"true";s:6:"avatar";s:0:"";s:15:"showXavisysLink";s:5:"false";s:11:"targetBlank";s:5:"false";s:5:"items";s:2:"10";s:6:"showts";s:5:"86400";s:10:"dateFormat";s:14:"h:i:s A F d, Y";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (543, '_transient_timeout_tlc__924771c23f8ee6bf7fb5c83b985d3e5e', '1421627980', 'no') ; 
INSERT INTO `wp_options` VALUES (544, '_transient_tlc__924771c23f8ee6bf7fb5c83b985d3e5e', 'a:2:{i:0;i:1390091980;i:1;a:1:{i:0;O:8:"stdClass":22:{s:10:"created_at";s:30:"Thu Oct 27 23:20:47 +0000 2011";s:2:"id";i:129699090836627458;s:6:"id_str";s:18:"129699090836627458";s:4:"text";s:138:"@contikiaus #contiki I\'m seeking amazing sights, fantastic architecture, absorb large amounts of history,  DELICIOUS FOOD and good friends";s:6:"source";s:118:"<a href="http://contiki.com.au/pages/1734-europe-2012-13-microsite-fortheseekers" rel="nofollow">Contiki Australia</a>";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";i:17455144;s:23:"in_reply_to_user_id_str";s:8:"17455144";s:23:"in_reply_to_screen_name";s:10:"contikiaus";s:4:"user";O:8:"stdClass":38:{s:2:"id";i:399730397;s:6:"id_str";s:9:"399730397";s:4:"name";s:8:"Andy Tan";s:11:"screen_name";s:15:"ash_skywalker10";s:8:"location";s:0:"";s:11:"description";s:0:"";s:3:"url";N;s:8:"entities";O:8:"stdClass":1:{s:11:"description";O:8:"stdClass":1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:1;s:13:"friends_count";i:0;s:12:"listed_count";i:0;s:10:"created_at";s:30:"Thu Oct 27 23:20:36 +0000 2011";s:16:"favourites_count";i:0;s:10:"utc_offset";N;s:9:"time_zone";N;s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:1;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:79:"http://abs.twimg.com/sticky/default_profile_images/default_profile_3_normal.png";s:23:"profile_image_url_https";s:80:"https://abs.twimg.com/sticky/default_profile_images/default_profile_3_normal.png";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:1;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";O:8:"stdClass":4:{s:8:"hashtags";a:1:{i:0;O:8:"stdClass":2:{s:4:"text";s:7:"contiki";s:7:"indices";a:2:{i:0;i:12;i:1;i:20;}}}s:7:"symbols";a:0:{}s:4:"urls";a:0:{}s:13:"user_mentions";a:1:{i:0;O:8:"stdClass":5:{s:11:"screen_name";s:10:"contikiaus";s:4:"name";s:17:"Contiki Australia";s:2:"id";i:17455144;s:6:"id_str";s:8:"17455144";s:7:"indices";a:2:{i:0;i:0;i:1;i:11;}}}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:4:"lang";s:2:"en";}}}', 'no') ; 
INSERT INTO `wp_options` VALUES (553, 'hupso_version', '3.9.22', 'yes') ; 
INSERT INTO `wp_options` VALUES (558, 'lightboxplus_options', 'a:57:{s:18:"lightboxplus_multi";s:1:"0";s:10:"use_inline";s:1:"0";s:10:"inline_num";s:1:"5";s:18:"lightboxplus_style";s:10:"fancypants";s:16:"use_custom_style";s:1:"0";s:11:"disable_css";s:1:"0";s:10:"hide_about";s:1:"0";s:12:"output_htmlv";s:1:"0";s:9:"data_name";s:12:"lightboxplus";s:13:"load_location";s:9:"wp_footer";s:13:"load_priority";s:2:"10";s:11:"use_perpage";s:1:"0";s:11:"use_forpage";s:1:"0";s:11:"use_forpost";s:1:"0";s:10:"transition";s:7:"elastic";s:5:"speed";s:1:"0";s:5:"width";s:0:"";s:6:"height";s:0:"";s:11:"inner_width";s:0:"";s:12:"inner_height";s:0:"";s:13:"initial_width";s:0:"";s:14:"initial_height";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:6:"resize";s:1:"0";s:7:"opacity";s:1:"0";s:10:"preloading";s:1:"0";s:11:"label_image";s:0:"";s:8:"label_of";s:0:"";s:8:"previous";s:0:"";s:4:"next";s:0:"";s:5:"close";s:0:"";s:13:"overlay_close";s:1:"0";s:9:"slideshow";s:1:"0";s:14:"slideshow_auto";s:1:"0";s:15:"slideshow_speed";s:3:"500";s:15:"slideshow_start";s:5:"start";s:14:"slideshow_stop";s:4:"stop";s:17:"use_caption_title";s:1:"0";s:20:"gallery_lightboxplus";s:1:"1";s:18:"multiple_galleries";s:1:"0";s:16:"use_class_method";s:1:"0";s:10:"class_name";s:11:"lbp_primary";s:16:"no_auto_lightbox";s:1:"0";s:10:"text_links";s:1:"0";s:16:"no_display_title";s:1:"0";s:9:"scrolling";s:1:"0";s:5:"photo";s:1:"0";s:3:"rel";s:1:"0";s:4:"loop";s:1:"0";s:7:"esc_key";s:1:"0";s:9:"arrow_key";s:1:"0";s:3:"top";s:0:"";s:6:"bottom";s:0:"";s:4:"left";s:0:"";s:5:"right";s:0:"";s:5:"fixed";s:1:"0";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (580, 'widget_black-studio-tinymce', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:4:"text";s:404:"[caption id="attachment_27" align="alignnone" width="180"]<a href="http://localhost/tigers/wp-content/uploads/2013/09/Jam.jpg"><img class=" wp-image-27 " alt="Michael Jackson and Michael Jordan" src="http://localhost/tigers/wp-content/uploads/2013/09/Jam-300x278.jpg" width="180" height="167" /></a> Michael Jackson and Michael Jordan[/caption]

Important Dates in 2013

AGM/Trophy Presentation Night";s:4:"type";s:6:"visual";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (762, '_transient_timeout_feed_mod_c809918297b2c893fd8504c06adcaf00', '1384557928', 'no') ; 
INSERT INTO `wp_options` VALUES (763, '_transient_feed_mod_c809918297b2c893fd8504c06adcaf00', '1384514728', 'no') ; 
INSERT INTO `wp_options` VALUES (861, 'wpspc_buyer_from_email', 'Gosford Junior Australian Football Club <sales@your-domain.com>', 'yes') ; 
INSERT INTO `wp_options` VALUES (862, 'wpspc_buyer_email_subj', 'Thank you for the purchase', 'yes') ; 
INSERT INTO `wp_options` VALUES (863, 'wpspc_buyer_email_body', 'Dear {first_name} {last_name}

Thank you for your purchase! You ordered the following item(s):

{product_details}', 'yes') ; 
INSERT INTO `wp_options` VALUES (849, '_transient_plugins_delete_result_1', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (860, 'wpspc_send_buyer_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (851, 'metaslider_systemcheck', 'a:2:{s:16:"wordPressVersion";b:0;s:12:"imageLibrary";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1902, '_site_transient_timeout_theme_roots', '1390093480', 'yes') ; 
INSERT INTO `wp_options` VALUES (1903, '_site_transient_theme_roots', 'a:5:{s:7:"expound";s:7:"/themes";s:4:"roar";s:7:"/themes";s:10:"tigertheme";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (1713, '_transient_all_the_cool_cats', '1', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Sunday 19. January 2014 00:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=345 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (319 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2, 27, '_wp_attached_file', '2013/09/Jam.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (3, 27, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:487;s:6:"height";i:452;s:4:"file";s:15:"2013/09/Jam.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"Jam-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:15:"Jam-300x278.jpg";s:5:"width";i:300;s:6:"height";i:278;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (4, 27, '_edit_lock', '1378732011:1') ; 
INSERT INTO `wp_postmeta` VALUES (5, 27, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (6, 28, '_wp_attached_file', '2013/09/cropped-football_generic.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (7, 28, '_wp_attachment_context', 'custom-header') ; 
INSERT INTO `wp_postmeta` VALUES (8, 28, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1050;s:6:"height";i:250;s:4:"file";s:36:"2013/09/cropped-football_generic.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"cropped-football_generic-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:35:"cropped-football_generic-300x71.jpg";s:5:"width";i:300;s:6:"height";i:71;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:37:"cropped-football_generic-1024x243.jpg";s:5:"width";i:1024;s:6:"height";i:243;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (9, 28, '_wp_attachment_is_custom_header', 'tigertheme') ; 
INSERT INTO `wp_postmeta` VALUES (10, 30, '_wp_attached_file', '2013/10/football_generic.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (11, 30, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:864;s:6:"height";i:100;s:4:"file";s:28:"2013/10/football_generic.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"football_generic-150x100.jpg";s:5:"width";i:150;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"football_generic-300x34.jpg";s:5:"width";i:300;s:6:"height";i:34;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:27:"football_generic-624x72.jpg";s:5:"width";i:624;s:6:"height";i:72;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (12, 29, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (13, 29, '_edit_lock', '1384650431:1') ; 
INSERT INTO `wp_postmeta` VALUES (14, 32, '_wp_attached_file', '2013/10/map-malaysia600.gif') ; 
INSERT INTO `wp_postmeta` VALUES (15, 32, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:600;s:6:"height";i:236;s:4:"file";s:27:"2013/10/map-malaysia600.gif";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"map-malaysia600-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:6:"medium";a:4:{s:4:"file";s:27:"map-malaysia600-300x118.gif";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/gif";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (16, 32, '_edit_lock', '1382239092:1') ; 
INSERT INTO `wp_postmeta` VALUES (19, 34, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (18, 34, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (17, 32, '_wp_attachment_backup_sizes', 'a:10:{s:9:"full-orig";a:3:{s:5:"width";i:600;s:6:"height";i:236;s:4:"file";s:19:"map-malaysia600.gif";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:27:"map-malaysia600-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:11:"medium-orig";a:4:{s:4:"file";s:27:"map-malaysia600-300x118.gif";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/gif";}s:18:"full-1382239246960";a:3:{s:5:"width";i:600;s:6:"height";i:236;s:4:"file";s:34:"map-malaysia600-e1382239226939.gif";}s:23:"thumbnail-1382239246960";a:4:{s:4:"file";s:42:"map-malaysia600-e1382239226939-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:20:"medium-1382239246960";a:4:{s:4:"file";s:42:"map-malaysia600-e1382239226939-300x118.gif";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/gif";}s:18:"full-1382239301503";a:3:{s:5:"width";i:183;s:6:"height";i:165;s:4:"file";s:34:"map-malaysia600-e1382239246960.gif";}s:18:"full-1382239307312";a:3:{s:5:"width";i:60;s:6:"height";i:54;s:4:"file";s:34:"map-malaysia600-e1382239301503.gif";}s:23:"thumbnail-1382239307312";a:4:{s:4:"file";s:42:"map-malaysia600-e1382239246960-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:20:"medium-1382239307312";a:4:{s:4:"file";s:42:"map-malaysia600-e1382239226939-300x118.gif";s:5:"width";i:300;s:6:"height";i:118;s:9:"mime-type";s:9:"image/gif";}}') ; 
INSERT INTO `wp_postmeta` VALUES (20, 34, '_menu_item_object_id', '34') ; 
INSERT INTO `wp_postmeta` VALUES (21, 34, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (22, 34, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (23, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (24, 34, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (25, 34, '_menu_item_url', 'http://localhost/tigers/') ; 
INSERT INTO `wp_postmeta` VALUES (26, 34, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (27, 35, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (28, 35, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (29, 35, '_menu_item_object_id', '4') ; 
INSERT INTO `wp_postmeta` VALUES (30, 35, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (31, 35, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (32, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (33, 35, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (34, 35, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (35, 35, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (36, 36, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (37, 36, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (38, 36, '_menu_item_object_id', '6') ; 
INSERT INTO `wp_postmeta` VALUES (39, 36, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (40, 36, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (41, 36, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (42, 36, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (43, 36, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (44, 36, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (45, 37, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (46, 37, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (47, 37, '_menu_item_object_id', '10') ; 
INSERT INTO `wp_postmeta` VALUES (48, 37, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (49, 37, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (50, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (51, 37, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (52, 37, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (53, 37, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (54, 38, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (55, 38, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (56, 38, '_menu_item_object_id', '12') ; 
INSERT INTO `wp_postmeta` VALUES (57, 38, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (58, 38, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (59, 38, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (60, 38, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (61, 38, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (62, 38, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (63, 39, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (64, 39, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (65, 39, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (66, 39, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (67, 39, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (68, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (69, 39, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (70, 39, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (71, 39, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (72, 40, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (73, 40, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (74, 40, '_menu_item_object_id', '16') ; 
INSERT INTO `wp_postmeta` VALUES (75, 40, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (76, 40, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (77, 40, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (78, 40, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (79, 40, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (80, 40, '_menu_item_orphaned', '1384261457') ; 
INSERT INTO `wp_postmeta` VALUES (81, 41, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (82, 41, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (83, 41, '_menu_item_object_id', '18') ; 
INSERT INTO `wp_postmeta` VALUES (84, 41, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (85, 41, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (86, 41, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (87, 41, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (88, 41, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (89, 41, '_menu_item_orphaned', '1384261458') ; 
INSERT INTO `wp_postmeta` VALUES (90, 42, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (91, 42, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (92, 42, '_menu_item_object_id', '20') ; 
INSERT INTO `wp_postmeta` VALUES (93, 42, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (94, 42, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (95, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (96, 42, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (97, 42, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (98, 42, '_menu_item_orphaned', '1384261458') ; 
INSERT INTO `wp_postmeta` VALUES (99, 43, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (100, 43, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (101, 43, '_menu_item_object_id', '22') ; 
INSERT INTO `wp_postmeta` VALUES (102, 43, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (103, 43, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (104, 43, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (105, 43, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (106, 43, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (107, 43, '_menu_item_orphaned', '1384261458') ; 
INSERT INTO `wp_postmeta` VALUES (108, 44, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (109, 44, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (110, 44, '_menu_item_object_id', '24') ; 
INSERT INTO `wp_postmeta` VALUES (111, 44, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (112, 44, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (113, 44, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (114, 44, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (115, 44, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (116, 44, '_menu_item_orphaned', '1384261458') ; 
INSERT INTO `wp_postmeta` VALUES (285, 85, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (286, 85, '_edit_lock', '1387193001:1') ; 
INSERT INTO `wp_postmeta` VALUES (284, 85, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (123, 48, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (124, 48, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (125, 48, '_menu_item_object_id', '48') ; 
INSERT INTO `wp_postmeta` VALUES (126, 48, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (127, 48, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (128, 48, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (129, 48, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (130, 48, '_menu_item_url', 'http://localhost/tigers/') ; 
INSERT INTO `wp_postmeta` VALUES (131, 48, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (132, 49, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (133, 49, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (134, 49, '_menu_item_object_id', '4') ; 
INSERT INTO `wp_postmeta` VALUES (135, 49, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (136, 49, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (137, 49, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (138, 49, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (139, 49, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (140, 49, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (141, 50, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (142, 50, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (143, 50, '_menu_item_object_id', '6') ; 
INSERT INTO `wp_postmeta` VALUES (144, 50, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (145, 50, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (146, 50, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (147, 50, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (148, 50, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (149, 50, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (150, 51, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (151, 51, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (152, 51, '_menu_item_object_id', '10') ; 
INSERT INTO `wp_postmeta` VALUES (153, 51, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (154, 51, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (155, 51, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (156, 51, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (157, 51, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (158, 51, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (159, 52, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (160, 52, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (161, 52, '_menu_item_object_id', '12') ; 
INSERT INTO `wp_postmeta` VALUES (162, 52, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (163, 52, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (164, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (165, 52, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (166, 52, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (167, 52, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (168, 53, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (169, 53, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (170, 53, '_menu_item_object_id', '14') ; 
INSERT INTO `wp_postmeta` VALUES (171, 53, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (172, 53, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (173, 53, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (174, 53, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (175, 53, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (176, 53, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (177, 54, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (178, 54, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (179, 54, '_menu_item_object_id', '16') ; 
INSERT INTO `wp_postmeta` VALUES (180, 54, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (181, 54, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (182, 54, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (183, 54, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (184, 54, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (185, 54, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (186, 55, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (187, 55, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (188, 55, '_menu_item_object_id', '18') ; 
INSERT INTO `wp_postmeta` VALUES (189, 55, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (190, 55, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (191, 55, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (192, 55, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (193, 55, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (194, 55, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (195, 56, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (196, 56, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (197, 56, '_menu_item_object_id', '20') ; 
INSERT INTO `wp_postmeta` VALUES (198, 56, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (199, 56, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (200, 56, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (201, 56, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (202, 56, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (203, 56, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (204, 57, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (205, 57, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (206, 57, '_menu_item_object_id', '22') ; 
INSERT INTO `wp_postmeta` VALUES (207, 57, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (208, 57, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (209, 57, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (210, 57, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (211, 57, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (212, 57, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (213, 58, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (214, 58, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (215, 58, '_menu_item_object_id', '24') ; 
INSERT INTO `wp_postmeta` VALUES (216, 58, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (217, 58, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (218, 58, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (219, 58, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (220, 58, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (221, 58, '_menu_item_orphaned', '1384345115') ; 
INSERT INTO `wp_postmeta` VALUES (222, 59, '_form', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit "Send"]</p>') ; 
INSERT INTO `wp_postmeta` VALUES (223, 59, '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:200:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://localhost/tigers)";s:9:"recipient";s:22:"andy.tan2624@gmail.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (224, 59, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:142:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://localhost/tigers)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (225, 59, '_messages', 'a:6:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";}') ; 
INSERT INTO `wp_postmeta` VALUES (226, 59, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (227, 59, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (228, 60, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (229, 60, '_edit_lock', '1387196183:1') ; 
INSERT INTO `wp_postmeta` VALUES (230, 60, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (231, 62, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (232, 62, '_edit_lock', '1384474783:1') ; 
INSERT INTO `wp_postmeta` VALUES (234, 4, '_edit_lock', '1384426417:1') ; 
INSERT INTO `wp_postmeta` VALUES (235, 4, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (236, 4, '_wp_page_template', 'page-templates/template-full-width.php') ; 
INSERT INTO `wp_postmeta` VALUES (237, 64, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (238, 64, '_edit_lock', '1384428887:1') ; 
INSERT INTO `wp_postmeta` VALUES (240, 66, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (241, 66, '_edit_lock', '1384474730:1') ; 
INSERT INTO `wp_postmeta` VALUES (243, 68, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (244, 68, '_edit_lock', '1384429055:1') ; 
INSERT INTO `wp_postmeta` VALUES (245, 69, '_wp_attached_file', '2013/11/les-miserables-image08.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (246, 69, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:34:"2013/11/les-miserables-image08.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:34:"les-miserables-image08-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:34:"les-miserables-image08-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:36:"les-miserables-image08-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:34:"les-miserables-image08-220x126.jpg";s:5:"width";i:220;s:6:"height";i:126;s:9:"mime-type";s:10:"image/jpeg";}s:16:"expound-featured";a:4:{s:4:"file";s:34:"les-miserables-image08-460x260.jpg";s:5:"width";i:460;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:12:"expound-mini";a:4:{s:4:"file";s:32:"les-miserables-image08-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (248, 71, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (249, 71, '_edit_lock', '1384474707:1') ; 
INSERT INTO `wp_postmeta` VALUES (252, 74, '_wp_attached_file', '2013/11/football_generic.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (253, 74, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (254, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:864;s:6:"height";i:100;s:4:"file";s:28:"2013/11/football_generic.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"football_generic-150x100.jpg";s:5:"width";i:150;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"football_generic-300x34.jpg";s:5:"width";i:300;s:6:"height";i:34;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:28:"football_generic-220x100.jpg";s:5:"width";i:220;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:16:"expound-featured";a:4:{s:4:"file";s:28:"football_generic-460x100.jpg";s:5:"width";i:460;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:12:"expound-mini";a:4:{s:4:"file";s:26:"football_generic-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (255, 74, '_wp_attachment_is_custom_background', 'expound') ; 
INSERT INTO `wp_postmeta` VALUES (256, 29, '_thumbnail_id', '69') ; 
INSERT INTO `wp_postmeta` VALUES (261, 76, 'ml-slider_settings', 'a:32:{s:4:"type";s:4:"flex";s:6:"random";s:5:"false";s:8:"cssClass";s:0:"";s:8:"printCss";s:4:"true";s:7:"printJs";s:4:"true";s:5:"width";s:3:"800";s:6:"height";s:3:"300";s:3:"spw";i:7;s:3:"sph";i:5;s:5:"delay";s:4:"3000";s:6:"sDelay";i:30;s:7:"opacity";d:0.6999999999999999555910790149937383830547332763671875;s:10:"titleSpeed";i:500;s:6:"effect";s:4:"fade";s:10:"navigation";s:4:"true";s:5:"links";s:4:"true";s:10:"hoverPause";s:4:"true";s:5:"theme";s:7:"default";s:9:"direction";s:10:"horizontal";s:7:"reverse";s:5:"false";s:14:"animationSpeed";s:3:"600";s:8:"prevText";s:1:"<";s:8:"nextText";s:1:">";s:6:"slices";i:15;s:6:"center";s:4:"true";s:9:"smartCrop";s:4:"true";s:12:"carouselMode";s:5:"false";s:6:"easing";s:6:"linear";s:8:"autoPlay";s:4:"true";s:11:"thumb_width";i:150;s:12:"thumb_height";i:100;s:12:"smoothHeight";s:5:"false";}') ; 
INSERT INTO `wp_postmeta` VALUES (262, 30, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (263, 30, '_wp_attachment_backup_sizes', 'a:3:{s:15:"resized-150x150";a:5:{s:4:"path";s:89:"/home/andytann/public_html/tigers/wp-content/uploads/2013/10/football_generic-150x150.jpg";s:4:"file";s:28:"football_generic-150x150.jpg";s:5:"width";i:150;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:15:"resized-233x100";a:5:{s:4:"path";s:89:"/home/andytann/public_html/tigers/wp-content/uploads/2013/10/football_generic-233x100.jpg";s:4:"file";s:28:"football_generic-233x100.jpg";s:5:"width";i:233;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:15:"resized-266x100";a:5:{s:4:"path";s:89:"/home/andytann/public_html/tigers/wp-content/uploads/2013/10/football_generic-266x100.jpg";s:4:"file";s:28:"football_generic-266x100.jpg";s:5:"width";i:266;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}') ; 
INSERT INTO `wp_postmeta` VALUES (264, 27, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (265, 69, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (266, 27, '_wp_attachment_backup_sizes', 'a:2:{s:15:"resized-487x208";a:5:{s:4:"path";s:76:"/home/andytann/public_html/tigers/wp-content/uploads/2013/09/Jam-487x208.jpg";s:4:"file";s:15:"Jam-487x208.jpg";s:5:"width";i:487;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}s:15:"resized-487x182";a:5:{s:4:"path";s:76:"/home/andytann/public_html/tigers/wp-content/uploads/2013/09/Jam-487x182.jpg";s:4:"file";s:15:"Jam-487x182.jpg";s:5:"width";i:487;s:6:"height";i:182;s:9:"mime-type";s:10:"image/jpeg";}}') ; 
INSERT INTO `wp_postmeta` VALUES (267, 69, '_wp_attachment_backup_sizes', 'a:2:{s:15:"resized-700x300";a:5:{s:4:"path";s:95:"/home/andytann/public_html/tigers/wp-content/uploads/2013/11/les-miserables-image08-700x300.jpg";s:4:"file";s:34:"les-miserables-image08-700x300.jpg";s:5:"width";i:700;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:15:"resized-800x300";a:5:{s:4:"path";s:95:"/home/andytann/public_html/tigers/wp-content/uploads/2013/11/les-miserables-image08-800x300.jpg";s:4:"file";s:34:"les-miserables-image08-800x300.jpg";s:5:"width";i:800;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}') ; 
INSERT INTO `wp_postmeta` VALUES (268, 77, 'ml-slider_settings', 'a:32:{s:4:"type";s:4:"flex";s:6:"random";s:5:"false";s:8:"cssClass";s:0:"";s:8:"printCss";s:4:"true";s:7:"printJs";s:4:"true";s:5:"width";s:3:"700";s:6:"height";s:3:"300";s:3:"spw";i:7;s:3:"sph";i:5;s:5:"delay";s:4:"3000";s:6:"sDelay";i:30;s:7:"opacity";d:0.6999999999999999555910790149937383830547332763671875;s:10:"titleSpeed";i:500;s:6:"effect";s:4:"fade";s:10:"navigation";s:4:"true";s:5:"links";s:4:"true";s:10:"hoverPause";s:4:"true";s:5:"theme";s:7:"default";s:9:"direction";s:10:"horizontal";s:7:"reverse";s:5:"false";s:14:"animationSpeed";s:3:"600";s:8:"prevText";s:1:"<";s:8:"nextText";s:1:">";s:6:"slices";i:15;s:6:"center";s:5:"false";s:9:"smartCrop";s:4:"true";s:12:"carouselMode";s:5:"false";s:6:"easing";s:6:"linear";s:8:"autoPlay";s:4:"true";s:11:"thumb_width";i:150;s:12:"thumb_height";i:100;s:12:"smoothHeight";s:5:"false";}') ; 
INSERT INTO `wp_postmeta` VALUES (271, 80, '_wp_attached_file', '2013/11/grass.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (272, 80, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (273, 80, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1725;s:6:"height";i:1159;s:4:"file";s:17:"2013/11/grass.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"grass-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"grass-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:18:"grass-1024x688.jpg";s:5:"width";i:1024;s:6:"height";i:688;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"grass-220x126.jpg";s:5:"width";i:220;s:6:"height";i:126;s:9:"mime-type";s:10:"image/jpeg";}s:16:"expound-featured";a:4:{s:4:"file";s:17:"grass-460x260.jpg";s:5:"width";i:460;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:12:"expound-mini";a:4:{s:4:"file";s:15:"grass-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:31:"Bowling green grass background.";}}') ; 
INSERT INTO `wp_postmeta` VALUES (274, 80, '_wp_attachment_is_custom_background', 'expound') ; 
INSERT INTO `wp_postmeta` VALUES (275, 81, '_wp_attached_file', '2013/11/grass1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (276, 81, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (277, 81, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1725;s:6:"height";i:1159;s:4:"file";s:18:"2013/11/grass1.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"grass1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"grass1-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"grass1-1024x688.jpg";s:5:"width";i:1024;s:6:"height";i:688;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:18:"grass1-220x126.jpg";s:5:"width";i:220;s:6:"height";i:126;s:9:"mime-type";s:10:"image/jpeg";}s:16:"expound-featured";a:4:{s:4:"file";s:18:"grass1-460x260.jpg";s:5:"width";i:460;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:12:"expound-mini";a:4:{s:4:"file";s:16:"grass1-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:31:"Bowling green grass background.";}}') ; 
INSERT INTO `wp_postmeta` VALUES (278, 81, '_wp_attachment_is_custom_background', 'expound') ; 
INSERT INTO `wp_postmeta` VALUES (279, 30, 'ml-slider_url', 'http://www.imdb.com') ; 
INSERT INTO `wp_postmeta` VALUES (280, 82, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (281, 82, '_edit_lock', '1384650311:1') ; 
INSERT INTO `wp_postmeta` VALUES (282, 82, '_thumbnail_id', '27') ; 
INSERT INTO `wp_postmeta` VALUES (287, 87, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (288, 87, '_edit_lock', '1387193025:1') ; 
INSERT INTO `wp_postmeta` VALUES (289, 87, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (290, 89, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (291, 89, '_edit_lock', '1387193035:1') ; 
INSERT INTO `wp_postmeta` VALUES (292, 89, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (297, 91, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (298, 91, '_edit_lock', '1387193188:1') ; 
INSERT INTO `wp_postmeta` VALUES (299, 91, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (300, 93, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (301, 93, '_edit_lock', '1387193544:1') ; 
INSERT INTO `wp_postmeta` VALUES (302, 93, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (303, 95, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (304, 95, '_edit_lock', '1387194399:1') ; 
INSERT INTO `wp_postmeta` VALUES (305, 95, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (306, 97, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (307, 97, '_edit_lock', '1387194421:1') ; 
INSERT INTO `wp_postmeta` VALUES (308, 97, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (309, 99, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (310, 99, '_edit_lock', '1387194443:1') ; 
INSERT INTO `wp_postmeta` VALUES (311, 99, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (312, 101, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (313, 101, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (314, 101, '_edit_lock', '1387195091:1') ; 
INSERT INTO `wp_postmeta` VALUES (315, 103, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (316, 103, '_edit_lock', '1387195112:1') ; 
INSERT INTO `wp_postmeta` VALUES (317, 103, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (318, 20, '_edit_lock', '1387195167:1') ; 
INSERT INTO `wp_postmeta` VALUES (319, 20, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (320, 20, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (321, 10, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (322, 10, '_edit_lock', '1387195187:1') ; 
INSERT INTO `wp_postmeta` VALUES (325, 105, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (326, 105, '_edit_lock', '1387196056:1') ; 
INSERT INTO `wp_postmeta` VALUES (327, 105, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (328, 107, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (329, 107, '_edit_lock', '1387196065:1') ; 
INSERT INTO `wp_postmeta` VALUES (330, 107, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (331, 109, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (332, 109, '_edit_lock', '1387196090:1') ; 
INSERT INTO `wp_postmeta` VALUES (333, 109, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (334, 111, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (335, 111, '_edit_lock', '1387196118:1') ; 
INSERT INTO `wp_postmeta` VALUES (336, 111, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (337, 119, '_wp_attached_file', 'claw.png') ; 
INSERT INTO `wp_postmeta` VALUES (338, 119, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:247;s:6:"height";i:248;s:4:"file";s:8:"claw.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"claw-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:16:"claw-220x126.png";s:5:"width";i:220;s:6:"height";i:126;s:9:"mime-type";s:9:"image/png";}s:12:"expound-mini";a:4:{s:4:"file";s:14:"claw-50x50.png";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}') ; 
INSERT INTO `wp_postmeta` VALUES (339, 119, 'ml-slider_type', 'image') ; 
INSERT INTO `wp_postmeta` VALUES (340, 119, '_wp_attachment_backup_sizes', 'a:1:{s:14:"resized-247x92";a:5:{s:4:"path";s:67:"/Applications/MAMP/htdocs/tigers/wp-content/uploads/claw-247x92.png";s:4:"file";s:15:"claw-247x92.png";s:5:"width";i:247;s:6:"height";i:92;s:9:"mime-type";s:9:"image/png";}}') ; 
INSERT INTO `wp_postmeta` VALUES (341, 121, '_wp_attached_file', 'grass1.jpg') ; 
INSERT INTO `wp_postmeta` VALUES (342, 121, '_wp_attachment_context', 'custom-background') ; 
INSERT INTO `wp_postmeta` VALUES (343, 121, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1725;s:6:"height";i:1159;s:4:"file";s:10:"grass1.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"grass1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"grass1-300x201.jpg";s:5:"width";i:300;s:6:"height";i:201;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"grass1-1024x688.jpg";s:5:"width";i:1024;s:6:"height";i:688;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:18:"grass1-220x126.jpg";s:5:"width";i:220;s:6:"height";i:126;s:9:"mime-type";s:10:"image/jpeg";}s:16:"expound-featured";a:4:{s:4:"file";s:18:"grass1-460x260.jpg";s:5:"width";i:460;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:12:"expound-mini";a:4:{s:4:"file";s:16:"grass1-50x50.jpg";s:5:"width";i:50;s:6:"height";i:50;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:31:"Bowling green grass background.";}}') ; 
INSERT INTO `wp_postmeta` VALUES (344, 121, '_wp_attachment_is_custom_background', 'expound') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Sunday 19. January 2014 00:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=123 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (105 records)
#
 
INSERT INTO `wp_posts` VALUES (85, 1, '2013-12-16 11:23:21', '2013-12-16 11:23:21', '', 'People', '', 'publish', 'open', 'open', '', 'people', '', '', '2013-12-16 11:23:21', '2013-12-16 11:23:21', '', 0, 'http://localhost/tigers/?page_id=85', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2013-09-08 16:02:54', '2013-09-08 16:02:54', 'This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'trash', 'open', 'open', '', 'about', '', '', '2013-09-08 06:20:36', '2013-09-08 06:20:36', '', 0, 'http://localhost/tigers/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (86, 1, '2013-12-16 11:23:21', '2013-12-16 11:23:21', '', 'People', '', 'inherit', 'open', 'open', '', '85-revision-v1', '', '', '2013-12-16 11:23:21', '2013-12-16 11:23:21', '', 85, 'http://localhost/tigers/tigers/85-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (30, 1, '2013-10-20 03:16:32', '2013-10-20 03:16:32', '', 'Football', 'Great', 'inherit', 'open', 'open', '', 'football_generic', '', '', '2013-10-20 03:16:32', '2013-10-20 03:16:32', '', 29, 'http://localhost/tigers/wp-content/uploads/2013/10/football_generic.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2013-09-08 06:17:57', '2013-09-08 06:17:57', '', 'Game On', '', 'publish', 'open', 'open', '', 'game-on', '', '', '2013-11-14 10:55:28', '2013-11-14 10:55:28', '', 0, 'http://localhost/tigers/?page_id=4', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2013-09-08 06:17:57', '2013-09-08 06:17:57', '', 'Game On', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2013-09-08 06:17:57', '2013-09-08 06:17:57', '', 4, 'http://localhost/tigers/uncategorized/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (6, 1, '2013-09-08 06:18:16', '2013-09-08 06:18:16', '', 'Teams', '', 'publish', 'open', 'open', '', 'teams', '', '', '2013-09-08 06:18:42', '2013-09-08 06:18:42', '', 0, 'http://localhost/tigers/?page_id=6', 1, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2013-09-08 06:18:16', '2013-09-08 06:18:16', '', 'Teams', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-09-08 06:18:16', '2013-09-08 06:18:16', '', 6, 'http://localhost/tigers/uncategorized/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2013-09-08 06:18:28', '2013-09-08 06:18:28', '', 'Registration', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-09-08 06:18:28', '2013-09-08 06:18:28', '', 6, 'http://localhost/tigers/uncategorized/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2013-09-08 06:18:42', '2013-09-08 06:18:42', '', 'Teams', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-09-08 06:18:42', '2013-09-08 06:18:42', '', 6, 'http://localhost/tigers/uncategorized/6-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2013-09-08 06:18:52', '2013-09-08 06:18:52', '', 'Registration', '', 'publish', 'open', 'closed', '', 'registration', '', '', '2013-12-16 11:59:47', '2013-12-16 11:59:47', '', 101, 'http://localhost/tigers/?page_id=10', 2, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2013-09-08 06:18:52', '2013-09-08 06:18:52', '', 'Registration', '', 'inherit', 'open', 'open', '', '10-revision-v1', '', '', '2013-09-08 06:18:52', '2013-09-08 06:18:52', '', 10, 'http://localhost/tigers/uncategorized/10-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2013-09-08 06:19:07', '2013-09-08 06:19:07', '', 'Resources', '', 'publish', 'open', 'open', '', 'resources', '', '', '2013-09-08 06:19:07', '2013-09-08 06:19:07', '', 0, 'http://localhost/tigers/?page_id=12', 3, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2013-09-08 06:19:07', '2013-09-08 06:19:07', '', 'Resources', '', 'inherit', 'open', 'open', '', '12-revision-v1', '', '', '2013-09-08 06:19:07', '2013-09-08 06:19:07', '', 12, 'http://localhost/tigers/uncategorized/12-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (18, 1, '2013-09-08 06:19:45', '2013-09-08 06:19:45', '', 'Ground Locations', '', 'publish', 'open', 'open', '', 'ground-locations', '', '', '2013-09-08 06:19:45', '2013-09-08 06:19:45', '', 0, 'http://localhost/tigers/?page_id=18', 5, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (19, 1, '2013-09-08 06:19:45', '2013-09-08 06:19:45', '', 'Ground Locations', '', 'inherit', 'open', 'open', '', '18-revision-v1', '', '', '2013-09-08 06:19:45', '2013-09-08 06:19:45', '', 18, 'http://localhost/tigers/uncategorized/18-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (20, 1, '2013-09-08 06:19:56', '2013-09-08 06:19:56', '', 'Trophy Room', '', 'publish', 'open', 'open', '', 'trophy-room', '', '', '2013-12-16 11:59:27', '2013-12-16 11:59:27', '', 101, 'http://localhost/tigers/?page_id=20', 6, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2013-09-08 06:19:56', '2013-09-08 06:19:56', '', 'Trophy Room', '', 'inherit', 'open', 'open', '', '20-revision-v1', '', '', '2013-09-08 06:19:56', '2013-09-08 06:19:56', '', 20, 'http://localhost/tigers/uncategorized/20-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2013-09-08 06:20:19', '2013-09-08 06:20:19', '', 'Shop', '', 'publish', 'open', 'open', '', 'shop', '', '', '2013-09-08 06:20:19', '2013-09-08 06:20:19', '', 0, 'http://localhost/tigers/?page_id=24', 8, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2013-09-08 06:20:19', '2013-09-08 06:20:19', '', 'Shop', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2013-09-08 06:20:19', '2013-09-08 06:20:19', '', 24, 'http://localhost/tigers/uncategorized/24-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2013-09-08 06:20:36', '2013-09-08 06:20:36', 'This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2013-09-08 06:20:36', '2013-09-08 06:20:36', '', 2, 'http://localhost/tigers/uncategorized/2-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2013-09-09 13:06:15', '2013-09-09 13:06:15', '', 'Jam', 'Michael Jackson and Michael Jordan', 'inherit', 'open', 'open', '', 'jam', '', '', '2013-09-09 13:06:15', '2013-09-09 13:06:15', '', 62, 'http://localhost/tigers/wp-content/uploads/2013/09/Jam.jpg', 1, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2013-09-09 13:16:00', '2013-09-09 13:16:00', 'http://localhost/tigers/wp-content/uploads/2013/09/cropped-football_generic.jpg', 'cropped-football_generic.jpg', '', 'inherit', 'closed', 'open', '', 'cropped-football_generic-jpg', '', '', '2013-09-09 13:16:00', '2013-09-09 13:16:00', '', 0, 'http://localhost/tigers/wp-content/uploads/2013/09/cropped-football_generic.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (29, 1, '2013-11-13 12:17:54', '2013-11-13 12:17:54', '&nbsp;

[caption id="attachment_69" align="aligncenter" width="300"]<a href="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08.jpg"><img class="size-medium wp-image-69 " alt="Dechen Gunden = Hugh Jackman" src="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08-300x300.jpg" width="300" height="300" /></a> Dechen Gunden = Hugh Jackman[/caption]', 'Test Hee Hee', '', 'publish', 'open', 'open', '', 'test-hee-hee', '', '', '2013-11-14 13:22:43', '2013-11-14 13:22:43', '', 0, 'http://localhost/tigers/?p=29', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2013-10-20 03:16:43', '2013-10-20 03:16:43', '<a href="http://localhost/tigers/wp-content/uploads/2013/10/football_generic.jpg"><img class="alignnone size-medium wp-image-30" alt="football_generic" src="http://localhost/tigers/wp-content/uploads/2013/10/football_generic-300x34.jpg" width="300" height="34" /></a>', '', '', 'inherit', 'open', 'open', '', '29-revision-v1', '', '', '2013-10-20 03:16:43', '2013-10-20 03:16:43', '', 29, 'http://localhost/tigers/uncategorized/29-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (32, 1, '2013-10-20 03:17:58', '2013-10-20 03:17:58', '', 'map-malaysia600', '', 'inherit', 'open', 'open', '', 'map-malaysia600', '', '', '2013-10-20 03:17:58', '2013-10-20 03:17:58', '', 29, 'http://localhost/tigers/wp-content/uploads/2013/10/map-malaysia600.gif', 0, 'attachment', 'image/gif', 0) ; 
INSERT INTO `wp_posts` VALUES (34, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=34', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (35, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=35', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (36, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=36', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (37, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=37', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (38, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=38', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (39, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 12, 'http://localhost/tigers/?p=39', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (40, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 12, 'http://localhost/tigers/?p=40', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (41, 1, '2013-11-12 13:04:17', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:17', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=41', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (42, 1, '2013-11-12 13:04:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:18', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=42', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (43, 1, '2013-11-12 13:04:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:18', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=43', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (44, 1, '2013-11-12 13:04:18', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-12 13:04:18', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=44', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (87, 1, '2013-12-16 11:23:44', '2013-12-16 11:23:44', '', 'Committee', '', 'publish', 'open', 'open', '', 'committee', '', '', '2013-12-16 11:23:44', '2013-12-16 11:23:44', '', 85, 'http://localhost/tigers/?page_id=87', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (47, 1, '2013-11-13 12:17:54', '2013-11-13 12:17:54', '<a href="http://localhost/tigers/wp-content/uploads/2013/10/football_generic.jpg"><img class="alignnone size-medium wp-image-30" alt="football_generic" src="http://localhost/tigers/wp-content/uploads/2013/10/football_generic-300x34.jpg" width="300" height="34" /></a>', 'Test Hee Hee', '', 'inherit', 'open', 'open', '', '29-revision-v1', '', '', '2013-11-13 12:17:54', '2013-11-13 12:17:54', '', 29, 'http://localhost/tigers/uncategorized/29-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (48, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=48', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (49, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=49', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (50, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=50', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (51, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=51', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (52, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=52', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (53, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 12, 'http://localhost/tigers/?p=53', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (54, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 12, 'http://localhost/tigers/?p=54', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (55, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=55', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (56, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=56', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (57, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=57', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (58, 1, '2013-11-13 12:18:35', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 12:18:35', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=58', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (59, 1, '2013-11-13 12:28:25', '2013-11-13 12:28:25', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit "Send"]</p>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://localhost/tigers)
andy.tan2624@gmail.com


0

[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://localhost/tigers)
[your-email]


0
Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.', 'Contact form 1', '', 'publish', 'open', 'open', '', 'contact-form-1', '', '', '2013-11-13 12:28:25', '2013-11-13 12:28:25', '', 0, 'http://localhost/tigers/?post_type=wpcf7_contact_form&p=59', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (60, 1, '2013-11-13 12:29:57', '2013-11-13 12:29:57', '[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'draft', 'open', 'open', '', 'contact', '', '', '2013-12-16 12:16:23', '2013-12-16 12:16:23', '', 0, 'http://localhost/tigers/?page_id=60', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (61, 1, '2013-11-13 12:29:57', '2013-11-13 12:29:57', '[contact-form-7 id="59" title="Contact form 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '60-revision-v1', '', '', '2013-11-13 12:29:57', '2013-11-13 12:29:57', '', 60, 'http://localhost/tigers/uncategorized/60-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (62, 1, '2013-11-13 12:43:11', '2013-11-13 12:43:11', 'Bloody Akiva Goldsman, you ruined Batman

[caption id="attachment_27" align="alignnone" width="300"]<a href="http://localhost/tigers/wp-content/uploads/2013/09/Jam.jpg"><img class="size-medium wp-image-27" alt="Michael Jackson and Michael Jordan" src="http://localhost/tigers/wp-content/uploads/2013/09/Jam-300x278.jpg" width="300" height="278" /></a> Michael Jackson and Michael Jordan[/caption]', 'The Second Post', '', 'publish', 'open', 'open', '', 'the-second-post', '', '', '2013-12-20 14:31:07', '2013-12-20 14:31:07', '', 0, 'http://localhost/tigers/?p=62', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (63, 1, '2013-11-13 12:43:11', '2013-11-13 12:43:11', 'Bloody Akiva Goldsman, you ruined Batman

[caption id="attachment_27" align="alignnone" width="300"]<a href="http://localhost/tigers/wp-content/uploads/2013/09/Jam.jpg"><img class="size-medium wp-image-27" alt="Michael Jackson and Michael Jordan" src="http://localhost/tigers/wp-content/uploads/2013/09/Jam-300x278.jpg" width="300" height="278" /></a> Michael Jackson and Michael Jordan[/caption]', 'The Second Post', '', 'inherit', 'open', 'open', '', '62-revision-v1', '', '', '2013-11-13 12:43:11', '2013-11-13 12:43:11', '', 62, 'http://localhost/tigers/uncategorized/62-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (64, 1, '2013-11-14 11:36:37', '2013-11-14 11:36:37', 'Mary J blige', 'Just Fine', '', 'publish', 'open', 'open', '', 'just-fine', '', '', '2013-11-14 11:36:37', '2013-11-14 11:36:37', '', 0, 'http://localhost/tigers/?p=64', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (65, 1, '2013-11-14 11:36:37', '2013-11-14 11:36:37', 'Mary J blige', 'Just Fine', '', 'inherit', 'open', 'open', '', '64-revision-v1', '', '', '2013-11-14 11:36:37', '2013-11-14 11:36:37', '', 64, 'http://localhost/tigers/uncategorized/64-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (66, 1, '2013-11-14 11:37:42', '2013-11-14 11:37:42', 'They are the best team in the world', 'Canberra Raiders', '', 'publish', 'open', 'open', '', 'canberra-raiders', '', '', '2013-11-15 00:20:41', '2013-11-15 00:20:41', '', 0, 'http://localhost/tigers/?p=66', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (67, 1, '2013-11-14 11:37:42', '2013-11-14 11:37:42', 'They are the best team in the world', 'Canberra Raiders', '', 'inherit', 'open', 'open', '', '66-revision-v1', '', '', '2013-11-14 11:37:42', '2013-11-14 11:37:42', '', 66, 'http://localhost/tigers/tigers/66-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (68, 1, '2013-11-14 11:38:50', '2013-11-14 11:38:50', 'is the best dancer in the world

[caption id="attachment_69" align="alignnone" width="210"]<a href="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08.jpg"><img class=" wp-image-69 " alt="Dechen Gunden = Hugh Jackman" src="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08-300x300.jpg" width="210" height="210" /></a> Dechen Gunden = Hugh Jackman[/caption]', 'Dechen Gunden', '', 'publish', 'open', 'open', '', 'dechen-gunden', '', '', '2013-11-14 11:38:50', '2013-11-14 11:38:50', '', 0, 'http://localhost/tigers/?p=68', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (69, 1, '2013-11-14 11:38:17', '2013-11-14 11:38:17', '', 'Les Miserables', 'Dechen Gunden = Hugh Jackman', 'inherit', 'open', 'open', '', 'les-miserables-image08', '', '', '2013-11-14 11:38:17', '2013-11-14 11:38:17', '', 68, 'http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08.jpg', 2, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (70, 1, '2013-11-14 11:38:50', '2013-11-14 11:38:50', 'is the best dancer in the world

[caption id="attachment_69" align="alignnone" width="210"]<a href="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08.jpg"><img class=" wp-image-69 " alt="Dechen Gunden = Hugh Jackman" src="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08-300x300.jpg" width="210" height="210" /></a> Dechen Gunden = Hugh Jackman[/caption]', 'Dechen Gunden', '', 'inherit', 'open', 'open', '', '68-revision-v1', '', '', '2013-11-14 11:38:50', '2013-11-14 11:38:50', '', 68, 'http://localhost/tigers/tigers/68-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (71, 1, '2013-11-14 11:39:57', '2013-11-14 11:39:57', 'Which is the best dance studio? We tell you after these breaks', 'Crossover or Dancekool', '', 'publish', 'open', 'open', '', 'crossover-or-dancekool', '', '', '2013-11-15 00:20:13', '2013-11-15 00:20:13', '', 0, 'http://localhost/tigers/?p=71', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (72, 1, '2013-11-14 11:39:57', '2013-11-14 11:39:57', 'Which is the best dance studio? We tell you after these breaks', 'Crossover or Dancekool', '', 'inherit', 'open', 'open', '', '71-revision-v1', '', '', '2013-11-14 11:39:57', '2013-11-14 11:39:57', '', 71, 'http://localhost/tigers/tigers/71-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (75, 1, '2013-11-14 13:22:43', '2013-11-14 13:22:43', '&nbsp;

[caption id="attachment_69" align="aligncenter" width="300"]<a href="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08.jpg"><img class="size-medium wp-image-69 " alt="Dechen Gunden = Hugh Jackman" src="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08-300x300.jpg" width="300" height="300" /></a> Dechen Gunden = Hugh Jackman[/caption]', 'Test Hee Hee', '', 'inherit', 'open', 'open', '', '29-revision-v1', '', '', '2013-11-14 13:22:43', '2013-11-14 13:22:43', '', 29, 'http://localhost/tigers/tigers/29-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (73, 1, '2013-11-14 13:00:50', '2013-11-14 13:00:50', '&nbsp;

[caption id="attachment_69" align="alignright" width="300"]<a href="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08.jpg"><img class="size-medium wp-image-69 " alt="Dechen Gunden = Hugh Jackman" src="http://localhost/tigers/wp-content/uploads/2013/11/les-miserables-image08-300x300.jpg" width="300" height="300" /></a> Dechen Gunden = Hugh Jackman[/caption]

<a href="http://localhost/tigers/wp-content/uploads/2013/10/football_generic.jpg"><img class="alignnone size-medium wp-image-30" alt="football_generic" src="http://localhost/tigers/wp-content/uploads/2013/10/football_generic-300x34.jpg" width="300" height="34" /></a>', 'Test Hee Hee', '', 'inherit', 'open', 'open', '', '29-revision-v1', '', '', '2013-11-14 13:00:50', '2013-11-14 13:00:50', '', 29, 'http://localhost/tigers/tigers/29-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (74, 1, '2013-11-14 13:07:51', '2013-11-14 13:07:51', '', 'football_generic', '', 'inherit', 'open', 'open', '', 'football_generic-2', '', '', '2013-11-14 13:07:51', '2013-11-14 13:07:51', '', 0, 'http://localhost/tigers/wp-content/uploads/2013/11/football_generic.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (76, 1, '2013-11-16 21:28:07', '2013-11-16 21:28:07', '', 'Home Page', '', 'publish', 'open', 'open', '', 'new-slider', '', '', '2013-11-17 01:04:44', '2013-11-17 01:04:44', '', 0, 'http://localhost/tigers/?post_type=ml-slider&#038;p=76', 0, 'ml-slider', '', 0) ; 
INSERT INTO `wp_posts` VALUES (77, 1, '2013-11-16 21:29:19', '2013-11-16 21:29:19', '', 'New Slider', '', 'publish', 'open', 'open', '', 'new-slider-2', '', '', '2013-11-16 21:29:19', '2013-11-16 21:29:19', '', 0, 'http://localhost/tigers/?post_type=ml-slider&p=77', 0, 'ml-slider', '', 0) ; 
INSERT INTO `wp_posts` VALUES (121, 1, '2014-01-02 12:39:47', '2014-01-02 12:39:47', '', 'Bowling green grass background.', '', 'inherit', 'open', 'open', '', 'bowling-green-grass-background-3', '', '', '2014-01-02 12:39:47', '2014-01-02 12:39:47', '', 0, 'http://localhost/tigers/wp-content/uploads/grass1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (88, 1, '2013-12-16 11:23:44', '2013-12-16 11:23:44', '', 'Committee', '', 'inherit', 'open', 'open', '', '87-revision-v1', '', '', '2013-12-16 11:23:44', '2013-12-16 11:23:44', '', 87, 'http://localhost/tigers/tigers/87-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (80, 1, '2013-11-16 22:24:53', '2013-11-16 22:24:53', '', 'Bowling green grass background.', '', 'inherit', 'open', 'open', '', 'bowling-green-grass-background', '', '', '2013-11-16 22:24:53', '2013-11-16 22:24:53', '', 0, 'http://localhost/tigers/wp-content/uploads/2013/11/grass.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (81, 1, '2013-11-16 22:25:05', '2013-11-16 22:25:05', '', 'Bowling green grass background.', '', 'inherit', 'open', 'open', '', 'bowling-green-grass-background-2', '', '', '2013-11-16 22:25:05', '2013-11-16 22:25:05', '', 0, 'http://localhost/tigers/wp-content/uploads/2013/11/grass1.jpg', 0, 'attachment', 'image/jpeg', 0) ; 
INSERT INTO `wp_posts` VALUES (82, 1, '2013-11-17 01:06:38', '2013-11-17 01:06:38', 'Something somethingdsfsdfsd4sdfsd

sdfsdf

sdfsdf

sdfsd

fds', 'Be an umpire', '', 'publish', 'open', 'open', '', 'be-an-umpire', '', '', '2013-11-17 01:06:38', '2013-11-17 01:06:38', '', 0, 'http://localhost/tigers/?p=82', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (83, 1, '2013-11-17 01:06:38', '2013-11-17 01:06:38', 'Something somethingdsfsdfsd4sdfsd

sdfsdf

sdfsdf

sdfsd

fds', 'Be an umpire', '', 'inherit', 'open', 'open', '', '82-revision-v1', '', '', '2013-11-17 01:06:38', '2013-11-17 01:06:38', '', 82, 'http://localhost/tigers/tigers/82-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (89, 1, '2013-12-16 11:23:55', '2013-12-16 11:23:55', '', 'Coaches', '', 'publish', 'open', 'open', '', 'coaches', '', '', '2013-12-16 11:23:55', '2013-12-16 11:23:55', '', 85, 'http://localhost/tigers/?page_id=89', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (90, 1, '2013-12-16 11:23:55', '2013-12-16 11:23:55', '', 'Coaches', '', 'inherit', 'open', 'open', '', '89-revision-v1', '', '', '2013-12-16 11:23:55', '2013-12-16 11:23:55', '', 89, 'http://localhost/tigers/tigers/89-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (91, 1, '2013-12-16 11:26:28', '2013-12-16 11:26:28', '', 'Volunteer Positions', '', 'publish', 'open', 'open', '', 'volunteer-positions', '', '', '2013-12-16 11:26:28', '2013-12-16 11:26:28', '', 12, 'http://localhost/tigers/?page_id=91', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (92, 1, '2013-12-16 11:26:28', '2013-12-16 11:26:28', '', 'Volunteer Positions', '', 'inherit', 'open', 'open', '', '91-revision-v1', '', '', '2013-12-16 11:26:28', '2013-12-16 11:26:28', '', 91, 'http://localhost/tigers/tigers/91-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (93, 1, '2013-12-16 11:32:24', '2013-12-16 11:32:24', '', 'Forms and Documents', '', 'publish', 'open', 'open', '', 'forms-and-documents', '', '', '2013-12-16 11:32:24', '2013-12-16 11:32:24', '', 12, 'http://localhost/tigers/?page_id=93', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (94, 1, '2013-12-16 11:32:24', '2013-12-16 11:32:24', '', 'Forms and Documents', '', 'inherit', 'open', 'open', '', '93-revision-v1', '', '', '2013-12-16 11:32:24', '2013-12-16 11:32:24', '', 93, 'http://localhost/tigers/tigers/93-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (95, 1, '2013-12-16 11:46:39', '2013-12-16 11:46:39', '', 'Mission Statement', '', 'publish', 'open', 'open', '', 'mission-statement', '', '', '2013-12-16 11:46:39', '2013-12-16 11:46:39', '', 12, 'http://localhost/tigers/?page_id=95', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (96, 1, '2013-12-16 11:46:39', '2013-12-16 11:46:39', '', 'Mission Statement', '', 'inherit', 'open', 'open', '', '95-revision-v1', '', '', '2013-12-16 11:46:39', '2013-12-16 11:46:39', '', 95, 'http://localhost/tigers/tigers/95-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (97, 1, '2013-12-16 11:47:00', '2013-12-16 11:47:00', '', 'Ladder', '', 'publish', 'open', 'open', '', 'ladder', '', '', '2013-12-16 11:47:00', '2013-12-16 11:47:00', '', 4, 'http://localhost/tigers/?page_id=97', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (98, 1, '2013-12-16 11:47:00', '2013-12-16 11:47:00', '', 'Ladder', '', 'inherit', 'open', 'open', '', '97-revision-v1', '', '', '2013-12-16 11:47:00', '2013-12-16 11:47:00', '', 97, 'http://localhost/tigers/tigers/97-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (99, 1, '2013-12-16 11:47:23', '2013-12-16 11:47:23', '', 'Results', '', 'publish', 'open', 'open', '', 'results', '', '', '2013-12-16 11:47:23', '2013-12-16 11:47:23', '', 4, 'http://localhost/tigers/?page_id=99', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (100, 1, '2013-12-16 11:47:23', '2013-12-16 11:47:23', '', 'Results', '', 'inherit', 'open', 'open', '', '99-revision-v1', '', '', '2013-12-16 11:47:23', '2013-12-16 11:47:23', '', 99, 'http://localhost/tigers/tigers/99-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (101, 1, '2013-12-16 11:58:11', '2013-12-16 11:58:11', '', 'Tiger Den', '', 'publish', 'open', 'open', '', 'tiger-den', '', '', '2013-12-16 11:58:11', '2013-12-16 11:58:11', '', 0, 'http://localhost/tigers/?page_id=101', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (102, 1, '2013-12-16 11:58:11', '2013-12-16 11:58:11', '', 'Tiger Den', '', 'inherit', 'open', 'open', '', '101-revision-v1', '', '', '2013-12-16 11:58:11', '2013-12-16 11:58:11', '', 101, 'http://localhost/tigers/tigers/101-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (103, 1, '2013-12-16 11:58:31', '2013-12-16 11:58:31', '', 'Gallery', '', 'publish', 'open', 'open', '', 'gallery', '', '', '2013-12-16 11:58:31', '2013-12-16 11:58:31', '', 101, 'http://localhost/tigers/?page_id=103', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (104, 1, '2013-12-16 11:58:31', '2013-12-16 11:58:31', '', 'Gallery', '', 'inherit', 'open', 'open', '', '103-revision-v1', '', '', '2013-12-16 11:58:31', '2013-12-16 11:58:31', '', 103, 'http://localhost/tigers/tigers/103-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (105, 1, '2013-12-16 12:14:16', '2013-12-16 12:14:16', '', 'Song History', '', 'publish', 'open', 'open', '', 'song-history', '', '', '2013-12-16 12:14:16', '2013-12-16 12:14:16', '', 101, 'http://localhost/tigers/?page_id=105', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (106, 1, '2013-12-16 12:14:16', '2013-12-16 12:14:16', '', 'Song History', '', 'inherit', 'open', 'open', '', '105-revision-v1', '', '', '2013-12-16 12:14:16', '2013-12-16 12:14:16', '', 105, 'http://localhost/tigers/tigers/105-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (107, 1, '2013-12-16 12:14:25', '2013-12-16 12:14:25', '', 'Clearance', '', 'publish', 'open', 'open', '', 'clearance', '', '', '2013-12-16 12:14:25', '2013-12-16 12:14:25', '', 101, 'http://localhost/tigers/?page_id=107', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (108, 1, '2013-12-16 12:14:25', '2013-12-16 12:14:25', '', 'Clearance', '', 'inherit', 'open', 'open', '', '107-revision-v1', '', '', '2013-12-16 12:14:25', '2013-12-16 12:14:25', '', 107, 'http://localhost/tigers/tigers/107-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (109, 1, '2013-12-16 12:14:50', '2013-12-16 12:14:50', '', 'Tiger Premiership', '', 'publish', 'open', 'open', '', 'tiger-premiership', '', '', '2013-12-16 12:14:50', '2013-12-16 12:14:50', '', 101, 'http://localhost/tigers/?page_id=109', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (110, 1, '2013-12-16 12:14:50', '2013-12-16 12:14:50', '', 'Tiger Premiership', '', 'inherit', 'open', 'open', '', '109-revision-v1', '', '', '2013-12-16 12:14:50', '2013-12-16 12:14:50', '', 109, 'http://localhost/tigers/tigers/109-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (111, 1, '2013-12-16 12:15:18', '2013-12-16 12:15:18', '', 'Life Time Moniker', '', 'publish', 'open', 'open', '', 'life-time-moniker', '', '', '2013-12-16 12:15:18', '2013-12-16 12:15:18', '', 101, 'http://localhost/tigers/?page_id=111', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (112, 1, '2013-12-16 12:15:18', '2013-12-16 12:15:18', '', 'Life Time Moniker', '', 'inherit', 'open', 'open', '', '111-revision-v1', '', '', '2013-12-16 12:15:18', '2013-12-16 12:15:18', '', 111, 'http://localhost/tigers/tigers/111-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (114, 1, '2013-12-20 14:32:06', '2013-12-20 14:32:06', 'WORK GOD DAMN IT', 'LINZA POWER', '', 'publish', 'open', 'open', '', 'linza-power', '', '', '2013-12-20 14:32:06', '2013-12-20 14:32:06', '', 0, 'http://localhost/tigers/?p=114', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (115, 1, '2013-12-20 14:32:06', '2013-12-20 14:32:06', 'WORK GOD DAMN IT', 'LINZA POWER', '', 'inherit', 'open', 'open', '', '114-revision-v1', '', '', '2013-12-20 14:32:06', '2013-12-20 14:32:06', '', 114, 'http://localhost/tigers/tigers/114-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (116, 1, '2013-12-20 14:32:44', '2013-12-20 14:32:44', 'dsfsodjfosdjfoisdhfoisdhjoifsd', 'Something something', '', 'publish', 'open', 'open', '', 'something-something', '', '', '2013-12-21 00:35:12', '2013-12-21 00:35:12', '', 0, 'http://localhost/tigers/?p=116', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (117, 1, '2013-12-20 14:32:44', '2013-12-20 14:32:44', 'dsfsodjfosdjfoisdhfoisdhjoifsd', 'Something something', '', 'inherit', 'open', 'open', '', '116-revision-v1', '', '', '2013-12-20 14:32:44', '2013-12-20 14:32:44', '', 116, 'http://localhost/tigers/tigers/116-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (122, 1, '2014-01-12 11:25:26', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-01-12 11:25:26', '0000-00-00 00:00:00', '', 0, 'http://localhost/tigers/?p=122', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (119, 1, '2013-12-22 13:21:22', '2013-12-22 13:21:22', '', 'claw', '', 'inherit', 'open', 'open', '', 'claw', '', '', '2013-12-22 13:21:22', '2013-12-22 13:21:22', '', 0, 'http://localhost/tigers/wp-content/uploads/claw.png', 1, 'attachment', 'image/png', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Sunday 19. January 2014 00:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (22 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (3, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (4, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (6, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (29, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (62, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (64, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (66, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (68, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (68, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (71, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (29, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (71, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (66, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (66, 6, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (62, 4, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (62, 5, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (119, 7, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (82, 1, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Sunday 19. January 2014 00:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (8 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'link_category', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'post_format', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'post_tag', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (6, 6, 'post_tag', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (7, 7, 'ml-slider', '', 0, 0) ; 
INSERT INTO `wp_term_taxonomy` VALUES (8, 8, 'ml-slider', '', 0, 0) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Sunday 19. January 2014 00:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (8 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Tigers', 'tigers', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Blogroll', 'blogroll', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'post-format-image', 'post-format-image', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'Raiders', 'raiders', 0) ; 
INSERT INTO `wp_terms` VALUES (5, 'Dechen', 'dechen', 0) ; 
INSERT INTO `wp_terms` VALUES (6, 'Gendun', 'gendun', 0) ; 
INSERT INTO `wp_terms` VALUES (7, '76', '76', 0) ; 
INSERT INTO `wp_terms` VALUES (8, '77', '77', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Sunday 19. January 2014 00:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (22 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', 'Andy') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', 'Tan') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', 'I\'m a web developer') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'aim', '') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'yim', '') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'jabber', '') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '122') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_customize_current_theme_link,wp350_media,wp360_revisions') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'wp_user-settings', 'editor=tinymce&hidetb=1&libraryContent=browse&uploader=1') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'wp_user-settings-time', '1387716727') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (20, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}') ; 
INSERT INTO `wp_usermeta` VALUES (21, 1, 'meta-box-order_post', 'a:3:{s:4:"side";s:61:"submitdiv,formatdiv,categorydiv,tagsdiv-post_tag,postimagediv";s:6:"normal";s:96:"revisionsdiv,postexcerpt,trackbacksdiv,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}') ; 
INSERT INTO `wp_usermeta` VALUES (22, 1, 'screen_layout_post', '2') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://localhost/tigers MySQL database backup
#
# Generated: Sunday 19. January 2014 00:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'andy.tan2624', '$P$BIJNjFU5EZ3u/C/wMhI3gi1h/BfdvK1', 'admin', 'andy.tan2624@gmail.com', '', '2013-09-07 12:44:34', '', 0, 'andy.tan2624') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

