# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Monday 11. November 2013 04:23 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Monday 11. November 2013 04:23 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (1 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2010-06-18 20:51:35', '2010-06-18 20:51:35', 'Hi, this is a comment.<br />To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Monday 11. November 2013 04:23 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (7 records)
#
 
INSERT INTO `wp_links` VALUES (1, 'http://codex.wordpress.org/', 'Documentation', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (2, 'http://wordpress.org/development/', 'WordPress Blog', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', 'http://wordpress.org/development/feed/') ; 
INSERT INTO `wp_links` VALUES (3, 'http://wordpress.org/extend/ideas/', 'Suggest Ideas', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (4, 'http://wordpress.org/support/', 'Support Forum', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (5, 'http://wordpress.org/extend/plugins/', 'Plugins', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (6, 'http://wordpress.org/extend/themes/', 'Themes', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (7, 'http://planet.wordpress.org/', 'WordPress Planet', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ;
#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Monday 11. November 2013 04:23 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=493 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (183 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'Gosford Junior Australian Football Club', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'andy.tan2624@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'links_recently_updated_prepend', '<em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'links_recently_updated_append', '</em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'links_recently_updated_time', '120', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'permalink_structure', '/%category%/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (36, 'active_plugins', 'a:3:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:45:"limit-login-attempts/limit-login-attempts.php";i:2;s:40:"twitter-widget-pro/wp-twitter-widget.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'home', 'http://www.andytan.net/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (41, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'recently_edited', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'template', 'tigertheme', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'stylesheet', 'tigertheme', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (49, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'db_version', '24448', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'upload_path', '/home/andytann/public_html/tigers/wp-content/uploads', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (83, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'embed_size_w', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'embed_size_h', '600', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'page_on_front', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (101, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (204, '_site_transient_timeout_browser_2dd0f307078ee8a785a20cc124791357', '1379592171', 'yes') ; 
INSERT INTO `wp_options` VALUES (205, '_site_transient_browser_2dd0f307078ee8a785a20cc124791357', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"29.0.1547.65";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (102, 'ftp_credentials', 'a:3:{s:8:"hostname";s:9:"localhost";s:8:"username";N;s:15:"connection_type";s:3:"ftp";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (103, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (104, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, 'link_manager_enabled', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, 'initial_db_version', '15260', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (108, 'cron', 'a:6:{i:1384137883;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1384138014;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1384142255;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1384210800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1384470000;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (117, 'rewrite_rules', 'a:72:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:31:".+?/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:".+?/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:".+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"(.+?)/([^/]+)/trackback/?$";s:57:"index.php?category_name=$matches[1]&name=$matches[2]&tb=1";s:46:"(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:41:"(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:34:"(.+?)/([^/]+)/page/?([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&paged=$matches[3]";s:41:"(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&cpage=$matches[3]";s:26:"(.+?)/([^/]+)(/[0-9]+)?/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&page=$matches[3]";s:20:".+?/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:".+?/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:".+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:26:"(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:33:"(.+?)/comment-page-([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&cpage=$matches[2]";s:8:"(.+?)/?$";s:35:"index.php?category_name=$matches[1]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (118, 'limit_login_retries', 'a:1:{s:3:"::1";i:1;}', 'no') ; 
INSERT INTO `wp_options` VALUES (237, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (490, '_site_transient_timeout_theme_roots', '1384123928', 'yes') ; 
INSERT INTO `wp_options` VALUES (491, '_site_transient_theme_roots', 'a:3:{s:10:"tigertheme";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (116, '_site_transient_update_themes', 'O:8:"stdClass":3:{s:12:"last_checked";i:1384122128;s:7:"checked";a:3:{s:10:"tigertheme";s:1:"1";s:14:"twentythirteen";s:3:"1.0";s:12:"twentytwelve";s:3:"1.2";}s:8:"response";a:2:{s:14:"twentythirteen";a:3:{s:11:"new_version";s:3:"1.1";s:3:"url";s:42:"http://wordpress.org/themes/twentythirteen";s:7:"package";s:59:"http://wordpress.org/themes/download/twentythirteen.1.1.zip";}s:12:"twentytwelve";a:3:{s:11:"new_version";s:3:"1.3";s:3:"url";s:40:"http://wordpress.org/themes/twentytwelve";s:7:"package";s:57:"http://wordpress.org/themes/download/twentytwelve.1.3.zip";}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (119, 'limit_login_retries_valid', 'a:1:{s:3:"::1";i:1381796543;}', 'no') ; 
INSERT INTO `wp_options` VALUES (120, '_transient_random_seed', '05b1f52ae0bf7e1973415ec8bad6f650', 'yes') ; 
INSERT INTO `wp_options` VALUES (121, '_site_transient_timeout_browser_de48341fc1229faa5760dbf4f44462ec', '1379126815', 'yes') ; 
INSERT INTO `wp_options` VALUES (122, '_site_transient_browser_de48341fc1229faa5760dbf4f44462ec', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"29.0.1547.62";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (123, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:29:"http://www.andytan.net/tigers";s:4:"link";s:105:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://www.andytan.net/tigers/";s:3:"url";s:138:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://www.andytan.net/tigers/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:26:"http://wordpress.org/news/";s:3:"url";s:31:"http://wordpress.org/news/feed/";s:5:"title";s:14:"WordPress Blog";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:28:"http://planet.wordpress.org/";s:3:"url";s:33:"http://planet.wordpress.org/feed/";s:5:"title";s:20:"Other WordPress News";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (373, '_site_transient_update_plugins', 'O:8:"stdClass":3:{s:12:"last_checked";i:1384091131;s:7:"checked";a:5:{s:19:"akismet/akismet.php";s:5:"2.5.9";s:35:"backupwordpress/backupwordpress.php";s:5:"2.3.3";s:9:"hello.php";s:3:"1.6";s:45:"limit-login-attempts/limit-login-attempts.php";s:5:"1.7.1";s:40:"twitter-widget-pro/wp-twitter-widget.php";s:5:"2.6.0";}s:8:"response";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (374, 'twp_version', '2.6.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (442, '_transient_timeout_feed_mod_a09314b1a57acfaba9faaca775e0e5d2', '1384094552', 'no') ; 
INSERT INTO `wp_options` VALUES (443, '_transient_feed_mod_a09314b1a57acfaba9faaca775e0e5d2', '1384051352', 'no') ; 
INSERT INTO `wp_options` VALUES (371, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1381765135', 'yes') ; 
INSERT INTO `wp_options` VALUES (372, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3898";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2456";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2344";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1930";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1856";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1583";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1329";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1325";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1310";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1260";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1225";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1121";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1000";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"982";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"974";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"950";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"844";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"821";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"780";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"722";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"686";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"681";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"678";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"623";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"615";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"595";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"572";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"570";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"541";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"539";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"530";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"522";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"506";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"505";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"471";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"458";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"453";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"452";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"436";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"432";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (138, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (241, 'hmbkp_default_path', '/Applications/MAMP/htdocs/tigers/wp-content/backupwordpress-43bcb68547-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (242, 'hmbkp_path', '/Applications/MAMP/htdocs/tigers/wp-content/backupwordpress-43bcb68547-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (458, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1384094555', 'no') ; 
INSERT INTO `wp_options` VALUES (459, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1384051355', 'no') ; 
INSERT INTO `wp_options` VALUES (468, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1384094555', 'no') ; 
INSERT INTO `wp_options` VALUES (469, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"WordPress.tv: Tony Perez: WordPress Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24089";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"http://wordpress.tv/2013/11/09/tony-perez-wordpress-security/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:643:"<div id="v-aDJ6mRFk-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24089/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24089/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24089&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/09/tony-perez-wordpress-security/"><img alt="Tony Perez: WordPress Security" src="http://videos.videopress.com/aDJ6mRFk/video-a3e0296802_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 09 Nov 2013 17:16:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"WordPress.tv: Panel Discussion: BuddyPress QandA Panel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24125";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.tv/2013/11/09/panel-discussion-buddypress-qanda-panel/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:657:"<div id="v-t4lN8L39-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24125/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24125/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24125&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/09/panel-discussion-buddypress-qanda-panel/"><img alt="Panel Discussion: BuddyPress QandA Panel" src="http://videos.videopress.com/t4lN8L39/video-836bf0bd9f_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 09 Nov 2013 14:34:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:95:"WPTavern: WPWeekly Episode 127 – Roundtable With Brad Williams Who Eats API’s For Breakfast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11319";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:102:"http://www.wptavern.com/wpweekly-episode-127-roundtable-with-brad-williams-who-eats-apis-for-breakfast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3621:"<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2.jpg?resize=150%2C150" alt="WordPress Weekly Cover Art" class="alignright size-thumbnail wp-image-8715" /></a> In this weeks episode, we were joined by Brad Williams of <a href="http://www.webdevstudios.com" title="http://www.webdevstudios.com">Webdevstudios</a> and <a href="http://www.dradcast.com" title="http://www.dradcast.com">Dradcast</a> to discuss the headlines of the week. We covered a large assortment of news items and received some updates on projects Webdevstudios is working on such as the latest release of <a href="http://wordpress.org/plugins/badgeos/" title="http://wordpress.org/plugins/badgeos/">BadgeOS</a>. Brad is a long time participant of the WordPress Weekly show and it was great to have him back. The last time he was on the show was June 6th, 2010 when he called into the show from WordCamp Chicago. This episode reminded me how much fun it is to be part of a roundtable type of show.<span id="more-11319"></span></p>
<h2>Stories Discussed:</h2>
<p><a href="http://www.wptavern.com/breaking-new-features-selected-to-merge-into-wordpress-3-8-core" title="http://www.wptavern.com/breaking-new-features-selected-to-merge-into-wordpress-3-8-core">Breaking: New Features Selected To Merge Into WordPress 3.8 Core</a><br />
<a href="http://www.wptavern.com/the-future-of-wordpress-widgets-a-better-ui-with-real-time-previews" title="http://www.wptavern.com/the-future-of-wordpress-widgets-a-better-ui-with-real-time-previews">The Future of WordPress Widgets: A Better UI With Real-Time Previews</a><br />
<a href="http://www.wptavern.com/cart66-launches-wordpress-managed-hosting-for-e-commerce" title="http://www.wptavern.com/cart66-launches-wordpress-managed-hosting-for-e-commerce">Cart66 Launches WordPress Managed Hosting for E-Commerce</a><br />
<a href="http://www.wptavern.com/my-approachable-wordpress-story" title="http://www.wptavern.com/my-approachable-wordpress-story">My Approachable WordPress Story</a><br />
<a href="http://www.wptavern.com/should-wordpress-include-a-password-generator" title="http://www.wptavern.com/should-wordpress-include-a-password-generator">Should WordPress Include a Password Generator?</a><br />
<a href="http://www.wptavern.com/buddypress-1-9-to-retire-default-theme-and-add-new-notifications-component" title="http://www.wptavern.com/buddypress-1-9-to-retire-default-theme-and-add-new-notifications-component">BuddyPress 1.9 To Retire Default Theme and Add New Notifications Component</a><br />
<a href="http://www.wptavern.com/gravityforms-1-8-beta-released-introduces-api" title="http://www.wptavern.com/gravityforms-1-8-beta-released-introduces-api">GravityForms 1.8 Beta Released, Introduces API</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, November 15th 3 P.M. Eastern &#8211; Special Guest will be Brian Gardner of StudioPress.com</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #127:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 09 Nov 2013 03:46:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: Free WordPress Writr Theme Now Available on WordPress.org";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11288";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.wptavern.com/free-wordpress-writr-theme-now-available-on-wordpress-org";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3119:"<p>Last week WordPress.com released <a href="http://en.blog.wordpress.com/2013/10/31/writr/" target="_blank">Writr</a>, a beautiful free theme that really puts your content in the spotlight. The tumblelog style is perfect for power bloggers who like to utilize <a href="http://en.support.wordpress.com/posts/post-formats/" target="_blank">post formats</a> for different types of content. </p>
<p>The good news this week is that Writr is now available for self-hosted WordPress sites via its new page on <a href="http://wordpress.org/themes/writr" target="_blank">WordPress.org</a>. You can install it directly through your dashboard and take advantage of the same features the theme offers on WordPress.com.</p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/writr.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/writr.jpg?resize=560%2C420" alt="writr" class="aligncenter size-full wp-image-11292" /></a><span id="more-11288"></span></p>
<p>Writr is responsive and looks absolutely stunning on any device. On smaller devices the sidebar is either displayed or hidden via a neatly tucked corner toggle. Instead of stacking the sidebar content below the list of posts, it&#8217;s always at your fingertips with one click. <a href="http://writrdemo.wordpress.com/" target="_blank">Test the demo</a> by resizing your browser window to see how nicely it works.</p>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/responsive.png" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/responsive.png?resize=560%2C204" alt="responsive" class="aligncenter size-full wp-image-11297" /></a></p>
<h3>Theme Options for Customizing Writr</h3>
<p>Writr comes with unique icons for each post type as well as 6 different color schemes: turquoise (default), blue, green, grey, purple, and red. It also has support for a custom header image, background, menu and social icons.</p>
<p>One of my favorite features of the Writr theme is the optional wider content area. It can be easily increased by visiting the customizer and ticking the “Wider Content Area” checkbox &#8211; no CSS edits necessary!</p>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/writr_wider_content_area.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/writr_wider_content_area.jpg?resize=560%2C293" alt="writr_wider_content_area" class="aligncenter size-full wp-image-11307" /></a></p>
<p>Since Writr was originally built for use on WordPress.com and has passed the <a href="http://codex.wordpress.org/Theme_Review" target="_blank">rigorous theme standards</a> of WordPress.org, you know that it&#8217;s a high quality theme. An added benefit here is that it&#8217;s supported by professional developers so you&#8217;ll be good to go for future updates.</p>
<p>Does <a href="http://wordpress.org/themes/writr" target="_blank">Writr</a> have you thinking about changing the theme on your blog? Install it from WordPress.org and check it out in live preview mode.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 23:33:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WPTavern: CoSchedule – A Viable Alternative To The Edit Flow WordPress Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11218";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:89:"http://www.wptavern.com/coschedule-a-viable-alternative-to-the-edit-flow-wordpress-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:11402:"<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleLogo.jpg" rel="thumbnail"><img class="alignright size-full wp-image-11248" alt="CoSchedule Logo" src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleLogo.jpg?resize=273%2C80" /></a>I&#8217;m a huge fan of the <a title="http://wordpress.org/plugins/edit-flow/" href="http://wordpress.org/plugins/edit-flow/">Edit Flow plugin</a>, especially since this site started publishing articles from multiple authors. It has all sorts of cool features such as custom post statuses, notifications, and editorial comments within posts. Unfortunately, Edit Flow is broken in a few places. I&#8217;ve been in touch with at least a few people who told me they switched to a different plugin because of the issues they encountered with Edit Flow. Thankfully, those items are being addressed and a fix should be released soon. In the mean time, I discovered a paid alternative to Edit Flow that looks to be just as good if not better than Edit Flow called <a title="http://coschedule.com/" href="http://coschedule.com/">CoSchedule</a>. <span id="more-11218"></span></p>
<div class="aligncenter">
<p><span class="embed-youtube"></span></p>
</div>
<h3>CoSchedule In a Nutshell</h3>
<p>CoSchedule is a service created by <a title="http://profiles.wordpress.org/todaymade/" href="http://profiles.wordpress.org/todaymade/">Garret Moon</a> of <a title="http://todaymade.com/" href="http://todaymade.com/">Todaymade</a> that is accessible in WordPress via a plugin. It provides an editorial workflow complete with a calendar to help keep track of activity across the site. It&#8217;s $10.00 per month per WordPress site. The plan includes:</p>
<ul>
<li>Unlimited Users</li>
<li>Unlimited Social Accounts</li>
<li>No hidden fees</li>
<li>Free support</li>
<li>The option of cancelling your account at any time, no credit card required.</li>
</ul>
<p>New users have 14 days to try out the service.</p>
<h3>Installing And Configuring CoSchedule</h3>
<p>Installing and configuring CoSchedule was a breeze thanks in large part to a video explanation and the excellent use of pointers introduced in <a href="http://wordpress.org/news/2011/12/sonny/" title="http://wordpress.org/news/2011/12/sonny/">WordPress 3.3</a>. It&#8217;s the first time those tips came in handy. They also disappeared once I went through the process once. When setting up for the first time, make certain you select the appropriate time zone. If you don&#8217;t, it will throw off the entire system. </p>
<h3>Controlling Social Media And Content From One Interface</h3>
<p>Not only can writers create and manage posts through CoSchedule, they can also manager their social media presence by connecting their accounts similar to the way <a title="http://jetpack.me/support/publicize/" href="http://jetpack.me/support/publicize/">Publicize works in Jetpack</a>. Unlike Jetpack, you can control when the social media message is broadcasted. Being able to control when and how your social media messages are displayed along with content is a great combination.</p>
<div id="attachment_11250" class="wp-caption aligncenter"><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleSocialMediaPost.jpg" rel="thumbnail"><img class="size-large wp-image-11250" alt="Creating A Social Media Post" src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleSocialMediaPost.jpg?resize=500%2C357" /></a><p class="wp-caption-text">Creating A Social Media Post</p></div>
<p>As you can see from the following screenshot, social media posts show up in the calendar alongside blog posts. Changing when these events occur is as simple as clicking and dragging the post from one day to the next. </p>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleTwitterPost.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleTwitterPost.jpg?resize=441%2C267" alt="CoScheduleTwitterPost" class="aligncenter size-full wp-image-11251" /></a></p>
<h3>Light Grey On White Is Not A Good Combination</h3>
<p>One thing I didn&#8217;t like is the lack of bold colors for the fonts used throughout the interface. The light grey colored fonts used on top of a white background were hard to see. Even though CoSchedule ships with multiple color schemes, none of them improved the situation. In fact, some of the color schemes made the problem worse. Take this screenshot for example. I&#8217;m hoping the next version of CoSchedule experiments with bolder colors.</p>
<div id="attachment_11252" class="wp-caption aligncenter"><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleInterfaceColors.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleInterfaceColors.jpg?resize=500%2C223" alt="CoSchedule Interface Colors" class="size-large wp-image-11252" /></a><p class="wp-caption-text">Hard To Read Light Grey Text</p></div>
<h3>Not Native To WordPress But It Works</h3>
<p>The interface for managing posts whether it be the calendar view or when writing/editing a blog post is not the native WordPress interface. But it&#8217;s not a drastic departure either. In fact, I like it and it works well. </p>
<h3>The Manager With Many Hats</h3>
<p>Just like Edit Flow, CoSchedule gives you the ability to create users and assign them specific roles. This is known as the team. The owner of the site has the power to create new users and assign them roles. One improvement that could be made here is when typing in a users name, CoSchedule looks at the WordPress users and auto suggests a match. That way, it just adds them to the team members list. I love how there is a clear explanation of what each role allows on the bottom of the Team Members page. </p>
<div id="attachment_11253" class="wp-caption aligncenter"><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleUsers.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleUsers.jpg?resize=500%2C302" alt="Creating CoSchedule Users" class="size-large wp-image-11253" /></a><p class="wp-caption-text">Controlling CoSchedule Users</p></div>
<p>CoSchedule has integration support for Bitly, Google Analytics, and Google Calendar. </p>
<h3>My Favorite Feature Of CoSchedule</h3>
<p>Just like Edit Flow, my favorite feature in CoSchedule is the ability to provide editorial comments attached to a post. This has proved to be an invaluable feature that makes collaboration easy. Besides being able to write comments, depending on your user role, you can assign tasks to that writer. For each task that is completed, the task creator will receive a notification that it&#8217;s been completed. You can also follow posts. Following a post means you&#8217;ll receive notifications for any activity that occurs on that post. </p>
<div id="attachment_11255" class="wp-caption aligncenter"><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleCommentsAndTasks.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleCommentsAndTasks.jpg?resize=362%2C412" alt="Adding Comments Or Tasks" class="size-full wp-image-11255" /></a><p class="wp-caption-text">Adding Comments Or Tasks</p></div>
<h3>Interview With Founder Garret Moon</h3>
<p><strong>How much functionality of CoSchedule is in the actual plugin versus the website?</strong><br />
<em>CoSchedule relies completely on WordPress core for post scheduling and publishing. Posts on the calendar are simply synced with your WordPress install, not moved. Social messages are handled a bit differently, and sent remotely from the CoSchedule servers. </p>
<p>CoSchedule is a web application that integrates deeply with WordPress through the use of the CoSchedule plugin. We aren&#8217;t 100% embedded into your WordPress install for all purposes, but this is by design. This combination provides the best possible user experience and reliability. Our goal is to allow WordPress to do what it does best, and our own service to add as much value as it possibly can. </em></p>
<p><strong>What happens if CoSchedule stops working or the website disappears? Will data be lost?</strong><br />
<em>Post data is never moved to our servers and remains on your local install. Post data loss is not a possibility with CoSchedule. Scheduled social messages are stored on our servers, but data loss is still very unlikely. We maintain redundant databases at all times and complete hourly backups of user data. Our data is secured with some of the largest data providers in the world.</em></p>
<p><strong>Was Edit Flow an inspiration when creating CoSchedule?</strong><br />
<em>Not really. We created CoSchedule because we wanted a robust tool for scheduling social media messages and blog posts on the same calendar, and in a team environment. We also believe in WordPress as a publishing platform, so we felt that the best way to accomplish this was through a custom application that worked in-hand with WordPress.</em></p>
<p><strong>How did you arrive at the $10 per month price point?</strong></p>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoSchedulePricing.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoSchedulePricing.jpg?resize=500%2C245" alt="CoSchedule Pricing" class="aligncenter size-large wp-image-11284" /></a></p>
<p><em>We talked to our users a lot about this, and ultimately decided on something that would make CoSchedule available to as many people as possible, while providing the income necessary to maintain the highest quality service possible. So far, the response had been good since the $10/month price point is still very affordable for most bloggers.</em></p>
<p><strong>What are some of the features you have in the works for the next iteration of CoSchedule?</strong><br />
<em>We have a lot of improvements to our social scheduling in the works. We recently added Buffer and Google+ Pages integration, which was a huge win. Up next, are core enhancements to the messages that are created –specifically how they look when they are published to social networks. We also have some exciting features in the works that will make social scheduling easier and more automated.  </p>
<p>Since we began building CoSchedule we have been very responsive to feedback, and in-tune with what our users want us to build. While we have many plans for CoSchedule, we are always looking for feedback from the community on how they want to see it grow. </em></p>
<h3>Conclusion</h3>
<p>CoSchedule is a great service. The application inside of WordPress was responsive without any noticeable lag. If it were not for the price tag, I could see myself ditching Edit Flow in favor of this. But at $10.00 a month, it&#8217;s very affordable. Sites running WordPress that have multiple authors need something like CoSchedule in place to make sense of all the chaos. I discovered a few minor styling issues while testing but I&#8217;ve already let the developers know and they are in the process of fixing them. Don&#8217;t take my word for it. Give <a href="http://coschedule.com/" title="http://coschedule.com/">CoSchedule</a> a try for 14 days and arrive at your own conclusion. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 22:00:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WordPress.tv: Mike Van Winkle: Adding Source Control To Your Code";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24129";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wordpress.tv/2013/11/08/mike-van-winkle-adding-source-control-to-your-code/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:685:"<div id="v-RXMnfkEq-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24129/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24129/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24129&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/08/mike-van-winkle-adding-source-control-to-your-code/"><img alt="Mike Van Winkle: Adding Source Control To Your Code" src="http://videos.videopress.com/RXMnfkEq/video-1d24340b87_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 20:19:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WPTavern: VIP Quickstart: A Local Development Environment That Mirrors WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11259";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://www.wptavern.com/vip-quickstart-a-local-development-environment-that-mirrors-wordpress-com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2920:"<p>The <a href="http://vip.wordpress.com/" target="_blank">WordPress.com VIP</a> development team maintains some of the largest WordPress installations on the web, including Time, NBC Sports, TechCrunch, CNN and many others. Creating a proper development environment is crucial to serving clients who use WordPress on such a large scale, but it&#8217;s not very easy to set up. That&#8217;s why the VIP development team decided to put together an environment that closely mirrors what they would be deploying to on WordPress.com.</p>
<p><a href="http://vip.wordpress.com/2013/10/07/vip-quickstart/" target="_blank">VIP Quickstart</a> makes setting up a development environment a quick and easy process. The really awesome thing is that this is open source software, now available on <a href="https://github.com/Automattic/vip-quickstart" target="_blank">github</a> for anyone to use. VIP Quickstart includes all the features and scalability that WordPress.com uses to power millions of blogs.<span id="more-11259"></span></p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/code.png" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/code.png?resize=560%2C310" alt="code" class="aligncenter size-full wp-image-11262" /></a></p>
<p>The package is made up of a mix of Vagrant, Puppet, Bash scripts, and some PHP code to create the WordPress.com development environment, plus it also includes all the extra tools recommended for developers:</p>
<ul>
<li>Ubuntu 12.04</li>
<li>WordPress trunk</li>
<li>WordPress.com VIP Shared Plugins repository</li>
<li>WordPress multisite</li>
<li>WordPress Developer Plugin and all VIP recommended plugins</li>
<li>Custom WordPress.com modifications</li>
<li>WP-CLI</li>
<li>MySQL</li>
<li>PHP</li>
<li>Nginx</li>
</ul>
<p>This package creates a WordPress multisite installation from the latest trunk build. VIP Quickstart will be maintained on github but you can always get the latest by running the VIP init script included in the package. Developers familiar with <a href="http://docs.vagrantup.com/v2/cli/index.html" target="_blank">Vagrant</a> can use those commands as well.</p>
<p>New WordPress development tools will be added, along with more VIP specific tools. Recently, the team added a Windows installer and support for PHPMyAdmin, which you can find if you navigate to: <a href="http://vip.dev/phpmyadmin" target="_blank">http://vip.dev/phpmyadmin</a>. </p>
<p>If you want to quickly create an enterprise class development environment or simply check out the technology that powers WordPress.com, have a look at <a href="https://github.com/Automattic/vip-quickstart" target="_blank">VIP Quickstart</a>. If you need help setting up your development environment, please refer to the <a href="http://vip.wordpress.com/documentation/development-environment/" target="_blank">documentation</a> on the VIP website.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 19:06:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Matt: The Way We Age Now";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43166";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://ma.tt/2013/11/the-way-we-age-now/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:963:"<blockquote><p>As engineers have long recognized, many simple devices do not age. They function reliably until a critical component fails, and the whole thing dies instantly. A windup toy works smoothly until a gear rusts or a spring breaks, and then it doesn’t work at all. But complex systems—power plants, say—have to survive and function despite having thousands of critical components. Engineers therefore design these machines with multiple layers of redundancy: with backup systems, and backup systems for the backup systems. The backups may not be as efficient as the first-line components, but they allow the machine to keep going even as damage accumulates. Gavrilov argues that, within the parameters established by our genes, that’s exactly how human beings appear to work.</p></blockquote>
<p>An oldie but a goodie from the New Yorker: <a href="http://www.newyorker.com/reporting/2007/04/30/070430fa_fact_gawande">The Way We Age Now</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 15:50:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:114:"WordPress.tv: John James Jacoby: Everything And Anything You’ve Ever Wanted To Know About BuddyPress And bbPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24121";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:128:"http://wordpress.tv/2013/11/08/john-james-jacoby-everything-and-anything-youve-ever-wanted-to-know-about-buddypress-and-bbpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:784:"<div id="v-gkFwlr1T-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24121/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24121/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24121&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/08/john-james-jacoby-everything-and-anything-youve-ever-wanted-to-know-about-buddypress-and-bbpress/"><img alt="John James Jacoby: Everything And Anything You&#8217;ve Ever Wanted To Know About BuddyPress And bbPress" src="http://videos.videopress.com/gkFwlr1T/video-328f955c02_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 14:07:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"WPTavern: How WordPress 3.7 Affects the Hotfix Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11227";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://www.wptavern.com/how-wordpress-3-7-affects-the-hotfix-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2518:"<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/hotfix.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/hotfix.jpg?resize=560%2C181" alt="hotfix" class="aligncenter size-full wp-image-11235" /></a></p>
<p>For the past two years or so, <a href="http://wordpress.org/plugins/hotfix/" target="_blank">Hotfix</a> has been one of those essential WordPress plugins that many users have added immediately upon installation. This plugin was <a href="http://make.wordpress.org/core/2011/02/08/hotfix/" target="_blank"> created by Mark Jaquith in early 2011</a> to provide early, automatic fixes for WordPress based on the version you’re using. He created it during a time when WordPress was cranking out a bunch of point-point releases in a short period of time. Update fatigue was becoming a problem.<span id="more-11227"></span></p>
<p>The Hotfix plugin was meant to address bugs not severe enough or common enough to warrant a separate release. At that time, performing WordPress updates on a large number of sites was very time-consuming and annoying. The Hotfix plugin provided a convenient solution that was far superior to packing hot fixes into an Akismet <a href="http://make.wordpress.org/core/2011/02/08/via-the-akismet-blog-akismet-2-5-3-has/" target="_blank">update</a>.</p>
<h3>Is the Hotfix Plugin Unnecessary With WordPress 3.7?</h3>
<p>Now that WordPress 3.7 has arrived with automatic background capabilities, where does Hotfix fit in? It seems to be much less useful for sites with automatic updates enabled. I checked with Andrew Nacin, who is one of the contributors to Hotfix, to see if this plugin would be fading away. He said that only time will tell. &#8220;But it&#8217;s less useful, not due to background updates directly, but because they eliminated update fatigue, making us inclined to quickly release.&#8221;</p>
<p>I asked him if they will continue to selectively push hot fixes through the plugin. He confirmed that they might if they need to. While it appears that it hasn&#8217;t been updated in nearly a year, Nacin says that &#8220;there wasn&#8217;t anything in 3.6 or 3.7 that A) could have been fixed using it and B) only affected a small number of people.&#8221; So if any of you have the Hotfix plugin in place, don&#8217;t rule this one out just yet. There&#8217;s no reason to go out of your way to deactivate it, as it may be used again in the future to push out hot fixes for installations that need them.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 14:01:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WordPress.tv: Shane Pearlman: Managing Distributed Code Teams";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24117";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://wordpress.tv/2013/11/07/shane-pearlman-managing-distributed-code-teams/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:677:"<div id="v-yXhk7xBN-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24117/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24117/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24117&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/07/shane-pearlman-managing-distributed-code-teams/"><img alt="Shane Pearlman: Managing Distributed Code Teams" src="http://videos.videopress.com/yXhk7xBN/video-12047b0c38_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 02:51:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WPTavern: WP Sessions Offers Free Video Series on Building WordPress Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11190";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://www.wptavern.com/wp-sessions-offers-free-video-series-on-building-wordpress-plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2838:"<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/wpsessions1.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/wpsessions1.jpg?resize=300%2C375" alt="wpsessions" class="alignright size-full wp-image-11210" /></a>Want to learn the basics of creating a WordPress plugin? If you&#8217;re a visual/audio learner, check out the free <a href="http://wpsessions.com/sessions/building-wordpress-plugins/" target="_blank">Building WordPress Plugins</a> video series from <a href="http://wpsessions.com/" target="_blank">WP Sessions</a>. </p>
<p>Inspired by the WordCamp style presentations of the <a href="http://www.wptavern.com/wordsesh-2013-live-streaming-24-hours-of-free-wordpress-education" target="_blank">24hr WordSesh event</a>, Brian Richards wanted to create a site to bring WordPress educational resources to people at home. The format of WP Sessions encourages users to watch live and ask questions. WP Sessions has several <a href="http://wpsessions.com/sessions/" target="_blank">video series</a> available with high quality speakers, but the plugin building series is the first that&#8217;s being offered for free.  <span id="more-11190"></span></p>
<p>The Building WordPress Plugins series features Pippin Williamson, Daniel Espinoza and Topher DeRosia, all of whom are highly experienced plugin developers. The series starts with beginner/introductory topics and ranges all the way to more advanced topics, such as data validation and sanitization.</p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/these-guys-build-plugins.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/these-guys-build-plugins.jpg?resize=466%2C152" alt="these-guys-build-plugins" class="aligncenter size-full wp-image-11202" /></a></p>
<p>These three professional developers will help you to understand basic plugin architecture. You&#8217;ll also learn about using hooks and filters, registering admin menu items, releasing your plugin on WordPress.org and much more. If you&#8217;re planning on adding plugin development to your list of WordPress skills, make sure to bookmark this free video series to get you started.</p>
<p>Next up on the WP Sessions schedule is a series on <a href="http://wpsessions.com/sessions/wordpress-unit-testing/" target="_blank">WordPress Unit Testing</a>, offered November 30, 2013, featuring Alison Barrett, John P. Bloch and K. Adam White. This might be a great followup session after you learn how to build plugins. The cost is $20 for early registration. Session prices offset the costs of running the site and compensating instructors for the first few months they are offered. As more sessions are added, all previous sessions will be made available for free on a rolling basis. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 23:19:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WPTavern: GravityForms 1.8 Beta Released, Introduces API";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11173";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://www.wptavern.com/gravityforms-1-8-beta-released-introduces-api";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6698:"<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2009/08/gravitylogo.png" rel="thumbnail"><img class="alignright size-full wp-image-2322" alt="gravityforms logo" src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2009/08/gravitylogo.png?resize=108%2C109" /></a>Rocketgenius, the team behind GravityForms <a title="http://www.gravityhelp.com/gravity-forms-v1-8-beta-1-released/" href="http://www.gravityhelp.com/gravity-forms-v1-8-beta-1-released/">has announced</a> the release of GravitfyForms 1.8 Beta 1. This is a big release as 1.8 contains a number of features such as:</p>
<ul>
<li>Support for the Heartbeat API</li>
<li>Integration with the Trash component of WordPress</li>
<li>Multi-file uploading</li>
<li>Form scheduling</li>
<li>Form Sorting</li>
<li>WordPress Multisite (Gravity Forms now supports being installed within the MU-PLUGINS folder on WordPress Multisite installations.)</li>
</ul>
<p>Developers are going to love this release since it contains a <a title="http://www.gravityhelp.com/documentation/page/Gravity_Forms_API" href="http://www.gravityhelp.com/documentation/page/Gravity_Forms_API">complete API</a> that allows developers to interact with a specific Gravity Forms install to add, update, delete and return Gravity Forms data. This new version also contains user interface refinements such as standardizing on the use of web fonts. <span id="more-11173"></span></p>
<p>One of the things I like most about GravityForms is that they&#8217;ve stayed true to the look and feel of WordPress. Even with their UI refinements, it still looks and functions as if it were part of WordPress all along. I got in touch with Carl Hancock, one of the lead developers of GravityForms and asked him two questions.</p>
<p><strong>How important has it been to develop GravityForms so it looks and functions as if it were part of WordPress all along?</strong></p>
<div id="attachment_11200" class="wp-caption aligncenter"><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/gravity-forms-18-ui-enhancements.png" rel="thumbnail"><img class="size-large wp-image-11200" alt="GravityForms UI Refinements In 1.8" src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/gravity-forms-18-ui-enhancements-500x311.png?resize=500%2C311" /></a><p class="wp-caption-text">GravityForms UI Refinements In 1.8</p></div>
<p><em>Very important. But not at the expense of what we are trying to accomplish. We try to use WordPress UI styling where we can. Where we can’t, we try to make it look like it was. There’s some interfaces we need that WordPress simply doesn’t have an example to utilize. Then there are other UI’s that we could use, but frankly they aren’t ideal.</p>
<p>A good example of a WordPress UI that we don’t use is the horizontal tabs. They simply don’t scale. Not scale as in responsive, but scale as in number of tabs. For the sub-navigation we use in various areas that require it we re purposed the look and feel of the WordPress Help that appears when you click on the “Help” link in the top right of various WordPress pages that have help. You’ll see that it has vertical sub-navigation. That scales. So we went with it.</p>
<p>I’m sure we’ll encounter more situations where there simply isn’t a WordPress UI convention that we can leverage. But we’ll tackle them as we encounter them to make sure that what we do, still looks good within the WordPress admin. We don’t want to create a product that looks completely out of place within the WordPress admin. We prefer consistency.<br />
</em><br />
<strong>Everyone is excited about the API introduced with GravityForms 1.8 Beta 1. What types of opportunities open up thanks to this API?</strong></p>
<p><em>Endless opportunities. That really is the truth.</p>
<p>The API within Gravity Forms v1.8 has two parts which can be used by developers depending on what they are trying to accomplish. One piece is a set of API Functions within a Gravity Forms class that can be used to interact with Gravity Forms from within the same WordPress install. So they can be used within a theme, plugin or custom code to interact with Gravity Forms data.</p>
<p>The second piece is the traditional Web API which is designed for interaction between your WordPress install and a 3rd party server. Although it could still also be accessed via code that resides on the same WordPress install if the site developer wanted to do so.</p>
<p>Prior to the API there was no standard way to easily add, update, get or delete Gravity Forms related data such as Forms and Entries outside of the Gravity Forms interface itself. It could be done. But it wasn’t simple. You could certainly query the data directly, but you’d need to know the data structure and how everything works to do it properly.</p>
<p>One example of how the Web API will be used is the Zapier Add-On. Zapier is a web service that allows you to integrate with almost 250 different other web services (<a title="https://zapier.com/zapbook/" href="https://zapier.com/zapbook/">https://zapier.com/zapbook/</a>). This allows you to integrate Gravity Forms with almost 250 different web services, which means a lot of services we don’t currently have native Add-Ons for. Currently the Zapier Add-On process isn’t very user friendly due to the way Zapier works. With the new Web API, it’s going to be extremely simple and most of the work will occur via Zapier’s admin instead of within Gravity Forms once your form exists. Within Zapier you’ll enter the URL of your site and your API keys and Zapier will then be able to get a list of all your forms via the Web API and from there you can setup your “Zaps” to integrate with any of the almost 250 web services they allow you to integrate with.</p>
<p>One example of opportunities that the new API functions open up is more power for 3rd party developers. Combined with the <a title="http://www.gravityhelp.com/documentation/page/Add-On_Framework" href="http://www.gravityhelp.com/documentation/page/Add-On_Framework">Add-On Framework</a> developers will be able to create Add-Ons and integration with Gravity Forms much easier than they could previously. There are already a LOT of 3rd party Add-Ons in the wild for Gravity Forms and these new developer features are going to be huge for their future growth.</p>
<p>They will also be huge for our future growth. For example our Web API could be used to allow something like say… a mobile app… to access and manage your Gravity Forms data.</p>
<p>We’re very excited about what both the Add-On Framework and the API means for the future of Gravity Forms. We’ve only just begun.</em></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 22:45:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WordPress.tv: Aaron Holbrook: WordPress Is A CMS Dammit!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24119";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wordpress.tv/2013/11/07/aaron-holbrook-wordpress-is-a-cms-dammit/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:666:"<div id="v-8LI2gxhr-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24119/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24119/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24119&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/07/aaron-holbrook-wordpress-is-a-cms-dammit/"><img alt="Aaron Holbrook: WordPress Is A CMS Dammit!" src="http://videos.videopress.com/8LI2gxhr/video-22c506f23a_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 20:12:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:93:"WPTavern: Behind The Scenes With Dogshaming.com: Helping People Humiliate Pets With WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11164";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:106:"http://www.wptavern.com/behind-the-scenes-with-dogshaming-com-helping-people-humiliate-pets-with-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6577:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/dogshaming.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/dogshaming.jpg?resize=360%2C365" alt="dogshaming" class="alignright size-full wp-image-11166" /></a>Some dogs are just plain naughty. Mine is 100% mischief so naturally I&#8217;m a pretty big fan of <a href="http://www.dogshaming.com/" target="_blank">Dogshaming.com</a>. I was thrilled to find out that this popular site is running on WordPress. </p>
<p>Inspired by her own naughty pup who chews holes in underwear for kicks, Pascale Lemire originated the online trend of &#8220;dog shaming.&#8221; The idea went viral and soon dog owners around the world were posting pictures of their wicked canines with homemade signs to illustrate their crimes. </p>
<p>Lemire now had a unique idea for a website. She got in touch with her husband&#8217;s friend, <a href="http://townhall.ca/" target="_blank">Jairus Pryor</a>, who happens to be a WordPress developer. Together they built Dogshaming.com to offer dog owners a place to publicly shame their dogs.<span id="more-11164"></span></p>
<h3>WordPress + DogShaming: Optimizing for Performance</h3>
<p>I asked Pryor if he builds with other platforms and why he selected WordPress for Dogshaming.com. He answered that for him it comes down to the community surrounding the project. <strong>&#8220;I work mostly with WordPress. I find the developer community to be second-to-none.&#8221;</strong>  </p>
<p>While building the site, he had no idea that it would become so popular. &#8220;I don&#8217;t think anyone could have anticipated just how much the site has resonated with people! Just the other week I saw Annie Lennox post a photo of the Dogshaming book to her Facebook page. It&#8217;s completely amazing.&#8221; Due to the heavy traffic the site receives, Pryor needed to have a performance plan in place to support the site&#8217;s heavy traffic load. Dogshaming.com regularly posts images that can easily go viral and take the server down if not properly optimized. After some experimentation, he settled on <a href="http://wordpress.org/plugins/wp-super-cache/" target="_blank">WP Super Cache</a> and <a href="http://jetpack.me/support/photon/" target="_blank">Jetpack&#8217;s Photon CDN</a>:</p>
<blockquote><p>We&#8217;re using WP Super Cache along with XCache on the server end and Jetpack&#8217;s Photon CDN on the front end. We tried a number of different solutions (including W3TC and Cloudflare), but this combination ended up being the most stable.</p></blockquote>
<p>In addition to keeping up with traffic, Pryor also keeps track of the site&#8217;s maintenance requirements.  &#8220;There&#8217;s a fair amount of maintenance involved. With high-profile sites you&#8217;re always discovering a new bug or trying to roll out a new feature, so there&#8217;s usually something you want to keep an eye on.&#8221; </p>
<h3>The Dogshaming Custom WordPress Theme</h3>
<p>I did a little snooping into the theme and found that Dogshaming.com makes use of the increasingly popular <a href="http://www.wptavern.com/10-free-wordpress-themes-based-on-the-foundation-framework" target="_blank">Foundation framework</a>. Pryor explained why he selected Foundation as the backbone of his custom theme:</p>
<blockquote><p>The Dogshaming site is built on a custom theme, using the Foundation framework as a basis for the presentation layer, and the Bones Theme as a basis for the theme itself. I generally use either <a href="http://underscores.me/" target="_blank">Underscores</a> or <a href="http://themble.com/bones/" target="_blank">Bones</a>, depending on the project. I love how easy <a href="http://foundation.zurb.com/" target="_blank">Foundation</a> is to work with if you&#8217;re into SASS, and Bones comes with SASS out of the box, which is really what sets it apart from Underscores.</p></blockquote>
<p>If you view Dogshaming.com on a mobile device, you&#8217;ll see that it responds nicely due to the combination of Foundation and Bones. The theme&#8217;s framework was a crucial part of helping the site gain more mobile traffic. </p>
<h3>Plugins Behind Dogshaming.com</h3>
<p>Dogshaming.com makes use of a small collection of plugins to power the site. Content is generated by regular submissions to the site. Pryor opted for a simple implementation of <a href="http://www.gravityforms.com/" target="_blank">Gravity Forms</a>. &#8220;We use Gravity Forms for the &#8216;<a href="http://www.dogshaming.com/submit-dog/" target="_blank">Submit a Dog</a>&#8216; section, pretty much out of the box,&#8221; he said. &#8220;Each submission is a new post, which makes the workflow to publish approved submissions simple.&#8221; The Dog Shaming Generator is actually a standalone app, created as part of the book launch and isn&#8217;t actually run by WordPress.</p>
<p>I asked Pryor to highlight some of the plugins that are necessary for running the site. They&#8217;re keeping it fairly lean: </p>
<blockquote><p>Akismet, Gravity Forms, Jetpack and Super Cache. The site lives and breathes by those four plugins. Nothing beyond that, we wanted to keep it as light as possible.</p></blockquote>
<p>I&#8217;m always amazed to see how quickly someone can build a kickass, performance-optimized website using plugins that are already available. No custom plugin development was required for this project. </p>
<p>If you visited the site on April Fool&#8217;s Day, you may have gotten to see Pryor&#8217;s sneaky dev prank:</p>
<blockquote><p> The owners of the site are obviously big on dogs, but I&#8217;m actually a cat person. On April Fools Day I dropped in a piece of Javascript that changed all of the dogs on the site to images of kittens from <a href="http://placekitten.com/" target="_blank">placekitten.com</a>, which I thought was hilarious. Turns out that some people who come looking for dogs get very upset when they see kittens instead! How can you be upset with so many kittens looking at you? It doesn&#8217;t even make sense.</p></blockquote>
<p>Pryor said that the Dogshaming site has been a great addition to his portfolio. These days he&#8217;s working with his partner through their company <a href="http://townhall.ca/" target="_blank">Townhall Communications</a>. While in discussions with a potential client who asked for portfolio examples, Pryor sent over a list of high-profile projects. The client sent back a one-line reply: &#8220;I&#8217;m sorry: I didn&#8217;t read anything after Dogshaming. BIG FAN!&#8221;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 20:11:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"BuddyPress: BuddyPress Theme Development by Tammie Lister";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://buddypress.org/?p=173605";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://buddypress.org/2013/11/buddypress-theme-development-by-tammie-lister/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2105:"<p>I&#8217;m pleased to announce the release of my book &#8216;<a href="http://www.packtpub.com/buddypress-theme-development/book">BuddyPress Theme Development</a>&#8216; published by Packt. This book serves as a guide (with practical tutorials) on how to make the most out of BuddyPress with custom templates and styles. It gives insight into the current state of BuddyPress theme creation and gently leads readers through creating one of their own.</p>
<p><img class="aligncenter size-full wp-image-173611" alt="webimage" src="http://buddypress.org/wp-content/uploads/1/2013/10/webimage.png" width="600" height="430" /></p>
<p>This book has a very BuddyPress origin story, with it&#8217;s beginning coming during BuddyCamp Miami in March of 2013 (the chapters and structure were worked out while I was there) and it was a pleasure to have the one and only <a href="http://profiles.wordpress.org/DJPaul">Paul Gibbs</a> perform the technical review.</p>
<p>My publisher allowed me to include the entire theme process from sketch and wireframe through to code, and I included coverage of some general theme topics like responsive design, theme checks, and testing. Far too often, we forget how important the planning and feature-complete stages of a theme are, and this book tries to address both. All this content, crammed into 130 pages &#8211; a feat of editing.</p>
<p>When I started writing BuddyPress Theme Development, I had 4 goals (along with providing a good resource for creating themes):</p>
<ol>
<li>Blow away the myth that creating BuddyPress themes is hard.</li>
<li>Encourage readers to tailor their experience, choosing which components are critical to their success.</li>
<li>Raise the quality of BuddyPress themes and highlight good theme practices.</li>
<li>Encourage people to get involved with the BuddyPress project.</li>
</ol>
<p>You can get the book <a href="http://www.packtpub.com/buddypress-theme-development/book">through Packt Publishing</a>, or through Amazon. It&#8217;s available in soft-cover and eBook, and comes with code samples to follow along with the tutorials.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 17:03:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"karmatosed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:88:"WordPress.tv: Austin Gunter: The Essential Strategy To Build An Online Community In 2013";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24091";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:105:"http://wordpress.tv/2013/11/06/austin-gunter-the-essential-strategy-to-build-an-online-community-in-2013/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:731:"<div id="v-3cCZtKxK-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24091/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24091/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24091&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/06/austin-gunter-the-essential-strategy-to-build-an-online-community-in-2013/"><img alt="Austin Gunter: The Essential Strategy To Build An Online Community In 2013" src="http://videos.videopress.com/3cCZtKxK/video-b2a48d1ab8_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 01:25:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"WPTavern: WordPress Iteration, Not Renovation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11135";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://www.wptavern.com/wordpress-iteration-not-renovation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3918:"<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/05/mp6logo.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/05/mp6logo.jpg?resize=206%2C197" alt="mp6 plugin header logo" class="alignright size-full wp-image-6888" /></a>Earlier today, I <a href="http://wpmu.org/boring-boring-wordpress/">read an article</a> that took all of the hard work volunteers completed for <a href="http://www.wptavern.com/breaking-new-features-selected-to-merge-into-wordpress-3-8-core" title="http://www.wptavern.com/breaking-new-features-selected-to-merge-into-wordpress-3-8-core">inclusion into WordPress 3.8</a> and flushed it down the toilet. The main reason for their criticism is that WordPress is boring. The software is not changing enough to keep pace with competitors such as SquareSpace, Ghost, or Medium. The premise of the article is that WordPress will not be the future of web publishing within the next 10 years. However, nowhere in the article did the author explain which platform that would be and why.</p>
<p><span id="more-11135"></span></p>
<h3>Experimental Plugins Are Good!</h3>
<p>WordPress has gone through at least 3 major redesigns of the administration interface. Those were radical changes involving colors, layouts, and moving links around. Each change brought a new round of anger from those that had just gotten used to the previous design. I&#8217;ve used software that renovated the user interface and it&#8217;s not easy adjusting to change, especially when a user considers it a change for the worse. The back-end of WordPress hasn&#8217;t seen a major redesign for a while and that is one of the reasons why the MP6 experiment took place. </p>
<p>Instead of the typical development process of changing everything in core, MP6 was developed as a plugin alongside core so that experiments could be conducted with colors, fonts, and various other changes. I love this development process for two reasons. First, it makes it easy to help out during the development phase by using the plugin. Second, using the plugin before it gets merged into core gives me an opportunity to become familiar with the user interface changes. Despite all of the changes within MP6, the final design is really just an improvement of what we already have in WordPress 3.7.</p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WordPressPowering20Percent.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WordPressPowering20Percent.jpg?resize=513%2C167" alt="WordPress Powering 20% Of The Web" class="aligncenter size-full wp-image-11154" /></a></p>
<h3>WordPress Can&#8217;t Afford To Renovate</h3>
<p>It&#8217;s experiments like MP6 that have me embracing <strong>iteration</strong> versus <strong>renovation</strong>. Why completely change things around if it&#8217;s not broken? In my opinion, that&#8217;s what change for the sake of change is. Sure, renovating an old kitchen into something sleek and modern is wonderful. But with WordPress being used on <a href="http://w3techs.com/" title="http://w3techs.com/">20% of the web</a>, it doesn&#8217;t make sense to push out major changes that could stop the growth of WordPress or worse, decrease market share due to so many disgruntled users. As features that would have been developed in core are starting off as plugins first, we should see changes merged into WordPress at an accelerated rate. Therefore, it&#8217;s only a matter of time before WordPress &#8220;<em>catches up</em>&#8220;. </p>
<p>I don&#8217;t have any doubt that WordPress will be celebrating its second decade of existence powering 30% of the web or more. Since iterations are small changes over time, it&#8217;s interesting to think about what WordPress may look like 10 years from now. I&#8217;d rather be part of the journey instead of getting everything all at once.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 06 Nov 2013 23:52:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Matt: No Email, No Office Workers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43163";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://ma.tt/2013/11/no-email-no-office-workers/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:271:"<p>Julie Bort at Business Insider writes <a href="http://www.businessinsider.com/automattic-no-email-no-office-workers-2013-11">How Automattic Grew Into A Startup Worth $1 Billion With No Email And No Office Workers</a>. Includes a short interview with me at the end.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 06 Nov 2013 22:43:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WPTavern: BuddyPress 1.9 To Retire Default Theme and Add New Notifications Component";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11130";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://www.wptavern.com/buddypress-1-9-to-retire-default-theme-and-add-new-notifications-component";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4819:"<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/bp-logo.png" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/bp-logo.png?resize=150%2C150" alt="bp-logo" class="alignright size-thumbnail wp-image-11139" /></a>BuddyPress 1.9 beta has been slightly delayed, but lead developer John James Jacoby says that it&#8217;s not too far off course. There are <a href="http://buddypress.trac.wordpress.org/query?status=assigned&status=new&status=accepted&status=reopened&group=status&milestone=1.9" target="_blank">43 tickets left</a> in 1.9. During the BuddyPress development meeting today, BP core contributors addressed tickets that need more attention and caught everyone up for where 1.9 is headed.</p>
<h3>BuddyPress 1.9 Will Introduce a New Notifications Component</h3>
<p>One of the exciting new features coming in the next release is a <a href="http://buddypress.trac.wordpress.org/ticket/5148" target="_blank">separate notifications component</a>. &#8220;I&#8217;ve wanted it to be it&#8217;s own component for some time, and we&#8217;re doing that in 1.9,&#8221; Jacoby said. &#8220;We&#8217;re adding a UI for it now, and allowing for read/unread marking. There are some improvements to the underlying code, but no breaking changes, schema changes, etc.&#8221;<span id="more-11130"></span></p>
<p>According to BP core developer <a href="http://boone.gorg.es/" target="_blank">Boone Gorges</a>, the new notifications component is largely adapted from BP_Core_Notification. He clarified: &#8220;The underlying code is actually brand new, in a new component directory, bp-notifications, with new function/class names.&#8221;</p>
<p>The good news is that third party plugins will not be affected by changes made to add the new notifications component to the core. Jacoby assured developers that this is not going to break everything. &#8220;Existing plugins/third party plugins will continue to work as they do.&#8221; </p>
<p>For 1.9 they are shooting for the following features to be included with the component:</p>
<ul>
<li>Ability to enable/disable at the component level.</li>
<li>Add a UI for read/unread notifications.</li>
<li>A control panel for moderators to see all notifications, to clear them, delete them, etc&#8230;</li>
<li>Allow users to toggle notifications back to unread.</li>
<li>Improve the BP_Core_Notification class methods so they are more flexible like the activity and group components.</li>
</ul>
<p>A dedicated notifications screen will be introduced to provide a log of notices for each member and is likely to be located at: <strong>members/username/notifications</strong>. The new component will allow for a lot more interesting interactions with BuddyPress notifications. </p>
<h3>Goodbye BP Default Theme</h3>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/bp-default.png" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/bp-default.png?resize=300%2C225" alt="bp-default" class="alignleft size-full wp-image-11138" /></a>The last part of the BuddyPress development meeting was dedicated to discussing the inevitable retirement of the BP Default theme. <a href="http://codex.buddypress.org/developer/releases/version-1-7/" target="_blank">BuddyPress 1.7</a>, released earlier this year in April, introduced theme compatibility. This made it possible for BuddyPress to be dropped into any WordPress theme. Boone created a <a href="http://buddypress.trac.wordpress.org/ticket/5223" target="_blank">ticket</a> that proposes a solution to stop offering bp-default on new installations.</p>
<blockquote><p>As of 1.9, we should no longer offer bp-default as an installable theme for new installations. This will be the first step in the longer-term task of removing bp-default from the BP codebase, and spinning it out into its own theme.</p></blockquote>
<p>The patch Boone submitted stops BuddyPress from registering the bp-themes theme directory unless it finds one of the following cases to be true:</p>
<ul>
<li>The current theme is bp-default (get_stylesheet())</li>
<li>The current theme is a child of bp-default (get_template())</li>
</ul>
<p>That means that there is nothing to worry about if you are running the default theme or a child theme derived from it. You will still be able to update your community to BuddyPress 1.9 when the time comes.</p>
<p>There is some work to be done here, as the team will need to provide an upgrade route for bp-default for future BuddyPress releases, but everything is moving in the right direction. As of 1.9, the BP core team will stop active development on the default theme. With that, BuddyPress will bid a fond farewell to BP Default and will focus on making its components more awesome for all WordPress themes.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 06 Nov 2013 22:32:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WPTavern: Should WordPress Include a Password Generator?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=10836";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://www.wptavern.com/should-wordpress-include-a-password-generator";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3790:"<p>WordPress 3.7 made big strides towards helping users create stronger passwords with the <a href="http://www.wptavern.com/ridiculously-smart-password-meter-coming-to-wordpress-3-7" target="_blank">new password strength meter</a>, powered by the <a href="https://tech.dropbox.com/2012/04/zxcvbn-realistic-password-strength-estimation/" target="_blank">zxcvbn</a> library. Despite having this excellent tool available, many users have admitted that they are in fact too lazy to come up with a strong password and would prefer to have a password generator available within the WordPress admin.<span id="more-10836"></span></p>
<p><a href="http://profiles.wordpress.org/aaroncampbell" title="Aaron Campbell" target="_blank">Aaron Campbell</a> opened a trac <a href="http://core.trac.wordpress.org/ticket/8296" target="_blank">ticket</a> on a related topic five years ago, requesting a button that generates a random password to use when creating a new user account in the admin section. Brad Williams chimed in on the original ticket to suggest the <a href="http://docs.cpanel.net/twiki/bin/view/11_30/CpanelDocs/PasswordGenerator" target="_blank">cPanel password generator</a> as a good UI example of how WordPress might include this feature. The same idea was also presented by Ryan Duff two years ago in a <a href="http://wordpress.org/ideas/topic/random-password-for-new-users#post-20725" target="_blank">post</a> on the <a href="http://wordpress.org/ideas/" target="_blank">WordPress Ideas</a> page. While the password strength meter is now active on this screen, you still need to create the password yourself. </p>
<h3>Proposal to Add Simple User Password Generator to Core</h3>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/password-generator.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/password-generator.jpg?resize=560%2C181" alt="password-generator" class="aligncenter size-full wp-image-11116" /></a>Several months ago, <a href="http://profiles.wordpress.org/mordauk/" target="_blank">Pippin Williamson</a> created a new <a href="http://core.trac.wordpress.org/ticket/24633" target="_blank">ticket</a>, proposing the inclusion of the <a href="http://wordpress.org/plugins/simple-user-password-generator/" target="_blank">Simple User Password Generator</a> plugin, created  by the folks at 10up, to accomplish this. This plugin also adds an option to encourage the user to change his password when logged in to the admin. It also has an option to send existing users the new, auto-generated password. It looks like this enhancement is on track to be included in WordPress 3.8.</p>
<h3>More Password Wishlist Items</h3>
<p>The <a href="http://wordpress.org/plugins/simple-user-password-generator/" target="_blank">Simple User Password Generator</a> plugin is excellent but it doesn&#8217;t take into account editing your own password at <em>profile.php</em>, which is just as important as setting up new user passwords. It would be helpful to include its capabilities on this screen for changing passwords.</p>
<p>Hopefully the new addition will be extensible so that other plugins can make use of it. It would be nice to be able to easily add this to BuddyPress front-end password management in the settings screen via a plugin.</p>
<p>Ultimately, maintaining a strong password is the responsibility of the user. Do you think that WordPress users would, on the whole, be better served with a built-in password generator? Given that there are already many third party services such as <a href="https://lastpass.com/" target="_blank">LastPass</a>, <a href="https://agilebits.com/onepassword" target="_blank">1password</a> and others that can do this in the browser, should we be adding this to the core? </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 06 Nov 2013 20:30:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"WPTavern: My Approachable WordPress Story";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11096";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://www.wptavern.com/my-approachable-wordpress-story";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3538:"<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/ChrisLemaLogo.jpg" rel="thumbnail"><img class="alignright size-medium wp-image-9575" alt="Chris Lema Blog Logo" src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/ChrisLemaLogo.jpg?resize=300%2C69" /></a>Chris Lema recently <a title="http://chrislema.com/approachable-wordpress/" href="http://chrislema.com/approachable-wordpress/">published a great article</a> that in my opinion, really shines a light on the positive aspects of the WordPress community as a whole. Chris calls it &#8220;Approachable WordPress&#8221;. In his story he describes how easy it is to approach anyone in the WordPress community, regardless of their popularity. <span id="more-11096"></span></p>
<h3>WordPress Celebrities</h3>
<p>Chris&#8217; story reminds me of my <a title="http://weblogtoolscollection.com/archives/2008/01/22/wordcamp-dallas/" href="http://weblogtoolscollection.com/archives/2008/01/22/wordcamp-dallas/">trip to Dallas in 2008</a> where I attended my first WordCamp. This event was a huge milestone. It&#8217;s where I met Mark Ghosh of <a href="http://weblogtoolscollection.com/" title="http://weblogtoolscollection.com/">Weblogtoolscollection.com</a>, which at the time, was the most popular website dedicated to WordPress. It&#8217;s also the first opportunity I had to meet other people within the WordPress community face to face. Attending WordCamp Dallas was like going to a family reunion. All of the attendees were friendly and enjoyed being in each others company.</p>
<p>The highlight of that event was that it was the first time I had the chance to meet Matt Mullenweg, the co-creator of WordPress. It was such a surreal experience as I had placed Matt up on the pedestal of Hollywood celebrity. I didn&#8217;t think I&#8217;d be able to get anywhere close to the guy. After all, he helped create the software that was taking over the web. I remember when he showed up on Saturday afternoon as his family drove him to the event from Houston, TX. If I remember correctly, he had his wisdom teeth pulled and that&#8217;s why he wasn&#8217;t feeling well. After arriving, I introduced myself to him. Turns out, he knew exactly who I was because of my writing on Weblogtoolscollection.com. During the event, I conducted a one on one interview with him, dined with him, conversed with him as much as I could, without having to go through any bodyguards.</p>
<p>It&#8217;s this experience with Matt Mullenweg at WordCamp Dallas that really opened my eyes. Since then, I&#8217;ve attended a number of WordCamp events and have been able to recreate that experience with multiple people within the WordPress community. I wanted to share that story as well as Chris Lema&#8217;s because the message behind both is true. In fact, Chris says it better than I could.</p>
<blockquote><p>Want to talk to the guy behind <a href="http://WP101.com" target="_blank">WordPress 101</a> – hit me up, I’ll introduce you.</p>
<p>Want to talk to the guy behind the <a href="http://mattreport.com" target="_blank">Matt Report</a> – hit me up, I’ll introduce you.</p>
<p>Want to talk to the dudes that are the <a href="http://dradcast.com" target="_blank">baddest podcasters</a> in town – hit me up, I’ll introduce you.</p>
<p>Who do you want to meet?</p>
<p>Here’s the amazing thing – you don’t even need my intro. Ping them directly on Twitter and watch – they’ll reply.</p>
<p>That’s <strong>Approachable WordPress</strong></p></blockquote>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 06 Nov 2013 17:30:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WPTavern: Cart66 Launches WordPress Managed Hosting for E-Commerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11074";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://www.wptavern.com/cart66-launches-wordpress-managed-hosting-for-e-commerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3112:"<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/cart66.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/cart66.jpg?resize=300%2C191" alt="cart66" class="alignright size-medium wp-image-11080" /></a><a href="http://cart66.com/" target="_blank">Cart66</a>, previously known as PHPurchase, was one of the very first WordPress e-commerce plugins on the scene. Over the years the company has experimented with different WordPress e-commerce products but this week marks a major milestone. Cart66 Hosted has launched the first fully managed WordPress e-commerce platform.</p>
<p>In partnership with the folks at <a href="https://pagely.com/" target="_blank">Pagely</a>, the <a href="http://cart66.com/hosted/" target="_blank">Cart66 Hosted</a> platform provides fully managed WordPress hosting plus its flagship e-commerce product, Cart66 Cloud. This hosted solution was created to make security and PCI compliance something that customers don&#8217;t have to think about. Store owners can concentrate on selling, instead of trying to wading through all the technical aspects of managing an online store. <span id="more-11074"></span></p>
<p>The Cart66 Cloud handles everything related to the secure storage and delivery of digital products, customer order history, storage of customer credit cards, payment gateways and all the e-commerce features you would normally get by installing a dozen different plugins and add-ons.</p>
<h3>The Rising Cost of WordPress E-Commerce</h3>
<p>Cart66 is delving into an area of e-commerce products and services that hasn&#8217;t yet been fully explored by other companies. The all-in-one approach is unique, given that most of the leading WordPress e-commerce solutions have business models centered around creating dozens of commercial add-ons or high cost bundles. Each piece of that puzzle adds up, especially when you include the costs of hosting, PCI compliance, backups and anything else server-related. Even with conservative estimates on all of these requirements, the price tag and responsibility of hosting and securing an online store will be fairly considerable for the average small business.</p>
<p>There&#8217;s also quite a steep learning curve for hosting your own WordPress e-commerce site. It&#8217;s not easy and will require store owners to study up on everything related to site maintenance and security. Many prospective store owners would gladly opt for a WordPress-powered store but have trouble grasping the whole concept of hosting, much less installing SSL certificates or getting a dedicated IP address. No matter how easy a WordPress e-commerce plugin is to use, if the user cannot get WordPress operational in the first place, he&#8217;s out of luck. The only other option for someone in this position is to pay a developer thousands of dollars to set up and build his store for him.</p>
<p>Cart66 has identified a segment of the market that has been overlooked. What do you think about hosted e-commerce? Is this a product that&#8217;s long been needed in the WordPress market?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 06 Nov 2013 16:33:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WordPress.tv: David Lockie: Becoming A Successful WordPress Freelancer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24103";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://wordpress.tv/2013/11/06/david-lockie-becoming-a-successful-wordpress-freelancer/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:689:"<div id="v-CRTGhpCm-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24103/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24103/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24103&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/06/david-lockie-becoming-a-successful-wordpress-freelancer/"><img alt="David Lockie: Becoming A Successful WordPress Freelancer" src="http://videos.videopress.com/CRTGhpCm/video-8576c2523a_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 06 Nov 2013 15:03:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:80:"WordPress.tv: Mario Peshev: WordPress.org Themes Directory – Behind The Scenes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://wordpress.tv/2013/11/05/mario-peshev-wordpress-org-themes-directory-behind-the-scenes/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:709:"<div id="v-x8J18ARP-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24101/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24101/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24101&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/05/mario-peshev-wordpress-org-themes-directory-behind-the-scenes/"><img alt="Mario Peshev: WordPress.org Themes Directory &#8211; Behind The Scenes" src="http://videos.videopress.com/x8J18ARP/video-4dacf801ee_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 06 Nov 2013 01:28:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WPTavern: The Future of WordPress Widgets: A Better UI With Real-Time Previews";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11041";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://www.wptavern.com/the-future-of-wordpress-widgets-a-better-ui-with-real-time-previews";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4602:"<p>Widgets make WordPress stand out as one of the most user-friendly CMS options available. The ability to easily place content blocks and features into a widgetized area has made website customization possible for millions of people who don&#8217;t know how to code. As mobile browsing has increased over the past few years, widget design is now moving to accommodate use on mobile devices. Due to the popularity of widgets in general, new designs must also accommodate users who have dozens of available widgets.<span id="more-11041"></span></p>
<h3>Better Widgets</h3>
<p>Shaun Andrews&#8217; <a href="http://www.wptavern.com/wordpress-widgets-area-chooser-plugin-a-handy-addition-to-mp6" target="_blank">Widgets Area Chooser plugin</a> is on its way into the core for WordPress 3.8, but he&#8217;s not done improving widgets. Andrews is on a quest to make WordPress widgets better. To that end he has a couple of plugins that are currently in development. <a href="http://wordpress.org/plugins/better-widgets/" target="_blank">Better Widgets</a> is one that he created in order to add more incremental updates. </p>
<p>Right now, if you check out the plugin&#8217;s page, all you will see is a vague description: <em><strong> &#8220;This makes widgets better. Trust me. Or don&#8217;t.&#8221;</strong></em> Since this is a plugin for continuing improvements to widgets, you&#8217;ll just have to install it and check it out. </p>
<p>Better Widgets offers a new layout, which briefly made an appearance in MP6 and includes separate scrollable areas for available widgets. It also provides better feedback when saving widgets.</p>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/widget-saved-feedback.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/widget-saved-feedback.jpg?resize=560%2C228" alt="widget-saved-feedback" class="aligncenter size-full wp-image-11058" /></a></p>
<p>Andrews may add a search filter to the plugin somewhere down the road, which would help users to quickly filter when searching a large number of widgets. He is also looking at adding the ability to drag widgets over closed sides, which would then automatically open so you could drop them in, similar to how dragging files around works in OS X. This is one plugin to watch for future updates if you want to be on the cutting edge of WordPress widget development.</p>
<h3>Widgets in the WordPress Customizer</h3>
<p>The widgets team is also working on an experimental plugin that allows users to edit and preview widgets in the <a href="https://codex.wordpress.org/Theme_Customization_API" target="_blank">WordPress Theme Customizer</a>. The <a href="http://wordpress.org/plugins/widget-customizer/" target="_blank">Widget Customizer</a> plugin is being developed as part of the ongoing Widgets UI Refresh effort and the team hopes to have it ready to present for consideration in WordPress 3.9.</p>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/widgets-in-customizer.png" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/widgets-in-customizer.png?resize=560%2C718" alt="widgets-in-customizer" class="aligncenter size-full wp-image-11061" /></a></p>
<p>Widget Customizer gives you real-time previews of the edits you make to a widget before making them live. With this plugin turned on, no changes are live until the Save &#038; Publish button is clicked. All widget-related actions are previewable before publishing, including:</p>
<ul>
<li>Adding a new widget</li>
<li>Editing existing widgets</li>
<li>Reordering widgets</li>
<li>Dragging widgets to other sidebars</li>
<li>Removing widgets from the sidebars</li>
</ul>
<p>If you want to test it out, install <a href="http://wordpress.org/plugins/widget-customizer/" target="_blank">Widget Customizer</a> on a test site.  The plugin&#8217;s description advocates the new feature by stating, &#8220;No longer do you have to edit your widgets blind!&#8221; Editing a widget and then having to navigate to the front-end to see what you did is in essence blind editing. Once you try the Widget Customizer, you may never go back to the old way of editing widgets.</p>
<p>The Better Widgets and Widget Customizer plugins are paving the way for the future of WordPress widgets. If you&#8217;ve ever been frustrated with widget management, you can breathe a sigh of relief, because some very nice updates are underway. Would you like to see real-time previews added to the core? What do you wish you could change about widget management? </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 05 Nov 2013 21:47:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WPTavern: Bon Appetit! Top WordPress Plugins for Restaurants";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=10568";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:111:"http://feedproxy.google.com/~r/WordpressTavern/~3/d3GehtlHpJc/bon-appetit-top-wordpress-plugins-for-restaurants";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9171:"<p><img class="size-full wp-image-10906 alignright" alt="Top WordPress Plugins for Restaurants" src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/chef-wppot.png?resize=200%2C321" />One of the earliest &#8220;jobs&#8221; I had as a kid in Chicago was printing the menu for the local pizza restaurant. Back in the early 80s, it was quite rare for a kid to have a computer, let alone a color printer. Owning one of the earliest color printers, I immediately found several local businesses who were willing to swap out services and merchandise in exchange for some well designed menus that they could  update with specials every month. I developed a long relationship printing flyers and pizza take-out menus in exchange for free pizzas every weekend. Not bad for a 13-year-old with an eye for proper layout. I was a young entrepreneurial spirit forged in tomato sauce and mozzarella.</p>
<p>Things are not much different thirty years later. There are more restaurant owners looking to build customer loyalty than ever. While online review services like Yelp and Foursquare have made finding a restaurant easier, it is the establishment&#8217;s main website that is often the determining factor for new restaurant customers. Independent restauranteurs and franchises are increasingly turning to capable WordPress designers to develop and create appetizing online presentations. Though there are many different WordPress themes for restaurants, we will focus on what plugins can be used on nearly any theme. Here are some plugins to help with the development and presentation for WordPress based restaurant sites. <span id="more-10568"></span></p>
<h3>Easy Restaurant Menu Manager</h3>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/bigmenu.jpg" rel="thumbnail"><img class="alignleft size-thumbnail wp-image-10987" alt="Easy Restaurant Menu Manager" src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/bigmenu.jpg?resize=150%2C150" /></a>For simple yet stylish menus with very little setup, my first suggestion is <a title="Easy Restaurant Menu Manager" href="http://wordpress.org/plugins/easy-restaurant-menu-manager/" target="_blank">Easy Restaurant Menu Manager</a>. ERMM gives you several options when setting up various dishes and beverages. Add categories like starters, sandwiches, desserts and drinks. Determine the display order of your categories. Include a description for each item and optionally display the price. CSS can be modified directly within the plugin. It also features different icons to add to the dish indicating spicy, heart-healthy or vegan options that might be presented. Just about any other kind of business that has a menu of services or products could use this plugin. Whether it&#8217;s a spa, restaurant or car detailing shop, Easy Restaurant Menu Manager offers an elegant presentation that can be easily customized to fit your site theme.</p>
<h3>Locu For Restaurants</h3>
<p><img class="alignleft  wp-image-10993" alt="Locu" src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/locu-logo.png?resize=160%2C71" />For a robust third-party integration of menus, a restaurant owner may want to consider <a title="Locu for Restaurant Menus" href="http://wordpress.org/plugins/locu-for-restaurant-menus-and-merchant-price-lists/" target="_blank">Locu for Restaurant Menus</a>. The Locu service lets one add their menu and specials on the Locu site. The plugin then displays the menu in the form of a shortcode. Though there is nothing noteworthy about that functionality, it&#8217;s the other services of Locu that make it appealing. In addition to site embed capability, the Locu site also submits the restaurant menu to sites like Foursquare, City Search and Open Table. Premium Locu subscribers can also submit their menus to Trip Advisor, Yelp and their own Facebook page. Once you update the menu on Locu, it updates everywhere else in real-time.</p>
<h3>Open Table</h3>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/screenshot-2.jpg" rel="thumbnail"><img class="alignleft size-thumbnail wp-image-10988" alt="Open Table Widget" src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/screenshot-2.jpg?resize=150%2C150" /></a>Many people have found Open Table to be a convenient way to get a table at a local restaurant. Restaurants that participate in Open Table can also use the service within their WordPress sites by utilizing the <a title="Open Table Widget" href="http://wordpress.org/plugins/open-table-widget/" target="_blank">Open Table Widget</a> plugin. Requiring only the restaurant ID number, the plugin renders a table reservation form as a widget. The prospective diner only needs to enter the date, time, and party size. I&#8217;ve personally used the Open Table reservation service as a dining customer and found it to be a very good user experience. It&#8217;s great to grab a last-minute table or for planning well in advance.</p>
<h3>GravityForms</h3>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/mamas-greek-food-catering-menu.jpg" rel="thumbnail"><img class="alignleft size-thumbnail wp-image-10913" title="Example Catering Addition Logic" alt="Example Catering Addition Logic" src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/mamas-greek-food-catering-menu.jpg?resize=150%2C150" /></a>We all like to use <a title="Gravity Forms" href="http://gravityforms.com" target="_blank">Gravity Forms</a> for the usual &#8220;Contact Us&#8221; pages and lead forms. But GF is also a very powerful conduit for catering order forms. Internally, GF has the capability of doing math! That means  you can create a catering order form that actually adds up the total as someone chooses their items and sides. It allows a restaurant or caterer the option of taking delivery orders without having to build a full-blown e-commerce setup on their site. When payment is fulfilled at a later time or in circumstances when there are always follow-up confirmation calls, a form can do the job perfectly.</p>
<p>Gravity Forms also allows for conditional logic. Does a caterer have a different menu option for serving a party of 20 vs a party of 200? You bet they do! Gravity Forms can present completely different menu options based on number of guests, distance from the restaurant and dietary restrictions. From the perspective of the restaurant staff, Gravity Forms can send out different notifications to the Chef, Catering Manager and to the person responsible for scheduling staff for event service. The notification email provides a comprehensive order list, total price and special food request notes. The address field has a Google map link, providing directions from the restaurant to the event venue in just one click. I have used this plugin for just about every type of business out there. When I put it to use creating a catering order form, I gained a whole new respect for the plugins capabilities.</p>
<h3>Foursquare Perks</h3>
<p><img class="alignleft size-full wp-image-10910" alt="Foursquare Perks" src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/foursquare-perks2.jpg?resize=240%2C139" />Many restaurants choose to reward people who frequently check in through Geo-Social channels like Yelp and Foursquare. In the case of Foursquare, there is a great plugin that allows a restaurant to proudly display venue statistics in near real-time. <a title="Foursquare Venue" href="http://wordpress.org/plugins/foursquare-venue/" target="_blank">Foursquare Venue</a> gives the restaurant site the ability to display total check-ins, how many people are currently checked in and who the current &#8220;mayor&#8221; of the location is. The mayor is the person who has checked into a particular place the most. Why not reward the mayor with a free side dish or drink with every order? Make it a contest of social supremacy. It&#8217;s good to be king! Obviously you will want to use caution with the real-time statistics. Nothing looks worse than a big fat zero in the column of current people checked in. If you have a restaurant with a lot of social check-ins with Foursquare, this may be a plugin that you want to use.</p>
<h3>Think Of These Plugins Before Your Next Restaurant Client</h3>
<p>Think of these plugins the next time you are involved in a restaurant site build. They will help to provide a much more engaging experience for future customers. Remember to always test your plugins on a staging site. Accepting pizza as payment is still considered a valid site developer currency, especially in Chicago or New York. Somewhere out there is a budding 13-year-old kid eagerly awaiting their first bite of WordPress-traded pizza. Hopefully these plugin features have helped to get the youngster more negotiating power, like a few extra toppings or some bread sticks to boot. Though much like a chef using a test kitchen, be sure to try these plugins on a staging site first. Using an unfamiliar plugin to a new environment could be a recipe for disaster.</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/d3GehtlHpJc" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 05 Nov 2013 20:47:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Marcus Couch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WPTavern: Preparing Plugins And Themes To Use Language Packs via WordPress.org";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11012";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:130:"http://feedproxy.google.com/~r/WordpressTavern/~3/fZouOPU3Vic/preparing-plugins-and-themes-to-use-language-packs-via-wordpress-org";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1657:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/LanguagePacks.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/LanguagePacks.jpg?resize=196%2C110" alt="Language Packs" class="alignright size-full wp-image-11013" /></a>One of the features added to the recently released <a href="http://wordpress.org/news/2013/10/basie/" title="http://wordpress.org/news/2013/10/basie/">WordPress 3.7</a> was support for language packs. &#8220;<em>WordPress 3.7 adds support for automatically installing the right language files and keeping them up to date, a boon for the many millions who use WordPress in a language other than English.</em>&#8221; While support has been added to core, there is still a lot of work to be done to properly have this feature implemented to the WordPress.org website.</p>
<p>Otto has <a href="http://ottopress.com/2013/language-packs-101-prepwork/" title="http://ottopress.com/2013/language-packs-101-prepwork/">published an excellent guide</a> for plugin and theme developers that explains what needs to be done to take full advantage of language packs. </p>
<blockquote><p>So go forth, plugin and theme authors. Start fixing up that code. Many of you may have nothing to fix. Some of you may just need a header change. But it’s worth giving it a once over anyway. It certainly would be very nice if, as the new features begin to be added to WordPress.org, then your code was all ready and set to take immediate advantage of it, wouldn’t it? &#8211; Otto </p></blockquote>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/fZouOPU3Vic" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 05 Nov 2013 20:10:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: DP Dashboard – An Alternative WordPress Admin Design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11018";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:112:"http://feedproxy.google.com/~r/WordpressTavern/~3/57d-VzBCKts/dp-dashboard-an-alternative-wordpress-admin-design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3655:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/DPDashboardLogo.jpg" rel="thumbnail"><img class="alignright size-full wp-image-11031" alt="DPDashboardLogo" src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/DPDashboardLogo.jpg?resize=257%2C164" /></a>Created by Tung Do of DevPress, <a title="http://devpress.com/plugins/dp-dashboard/" href="http://devpress.com/plugins/dp-dashboard/">DP Dashboard</a> is a plugin that transforms the back-end of WordPress into something that is supposed to be simpler, modern, clutter-free, productive and an enjoyable experience. For me however, I preferred the experience of MP6. Instead of writing a lengthy review, I&#8217;m going to tell you what I liked and disliked about DP Dashboard. <span id="more-11018"></span></p>
<h3>What I Like</h3>
<p><strong>Typography</strong> &#8211; The typography is easy to read, even from a distance.</p>
<p><strong>Numbered Menus</strong> &#8211; I like the idea of using numbers for top-level menu items just as long as the order doesn&#8217;t change.</p>
<h3>Things I Don&#8217;t Like</h3>
<p><strong>Everything Is Too Big</strong> &#8211; DP Dashboard was created to provide a large screen experience by only supporting 1024 resolutions and above. He also added support for landscape view in tablet devices. I&#8217;m using a 20 inch widescreen LCD monitor and DP Dashboard has me thinking I don&#8217;t have a big enough screen. Buttons, text fields, menu items, everything is just too big.</p>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/DPDashboardTooBig.jpg" rel="thumbnail"><img class="aligncenter size-large wp-image-11036" alt="DP Dashboard Is Too Big" src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/DPDashboardTooBig.jpg?resize=500%2C220" /></a></p>
<p>This leads to a lot of unnecessary scrolling.</p>
<p><strong>Not A Fan Of The Color Scheme</strong> &#8211; I don&#8217;t like the seaweed color scheme. There is also not enough contrast between the white and grey. On my monitor, they appear to be the same color.</p>
<p><strong>Too Many Clicks Added To My Workflow</strong> &#8211; Using MP6 or the default post writing screen, the right side of the page has an area to drag around widgets. In DP Dashboard, the widgets have been replaced by links to the widgets. I prefer to have the widgets I use most such as Tags, Publish, and Categories on the right side of the post writing screen. By having the widgets I use most to the right of the post writing panel already open, it saves me a mouse click. Using DP Dashboard, I have the choice of scrolling down to find the widget I&#8217;m looking for, or clicking the link to take me straight to the widget. After using DP Dashboard for a day, I&#8217;ve concluded that I don&#8217;t like this workflow.</p>
<h3>Conclusion</h3>
<p>I&#8217;ve respected Tung Do&#8217;s work over the years. His WordPress themes always have a touch of class and sparkle that, in my opinion, is unmatched in the WordPress theme community. However, I can&#8217;t see myself ever using DP Dashboard. It doesn&#8217;t improve any part of my WordPress back-end experience versus MP6. I’ve left the plugin enabled for a day to perform typical administrative functions but the longer I use it, the more I want to disable it!</p>
<p>Instead of creating an alternative to MP6, I&#8217;d like to see Tung Do create his own version of MP6 using it as a foundation. I can tell that Tung put a lot of work into DP Dashboard, it&#8217;s just not my cup of tea.</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/57d-VzBCKts" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 05 Nov 2013 19:23:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:70:"WPTavern: WordPress Inline Documentation Marches Forward: 50% Complete";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=10954";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:120:"http://feedproxy.google.com/~r/WordpressTavern/~3/N5SXwXk35Ho/wordpress-inline-documentation-marches-forward-50-complete";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3243:"<p>When the <a href="http://www.wptavern.com/coming-soon-inline-documentation-for-all-wordpress-hooks" target="_blank">Inline Documentation project</a> was started in July at WordCamp San Francisco, a handful of contributors set out to tackle a massive list of hooks in 195 files. This effort continues and the team is hoping that they will have the hook documentation completed in time with the WordPress 3.8 release in December. Kim Parsell posted an <a href="http://make.wordpress.org/core/2013/11/04/the-state-of-inline-docs/" target="_blank">update</a> on the project and said that the progress to date is right at 50%. <span id="more-10954"></span></p>
<h3>Documentation Sprints at WordCamp Contributor Days</h3>
<div id="attachment_11028" class="wp-caption alignright"><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/contributor-day.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/contributor-day.jpg?resize=560%2C420" alt="photo credit: nacokomc" class="size-full wp-image-11028" /></a><p class="wp-caption-text">WordCamp Europe Contributor Day: photo credit: <a href="http://www.flickr.com/photos/naokomc/10195151834/sizes/z/in/photostream/" target="_blank">nacokomc</a></p></div>
<p>Some of the most recent WordCamp contributor days added new contributors to the ranks and spurred on a good chunk of the documentation to reach that 50% mark.  Coordinators for WordCamp Toronto, WordCamp Europe and WordCamp Sofia all included inline documentation as part of the contributor days, resulting in 35 more files documented and 47 people receiving props for submitting inline docs patches. More progress is also on the way in <a href="http://core.trac.wordpress.org/query?status=accepted&status=assigned&status=new&status=reopened&status=reviewing&component=Inline+Docs&col=id&col=summary&col=status&col=type&col=milestone&col=keywords&order=priority" target="_blank">patches waiting to be reviewed</a>. </p>
<h3>How to Get Involved in WordPress Inline Documentation</h3>
<p>Check out the <a href="http://make.wordpress.org/core/2013/09/05/add-inline-docs-for-hooks/" target="_blank">master list</a> for the remaining hooks that need to be documented and jump in on that post to claim ones that you want to work on. Make sure to read the <a href="http://make.wordpress.org/core/handbook/inline-documentation-standards/php-documentation-standards/" target="_blank">PHP Documentation Standards</a>, especially the newly updated sections on <a href="http://make.wordpress.org/core/handbook/inline-documentation-standards/php-documentation-standards/#documenting-tips" target="_blank">Documenting Tips</a>, <a href="http://make.wordpress.org/core/handbook/inline-documentation-standards/php-documentation-standards/#formatting-guidelines" target="_blank">Formatting Guidelines</a> and how to document <a href="http://make.wordpress.org/core/handbook/inline-documentation-standards/php-documentation-standards/#4-1-duplicate-hooks" target="_blank">duplicate hooks</a>. Your contributions can help this project reach completion by the time WordPress 3.8 is released in December.</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/N5SXwXk35Ho" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 05 Nov 2013 18:50:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: wpXtreme – Another Take On The WordPress App Store Idea";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=10962";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:115:"http://feedproxy.google.com/~r/WordpressTavern/~3/qZgQFIU1H3A/wpxtreme-another-take-on-the-wordpress-app-store-idea";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8423:"<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPExtremeLogo.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPExtremeLogo.jpg?resize=295%2C58" alt="WPExtreme Logo" class="alignright size-full wp-image-11000" /></a><a href="https://wpxtre.me/" title="https://wpxtre.me/">wpXtreme</a> is trying to take the <a href="http://www.wptavern.com/the-wordpress-app-store-1-year-later" title="http://www.wptavern.com/the-wordpress-app-store-1-year-later">WordPress App Store idea</a> to the next level. The site recently launched and provides a method to download plugins and themes through their marketplace. While their plugin didn&#8217;t function properly on my local WordPress install, it worked just fine on the Tavern website.<span id="more-10962"></span></p>
<h3>What Is wpXtreme Trying To Accomplish</h3>
<div class="aligncenter"></div>
<p>While the app store is the best way to describe wpXtreme, it is aiming to be much more than that. In conversation with one of their lead developers, he told me &#8220;<em>Even if we provide users with an App Store-like buying experience directly from the WP dashboard, we&#8217;re much more than this. wpXtreme is more of an ecosystem aiming to create a standard for plugins and (soon) for theme development. Specifically, all plugins available on the WPX Store are required a) to be built on WPDK [<a href="http://wpdk.io" title="http://wpdk.io">http://wpdk.io</a>], an Open Source framework we developed, and b) get validated by our staff</em>&#8220;.</p>
<h3>Requirements To Sell?</h3>
<p>In order to sell a plugin within the Xtreme marketplace, it must be built using their open source framework called <a href="http://wpdk.io" title="http://wpdk.io">WPDK</a>. Sellers will also need to <a href="https://developer.wpxtre.me/users/sign_up" title="https://developer.wpxtre.me/users/sign_up">sign up</a> to their developer program. This is a similar process Apple App Store developers have to go through by using the Apple SDK, having each app reviewed before it&#8217;s approved for sale on the store, etc. Unlike the Apple process, developers who create plugins using their open source framework can sell them on the Xtreme marketplace as well as anywhere else on the web. However, because of the requirements, not every developer will be able to tap into the audience wpXtreme offers. </p>
<h3>Licensing</h3>
<p>All plugins, themes, and support are provided as is under the GPL 2.0 license. When a marketplace item has a 1Y symbol, it stands for one year of product updates, priority support, and full documentation. This is in line with the business model a lot of commercial plugin developers are using. The free license provides access to basic support resources, partial documentation, and product updates. The interesting thing about free licenses is that if at some point the free item goes commercial, free license holders will be able to upgrade to a yearly subscription at a discounted rate.</p>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPExtremeLicensing.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPExtremeLicensing.jpg?resize=500%2C473" alt="WPExtremeLicensing" class="aligncenter size-large wp-image-11004" /></a></p>
<h3>The Marketplace</h3>
<p>Their marketplace already has a number of plugins and themes available, most of them for free. If developers choose to sell plugins through them, they&#8217;ll be able to keep 70% of the sale with 30% going towards wpXtreme to cover their costs. As a user, wpXtreme becomes another resource for themes and plugins. Their plugin doesn&#8217;t replace the existing methods of obtaining them from the WordPress repositories rather, works alongside them.</p>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPExtremePluginStore.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPExtremePluginStore.jpg?resize=500%2C298" alt="WPExtreme Plugin Store" class="aligncenter size-large wp-image-11002" /></a></p>
<p>The shopping experience is not bad. Browsing through themes and plugins was a breeze. The use of colors for items makes it easy to see important information. Clicking the more button takes users to a page that has ratings, features, a description, changelog, and a link to install the theme or plugin. You&#8217;ll need to be logged in to download any of the free themes or plugins. Thankfully, an Xtreme user account is free. </p>
<h3>Have To Use One To Use The Other</h3>
<p>The fact that plugins connected to wpXtreme will stop functioning if it&#8217;s deactivated is a huge turn off. When I asked why this restriction was in place, they told me it&#8217;s because the plugins are using wpXtreme which is a framework plugin. </p>
<blockquote><p>All the plugins downloaded from the WPX Store require our wpXtreme plugin as the main &#8220;engine&#8221; to correctly work in a single WordPress installation. This means any plugin, no matter if a paid or free product, will be disabled as soon as the main plugin, i.e. wpXtreme plugin, gets deactivated.</p>
<p>What I can say for sure is that all plugins run exclusively on the wpXtreme &#8220;main&#8221; plugin because the latter is a framework itself and the former work as enhancements of the core functionality provided by wpXtreme. That&#8217;s the same approach we embraced for Extensions, which <a href="https://wpxtre.me/blog/wpxtreme/releases/wpxtreme-1-1-1-is-now-available-and-brings-you-extensions/" title="https://wpxtre.me/blog/wpxtreme/releases/wpxtreme-1-1-1-is-now-available-and-brings-you-extensions/">we introduced just yesterday</a>, and how they work as plugin enhancements while they technically are plugins themselves.</p></blockquote>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPExtremeDeactivate.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPExtremeDeactivate.jpg?resize=500%2C108" alt="WPExtremeDeactivate" class="aligncenter size-large wp-image-11007" /></a></p>
<p>I don&#8217;t like the idea of marketplace items relying on wpXtreme to be activated in order to function. If wpXtreme stops working or if the marketplace closes up shop, then whatever purchases were made in the marketplace will stop functioning as well. I searched their website for some type of sunset clause but I didn&#8217;t see any. I&#8217;d like to see them implement a clause that states that if they were to go out of business, that they would make it so that purchased items can work independently of their framework plugin.</p>
<h3>What Will It Take To Succeed?</h3>
<p>One thing that would help wpXtreme gain momentum is if their plugin was allowed to be hosted on the repository. Just like the WP App Store plugin, wpXtreme is not allowed within the repository because it provides no functionality. It also serves as a pointer to a third party. Unfortunately, two WordPress plugins that were actively developed prior to Xtreme launching will no longer be available in stand-alone form. Those plugins are <a href="http://wordpress.org/plugins/wp-bannerize/" title="http://wordpress.org/plugins/wp-bannerize/">WP Bannerize</a> and <a href="http://wordpress.org/plugins/wp-cleanfix/" title="http://wordpress.org/plugins/wp-cleanfix/">WP CleanFix</a>. Both plugins have been assimilated into the Xtreme marketplace with WP CleanFix now having a price tag of $15.00. However, both of these plugins now serve a primary role of pointing people to wpXtreme. Users have already <a href="http://wordpress.org/support/topic/new-release-of-cleanfix" title="http://wordpress.org/support/topic/new-release-of-cleanfix">expressed their displeasure</a> at having to download another plugin to use an existing plugin. </p>
<p>A number of active developers will need to first pass the requirements and then buy into their idea of creating a better WordPress ecosystem. While those requirements act as barriers for developers, the process of having to install the wpXtreme plugin to access the store is a barrier to entry for users. Both aspects of the marketplace will need a large contingent of support in order to gain any steam along with any chance of long term success. </p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/qZgQFIU1H3A" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 05 Nov 2013 17:30:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress.tv: Curtis McHale: Don’t Be An Idiot";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24256";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.tv/2013/11/05/curtis-mchale-dont-be-an-idiot/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:652:"<div id="v-rp1BJZl4-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24256/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24256/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24256&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/05/curtis-mchale-dont-be-an-idiot/"><img alt="Curtis McHale: Don&#8217;t Be An Idiot" src="http://videos.videopress.com/rp1BJZl4/video-57b28c86f7_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 05 Nov 2013 14:47:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WPTavern: Breaking: New Features Selected To Merge Into WordPress 3.8 Core";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=10958";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:125:"http://feedproxy.google.com/~r/WordpressTavern/~3/_lvjtTGbWVc/breaking-new-features-selected-to-merge-into-wordpress-3-8-core";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6199:"<p>Today was an important day for nailing down the features that will be moving forward in WordPress 3.8.  In an epic three hour planning and decisions meeting, Matt Mullenweg opened up the discussion by asking plugin leaders to provide a status for their proposed features. I&#8217;ve summarized a few of the highlights.<span id="more-10958"></span></p>
<h3>Widgets Area Chooser Plugin Gets a Green Light</h3>
<p><div id="attachment_10101" class="wp-caption alignright"><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/10/widgets-area-chooser.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/10/widgets-area-chooser.jpg?resize=353%2C250" alt="Widgets Area Chooser" class="size-full wp-image-10101" /></a><p class="wp-caption-text">Widgets Area Chooser</p></div>The meeting started with discussion on the accessibility benefits of the Widgets Area Chooser plugin, which we recently <a href="http://www.wptavern.com/wordpress-widgets-area-chooser-plugin-a-handy-addition-to-mp6" target="_blank">featured</a> on the Tavern. Shaun Andrews submitted a <a href="http://make.wordpress.org/core/2013/11/04/widgets-area-chooser-3-8-proposal/" target="_blank">proposal</a> at the last minute for its inclusion in 3.8.</p>
<p>Matt said, &#8220;I think this is a small but useful addition, and the trac ticket should allow any code issues to be worked out.&#8221; In the next day or two the plugin should be live on WordPress.com so that the team can gather a wider range of browser and user testing. It looks like this feature will be getting the green light.</p>
<h3>Omnisearch Needs More Refining</h3>
<p>During the meeting it was determined that the Omnisearch plugin needs more discussion on implementation and features, so work will continue there before it will be cleared to move on to core. </p>
<h3>DASH Plugin Will Be Merged Into Core</h3>
<p><a href="https://twitter.com/growthdesigner" target="_blank">Dave Martin</a>, otherwise known as @lessbloat and the Dash plugin team leader, has been paired with core developer Mark Jaquith who will be working with them on merging the plugin into core. No major roadblocks were raised in the discussion of this feature. </p>
<p>When asked what the screen looks like for a site that doesn&#8217;t have much content, @lessbloat posted a screenshot of a brand new dashboard: </p>
<div id="attachment_10964" class="wp-caption aligncenter"><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/new-dash.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/new-dash.jpg?resize=560%2C420" alt="New dashboard" class="size-full wp-image-10964" /></a><p class="wp-caption-text">New dashboard</p></div>
<p>This feature is looking pretty solid and is cleared to merge into core. WordPress users can expect a beautiful new dashboard in the next release.</p>
<h3>THX &#8211; All Systems a Go!</h3>
<p>The <a href="http://make.wordpress.org/core/2013/10/23/thx-presentation/" target="_blank">Theme Experience</a> plugin is now on its way into 3.8. WordPress users can expect a much improved way of viewing themes in the next release. </p>
<div id="attachment_10967" class="wp-caption aligncenter"><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/theme-with-multiple-sreenshots.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/theme-with-multiple-sreenshots.jpg?resize=560%2C344" alt="Theme with multiple screenshots" class="size-full wp-image-10967" /></a><p class="wp-caption-text">New theme experience demo with multiple screenshots</p></div>
<p>A few points were raised about enhancing what the plugin already does and making its features more discoverable in the UI. There&#8217;s plenty of time to polish it up. Matt noted that testing this feature with lots of themes will be important in order to ensure that the experience stays speedy.</p>
<h3>MP6 Finally Cleared for Takeoff</h3>
<p>Some work needs to be done on browser support and performance but other than that the plugin is looking pretty solid right now. MP6 will finally be rolled into the core in WordPress 3.8.</p>
<p>&#8220;MP6 is a shot in the arm,&#8221; Matt said. &#8220;It forces plugin devs to up their game, makes WP feel modern, and the importance of the responsive aspect of it cannot be overstated.&#8221; MP6 is a vast improvement upon the current admin design and is arguably the most highly anticipated addition to WordPress 3.8.</p>
<h3>Twenty Fourteen &#8211; Not Yet a Lock For 3.8</h3>
<p><a href="http://twentyfourteendemo.wordpress.com/" target="_blank">Twenty Fourteen</a> will be the next WordPress default theme. Because this is the most fully featured theme so far, a major challenge will be helping users discover what is possible with Twenty Fourteen. The development team is aiming to push as many of the customizations as possible into WordPress&#8217; Customizer so that it&#8217;s easier to work with. Lingering development concerns mean that Twenty Fourteen&#8217;s inclusion in 3.8 is not yet a lock. The worst case scenario would be holding it back for the 3.9 release, but it hasn&#8217;t yet been decided.</p>
<h3>Features Are Merging into the WordPress Trunk</h3>
<p>During the 3.8 development meeting Matt paired each incoming feature with a core developer as a &#8220;buddy&#8221; to the plugin leader. &#8220;The role of the buddy is a support one to try to sherpa the plugin getting in as friction-free as possible,&#8221; he said.</p>
<p>The trunk is about to get a bit more volatile, so developers might want to turn off those nightlies for awhile. As features are merged into the trunk, Matt encouraged developers to see the trunk as &#8220;a place where things can and will break, versus a museum of perfect code that we all svn up to in production every morning at 5am.&#8221; Things may be a bit messy in the transition, but this is a good sign that WordPress is growing and improving in many new ways. Core development is ramping up for a very exciting 3.8 release in December.</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/_lvjtTGbWVc" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 05 Nov 2013 00:30:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"WPTavern: Tour Automattic Without Leaving Your House";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=10903";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:104:"http://feedproxy.google.com/~r/WordpressTavern/~3/yyMz7sKEof4/tour-automattic-without-leaving-your-house";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4436:"<p>If you have not had the chance to see Automattic&#8217;s new office in downtown San Francisco in person, you&#8217;re in luck. You can now take a virtual tour of the Automattic office via Google Maps. Joey Kudish who is an Automattic employee <a href="http://jkudish.com/2013/10/31/automattic-is-on-google-maps" title="http://jkudish.com/2013/10/31/automattic-is-on-google-maps">shared the news on his blog</a>. According to Joey, a photographer stopped by, took pictures, and was able to map out the entire building, including the second floor. <span id="more-10903"></span></p>
<p>The tour starts on the second floor and as noted in the comments, you&#8217;ll need to hit the back arrow in order to go down the steps. Notable stops on the journey include the custom shuffle board on the second floor and the mini WordPress museum on the first floor. My favorite image actually has nothing to do with the Automattic office. On the first floor near the entrance, if you look in the direction towards the museum in front of the steel beam, you&#8217;ll see a reflection of the the camera stand. </p>
<div id="attachment_10943" class="wp-caption aligncenter"><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WalkingCamera.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WalkingCamera.jpg?resize=220%2C300" alt="The Walking Camera" class="size-medium wp-image-10943" /></a><p class="wp-caption-text">Walking Camera?</p></div>
<p>We know a photographer came into the office and took these photos. But this particular photo has me thinking he used a walking camera to take the photos for him. I only kid. But it sure does look like a walking camera in mid stride. </p>
<h3>How Were These Photographs Created?</h3>
<p>I got in touch with Alex Schoenfeldt of <a href="http://www.schoenfeldt.com/" title="http://www.schoenfeldt.com/">Scheonfeldt.com</a> who was commissioned by Automattic to find out what type of equipment he used. While Google streetview uses a vehicle with cameras pointing in all directions to generate their panoramic shots, Alex achieves this using one camera. For this job, he used a Canon 5D Mark 2 with a Sigma 8mm fisheye lens. A Nodal Ninja Panoramic head all mounted on a Bogen Tripod. He used a technique called <a href="http://en.wikipedia.org/wiki/Exposure_bracketing" title="http://en.wikipedia.org/wiki/Exposure_bracketing">exposure bracketing</a> to piece together the panoramic shots. He starts off pointing the camera in a northward position turning the camera 90 degrees. Three photos are taken for each 90 degree turn. One photo is taken overexposed. The next is underexposed. The last photo is taken with spot on settings. He&#8217;s then able to stitch the images together to form one image. </p>
<p>Until I spoke with Alex, I was unaware of the fact that Google Maps <a href="http://www.google.com/intl/en/help/maps/businessphotos/photographers/" title="http://www.google.com/intl/en/help/maps/businessphotos/photographers/">has a program in place</a> that will train people on how to run a photography business. Alex completed the training program and is now able to offer photography services to businesses like Automattic. He also has the ability publish those images to Google Maps. It&#8217;s an interesting service for photographers and I see no reason why businesses wouldn&#8217;t take advantage of it, especially those who are proud of their offices and want to show them off to the world. </p>
<h3>What The New Automattic Office Use To Be</h3>
<div class="aligncenter"><br /><small><a href="https://maps.google.com/maps?cbll=37.784159,-122.3972&layer=c&cbp=12,226.14,,0,-10.16&hl=en&gl=us&ie=UTF8&ll=37.783562,-122.396622&spn=0.005944,0.013078&t=m&z=17&panoid=I4jyXig_o3EyhPceyT2neg&source=embed">View Larger Map</a></small></div>
<p>By the way, while Google Maps knows where the Automattic office is located, their street view has older images showing the previous building tenants. It used to be a <a href="http://fairtex.com/" title="http://fairtex.com/">Fairtex location</a>. Fairtex is a manufacturer of combat equipment and clothing for Muay Thai and Mixed Martial Arts. This should give you a good idea as to the amount of work and renovation that took place prior to Automattic calling this building their new home.</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/yyMz7sKEof4" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 04 Nov 2013 22:00:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WordPress.tv: Natalie MacLees: Responsive Typography For WordPress Themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24454";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://wordpress.tv/2013/11/04/natalie-maclees-responsive-typography-for-wordpress-themes/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:701:"<div id="v-Gw0Z94uq-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24454/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24454/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24454&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/04/natalie-maclees-responsive-typography-for-wordpress-themes/"><img alt="Natalie MacLees: Responsive Typography For WordPress Themes" src="http://videos.videopress.com/Gw0Z94uq/video-f9f014ae00_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 04 Nov 2013 19:14:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: 10 Free WordPress Themes Based on the Foundation Framework";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=10901";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:120:"http://feedproxy.google.com/~r/WordpressTavern/~3/MtaJ6CEnq_g/10-free-wordpress-themes-based-on-the-foundation-framework";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9230:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/zurb-foundation.png" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/zurb-foundation.png?resize=400%2C244" alt="zurb-foundation" class="alignright size-full wp-image-10916" /></a>At the beginning of this year there were just a handful of WordPress themes available for Zurb&#8217;s <a href="http://foundation.zurb.com/" target="_blank">Foundation</a> framework. Most of these were basic starter themes for developers. As we near the end of 2013, Foundation is rapidly becoming more popular with front-end developers and the demand for WordPress themes is also increasing. In addition to the 10 free themes included in this article, Foundation-based themes are popping up on Themeforest and other commercial sites. </p>
<p>Many front-end developers prefer Foundation over Twitter Bootstrap, its more well-known counterpart. Foundation was created with a mobile first approach. It&#8217;s more style-agnostic when it comes to UI tools, which often translates into less work when theming. Foundation also provides native support for SASS, enabling developers to use <a href="http://compass-style.org/" target="_blank">compass</a> in their workflow.<span id="more-10901"></span></p>
<p>All of the WordPress themes below incorporate the Foundation framework. Their project websites are an example of what is possible when building with Foundation.</p>
<h2>Reverie</h2>
<p><a href="http://themefortress.com/reverie/"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/reverie.jpg?resize=560%2C576" alt="reverie" class="aligncenter size-full wp-image-10919" /></a><br />
In addition to inheriting all the Foundation features, Reverie also includes customized output for WordPress menus, caption and pagination. It has two built-in widget ares and two custom menus.  Reverie can be used as a starter theme or as the parent theme to a child theme that you create.</p>
<h4><a href="http://themefortress.com/reverie/" target="_blank">Theme Info</a> | <a href="http://themefortress.com/demo/" target="_blank">Demo</a></h4>
<h2>Requried+</h2>
<p><a href="http://themes.required.ch/" target="_blank"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/required.jpg?resize=560%2C477" alt="required" class="aligncenter size-full wp-image-10924" /></a><br />
Along with Reverie, Required+ was one of the first ones on the scene to offer a Foundation-based WordPress theme. It is meant to be used as a parent theme and <a href="http://themes.required.ch/theme-features/documentation/" target="_blank">features</a> commented code, flexible layout options with page templates and widget areas for different layouts. Required+ includes shortcodes to help you create columns, galleries and more using the visual editor. The shortcodes are offered as optional plugins. One unique feature of Required+ is that it offers <a href="http://themes.required.ch/theme-features/editor-styles/" target="_blank">editor styles</a> for adding Foundation styles and elements to the post editor without using shortcodes.</p>
<h4><a href="http://themes.required.ch/" target="_blank">Theme Info</a> | <a href="http://themes.required.ch/demo/" target="_blank">Demo</a></h4>
<h2>Reactor</h2>
<p><a href="http://awtheme.com/"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/reactor.jpg?resize=560%2C464" alt="reactor" class="aligncenter size-full wp-image-10927" /></a><br />
Reactor makes use of the WordPress Customizer to offer customization options. It includes shortcodes for UI elements such as pricing grid, orbit slider, buttons and more. Reactor was built with the developer in mind and offers an assortment of hooks, content actions and theme actions.</p>
<h4><a href="http://awtheme.com/" target="_blank">Theme Info</a> | <a href="http://demo.awtheme.com/reactor/" target="_blank">Demo</a></h4>
<h2>WP Foundation</h2>
<p><a href="http://320press.com/wp-foundation/"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/wp-foundation.jpg?resize=560%2C518" alt="wp-foundation" class="aligncenter size-full wp-image-10930" /></a></p>
<p>WP Foundation includes four different page templates, a configurable via theme options panel, shortcodes pre-styled with Foundation’s styles and two different sidebars.</p>
<h4><a href="http://320press.com/wp-foundation/" target="_blank">Theme Info</a> | <a href="http://320press.com/wp-foundation/" target="_blank">Demo</a></h4>
<h2>Base Station</h2>
<p><a href="http://www.johnparris.com/basestation/"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/base-station.jpg?resize=560%2C496" alt="base-station" class="aligncenter size-full wp-image-10932" /></a></p>
<p>Base Station is an extensible WordPress theme built on Foundation. It was built to be extended by developers, includes a number of hooks, and most of its functions are either pluggable or accessible via filters. The theme also has a feature called <a href="http://www.johnparris.com/basestation/documentation#featured-posts" target="_blank">featured posts</a> for highlighting your content. Base Station shortcodes offer support for alerts, buttons, featured posts slider, labels, login form and panels.</p>
<h4><a href="http://www.johnparris.com/basestation/" target="_blank">Theme Info</a> | <a href="http://www.johnparris.com/basestation/" target="_blank">Demo</a></h4>
<h2>WP Foundation</h2>
<p><a href="http://micahblu.com/products/wp-foundation/"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/wp-foundation1.jpg?resize=560%2C475" alt="wp-foundation" class="aligncenter size-full wp-image-10934" /></a><br />
WP Foundation is a free theme created by developer Micah Blu. This theme can be used as it is or easily customized via the options panel. WP Foundation theme options include basic branding, typography and a set of social buttons.</p>
<h4><a href="http://micahblu.com/products/wp-foundation/" target="_blank">Theme Info</a> | <a href="http://micahblu.com/demo/?theme=wp-foundation" target="_blank">Demo</a></h4>
<h2>Foundation for WordPress</h2>
<p><a href="https://github.com/drewsymo/Foundation"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/foundation-for-wp.jpg?resize=560%2C465" alt="foundation-for-wp" class="aligncenter size-full wp-image-10936" /></a></p>
<p>Foundation for WordPress is a responsive starter theme that features developer friendly markup, shortcodes, custom background and header and support for child themes and custom post types. The theme offers built-in navigation and widgetized sidebars to get you on your way developing your theme with Foundation.</p>
<h4><a href="https://github.com/drewsymo/Foundation" target="_blank">Theme Info</a> | <a href="http://fwp.drewsymo.com/" target="_blank">Demo</a></h4>
<h2>Spine</h2>
<p><a href="http://spine.paulwp.com/"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/spine.jpg?resize=560%2C475" alt="spine" class="aligncenter size-full wp-image-10938" /></a></p>
<p>Spine is a WordPress theme based on Foundation and <a href="http://themehybrid.com/hybrid-core" target="_blank">Hybrid core</a>. It features three custom menu locations and several different layouts, including no sidebar, one or two sidebars. The front page template is completely widgetized and you can use the theme customizer with live preview to customize your site.</p>
<h4><a href="http://spine.paulwp.com/" target="_blank">Theme Info</a> | <a href="http://spine.paulwp.com/" target="_blank">Demo</a></h4>
<h2>SmartAdapt</h2>
<p><a href="http://wordpress.org/themes/smartadapt"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/smartadapt.jpg?resize=560%2C452" alt="smartadapt" class="aligncenter size-full wp-image-10940" /></a></p>
<p>SmartAdapt is a Foundation-based theme hosted on WordPress.org, which means that this is a solid theme that holds to the rigorous code standards maintained by the <a href="http://codex.wordpress.org/Theme_Review" target="_blank">WordPress Theme Review</a> team. It allows you to easily customize background, logo or header image, etc and includes social share button support (Facebook like, Twitter share, Google +1, Pin it). </p>
<h4><a href="http://wordpress.org/themes/smartadapt" target="_blank">Theme Info</a> | <a href="http://netbiel.pl/smartadapt/demo/" target="_blank">Demo</a></h4>
<h2>_second-foundation</h2>
<p><a href="http://wordpress.org/themes/_second-foundation"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/second.jpg?resize=560%2C431" alt="second" class="aligncenter size-full wp-image-10942" /></a></p>
<p>_second-foundation is another Foundation-based theme hosted at WordPress.org. It utilizes Masonry.js to create the responsive post grid display. This is a theme that you might select if you desire that specific homepage layout plus Foundation as a base.</p>
<h4><a href="http://wordpress.org/themes/_second-foundation" target="_blank">Theme Info</a> | <a href="http://joshpress.net/" target="_blank">Demo</a></h4>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/MtaJ6CEnq_g" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 04 Nov 2013 17:39:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WordPress.tv: Zack Tollman: Towards A Partial Page Templating System In WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24629";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://wordpress.tv/2013/11/04/zack-tollman-towards-a-partial-page-templating-system-in-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:717:"<div id="v-i7Ez6P9l-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24629/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24629/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24629&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/04/zack-tollman-towards-a-partial-page-templating-system-in-wordpress/"><img alt="Zack Tollman: Towards A Partial Page Templating System In WordPress" src="http://videos.videopress.com/i7Ez6P9l/video-5c1e4ed192_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 04 Nov 2013 09:35:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:92:"WordPress.tv: Tris Hussey: WordPress On The iPad: Blogging, Maintaining, Doing It All Mobile";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24224";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:106:"http://wordpress.tv/2013/11/03/tris-hussey-wordpress-on-the-ipad-blogging-maintaining-doing-it-all-mobile/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:736:"<div id="v-LWnmIwp9-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24224/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24224/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24224&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/03/tris-hussey-wordpress-on-the-ipad-blogging-maintaining-doing-it-all-mobile/"><img alt="Tris Hussey: WordPress On The iPad: Blogging, Maintaining, Doing It All Mobile" src="http://videos.videopress.com/LWnmIwp9/video-4fbc2ec3a5_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 04 Nov 2013 02:39:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WordPress.tv: Michael Toppa: Clean Code For WordPress Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24372";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://wordpress.tv/2013/11/03/michael-toppa-clean-code-for-wordpress-plugins/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:677:"<div id="v-XSnQNwP5-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24372/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24372/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24372&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/03/michael-toppa-clean-code-for-wordpress-plugins/"><img alt="Michael Toppa: Clean Code For WordPress Plugins" src="http://videos.videopress.com/XSnQNwP5/video-3711b2ff79_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 03 Nov 2013 12:57:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Matt: NYC Subway Stop Secret";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43160";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://ma.tt/2013/11/nyc-subway-stop-secret/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:300:"<p><span class="embed-youtube"></span></p>
<p>Apparently to prove they&#8217;re paying attention subway conductors in New York have to point at a sign at every stop. Someone decided to make them smile. As I go back to New York today, it&#8217;s cool to learn something new about the city as well.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 03 Nov 2013 11:09:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:81:"WordPress.tv: Steve Wilkison: An Introduction To Creating Custom WordPress Themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24424";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:98:"http://wordpress.tv/2013/11/02/steve-wilkison-an-introduction-to-creating-custom-wordpress-themes/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:717:"<div id="v-BSg1SHAM-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24424/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24424/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24424&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/02/steve-wilkison-an-introduction-to-creating-custom-wordpress-themes/"><img alt="Steve Wilkison: An Introduction To Creating Custom WordPress Themes" src="http://videos.videopress.com/BSg1SHAM/video-1981a786d7_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 02 Nov 2013 23:44:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WPTavern: WPWeekly Episode 126 – Catching Up With Cory Miller From iThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=10844";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:124:"http://feedproxy.google.com/~r/WordpressTavern/~3/LAGCARUPZ1c/wpweekly-episode-126-catching-up-with-cory-miller-from-ithemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2974:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2.jpg?resize=150%2C150" alt="WordPress Weekly Cover Art" class="alignright size-thumbnail wp-image-8715" /></a> <span id="more-10844"></span>In this episode, we caught up with Cory Miller of <a href="http://ithemes.com/" title="http://ithemes.com/">iThemes.com</a> to walk down memory lane starting with 2008. The year he launched the company. Then we progressed into the future and visited various milestones along the way such as the release of the <a href="http://ithemes.com/purchase/flexx-theme/" title="http://ithemes.com/purchase/flexx-theme/">Flexx theme</a>, <a href="http://www.wptavern.com/review-of-ithemes-builder-theme" title="http://www.wptavern.com/review-of-ithemes-builder-theme">Builder</a>, <a href="http://ithemes.com/find/plugins/" title="http://ithemes.com/find/plugins/">PluginBuddy</a>, <a href="http://www.wptavern.com/backup-buddy-is-a-home-run" title="http://www.wptavern.com/backup-buddy-is-a-home-run">Backup Buddy</a>, <a href="http://webdesign.com/" title="http://webdesign.com/">Webdesign.com</a>, and <a href="http://ithemes.com/exchange/" title="http://ithemes.com/exchange/">iThemes Exchange</a>. I loved talking to Cory about the early years of WordPress themes. We also covered the headlines of the week. <!--more--></p>
<h2>Stories Discussed:</h2>
<p><a href="http://www.wptavern.com/wordpress-3-7-1-a-historical-maintenance-release" title="http://www.wptavern.com/wordpress-3-7-1-a-historical-maintenance-release">WordPress 3.7.1 Released</a><br />
<a href="http://www.wptavern.com/akismet-celebrates-huge-spam-blocking-milestone" title="http://www.wptavern.com/akismet-celebrates-huge-spam-blocking-milestone">Akismet Celebrates Huge Spam Blocking Milestone</a><br />
<a href="http://www.wptavern.com/wordpress-3-8-development-heats-up-with-discussion-of-new-core-features" title="http://www.wptavern.com/wordpress-3-8-development-heats-up-with-discussion-of-new-core-features">WordPress 3.8 Development Heats Up With Discussion of New Core Features</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, November 8th 3 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #126:</strong><br />
</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/LAGCARUPZ1c" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 02 Nov 2013 18:35:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WordPress.tv: Justin Sainton: Hacking Your Business: Business Workflow For Developers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24548";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"http://wordpress.tv/2013/11/02/justin-sainton-hacking-your-business-business-workflow-for-developers/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:724:"<div id="v-3auPLRWJ-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24548/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24548/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24548&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/02/justin-sainton-hacking-your-business-business-workflow-for-developers/"><img alt="Justin Sainton: Hacking Your Business: Business Workflow For Developers" src="http://videos.videopress.com/3auPLRWJ/video-80686fa92c_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 02 Nov 2013 11:40:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"Matt: Automattic on Google Maps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43156";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:47:"http://ma.tt/2013/11/automattic-on-google-maps/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:343:"<p>You can now view <a href="http://jkudish.com/2013/10/31/automattic-is-on-google-maps/">the inside of Automattic&#8217;s office on Google Maps street view</a> and walk around inside. To get downstairs go by the stairs and press the back arrow, a bit unintuitive but gets you to the main floor. Check out the custom shuffleboard upstairs.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 02 Nov 2013 10:00:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:40:"Matt: Ultra-high Frequency Sound Malware";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43154";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://ma.tt/2013/11/ultra-high-frequency-sound-malware/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:985:"<p>The story around <a href="http://arstechnica.com/security/2013/10/meet-badbios-the-mysterious-mac-and-pc-malware-that-jumps-airgaps/">badBIOS, the mysterious Mac and PC malware that jumps airgaps</a>, is fascinating and surprising. The capabilities of sophisticated attackers right now vastly outstrip the defenses of any computer user or company. The <a href="http://www.washingtonpost.com/world/national-security/nsa-infiltrates-links-to-yahoo-google-data-centers-worldwide-snowden-documents-say/2013/10/30/e51d661e-4166-11e3-8b74-d89d714ca4dd_story.html?Post+generic=%3Ftid%3Dsm_twitter_washingtonpost">news that the NSA had broken into the networks of Google and Yahoo</a>, unfortunately, wasn&#8217;t surprising given <a href="http://www.washingtonpost.com/business/technology/google-encrypts-data-amid-backlash-against-nsa-spying/2013/09/06/9acc3c20-1722-11e3-a2ec-b47e45e6f8ef_story.html">Google&#8217;s move to encrypt traffic between datacenters</a> early in September.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 02 Nov 2013 00:37:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:71:"WPTavern: How to Disable Related Videos for YouTube Embeds in WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=10873";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:123:"http://feedproxy.google.com/~r/WordpressTavern/~3/nzi_d1TU9MA/how-to-disable-related-videos-for-youtube-embeds-in-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3743:"<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/youtube-logo.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/youtube-logo.jpg?resize=313%2C136" alt="youtube-logo" class="alignright size-full wp-image-10884" /></a>When you embed a YouTube video in a WordPress post, it is generally added to illustrate your content. Sometimes your video is the main focal point of the post. Chances are that you don&#8217;t want to be sending users to related videos after viewing the embedded one. You want to keep the reader&#8217;s attention on your content. The video was meant to be a tool to capture that attention in the first place. <span id="more-10873"></span></p>
<h3>Turn Off Related Videos</h3>
<p>Related videos is a YouTube feature that can be a lot of fun when you&#8217;re browsing YouTube, but it&#8217;s not so helpful on videos you embed in WordPress posts. There are two different ways to turn related videos off, depending on how your WordPress site is set up. </p>
<h4>WordPress.com Sites and Jetpack-Powered WordPress.org Sites</h4>
<p>On WordPress.com and on self-hosted WordPress sites using Jetpack, you can simply append &#8216;<strong>&#038;rel=0</strong>&#8216; to the end of the YouTube URL to disable related videos at the end of the video. </p>
<p>Normally, you would just grab the URL from the browser window and paste it in on its own line:</p>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/youtube-url.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/youtube-url.jpg?resize=312%2C34" alt="youtube-url" class="aligncenter size-full wp-image-10882" /></a></p>
<p>On our site we are using Jetpack, so we just append &#8216;<strong>&#038;rel=0</strong>&#8216; to the URL:</p>
<pre>http://www.youtube.com/watch?v=xPe4NbWQzkM&#038;rel=0</pre>
<p>The output for that is this ridiculously cute video with <strong>no related videos at the end</strong>:</p>
<p><span class="embed-youtube"></span></p>
<p>The same method can also be applied if you opt for the <a href="http://jetpack.me/support/shortcode-embeds/" target="_blank">Jetpack shortcode embed</a>. More <a href="http://en.support.wordpress.com/videos/youtube/#video-customization-options" target="_blank">video customization options</a> can be found in the WordPress.com documentation.</p>
<h4>Self-Hosted WordPress Sites Without Jetpack</h4>
<p>If you have a self-hosted WordPress site and you&#8217;re not using Jetpack, turning off related videos can be done by selecting the embed option directly from YouTube, instead of using <a href="http://codex.wordpress.org/Embeds" target="_blank">WordPress&#8217; oembed feature</a>. </p>
<p>When you&#8217;re on the YouTube video&#8217;s page, select embed and then <strong>uncheck</strong> the option that says: &#8220;<strong>Show suggested videos when the video finishes.</strong>&#8221;</p>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/uncheck.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/uncheck.jpg?resize=526%2C316" alt="uncheck" class="aligncenter size-full wp-image-10885" /></a></p>
<p>If getting the embed code is a bother, you might try using a plugin such as <a href="http://wordpress.org/plugins/hide-youtube-related-videos/" target="_blank">Hide YouTube Related Videos</a> to do this automatically.</p>
<p>This topic tends to be a bit tricky, depending on if you are on WordPress.com, self-hosted with Jetpack or self-hosted without Jetpack. Fortunately, there&#8217;s an easy solution for everyone.</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/nzi_d1TU9MA" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 02 Nov 2013 00:24:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: WP Test: Unit Testing Data for WordPress Themes and Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=10848";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:120:"http://feedproxy.google.com/~r/WordpressTavern/~3/g9jU9IlaVu8/wp-test-unit-testing-data-for-wordpress-themes-and-plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2414:"<p><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/wptest.png?resize=560%2C135" alt="wptest" class="aligncenter size-full wp-image-10853" /><br />
<a href="http://wptest.io/" title="WP Test" target="_blank">WP Test</a> is a site that any WordPress theme or plugin developer will want to bookmark. Created by WordPress developer <a href="https://twitter.com/manovotny" target="_blank">Michael Novotny</a>, WP Test exists to provide test data for WordPress themes and plugins. The site is very simple and includes only a download and a demo button.</p>
<p>What&#8217;s in the download package? WP Test sums it up nicely:</p>
<blockquote><p>A fantastically exhaustive set of test data to measure the integrity of your plugins and themes.</p></blockquote>
<p><span id="more-10848"></span></p>
<p>The WP Test data is based off of recommendations from <a href="http://codex.wordpress.org/Theme_Unit_Test" target="_blank">WordPress’ Theme Unit Test data</a> found in the codex. Added into the mix is Novotny&#8217;s years of experience supporting themes and plugins. </p>
<h3>The Importance of Unit Testing</h3>
<p>Unit testing is a recommended practice for developers who create software for other people to use. Essentially, it involves putting your code through the paces using a set of control data. If you want your theme or plugin to provide a smooth experience out of the box, then you need to perform tests before it&#8217;s released. WP Test makes unit testing easy. Download the test data and then import it into your test site using the <a href="http://wordpress.org/extend/plugins/wordpress-importer/" target="_blank">WordPress Importer</a>.</p>
<p>Check out the <a href="http://wptest.io/demo/" target="_blank">demo</a> to see the full range of test data in action on a site.</p>
<p>The project is maintained on <a href="https://github.com/manovotny/wptest" target="_blank">github</a> if you want to follow the repository or contribute. Novotny emphasizes that WP Test is by no means a fully comprehensive set of test data and will always be evolving to provide more test scenarios. If you think <a href="http://wptest.io/" target="_blank">WP Test</a> is missing some important tests, please get in touch via the <a href="http://wptest.io/contact/" target="_blank">contact form</a>.</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/g9jU9IlaVu8" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 21:12:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: WordPress By Example: A Search Engine for WordPress Themes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=10838";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:117:"http://feedproxy.google.com/~r/WordpressTavern/~3/fATG7A3BVd4/wordpress-by-example-a-wordpress-specific-search-engine";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3563:"<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPByExampleLogo.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPByExampleLogo.jpg?resize=230%2C44" alt="WordPress By Example Logo" class="alignright size-full wp-image-10839" /></a>A few days ago, we <a href="http://www.wptavern.com/how-to-find-live-examples-of-sites-using-a-theme" title="http://www.wptavern.com/how-to-find-live-examples-of-sites-using-a-theme">mentioned an article by WPShout.com</a> that explained how to find live examples of WordPress powered sites using themes. Today, I wanted to share a new site that&#8217;s been launched called <a href="http://www.wpbyexample.com/" title="http://www.wpbyexample.com/">WordPress by Example</a>. It&#8217;s a WordPress specific search engine designed to showcase sites using themes related to search terms such as photography, or weddings. <span id="more-10838"></span></p>
<p>Developed by Joris Van den Bogaert, WordPress by Example has three different ways you can search. <em>Organic, Premium WordPress Themes, and Free WordPress Themes</em>. Just like any other search engine, this one works via keywords. In this example, I used the keyword of <strong>weddings</strong> with the organic search option. </p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPByExampleOrganicSearchResults.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPByExampleOrganicSearchResults.jpg?resize=500%2C376" alt="Organic Search Results From WP By Example" class="aligncenter size-large wp-image-10840" /></a></p>
<p>While some of the results were relevant, displaying modified themes catering to weddings, other results were not as relevant. When you click on any of the results, a larger image is displayed with a link at the bottom that takes you to a page with more information about that result. The additional information shown includes what theme is being used on the site, information about the site, and the source of the theme. Within the right sidebar, there are buttons to buy the theme, visit the actual website, or view a demo of the theme in use on the site. As you might have guessed, the buy button is an affiliate link. </p>
<h3>A Nice Alternative To The Typical WordPress Theme Search Engine</h3>
<p>There are now hundreds of themes that are released for WordPress everyday. Most have a price tag while others are free. With all of the various WordPress themes available in so many different places, a cottage industry has developed trying to organize and index all of them. Examples include <a href="http://qualithemes.com/" title="http://qualithemes.com/">QualiThemes</a>, <a href="http://themesorter.com/" title="http://themesorter.com/">ThemeSorter</a>, and <a href="http://yellowthemes.com/" title="http://yellowthemes.com/">Yellow Themes</a>. None of these theme finders show sites actually using the theme. </p>
<p>While I like the idea behind WordPress by Example, I couldn&#8217;t help but notice the number of websites that were butchered beyond recognition. This is why I think it&#8217;s better for a theme company to put together site showcases that really show off what the theme is capable of. If nothing else, this search engine shows why good web designers are still needed. Apparently, there are not enough to go around. </p>
<p>Give the site a try and tell me your thoughts in the comments. </p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/fATG7A3BVd4" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 18:00:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WordPress.tv: Judy Wilson: Security With WordPress.org Self-Installation";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24553";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:89:"http://wordpress.tv/2013/11/01/judy-wilson-security-with-wordpress-org-self-installation/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:693:"<div id="v-N98qh0qC-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24553/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24553/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24553&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/01/judy-wilson-security-with-wordpress-org-self-installation/"><img alt="Judy Wilson: Security With WordPress.org Self-Installation" src="http://videos.videopress.com/N98qh0qC/video-6d2e551714_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 11:35:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WordPress.tv: Panel Discussion: Themes And Theme Frameworks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24560";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://wordpress.tv/2013/11/01/panel-discussion-themes-and-theme-frameworks/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:667:"<div id="v-hNA5N7pb-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24560/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24560/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24560&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/01/panel-discussion-themes-and-theme-frameworks/"><img alt="Panel Discussion: Themes And Theme Frameworks" src="http://videos.videopress.com/hNA5N7pb/video-834135521e_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 10:16:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 10 Nov 2013 01:40:56 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"181640";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Sun, 10 Nov 2013 01:30:13 GMT";s:4:"x-nc";s:11:"HIT lax 250";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130908064941";}', 'no') ; 
INSERT INTO `wp_options` VALUES (464, '_transient_timeout_plugin_slugs', '1384177532', 'no') ; 
INSERT INTO `wp_options` VALUES (465, '_transient_plugin_slugs', 'a:5:{i:0;s:19:"akismet/akismet.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:2;s:9:"hello.php";i:3;s:45:"limit-login-attempts/limit-login-attempts.php";i:4;s:40:"twitter-widget-pro/wp-twitter-widget.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (440, '_transient_timeout_feed_a09314b1a57acfaba9faaca775e0e5d2', '1384094552', 'no') ; 
INSERT INTO `wp_options` VALUES (441, '_transient_feed_a09314b1a57acfaba9faaca775e0e5d2', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Range:  Week in WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:13:"http://ran.ge";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:45:"High quality design and WordPress development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 22:18:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=3.7.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"Brian guest appears on a podcast  Week in WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/11/01/brian-guest-appears-on-a-podcast/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:67:"http://ran.ge/2013/11/01/brian-guest-appears-on-a-podcast/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 21:03:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4131";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:167:"Our own Brian Krogsgard talked to Matt Medeiros and Scott Sousa of Slocum Studio on Week in WordPress, a podcast about the news of the week in the WordPress ecosystem.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:555:"<p>Our own Brian Krogsgard talked to Matt Medeiros and Scott Sousa of <a href="http://slocumstudio.com/">Slocum Studio</a> on Week in WordPress, a podcast about the news of the week in the WordPress ecosystem.</p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/81i_v73ONgQ?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:63:"http://ran.ge/2013/11/01/brian-guest-appears-on-a-podcast/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Ranger Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://ran.ge/2013/10/13/ranger-brian-krogsgard/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:57:"http://ran.ge/2013/10/13/ranger-brian-krogsgard/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 13 Oct 2013 17:45:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:5:"Range";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4112";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:348:"Hey y&#8217;all. My name is Brian Krogsgard, and I&#8217;m happy to be joining Range as a Junior Partner. I&#8217;m looking forward to working with the outstanding team here. I&#8217;ve followed Range since its inception, and I&#8217;ve always loved their mentality that a small company could do big things. So, who am I? I graduated from [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1658:"<p><span style="line-height: 1.5;">Hey y&#8217;all. My name is Brian Krogsgard, and I&#8217;m happy to be joining Range as a Junior Partner. I&#8217;m looking forward to working with the outstanding team here.</span></p>
<p>I&#8217;ve followed Range since its inception, and I&#8217;ve always loved their mentality that a small company could do big things.</p>
<p>So, who am I?</p>
<p>I graduated from Auburn University with an Industrial Engineering degree, and for a few years web development was purely a hobby for me. My first job was as a technical sales engineer in the manufacturing industry, where I got my feet wet learning the value of effectively managing customer relationships and complex projects from start to finish.</p>
<p>But eventually I made the leap and turned my web development hobby into my career. Today, I bring experience building websites large and small across a variety of industries. I specialize in theme and light plugin development.</p>
<p>I also keep a keen eye on what&#8217;s happening in the WordPress community. I run a WordPress news blog called Post Status, which helps me learn more about my craft, share what I learn, and get to know many wonderful people that make the WordPress ecosystem great.</p>
<p>I&#8217;m based out of Birmingham, Alabama, where I live with my wife, Erica, and our blue Great Dane, Lucy May. I organize the Birmingham WordPress Meetup Group and co-organize WordCamp Birmingham.</p>
<p>At Range, I&#8217;ll wear many hats, just like Sara, Pete, and Aaron. My skill set compliments theirs nicely, and I really look forward to learning from them and bringing my best efforts to the table.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ran.ge/2013/10/13/ranger-brian-krogsgard/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"Disney Books relaunches on WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://ran.ge/2013/10/10/disney-books-relaunches-on-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:71:"http://ran.ge/2013/10/10/disney-books-relaunches-on-wordpress/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Oct 2013 14:32:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:8:"Branding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"Design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"Front End";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:17:"Project Spotlight";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4082";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:348:"Disney Publishing Worldwide has relaunched it&#8217;s books site, books.disney.com, on WordPress. When Disney came to us, we were excited, but it was clear that the biggest struggle was going to be the timeline. They wanted to build an all new books.disney.com on WordPress, and they needed it in less than a month. It was a tall order, [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Pete Mall";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1719:"<p><img class="size-large alignright" alt="disney-books-iphone" style="box-shadow: none;" src="http://s1.ran.ge/content/uploads/2013/10/disney-books-iphone-241x500.png" width="241" height="500" /><br />
Disney Publishing Worldwide has relaunched it&#8217;s books site, <a title="Disney Publishing Worldwide" href="http://books.disney.com/">books.disney.com</a>, on WordPress. When Disney came to us, we were excited, but it was clear that the biggest struggle was going to be the timeline. They wanted to build an all new books.disney.com on WordPress, and they needed it in less than a month. It was a tall order, but we pulled it off. From concept, to wireframing, design, development, and launch, Range put in a team effort to design and build the new books.disney.com.</p>
<p>In order to keep such a tight timeline, we knew wireframes needed to be done in less than a week, and the design needed to be finished just a week after that. Sara Cannon stepped up to the plate to lead the wireframes and design, and kept the schedule right on track. The design is also responsive, so it looks great on every device.</p>
<p>The development team pulled some crazy hours for a little while there, but the end result is an amazing site that meets our client&#8217;s needs and was delivered on time. We couldn&#8217;t have done it without Disney, who was a great partner. They held up their end of the bargain to trust our instincts and give quick feedback every time we needed it.</p>
<p>We are proud of the end result, and we hope you like it too. Be sure to <a title="Disney Publishing Worldwide" href="http://books.disney.com/">check out the site</a>, and who knows, you may find a new book for you and your family.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:67:"http://ran.ge/2013/10/10/disney-books-relaunches-on-wordpress/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Sara Cannon’s Be the Unicorn Published on Torque";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ran.ge/2013/07/29/sara-cannons-be-the-unicorn/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:62:"http://ran.ge/2013/07/29/sara-cannons-be-the-unicorn/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 30 Jul 2013 04:35:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:7:"Writing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"unicorns";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"writing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4024";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:342:"Check Out the full post on Torque at WCSF! Be The Unicorn by Sara Cannon What’s all this talk about Unicorns? Beautiful, sparkling, Golden Unicorns. My beginnings in Web Design and Development surfaced out of a love for technology an art. I was an artist and print designer with a thirst for something more. Because I wanted to [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2904:"<p><strong>Check Out the full post on <a href="http://torquemag.io/be-the-unicorn/">Torque</a> at WCSF!</strong></p>
<h3 style="padding-left: 60px;">Be The Unicorn by Sara Cannon</h3>
<p style="padding-left: 60px;">What’s all this talk about Unicorns? Beautiful, sparkling, Golden Unicorns.</p>
<p dir="ltr" style="padding-left: 60px;">My beginnings in Web Design and Development surfaced out of a love for technology an art. I was an artist and print designer with a thirst for something more. Because I wanted to be relevant and engaged, I ended up diving head first into the fast moving waters of web design and development. To get things done, I hunkered down, studied, imitated, and learned. To be completely self-sustainable, you end up learning bits of everything. I strived to become a renaissance woman. I wanted to build and create, without needing to rely on others to achieve my goals.</p>
<p dir="ltr" style="padding-left: 60px;">A few years later, I was hired by a small agency that really needed a one woman show. They did not want to need to rely multiple departments and titles to get the job done.</p>
<h3 dir="ltr" style="padding-left: 60px;">They needed a Golden Unicorn<img alt="" src="https://lh4.googleusercontent.com/Kf7Lg_5t9odG5Kjj7LF1MPQA39rSG3P_Thk7egmbWK8GEwAJ9hQ6lFcCZbFxbE3__nTgYNeF7qdMWcXI0Y0bl_lDQQFjQFsnrh_J2bZiyJGK_H-tNbPZbgZ8" width="223px;" height="233px;" /></h3>
<p dir="ltr" style="padding-left: 60px;">They wanted someone who could not only always solve the technical problems at hand, but had an eye for design and user experience. Someone who could say “yes that can happen” without hesitation and then google it right after making the promise. Since then, I decided to strive to be the unicorn.</p>
<p dir="ltr" style="padding-left: 60px;">In the industry now, there seems to be a long standing tension between designers and developers. This tension is manifested in the workplace, in social settings, but it is also within ourselves – with how we think. It is the longstanding battle of the left brain and right brain. The left side of the brain is known to be logical, analytical, and objective (hello technical directors!) while the right side is known to be intuitive, thoughtful, and subjective (creative thinkers). But the one thing both sides of our brains have in common is Problem Solving. Even though both sides are radically different, there is a common thread there. No one wants to be a code monkey or a pixel pusher. We want to solve problems, and do great work.</p>
<p dir="ltr" style="padding-left: 60px;"><img alt="" src="https://lh3.googleusercontent.com/Qw9xPk_1Ao-OXe8S2SSW0Qe78766iau8sXfgAQxvW46rljL5hG-ejlInKKnFFLPpSslgx0TYxyN-kS2lJ_T6l6tupzlWf0uaethYaGfFDW1yKzFWo1QLqx0X" width="652px;" height="484px;" /></p>
<p><strong>Check Out the rest of the Post on <a href="http://torquemag.io/be-the-unicorn/">Torque</a></strong></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/07/29/sara-cannons-be-the-unicorn/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"Pete Mall to talk about the YouTube Upload Widget Live today at 10am PDT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://ran.ge/2013/07/10/pete-mall-to-talk-about-the-youtube-upload-widget/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:84:"http://ran.ge/2013/07/10/pete-mall-to-talk-about-the-youtube-upload-widget/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 10 Jul 2013 16:26:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:5:"Range";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=3996";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:351:"Join Ran.ge and YouTube this week to find out more about our open source upload widget for WordPress. We will show you how it works and walk you through the source code for the widget itself. Tune in to @YouTube Developers Live at 10am PDT https://developers.google.com/live/shows/38132276-6003 &#160; update: check out the video of the show [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:840:"<p>Join Ran.ge and YouTube this week to find out more about our open source upload widget for WordPress. We will show you how it works and walk you through the source code for the widget itself.</p>
<p>Tune in to @YouTube Developers Live at 10am PDT</p>
<p><a title="Range and YouTube" href="https://developers.google.com/live/shows/38132276-6003">https://developers.google.com/live/shows/38132276-6003</a></p>
<p>&nbsp;</p>
<p><em>update: check out the video of the show &amp; demo below!</em></p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/LXYwLo4fkIA?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:80:"http://ran.ge/2013/07/10/pete-mall-to-talk-about-the-youtube-upload-widget/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"Sara Cannon to Speak in Montreal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/04/17/sara-cannon-to-speak-in-montreal/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:67:"http://ran.ge/2013/04/17/sara-cannon-to-speak-in-montreal/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 17 Apr 2013 18:01:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:25:"http://dev.ran.ge/?p=3916";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:320:"I can&#8217;t tell you how excited I am to be able to speak at the Montreal WordPress Developers Meetup and the Montreal Girl Geeks! On Tuesday, April 23: The Future of UI: How Mobile Design is Shaping the Web Web design is not an interactive brochure anymore. Smart mobile devices have forever changed the way [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4096:"<p>I can&#8217;t tell you how excited I am to be able to speak at the <a href="http://wpmtl.org/2013/04/montreal-wordpress-developer_meetup-april-23rd-2013/">Montreal WordPress Developers Meetup</a> and the <a href="http://montrealgirlgeeks.com/2013/04/18/april-event/">Montreal Girl Geeks</a>!</p>
<hr />
<p><img class="size-full wp-image-3918 alignleft" alt="wcmtl-developer-meetup-facebook-size-179px" src="http://s1.ran.ge/content/uploads/2013/05/wcmtl-developer-meetup-facebook-size-179px.png" width="179" height="126" />On Tuesday, April 23:</p>
<p><strong>The Future of UI: How Mobile Design is Shaping the Web</strong></p>
<p>Web design is not an interactive brochure anymore. Smart mobile devices have forever changed the way we think and interact with websites. Now you have to consider an array of things you didn’t have to worry about before, such as HiDPI graphics, UI/UX patterns, touch target sizes, gestures, and managing expectations. All the while not losing track of what’s important: Content.</p>
<p>We’re going to discuss the influence of mobile on design, trends, and implementation methods, as well as how touch is changing our lives. As designers and developers, we can benefit from learning about how mobile is changing the way we interact with websites, and what that means for the future of UI. <a href="http://wpmtl.org/2013/04/montreal-wordpress-developer_meetup-april-23rd-2013/" target="_blank" rel="nofollow nofollow">http://wpmtl.org/2013/04/montreal-wordpress-developer_meetup-april-23rd-2013/</a></p>
<p><iframe style="border: 1px solid #CCC; border-width: 1px 1px 0; margin-bottom: 5px;" src="http://www.slideshare.net/slideshow/embed_code/19911427" height="356" width="427" allowfullscreen="" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></p>
<div style="margin-bottom: 5px;"><strong> <a title="The Future of UI - How Mobile Design is Shaping The Web 2" href="http://www.slideshare.net/saracannon/the-future-of-ui-how-mobile-design-is-shaping-the-web-2" target="_blank">The Future of UI &#8211; How Mobile Design is Shaping The Web 2</a> </strong> from <strong><a href="http://www.slideshare.net/saracannon" target="_blank">Sara Cannon</a></strong></div>
<hr />
<p><img class="alignleft size-full wp-image-3917" alt="MTLGGbarcode1-300x300" src="http://s1.ran.ge/content/uploads/2013/05/MTLGGbarcode1-300x300.jpg" width="300" height="300" />On Thursday, April 25:</p>
<p><strong>Font Swoon!</strong></p>
<p>Times New Roman. Helvetica. Comic Sans. We’ve all got fonts we love to use or love to hate. Typography is one of those topics that’s easy to overlook, but when you bring it up, everyone has an opinion. Sara’s talk is not just for designers spending hours debating on the slant of a curly-quote or the perfect sans serif – it’s for anyone who’s ever typed, read, or even just stared at the screen or page. Because typography is essential to how we read, consume, convey, and process the written word and it’s BFF, design.</p>
<p>Let’s take our relationship with web typography to the next level and crush on the latest fonts, check out some awesome CSS3 implementations, and find incredible inspiration for interaction, refinement and our next dates with negative space. Come fall head over heels with us at Font Swoon! <a href="http://montrealgirlgeeks.com/2013/04/18/april-event/" target="_blank" rel="nofollow nofollow">http://montrealgirlgeeks.com/2013/04/18/april-event/</a></p>
<p><iframe style="border: 1px solid #CCC; border-width: 1px 1px 0; margin-bottom: 5px;" src="http://www.slideshare.net/slideshow/embed_code/19994942" height="356" width="427" allowfullscreen="" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></p>
<div style="margin-bottom: 5px;"><strong> <a title="Font swoon" href="http://www.slideshare.net/saracannon/font-swoon" target="_blank">Font swoon</a> </strong> from <strong><a href="http://www.slideshare.net/saracannon" target="_blank">Sara Cannon</a></strong></div>
<p>If you are in Montreal, come on out &#8211; I&#8217;d love to meet you!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:63:"http://ran.ge/2013/04/17/sara-cannon-to-speak-in-montreal/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Join Me at WordSesh Tonight!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ran.ge/2013/04/12/join-me-at-wordsesh-tonight/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:62:"http://ran.ge/2013/04/12/join-me-at-wordsesh-tonight/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 12 Apr 2013 21:24:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"be the unicorn";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"WordSesh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=1844";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:365:"Tonight I&#8217;m going to be speaking at the first ever WordSesh online WordPress Conference! WordSesh is a day of live WordPress presentations from all over the world streamed live, and it&#8217;s free! Tune in at 4UTC 12am EST (midnight tonight!) to join me in my talk &#8220;Be the Unicorn.&#8221; I&#8217;m really looking forward to hearing all the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:519:"<p>Tonight I&#8217;m going to be speaking at the first ever <a href="http://wordsesh.org/">WordSesh</a> online WordPress Conference! WordSesh is a day of live WordPress presentations from all over the world streamed live, and it&#8217;s free! Tune in at 4UTC 12am EST (midnight tonight!) to join me in my talk &#8220;Be the Unicorn.&#8221;</p>
<p>I&#8217;m really looking forward to hearing all the other awesome speakers! If you can&#8217;t make it, don&#8217;t worry, all the sessions will be recorded. #WPYall</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/04/12/join-me-at-wordsesh-tonight/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"Re-thinking WordPress Post Format UI An Exercise ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://ran.ge/2013/04/11/re-thinking-wordpress-post-format-ui-an-exercise/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:83:"http://ran.ge/2013/04/11/re-thinking-wordpress-post-format-ui-an-exercise/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 11 Apr 2013 07:30:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:7:"UI / UX";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"WordPress Core";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=1771";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"Post Formats are slated to drop in 3.6 and are currently in Beta. I love how WordPress is standardizing formats so that when you change your theme, the content format and metadata associated with that format is preserved. This opens up new doors and possibilities for bloggers who want a unique look without having to customize [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:12714:"<div id="attachment_1818" style="width: 1034px" class="wp-caption alignleft"><a href="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach.jpg"><img class="size-large wp-image-1818" alt="Post Format Modal" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach-1024x698.jpg" width="1024" height="698" /></a><p class="wp-caption-text">Post Format Modal</p></div>
<p>Post Formats are slated to drop in 3.6 and are currently in Beta. I love how WordPress is standardizing formats so that when you change your theme, the content format and metadata associated with that format is preserved. This opens up new doors and possibilities for bloggers who want a unique look without having to customize a category display.</p>
<p><img class="alignleft size-full wp-image-1772" alt="3.5 post formats enabled" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.51.52-AM.png" width="299" height="253" />Post formats are currently in WordPress 3.5 but are just in a tiny modal box to you right (if your theme has them enabled)</p>
<p>They don&#8217;t change the metaboxes for use with the content (aka make a &#8220;Video URL&#8221; field when selecting) but in 3.6 they will &#8211; which is exciting.</p>
<p>There has been lots of discussion and wireframes about the Post Formats UI and user testing&#8230; I decided to do an exercise that might address some of the pain points of the current UI&#8217;s iteration.</p>
<h2>Researching Other similar tools</h2>
<h2><strong>WordPress.com New Dash</strong></h2>
<p>Taking a look at the simplified blogging tool for WordPress.com &#8211; they deal with Post Formats right away.</p>
<div id="attachment_1776" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1776" alt="WordPress.com New Dash - Screen right after you hit &quot;New Post&quot;" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.58.11-AM-1024x438.png" width="1024" height="438" /><p class="wp-caption-text">WordPress.com New Dash &#8211; Screen right after you hit &#8220;New Post&#8221;</p></div>
<div id="attachment_1775" style="width: 1068px" class="wp-caption alignleft"><img class=" wp-image-1775" alt="WordPress.com New Dash - Post Page" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.58.22-AM.png" width="1058" height="567" /><p class="wp-caption-text">WordPress.com New Dash &#8211; Post Page :: a simplified version of the one in the admin</p></div>
<div id="attachment_1774" style="width: 1061px" class="wp-caption alignleft"><img class=" wp-image-1774" alt="WordPress.com New Dash - Screen" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.58.36-AM.png" width="1051" height="553" /><p class="wp-caption-text">WordPress.com New Dash &#8211; Video Post Selected<br />note the customized interface just for uploading photos</p></div>
<h2><strong style="font-size: 1.2em;"><strong style="font-size: 1.2em;">Tumblr</strong></strong></h2>
<div id="attachment_1784" style="width: 954px" class="wp-caption alignleft"><img class="size-full wp-image-1784" alt="Tumblr.com Dashboard - choose the format from the icons across before posting" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.16.27-AM.png" width="944" height="453" /><p class="wp-caption-text">Tumblr.com Dashboard &#8211; choose the format from the icons across before posting</p></div>
<div id="attachment_1783" style="width: 977px" class="wp-caption alignleft"><img class="size-full wp-image-1783" alt="tumblr.com Post a Video Screen" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.16.41-AM.png" width="967" height="482" /><p class="wp-caption-text">tumblr.com Post a Video Screen</p></div>
<p>The glaring similarities between WordPress.com New Dash and Tumblr is that they are 1) making a post format decision  before they get to the editor and 2) the editor is only giving them the modals and upload buttons that they need. If we think about #1 philosophically from a UX point of view &#8211; the formats are action-centric. They are not passively opening up the post editor then wondering what they are going to post &#8211; they are forced to make a decision, an action, and therefore the UI they are given is tailored to this decision making for a better UX.</p>
<p>Neither Tumblr or New Dash have a way of changing the post formats &#8211; which I think is good because they would lose all the data that they put in there to the custom modals. (more on this later)</p>
<h2><strong style="font-size: 1.2em;"></strong>Current 3.6 Iteration in Beta</h2>
<div id="attachment_1786" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1786" alt="WordPress.com 3.6 Beta" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.28.04-AM-1024x414.png" width="1024" height="414" /><p class="wp-caption-text">WordPress.com 3.6 Beta</p></div>
<p>The current iteration of the new Post-Formats UI that is now in 3.6 Beta has icons for each of the 10 formats spread across the top of the post editor. They are currently passive button-like selectors with a label to the right. Dave Martin ran some user tests on the current UI and the results were <a href="http://make.wordpress.org/ui/2013/04/09/post-formats-usability-test-round-4/">not good</a>.</p>
<p>I decided to do some action-centric decision-first based UI exercises to explore some options.</p>
<h2>Decision Based Approach &#8211; Working Within the Current Menu System</h2>
<p>The first exercise is one based on just using the current menu system. It turns out that it *could* in theory work &#8211; but in reality there are just way too many post formats.</p>
<div id="attachment_1790" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1790" alt="Action-Centric Dashboard Menu" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-h-copy-1024x695.jpg" width="1024" height="695" /><p class="wp-caption-text">Action-Centric Dashboard Menu</p></div>
<div id="attachment_1792" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1792" alt="Post Page - Sub Menu" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-p-copy-1024x698.jpg" width="1024" height="698" /><p class="wp-caption-text">Post Page &#8211; Sub Menu</p></div>
<p>Basically in this iteration, we make the choice in the menu and then the post screen will have just what you need.</p>
<div id="attachment_1794" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1794" alt="Video Post Format - note the simplified interface, the title changes to include the word &quot;video&quot; in it , and the labels are inside the boxes" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-video-post-1024x699.jpg" width="1024" height="699" /><p class="wp-caption-text">Video Post Format &#8211; note the simplified interface, the title changes to include the word &#8220;video&#8221; in it , and the labels are inside the boxes</p></div>
<h2>Changing Formats</h2>
<p>In the above screenshot &#8211; there is a way to change formats (unlike new dash or tumblr.) It is in the publish meta box. This is a more passive-switch than an in-your-face one which is important, as someone would have to completely change their mind to use it. It also falls under the same importance as the other items in the publish meta box.</p>
<div id="attachment_1799" style="width: 307px" class="wp-caption aligncenter"><img class="size-large wp-image-1799 " alt="Post Format Switching" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.57.34-AM.png" width="297" height="270" /><p class="wp-caption-text">Post Format Switching</p></div>
<div id="attachment_1797" style="width: 306px" class="wp-caption aligncenter"><img class="size-full wp-image-1797 " alt="Post Format Switching - drop down option" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.59.19-AM.png" width="296" height="313" /><p class="wp-caption-text">Post Format Switching &#8211; drop down option</p></div>
<div id="attachment_1798" style="width: 304px" class="wp-caption aligncenter"><img class="size-full wp-image-1798 " alt="Post Format Switching - radio button option" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.58.42-AM.png" width="294" height="541" /><p class="wp-caption-text">Post Format Switching &#8211; radio button option</p></div>
<p>Exploring both radio buttons for switching or a drop-down &#8211; That meta box currently uses both as a standard, but I think I prefer the radio simply because the icons are visual cues.</p>
<h2>Explorations outside of the current navigation pattern</h2>
<p>So, seeing that the navigation above is a bit cramped - I decided to explore in-page and modal decision patterns.</p>
<div id="attachment_1803" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1803" alt="In Page decision with post editor greyed out. Icons will go away and the &quot;switching&quot; will be in the siidebar like above" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-i-copy-1024x698.jpg" width="1024" height="698" /><p class="wp-caption-text">In Page decision with post editor greyed out. Icons will go away and the &#8220;switching&#8221; will be in the sidebar like above</p></div>
<div id="attachment_1804" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1804" alt="not greyed out but post editor fades in after decision" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-i-copy1-1024x698.jpg" width="1024" height="698" /><p class="wp-caption-text">not greyed out but post editor fades in after decision</p></div>
<div id="attachment_1805" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1805" alt="without labels - cursor rollover changes page title" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-in-page-approach-with-cursor-rollover-1024x355.jpg" width="1024" height="355" /><p class="wp-caption-text">without labels &#8211; cursor rollover changes page title</p></div>
<p>While all this is interesting &#8211; I&#8217;m not sure if it feels quite right as it is outside of the typical WordPress interface, but could be explored further.</p>
<h2>Modal Window</h2>
<p>So our natural progression here is to try out a modal. Usually I&#8217;m not-a-fan of modals at all. They tend to be disruptive. After the new media editor launched last release, its made me re-think modals. Lightbox was so terrible and slow &#8211; but using a modal for this action kind of makes sense as you can be on any page and receive it before hitting the post editor, without another page load or coming from any add post action. (think top nav bar add new)</p>
<div id="attachment_1818" style="width: 1034px" class="wp-caption alignleft"><a href="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach.jpg"><img class="size-large wp-image-1818" alt="Post Format Modal" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach-1024x698.jpg" width="1024" height="698" /></a><p class="wp-caption-text">Post Format Modal</p></div>
<p>At this point, I am leaning towards a fast modal with a few caveats. 1) you can turn the modal off if you don&#8217;t use other formats as much and just want to use the passive switcher. 2) you can turn all post formats off from within core settings to override what your theme set. 3) you can filter list tables by format (like you do categories.) The last two I think this should be an option regardless of the approach.</p>
<p>However, that being said, I know we are in Beta for 3.6 and the modal window approach might be a bit out of reach for this release. If I were to have a #2 I would say the greyed out post edit UI with the larger icons. approach might be viable (after the decision is made, the icons go away, post editor fades in, and the format switching is in the publish meta box.)</p>
<p>In conclusion, I hope to get some conversation going and hear what everyone else thinks so that we can make WordPress amazing together.</p>
<p><strong><em>update: if anyone else wants to tinker, here are my thrown together photoshop files etc s.sar.ac/071P0S3r2H2Q</em></strong></p>
<p>Update 2: Mark Jaquith is asking for feedback on the Make UI Blog <a href="http://make.wordpress.org/ui/2013/04/11/saracannon-has-posted-her-take-on-a-new/">http://make.wordpress.org/ui/2013/04/11/saracannon-has-posted-her-take-on-a-new/</a></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:79:"http://ran.ge/2013/04/11/re-thinking-wordpress-post-format-ui-an-exercise/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"29";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"Globalnews.ca Data Migration The MSSQL to MySQL Delima";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://ran.ge/2013/03/26/globalnews-ca-data-migration-and-the-mssql-to-mysql-delima/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:93:"http://ran.ge/2013/03/26/globalnews-ca-data-migration-and-the-mssql-to-mysql-delima/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Mar 2013 16:19:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Migration";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:5:"MSSQL";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:5:"MySQL";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:25:"http://dev.ran.ge/?p=3844";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:350:"Recently Globalnews.ca made the move to WordPress and we were tasked with migrating all their data from their existing custom MSSQL-based environment to the new WordPress environment hosted with WordPress.com VIP. We have a normal process for this kind of thing, and it goes something like this: Create a local WordPress install and get rid [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Aaron D. Campbell";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3593:"<p>Recently Globalnews.ca made the move to WordPress and we were tasked with migrating all their data from their existing custom MSSQL-based environment to the new WordPress environment hosted with <a href="http://vip.wordpress.com/">WordPress.com VIP</a>. We have a normal process for this kind of thing, and it goes something like this:</p>
<ol>
<li>Create a local WordPress install and get rid of the default posts, comments, and meta data.</li>
<li>Put the clients old data into tables in the same WordPress database.</li>
<li>Write a script that pulls the data from the old tables and uses a combination of WordPress functions and direct database queries to put it into the WordPress install.</li>
<li>Check the data and if it&#8217;s not quite right blast out the posts, comments, and meta data and go back to step 3.</li>
<li>When the data is exactly what we want in WordPress we use <a href="http://wp-cli.org/">wp-cli</a> to export the data in <abbr title="WordPress eXtended Rss">WXR</abbr> format, and submit those files to WordPress.com VIP.</li>
</ol>
<p>It sounds pretty straight forward, and usually it is, with the most difficult part obviously being the script that imports the data from the old tables into WordPress. Not this time however. This time the most difficult part turned out to be step 2, putting the clients data into the same database as WordPress. The problem was that the conversion from MSSQL to MySQL was no trivial matter.</p>
<p>Often you can use <a href="http://www.mysql.com/products/workbench/">MySQL Workbench</a> to migrate data from MSSQL to MySQL, so we started by spinning up a Windows cloud server with MSSQL. We imported the data into an MSSQL database on this new server, and then we installed MySQL and the MySQL Workbench. Due to the large amount of data being converted, we ran into memory issues several times and had to resize the cloud server, but once the memory issues were under control we realized that MySQL Workbench simply could not migrate many of the tables that we needed.</p>
<p>After many hours of digging and research, I finally found the problem. It turns out that there were a couple data types that were causing things to choke. In our case that was mostly limited to nvarchar and ntext. Why? Well because MSSQL doesn&#8217;t actually support UTF-8. What?! I know&#8230;I was surprised too, but it seems MSSQL doesn&#8217;t support the standard in character encoding. Instead it has nvarchar and ntext that don&#8217;t store as UTF-8 but offer similar output in a classic Microsoft-proprietary way.</p>
<p>I was able to work around this limitation by creating duplicate tables for each table that contained one of these field types, using nvarchar in place of varchar and ntext in place of text. Then I ran queries to select the data from the old tables and insert it into these newly created tables.</p>
<pre class="brush: sql; title: ; notranslate">
CREATE TABLE [dbo].[ImportFixed](
	[RowNum] [bigint] NULL,
	[post_title] [nvarchar](200) NOT NULL, -- Previously varchar
	[content_html] [ntext] NULL -- Previously text
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
----------------------
INSERT INTO [import].[dbo].[ImportFixed](
	[RowNum],
	[post_title],
	[content_html]
)
SELECT
	[RowNum],
	[post_title],
	[content_html]
FROM [import].[dbo].[Import]
GO
</pre>
<p>This then allowed MySQL Workbench to properly handle the encoding during it&#8217;s migration from MSSQL to MySQL. Even once the process is known it&#8217;s tedious and time consuming at best, but it seems to be very reliable and stable.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:89:"http://ran.ge/2013/03/26/globalnews-ca-data-migration-and-the-mssql-to-mysql-delima/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"Sara Cannon to Speak at WordCamp Atlanta on Saturday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://ran.ge/2013/03/12/sara-cannon-to-speak-at-wordcamp-atlanta-on-saturday/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:87:"http://ran.ge/2013/03/12/sara-cannon-to-speak-at-wordcamp-atlanta-on-saturday/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Mar 2013 22:57:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:16:"WordCamp Atlanta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=1684";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:317:"I&#8217;m so excited to be speaking at WordCamp Atlanta this Saturday! If you haven&#8217;t got tickets, its already SOLD OUT at 450 people. WOW. If you&#8217;re in the South and you missed it, be sure to keep an eye on 2013.Birmingham.WordCamp.org for a date announcement &#38; early tickets for late summer. &#160;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:657:"<p><a href="http://2013.Atlanta.WordCamp.org"><img class="size-full wp-image-3744 alignleft" alt="WCBadge2013-Speaker" src="http://sara-cannon.com/wp-content/uploads/2013/03/WCBadge2013-Speaker.jpg" width="150" height="150" /></a>I&#8217;m so excited to be speaking at <a href="http://2013.atlanta.wordcamp.org/">WordCamp Atlanta</a> this Saturday! If you haven&#8217;t got tickets, its already SOLD OUT at 450 people. WOW. If you&#8217;re in the South and you missed it, be sure to keep an eye on <a href="http://2013.Birmingham.WordCamp.org">2013.Birmingham.WordCamp.org</a> for a date announcement &amp; early tickets for late summer.</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:83:"http://ran.ge/2013/03/12/sara-cannon-to-speak-at-wordcamp-atlanta-on-saturday/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:19:"http://ran.ge/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 10 Nov 2013 01:40:53 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";a:2:{i:0;s:15:"Accept-Encoding";i:1;s:6:"Cookie";}s:13:"cache-control";s:28:"max-age=251, must-revalidate";s:12:"x-powered-by";s:21:"PHP/5.4.19-1~dotdeb.0";s:10:"x-pingback";s:27:"http://ran.ge/wp/xmlrpc.php";s:13:"last-modified";s:29:"Fri, 01 Nov 2013 22:18:21 GMT";s:4:"etag";s:34:""21a61201f9b1815ebe86a76fe4ece902"";s:4:"node";s:20:"web11.dfw.wphost.com";}s:5:"build";s:14:"20130908064941";}', 'no') ; 
INSERT INTO `wp_options` VALUES (462, '_transient_timeout_feed_mod_77fa140e07ce53fe8c87136636f83d72', '1384094555', 'no') ; 
INSERT INTO `wp_options` VALUES (463, '_transient_feed_mod_77fa140e07ce53fe8c87136636f83d72', '1384051355', 'no') ; 
INSERT INTO `wp_options` VALUES (466, '_transient_timeout_dash_de3249c4736ad3bd2cd29147c4a0d43e', '1384094555', 'no') ; 
INSERT INTO `wp_options` VALUES (467, '_transient_dash_de3249c4736ad3bd2cd29147c4a0d43e', '<h4>Most Popular</h4>
<h5><a href=\'http://wordpress.org/plugins/wordfence/\'>Wordfence Security</a></h5>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=wordfence&amp;_wpnonce=7c48be407f&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Wordfence Security\'>Install</a>)</span>
<p>Wordfence Security is a free enterprise class security plugin that includes a firewall, virus scanning, real-time traffic with geolocation and more.</p>
<h4>Newest Plugins</h4>
<h5><a href=\'http://wordpress.org/plugins/memit-widget/\'>memit.com Widget</a></h5>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=memit-widget&amp;_wpnonce=a099c94572&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'memit.com Widget\'>Install</a>)</span>
<p>Integration of the memit.com Widget to the WordPress blog page.</p>
', 'no') ; 
INSERT INTO `wp_options` VALUES (460, '_transient_timeout_feed_77fa140e07ce53fe8c87136636f83d72', '1384094555', 'no') ; 
INSERT INTO `wp_options` VALUES (461, '_transient_feed_77fa140e07ce53fe8c87136636f83d72', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/plugins/browse/new/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Nov 2013 01:37:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:10:"CP Support";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wordpress.org/plugins/cp-support/#post-60337";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 23:37:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60337@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"CP Support a wordpress plugin for tracking tickets and bugs etc";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"casserlyprogramming";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"WP Athletics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wp-athletics/#post-60289";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 06 Nov 2013 15:12:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60289@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:144:"Allow registered users to log, compare and analyse their athletic results. A club records page will then summarise athletes data for all to see.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"conormccauley";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"Profit Button";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/profit-button/#post-60069";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 31 Oct 2013 08:14:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60069@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:135:"Floating button for you site or blog, which can give you opportunity to make a survey, show ads and collect some statistics about user.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"hintsolutions";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Beautiful Social Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/plugins/beautiful-social-widget/#post-60308";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 13:20:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60308@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:77:"This plugin add the widget through which you can link to your social profile.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Sudeep Acharya";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"memit.com Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/memit-widget/#post-60351";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 17:48:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60351@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:63:"Integration of the memit.com Widget to the WordPress blog page.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"oleglark";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"Get terms name__like";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/plugins/get-terms-name-like/#post-60347";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 16:05:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60347@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:116:"Get the terms by name that begin with the &#34;name__like&#34; parameter used by the WordPress function get_terms().";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"keesiemeijer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Presseportal Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/presseportal/#post-60311";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 13:48:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60311@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:89:"This plugin loads the latest news from German Pressportal and displays them in your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"MisterK";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"Pods Auto-Display";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/pods-auto-display/#post-60305";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 11:18:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60305@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:68:"Automatically displays Pods custom fields below custom post content.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"tysonlt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"FREE TO ALL MEMBERSHIP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/free-to-all-membership/#post-60343";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 10:24:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60343@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Free to all Membership helps you to do fully functional membership site. So don&#039;t wait, use it now.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"tirthankar modak";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"Howdy-2-Aloha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/howdy-2-aloha/#post-60316";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 17:11:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60316@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:81:"Replaces the standard WordPress &#039;Howdy&#039; welcome with &#039;Aloha&#039;.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"khushapps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"Redirectify";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/redirectify/#post-60301";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 03:39:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60301@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:23:"Custom Redirect Options";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"codeify";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:23:"Content Runner Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/plugins/content-runner-importer/#post-60375";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 20:56:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60375@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:108:"Content Runner Importer allows for the quick and easy transfer of
contentrunner.com articles into WordPress.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"crunner";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Digicution Simple Twitter Feed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/plugins/digicution-simple-twitter-feed/#post-60345";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 11:40:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60345@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:119:"This plugin provides a simple list of Tweets from a users screen name for usage within your Wordpress Blog or Template.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"digicution";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Tekserve Single Post Shortcode";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/plugins/tekserve-single-post-shortcode/#post-60355";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 19:23:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60355@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:125:"Wordpress plugin to create a shortcode and widget for showing the title, post info, excerpt, and thumbnail for a single post.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"bangerkuwranger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Amazon Scraper";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/amazon-scraper/#post-60298";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 02:18:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60298@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"Pull data from any Amazon product page using only the product&#039;s ASIN number and automatically embed your amazon affiliate link.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Submone";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:41:"http://wordpress.org/plugins/rss/view/new";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:7:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 10 Nov 2013 01:40:57 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Thu, 07 Nov 2013 23:37:03 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130908064941";}', 'no') ; 
INSERT INTO `wp_options` VALUES (450, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1384094554', 'no') ; 
INSERT INTO `wp_options` VALUES (451, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 29 Oct 2013 21:04:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/?v=3.8-alpha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.7.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/10/wordpress-3-7-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2013/10/wordpress-3-7-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 29 Oct 2013 21:04:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2745";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:371:"WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including: Images with captions no longer appear broken in the visual editor. Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org. Avoid fatal errors with certain plugins that were incorrectly calling some [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1594:"<p>WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including:</p>
<ul>
<li>Images with captions no longer appear broken in the visual editor.</li>
<li>Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org.</li>
<li>Avoid fatal errors with certain plugins that were incorrectly calling some WordPress functions too early.</li>
<li>Fix hierarchical sorting in get_pages(), exclusions in wp_list_categories(), and in_category() when called with empty values.</li>
<li>Fix a warning that may occur in certain setups while performing a search, and a few other notices.</li>
</ul>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.7.1">list of tickets</a> and <a href="http://core.trac.wordpress.org/log/branches/3.7?stop_rev=25914&amp;rev=25986">the changelog</a>.</p>
<p>If you are one of the <a href="http://wordpress.org/download/counter/">nearly two million</a> already running WordPress 3.7, we will start rolling out the all-new <a href="http://wordpress.org/news/2013/10/basie/">automatic background updates</a> for WordPress 3.7.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.7.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p><em>Just a few fixes<br />
Your new update attitude:<br />
Zero clicks given</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/10/wordpress-3-7-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.7 “Basie”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2013/10/basie/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2013/10/basie/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Oct 2013 22:35:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2736";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:357:"Version 3.7 of WordPress, named &#8220;Basie&#8221; in honor of Count Basie, is available for download or update in your WordPress dashboard. This release features some of the most important architectural updates we&#8217;ve made to date. Here are the big ones: Updates while you sleep: With WordPress 3.7, you don&#8217;t have to lift a finger to [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:17229:"<p>Version 3.7 of WordPress, named &#8220;Basie&#8221; in honor of <a href="http://en.wikipedia.org/wiki/Count_basie">Count Basie</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features some of the most important architectural updates we&#8217;ve made to date. Here are the big ones:</p>
<ul>
<li><strong>Updates while you sleep</strong>: With WordPress 3.7, you don&#8217;t have to lift a finger to apply maintenance and security updates. Most sites are now able to automatically apply these updates in the background. The update process also has been made even more reliable and secure, with dozens of new checks and safeguards.</li>
<li><strong>Stronger password recommendations</strong>: Your password is your site&#8217;s first line of defense. It&#8217;s best to create passwords that are complex, long, and unique. To that end, our password meter has been updated in WordPress 3.7 to recognize common mistakes that can weaken your password: dates, names, keyboard patterns (123456789), and even pop culture references.</li>
<li><strong>Better global support</strong>: Localized versions of WordPress will receive faster and more complete translations. WordPress 3.7 adds support for automatically installing the right language files and keeping them up to date, a boon for the many millions who use WordPress in a language other than English.</li>
</ul>
<p>For developers there are lots of options around how to control the new updates feature, including allowing it to handle major upgrades as well as minor ones, more sophisticated date query support, and multisite improvements. As always, if you&#8217;re hungry for more <a href="http://codex.wordpress.org/Version_3.7">dive into the Codex</a> or browse the <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.7">over 400 closed tickets on Trac</a>.</p>
<h3>A New Wave</h3>
<p>This release was led by Andrew Nacin, backed up by Dion Hulse and Jon Cave. This is our first release using the new plugin-first development process, with a much shorter timeframe than in the past. (3.6 was released in August.) The 3.8 release, due in December, will continue this plugin-led development cycle that gives much more autonomy to plugin leads and allows us to decouple feature development from a release. You can follow this grand experiment, and what we&#8217;re learning from it, <a href="http://make.wordpress.org/core/">on the make/core blog</a>. There are 211 contributors with props in this release:</p>
<p><a href="http://profiles.wordpress.org/technosailor">Aaron Brazell</a>, <a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/aaronholbrook">Aaron Holbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/adamsilverstein">adamsilverstein</a>, <a href="http://profiles.wordpress.org/ahoereth">Alexander Hoereth</a>, <a href="http://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/andg">andg</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/andrewspittle">Andrew Spittle</a>, <a href="http://profiles.wordpress.org/askapache">askapache</a>, <a href="http://profiles.wordpress.org/atimmer">atimmer</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/beaulebens">Beau Lebens</a>, <a href="http://profiles.wordpress.org/benmoody">ben.moody</a>, <a href="http://profiles.wordpress.org/bhengh">Ben Miller</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bftrick">BFTrick</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy (bananastalktome)</a>, <a href="http://profiles.wordpress.org/bmb">bmb</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brianhogg">brianhogg</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/carldanley">Carl Danley</a>, <a href="http://profiles.wordpress.org/charlesclarkson">CharlesClarkson</a>, <a href="http://profiles.wordpress.org/chipbennett">Chip Bennett</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisrudzki">Chris Rudzki</a>, <a href="http://profiles.wordpress.org/aeg0125">coderaaron</a>, <a href="http://profiles.wordpress.org/coenjacobs">Coen Jacobs</a>, <a href="http://profiles.wordpress.org/crrobi01">Colin Robinson</a>, <a href="http://profiles.wordpress.org/andreasnrb">cyonite</a>, <a href="http://profiles.wordpress.org/daankortenbach">Daan Kortenbach</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/convissor">Daniel Convissor</a>, <a href="http://profiles.wordpress.org/dartiss">dartiss</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/csixty4">Dave Ross</a>, <a href="http://profiles.wordpress.org/davidjlaietta">David Laietta</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/dllh">dllh</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling (ocean90)</a>, <a href="http://profiles.wordpress.org/dpash">dpash</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/dzver">dzver</a>, <a href="http://profiles.wordpress.org/cais">Edward Caissie</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/faishal">faishal</a>, <a href="http://profiles.wordpress.org/faison">Faison</a>, <a href="http://profiles.wordpress.org/foofy">Foofy</a>, <a href="http://profiles.wordpress.org/fjarrett">Frankie Jarrett</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/gayadesign">Gaya Kessler</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/gizburdt">Gizburdt</a>, <a href="http://profiles.wordpress.org/goldenapples">goldenapples</a>, <a href="http://profiles.wordpress.org/gradyetc">gradyetc</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/webord">Gustavo Bordoni</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/creativeinfusion">itinerant</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jakubtyrcha">jakub.tyrcha</a>, <a href="http://profiles.wordpress.org/jamescollins">James Collins</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/buffler">Jeremy Buller</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="http://profiles.wordpress.org/johnnyb">John Beales</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn (johnbillion)</a>, <a href="http://profiles.wordpress.org/johnafish">John Fish</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/jchristopher">Jonathan Christopher</a>, <a href="http://profiles.wordpress.org/desrosj">Jonathan Desrosiers</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jonlynch">Jon Lynch</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/josephscott">Joseph Scott</a>, <a href="http://profiles.wordpress.org/betzster">Josh Betz</a>, <a href="http://profiles.wordpress.org/devesine">Justin de Vesine</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/ketwaroo">Ketwaroo</a>, <a href="http://profiles.wordpress.org/kevinb">kevinB</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/koopersmith">koopersmith</a>, <a href="http://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis (leewillis77)</a>, <a href="http://profiles.wordpress.org/lessbloat">lessbloat</a>, <a href="http://profiles.wordpress.org/layotte">Lew Ayotte</a>, <a href="http://profiles.wordpress.org/lgedeon">Luke Gedeon</a>, <a href="http://profiles.wordpress.org/iworks">Marcin Pietrzak</a>, <a href="http://profiles.wordpress.org/cimmo">Marco Cimmino</a>, <a href="http://profiles.wordpress.org/marco_teethgrinder">Marco Galasso</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markmcwilliams">Mark McWilliams</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/tw2113">Michael Beckwith</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/usermrpapa">Mr Papa</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/naomicbush">Naomi</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/natejacobs">NateJacobs</a>, <a href="http://profiles.wordpress.org/nathanrice">nathanrice</a>, <a href="http://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="http://profiles.wordpress.org/nickdaugherty">Nick Daugherty</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nickmomrik">Nick Momrik</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="http://profiles.wordpress.org/noahsilverstein">noahsilverstein</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nukaga">nukaga</a>, <a href="http://profiles.wordpress.org/nullvariable">nullvariable</a>, <a href="http://profiles.wordpress.org/butuzov">Oleg Butuzov</a>, <a href="http://profiles.wordpress.org/paolal">Paolo Belcastro</a>, <a href="http://profiles.wordpress.org/xparham">Parham</a>, <a href="http://profiles.wordpress.org/pbiron">Paul Biron</a>, <a href="http://profiles.wordpress.org/pauldewouters">Paul de Wouters</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/peterjaap">peterjaap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/plocha">plocha</a>, <a href="http://profiles.wordpress.org/pollett">Pollett</a>, <a href="http://profiles.wordpress.org/ptahdunbar">Ptah Dunbar</a>, <a href="http://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="http://profiles.wordpress.org/rasheed">Rasheed Bydousi</a>, <a href="http://profiles.wordpress.org/raybernard">RayBernard</a>, <a href="http://profiles.wordpress.org/rboren">rboren</a>, <a href="http://profiles.wordpress.org/greuben">Reuben Gunday</a>, <a href="http://profiles.wordpress.org/rfair404">rfair404</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/r3df">Rick Radko</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/wpmuguru">Ron Rennick</a>, <a href="http://profiles.wordpress.org/rpattillo">rpattillo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/hotchkissconsulting">Sam Hotchkiss</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/scottsweb">scottsweb</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/scruffian">scruffian</a>, <a href="http://profiles.wordpress.org/tenpura">Seisuke Kuraishi (tenpura)</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sillybean">Stephanie Leary</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar (@netweb)</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/strangerstudios">strangerstudios</a>, <a href="http://profiles.wordpress.org/sweetie089">sweetie089</a>, <a href="http://profiles.wordpress.org/swissspidy">swissspidy</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tmtoy">Takuma Morikawa</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tivnet">tivnet</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/toscho">toscho</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/sorich87">Ulrich Sossou</a>, <a href="http://profiles.wordpress.org/vericgar">vericgar</a>, <a href="http://profiles.wordpress.org/vinod-dalvi">Vinod Dalvi</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wikicms">wikicms</a>, <a href="http://profiles.wordpress.org/willnorris">Will Norris</a>, <a href="http://profiles.wordpress.org/wojtekszkutnik">Wojtek Szkutnik</a>, <a href="http://profiles.wordpress.org/wycks">wycks</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p>Enjoy what may be one of your last few manual updates. See you soon for version 3.8!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2013/10/basie/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.7 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Oct 2013 00:05:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2729";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:417:"The second release candidate of WordPress 3.7 is now available for testing! Those of you already testing WordPress 3.7 will be updated automatically to RC2. (Nice.) If you&#8217;d like to start testing, there&#8217;s no time like the present! Try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”) or download the release candidate here (zip). Please post to the Alpha/Beta [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1183:"<p>The second release candidate of WordPress 3.7 is now available for testing!</p>
<p>Those of you already testing WordPress 3.7 will be updated automatically to RC2. (<em>Nice.</em>) If you&#8217;d like to start testing, there&#8217;s no time like the present! Try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”) or <a href="http://wordpress.org/wordpress-3.7-RC2.zip">download the release candidate here</a> (zip). Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a> if you think you&#8217;ve found a bug, and if any known issues are raised, you’ll be able to <a href="http://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>Developers, please test your plugins and themes against WordPress 3.7. If there is a compatibility issue, let us know as soon as possible so we can deal with it before the final release.</p>
<p>For more on WordPress 3.7, check out the <a href="http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/">announcement post for Release Candidate 1</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Upcoming WordCamps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Oct 2013 19:25:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2723";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:368:"WordCamps are casual, locally-organized conferences that celebrate everything related to WordPress, and are a great opportunity to meet other WordPress users and professionals in your community. This has been a great year for WordCamps &#8212; there have been 56 so far in more than 20 countries, and there another 15 on the calendar before the year&#8217;s [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"Jen Mylo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3584:"<p><a href="http://central.wordcamp.org/">WordCamps</a> are casual, locally-organized conferences that celebrate everything related to WordPress, and are a great opportunity to meet other WordPress users and professionals in your community. This has been a great year for WordCamps &#8212; there have been 56 so far in more than 20 countries, and there another 15 on the calendar before the year&#8217;s over. If there&#8217;s one near you, check it out! In addition to getting to know your local WordPress community, most WordCamps attract some traveling visitors a well, giving you the chance to meet contributors to the WordPress open source project and <a href="http://make.wordpress.org/">get involved</a> yourself.</p>
<p>Here are the WordCamps on the schedule for the rest of this year.</p>
<p>October 25-27: <strong><a href="http://2013.boston.wordcamp.org/">WordCamp Boston</a></strong>, Boston, MA, USA<br />
October 25-26: <strong><a href="http://2013.malaga.wordcamp.org/">WordCamp Malaga</a></strong>, Spain<br />
October 26: <strong><a href="http://2013.nepal.wordcamp.org/">WordCamp Nepal</a></strong>, Kathmandu, Nepal<br />
October 26: <strong><a href="http://2013.sofia.wordcamp.org/">WordCamp Sofia</a></strong>, Bulgaria<br />
November 7: <strong><a href="http://2013.capetown.wordcamp.org/">WordCamp Cape Town</a></strong>, South Africa<br />
November 9: <strong><a href="http://2013.porto.wordcamp.org/">WordCamp Porto</a></strong>, Portugal<br />
November 9-10: <strong><a href="http://2013.kenya.wordcamp.org/">WordCamp Kenya</a></strong>, Nairobi, Kenya<br />
November 15: <strong><a href="http://2013.edmonton.wordcamp.org/">WordCamp Edmonton</a></strong>, AB, Canada<br />
November 16-17: <strong><a href="http://2013.orlando.wordcamp.org/">WordCamp Orlando</a></strong>, FL, USA<br />
November 16: <strong><a href="http://2013.denver.wordcamp.org/">WordCamp Denver</a></strong>, CO, USA<br />
November 23-24: <strong><a href="http://2013.london.wordcamp.org/">WordCamp London</a></strong>, UK<br />
November 23-24: <strong><a href="http://2013.raleigh.wordcamp.org/">WordCamp Raleigh</a></strong>, NC, USA<br />
November 23: <strong><a href="http://2013.saopaulo.wordcamp.org/">WordCamp São Paulo</a></strong>, Brazil<br />
December 14: <strong><a href="http://2013.vegas.wordcamp.org/">WordCamp Las Vegas</a></strong>, NV, USA<br />
December 14-15: <strong><a href="http://2013.sevilla.wordcamp.org/">WordCamp Sevilla</a></strong>, Spain</p>
<p>No WordCamps on this list in your area? Not to worry! There are thriving <a href="http://wordpress.meetup.com/">WordPress meetups</a> all over the world where you can meet like-minded people, and we maintain a library of <a href="http://wordpress.tv/category/wordcamptv/">WordCamp videos</a> at <a href="http://wordpress.tv/">WordPress.tv</a>.</p>
<h3>Get Involved</h3>
<ul>
<li>If you&#8217;re interested in organizing a WordCamp in your area, check out our <a href="http://plan.wordcamp.org/">WordCamp planning</a> site.</li>
<li>If you&#8217;re interested in <a href="http://make.wordpress.org/community/meetup-interest-form/">starting a WordPress meetup</a> in your area, let us know and we can set up a group on meetup.com for you.</li>
<li>And speaking of WordCamp videos, we&#8217;ve recently enabled volunteer-generated subtitles/closed captioning of the videos on WordPress.tv to make them more accessible. Interested in helping? Check out the <a href="http://wordpress.tv/using-amara-org-to-caption-or-subtitle-a-wordpress-tv-video/">WordPress.tv subtitling instructions</a>.</li>
</ul>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.7 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Oct 2013 19:52:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2718";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:331:"The first release candidate for WordPress 3.7 is now available! In RC 1, we&#8217;ve made some adjustments to the update process to make it more reliable than ever. We hope to ship WordPress 3.7 next week, but we need your help to get there. If you haven’t tested 3.7 yet, there’s no time like the present. (Please, [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2237:"<p>The first release candidate for WordPress 3.7 is now available!</p>
<p>In RC 1, we&#8217;ve made some adjustments to the update process to make it more reliable than ever. We hope to ship WordPress 3.7 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.7 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>WordPress 3.7 introduces <strong>automatic background updates</strong> for security and minor releases (like updating from 3.7 to 3.7.1). These are really easy to test  — RC 1 will update every 12 hours or so to the latest development version, and then email you the results. (You may get two emails: one for debugging, and one all users of 3.7 will receive.) If something went wrong, you can report it.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="http://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>To test WordPress 3.7 RC1, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.7-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what&#8217;s new in WordPress 3.7, visit the awesome About screen in your dashboard (<strong><img alt="" src="http://core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png" /> → About</strong> in the toolbar). There, you can also see if your install is eligible for background updates. WordPress won’t automatically update, for example, if you’re using version control like Subversion or Git.</p>
<p><strong>Developers,</strong> please test your plugins and themes against WordPress 3.7, so that if there is a compatibility issue, we can figure it out before the final release. Make sure you post any issues to the support forums.</p>
<p><em>WordPress three seven</em><br />
<em>A self-updating engine</em><br />
<em>Lies beneath the hood</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.7 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/10/wordpress-3-7-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/10/wordpress-3-7-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Oct 2013 21:28:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2706";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:357:"WordPress 3.7 Beta 2 is now available for download and testing. This is software still in development, so we don&#8217;t recommend that you run it on a production site. This has been a quiet beta period. We&#8217;re hoping to get some more testers for automatic background updates, which will occur for security and minor releases (like updating [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2108:"<p>WordPress 3.7 Beta 2 is now available for download and testing. This is software still in development, so we don&#8217;t recommend that you run it on a production site.</p>
<p>This has been a quiet beta period. We&#8217;re hoping to get some more testers for <strong>automatic background updates</strong>, which will occur for security and minor releases (like updating from 3.7 to 3.7.1). It&#8217;s really easy to test this, as Beta 2 will update each day to the latest development version and then email you the results. If something goes wrong, you can report it — it&#8217;s that simple. To get the beta, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="http://wordpress.org/wordpress-3.7-beta2.zip">download the beta here</a> (zip). Check out <strong>Dashboard → Updates</strong> to see if your install is eligible for background updates. WordPress won&#8217;t update if, for example, you&#8217;re using version control like SVN or Git.</p>
<p>For more of what&#8217;s new in version 3.7, <a title="WordPress 3.7 Beta 1" href="http://wordpress.org/news/2013/09/wordpress-3-7-beta-1/">check out the Beta 1 blog post</a>. In Beta 2, we further increased the stability of background updates and also added about 50 bug fixes, including a fix for Internet Explorer 11 in the visual editor.</p>
<p>If you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.7">everything we’ve fixed</a>.</p>
<p>Happy testing!</p>
<p><em>Beta 2 released<br />
Dotting i&#8217;s and crossing t&#8217;s</em><br />
<em>Expect RC next</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/10/wordpress-3-7-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.7 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/09/wordpress-3-7-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/09/wordpress-3-7-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 28 Sep 2013 07:25:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2688";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:339:"I&#8217;m pleased to announce the availability of WordPress 3.7 Beta 1. For WordPress 3.7 we decided to shorten the development cycle and focus on a few key improvements. We plan to release the final product in October, and then follow it in December with a jam-packed WordPress 3.8 release, which is already in development. Some [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3684:"<p>I&#8217;m pleased to announce the availability of WordPress 3.7 Beta 1.</p>
<p>For WordPress 3.7 we decided to shorten the development cycle and focus on a few key improvements. We plan to release the final product in October, and then follow it in December with a jam-packed WordPress 3.8 release, which is already in development. Some of the best stuff in WordPress 3.7 is subtle &#8212; by design! So let&#8217;s walk through what we&#8217;d love for you to test, just in time for the weekend.</p>
<p><strong>Automatic, background updates.</strong> 3.7 Beta 1 will keep itself updated. That&#8217;s right &#8212; you&#8217;ll be updated each night to the newest development build, and eventually to Beta 2. We&#8217;re working to provide as many installs as possible with fast updates to security releases of WordPress &#8212; and you can help us test by just installing Beta 1 on your server and seeing how it works!</p>
<p>When you go to <strong>Dashboard → Updates</strong>, you&#8217;ll see a note letting you know whether your install is working for automatic updates. There are a few situations where WordPress can&#8217;t reliably and securely update itself. But if it can, you&#8217;ll get an email (sent to the &#8216;Admin Email&#8217; on the General Settings page) after each update letting you know what worked and what didn&#8217;t. If it worked, great! If something failed, the email will suggest you make a post in the support forums or create a bug report.</p>
<p>Here are some other things you should test out:</p>
<ul>
<li>If you&#8217;re running <strong>WordPress in another language</strong>, we&#8217;ll automatically download any available translations for official WordPress importers and the default themes. (More to come here.)</li>
<li>Our <strong>password meter</strong> got a whole lot better, thanks to Dropbox&#8217;s <a href="https://tech.dropbox.com/2012/04/zxcvbn-realistic-password-strength-estimation/">zxcvbn</a> library. Again, subtle but effective. Strong passwords are very important!</li>
<li><strong>Search results</strong> are now <a href="http://core.trac.wordpress.org/changeset/25632">ordered by relevance</a>, rather than just by date. When your keywords match post titles and not just content, they&#8217;ll be pushed to the top.</li>
<li>Developers should check out the new <strong>advanced date queries</strong> in <code>WP_Query</code>. (<a href="http://core.trac.wordpress.org/ticket/18694">#18694</a>)</li>
</ul>
<p><strong>This software is still in development</strong>, so we don&#8217;t recommend you run it on a production site. I&#8217;d suggest setting up a test site just to play with the new version. To test WordPress 3.7, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="http://wordpress.org/wordpress-3.7-beta1.zip">download the beta here</a> (zip).</p>
<p>As always, <strong>if you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.7">everything we’ve fixed</a> so far.</p>
<p>Happy testing!</p>
<p><em>WordPress three seven<br />
Saves your weary hand a click<br />
Updates while you sleep</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/09/wordpress-3-7-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress 3.6.1 Maintenance and Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/09/wordpress-3-6-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2013/09/wordpress-3-6-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Sep 2013 20:48:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2675";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:353:"After nearly 7 million downloads of WordPress 3.6, we are pleased to announce the availability of version 3.6.1. This maintenance release fixes 13 bugs in version 3.6, which was a very smooth release. WordPress 3.6.1 is also a security release for all previous WordPress versions and we strongly encourage you to update your sites immediately. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2033:"<p>After <a href="http://wordpress.org/download/counter/">nearly 7 million downloads</a> of WordPress 3.6, we are pleased to announce the availability of version 3.6.1. This maintenance release <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.6.1">fixes 13 bugs</a> in version 3.6, which was a very smooth release.</p>
<p><strong>WordPress 3.6.1 is also a security release for all previous WordPress versions</strong> and we strongly encourage you to update your sites immediately. It addresses three issues fixed by the WordPress security team:</p>
<ul>
<li>Block unsafe PHP unserialization that could occur in limited situations and setups, which can lead to remote code execution. Reported by <a href="http://vagosec.org/" rel="nofollow">Tom Van Goethem</a>.</li>
<li>Prevent a user with an Author role, using a specially crafted request, from being able to create a post &#8220;written by&#8221; another user. Reported by <a href="http://anakornk.wordpress.com/" rel="nofollow">Anakorn Kyavatanakij</a>.</li>
<li>Fix insufficient input validation that could result in redirecting or leading a user to another website. Reported by Dave Cummo, a Northrup Grumman subcontractor for the <a href="http://www.cdc.gov/" rel="nofollow">U.S. Centers for Disease Control and Prevention</a>.</li>
</ul>
<p>Additionally, we&#8217;ve adjusted security restrictions around file uploads to mitigate the potential for cross-site scripting.</p>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these issues directly to our security team. For more information on the changes, see the <a href="http://codex.wordpress.org/Version_3.6.1">release notes</a> or consult <a href="http://core.trac.wordpress.org/log/branches/3.6?stop_rev=24972&amp;rev=25345">the list of changes</a>.</p>
<p><a href="http://wordpress.org/wordpress-3.6.1.zip">Download WordPress 3.6.1</a> or update now from the Dashboard → Updates menu in your site&#8217;s admin area.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/09/wordpress-3-6-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.6 “Oscar”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2013/08/oscar/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2013/08/oscar/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Aug 2013 21:43:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2661";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:368:"The latest and greatest WordPress, version 3.6, is now live to the world and includes a beautiful new blog-centric theme, bullet-proof autosave and post locking, a revamped revision browser, native support for audio and video embeds, and improved integrations with Spotify, Rdio, and SoundCloud. Here&#8217;s a video that shows off some of the features using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:18626:"<p>The latest and greatest WordPress, version 3.6, is now <a href="http://wordpress.org/download/">live to the world</a> and includes a beautiful new blog-centric theme, bullet-proof autosave and post locking, a revamped revision browser, native support for audio and video embeds, and improved integrations with Spotify, Rdio, and SoundCloud. Here&#8217;s a video that shows off some of the features using our cast of professional actors:</p>
<div id="v-UmhwbWJH-1" class="video-player"><embed id="v-UmhwbWJH-1-video" src="http://s0.videopress.com/player.swf?v=1.03&amp;guid=UmhwbWJH&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" title="Introducing WordPress 3.6 &quot;Oscar&quot;" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<p>We&#8217;re calling this release &#8220;Oscar&#8221; in honor of the great jazz pianist <a href="http://en.wikipedia.org/wiki/Oscar_Peterson">Oscar Peterson</a>. Here&#8217;s a bit more about some of the new features, which you can also find on the about page in your dashboard after you upgrade.</p>
<h3>User Features</h3>
<p><img class="alignright" alt="" src="https://wordpress.org/images/core/3.6/twentythirteen.png" width="300" /></p>
<ul>
<li>The <strong>new Twenty Thirteen theme</strong> inspired by modern art puts focus on your content with a colorful, single-column design made for media-rich blogging.</li>
<li><strong>Revamped Revisions</strong> save every change and the new interface allows you to scroll easily through changes to see line-by-line who changed what and when.</li>
<li><strong>Post Locking</strong> and <strong>Augmented Autosave</strong> will especially be a boon to sites where more than a single author is working on a post. Each author now has their own autosave stream, which stores things locally as well as on the server (so much harder to lose something) and there&#8217;s an interface for taking over editing of a post, as demonstrated beautifully by our bearded buddies in the video above.</li>
<li><strong>Built-in HTML5 media player</strong> for native audio and video embeds with no reliance on external services.</li>
<li>The <strong>Menu Editor</strong> is now much easier to understand and use.</li>
</ul>
<h3>Developer features</h3>
<ul>
<li>A new audio/video API gives you access to metadata like ID3 tags.</li>
<li>You can now choose HTML5 markup for things like comment and search forms, and comment lists.</li>
<li>Better filters for how revisions work, so you can store a different amount of history for different post types.</li>
<li>Tons more <a href="http://codex.wordpress.org/Version_3.6">listed on the Codex</a>, and of course you can always <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.6">browse the over 700 closed tickets</a>.</li>
</ul>
<h3>The Band</h3>
<p>This release was led by <a href="http://markjaquith.com/">Mark Jaquith</a> and <a href="http://geekreprieve.com/">Aaron Campbell</a>, and included contributions from the following fine folks. Pull up some Oscar Peterson on your music service of choice, or vinyl if you have it, and check out some of their profiles:</p>
<p><a href="http://profiles.wordpress.org/technosailor">Aaron Brazell</a>, <a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/aaronholbrook">Aaron Holbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/adamsilverstein">adamsilverstein</a>, <a href="http://profiles.wordpress.org/akted">AK Ted</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/alexkingorg">Alex King</a>, <a href="http://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="http://profiles.wordpress.org/momo360modena">Amaury Balmer</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/anatolbroder">Anatol Broder</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/andrewryno">Andrew Ryno</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/gorgoglionemeister">Antonio</a>, <a href="http://profiles.wordpress.org/apimlott">apimlott</a>, <a href="http://profiles.wordpress.org/awellis13">awellis13</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/beaulebens">Beau Lebens</a>, <a href="http://profiles.wordpress.org/belloswan">BelloSwan</a>, <a href="http://profiles.wordpress.org/bilalcoder">bilalcoder</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy (bananastalktome)</a>, <a href="http://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="http://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brianlayman">Brian Layman</a>, <a href="http://profiles.wordpress.org/beezeee">Brian Zeligson</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/chmac">Callum Macdonald</a>, <a href="http://profiles.wordpress.org/carldanley">Carl Danley</a>, <a href="http://profiles.wordpress.org/caspie">Caspie</a>, <a href="http://profiles.wordpress.org/charlestonsw">Charleston Software Associates</a>, <a href="http://profiles.wordpress.org/cheeserolls">cheeserolls</a>, <a href="http://profiles.wordpress.org/chipbennett">Chip Bennett</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/cochran">Christopher Cochran</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/chriswallace">Chris Wallace</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/crazycoders">crazycoders</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/mzaweb">Daniel Dvorkin (MZAWeb)</a>, <a href="http://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="http://profiles.wordpress.org/daniloercoli">daniloercoli</a>, <a href="http://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="http://profiles.wordpress.org/csixty4">Dave Ross</a>, <a href="http://profiles.wordpress.org/dfavor">David Favor</a>, <a href="http://profiles.wordpress.org/jdtrower">David Trower</a>, <a href="http://profiles.wordpress.org/davidwilliamson">David Williamson</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/dllh">dllh</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling (ocean90)</a>, <a href="http://profiles.wordpress.org/dovyp">dovyp</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes (DrewAPicture)</a>, <a href="http://profiles.wordpress.org/dvarga">dvarga</a>, <a href="http://profiles.wordpress.org/cais">Edward Caissie</a>, <a href="http://profiles.wordpress.org/elfin">elfin</a>, <a href="http://profiles.wordpress.org/empireoflight">Empireoflight</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/faishal">faishal</a>, <a href="http://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/f-j-kaiser">Franz Josef Kaiser</a>, <a href="http://profiles.wordpress.org/fstop">FStop</a>, <a href="http://profiles.wordpress.org/mintindeed">Gabriel Koen</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/gcorne">gcorne</a>, <a href="http://profiles.wordpress.org/geertdd">GeertDD</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/gish">gish</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hbanken">hbanken</a>, <a href="http://profiles.wordpress.org/hebbet">hebbet</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/helgatheviking">helgatheviking</a>, <a href="http://profiles.wordpress.org/hirozed">hirozed</a>, <a href="http://profiles.wordpress.org/hurtige">hurtige</a>, <a href="http://profiles.wordpress.org/hypertextranch">hypertextranch</a>, <a href="http://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/jakub">jakub</a>, <a href="http://profiles.wordpress.org/h4ck3rm1k3">James Michael DuPont</a>, <a href="http://profiles.wordpress.org/jbutkus">jbutkus</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jerrysarcastic">Jerry Bates (JerrySarcastic)</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (Jayjdk)</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/joen">Joen Asmussen</a>, <a href="http://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn (johnbillion)</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/desrosj">Jonathan Desrosiers</a>, <a href="http://profiles.wordpress.org/jonbishop">Jon Bishop</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jcastaneda">Jose Castaneda</a>, <a href="http://profiles.wordpress.org/josephscott">Joseph Scott</a>, <a href="http://profiles.wordpress.org/jvisick77">Josh Visick</a>, <a href="http://profiles.wordpress.org/jrbeilke">jrbeilke</a>, <a href="http://profiles.wordpress.org/jrf">jrf</a>, <a href="http://profiles.wordpress.org/devesine">Justin de Vesine</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">kadamwhite</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/karmatosed">karmatosed</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/keoshi">keoshi</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/ktdreyer">ktdreyer</a>, <a href="http://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="http://profiles.wordpress.org/kwight">kwight</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis (leewillis77)</a>, <a href="http://profiles.wordpress.org/lessbloat">lessbloat</a>, <a href="http://profiles.wordpress.org/settle">Mantas Malcius</a>, <a href="http://profiles.wordpress.org/maor">Maor Chasen</a>, <a href="http://profiles.wordpress.org/macbrink">Marcel Brinkkemper</a>, <a href="http://profiles.wordpress.org/marcuspope">MarcusPope</a>, <a href="http://profiles.wordpress.org/mark-k">Mark-k</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markmcwilliams">Mark McWilliams</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="http://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="http://profiles.wordpress.org/matthewruddy">MatthewRuddy</a>, <a href="http://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/mgibbs189">mgibbs189</a>, <a href="http://profiles.wordpress.org/fanquake">Michael</a>, <a href="http://profiles.wordpress.org/mdawaffe">Michael Adams (mdawaffe)</a>, <a href="http://profiles.wordpress.org/tw2113">Michael Beckwith</a>, <a href="http://profiles.wordpress.org/mfields">Michael Fields</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/najamelan">najamelan</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="http://profiles.wordpress.org/nickdaugherty">Nick Daugherty</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/ninnypants">ninnypants</a>, <a href="http://profiles.wordpress.org/norcross">norcross</a>, <a href="http://profiles.wordpress.org/paradiseporridge">ParadisePorridge</a>, <a href="http://profiles.wordpress.org/pauldewouters">Paul</a>, <a href="http://profiles.wordpress.org/pdclark">Paul Clark</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/petemall">Pete Mall</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/phill_brown">Phill Brown</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/pollett">Pollett</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/programmin">programmin</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="http://profiles.wordpress.org/redpixelstudios">redpixelstudios</a>, <a href="http://profiles.wordpress.org/reidburke">reidburke</a>, <a href="http://profiles.wordpress.org/retlehs">retlehs</a>, <a href="http://profiles.wordpress.org/greuben">Reuben Gunday</a>, <a href="http://profiles.wordpress.org/rlerdorf">rlerdorf</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/roulandf">roulandf</a>, <a href="http://profiles.wordpress.org/rovo89">rovo89</a>, <a href="http://profiles.wordpress.org/ryanduff">Ryan Duff</a>, <a href="http://profiles.wordpress.org/ryanhellyer">Ryan Hellyer</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/zeo">Safirul Alredha</a>, <a href="http://profiles.wordpress.org/saracannon">sara cannon</a>, <a href="http://profiles.wordpress.org/scholesmafia">scholesmafia</a>, <a href="http://profiles.wordpress.org/sc0ttkclark">Scott Kingsley Clark</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/tenpura">Seisuke Kuraishi (tenpura)</a>, <a href="http://profiles.wordpress.org/sergej">Sergej</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/sim">Simon Hampel</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/slene">slene</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/srinig">SriniG</a>, <a href="http://profiles.wordpress.org/stephenh1988">Stephen Harris</a>, <a href="http://profiles.wordpress.org/storkontheroof">storkontheroof</a>, <a href="http://profiles.wordpress.org/sunnyratilal">Sunny Ratilal</a>, <a href="http://profiles.wordpress.org/sweetie089">sweetie089</a>, <a href="http://profiles.wordpress.org/tar">Tar</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/thomasvanderbeek">Thomas van der Beek</a>, <a href="http://profiles.wordpress.org/n7studios">Tim Carr</a>, <a href="http://profiles.wordpress.org/tjsingleton">tjsingleton</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/toscho">toscho</a>, <a href="http://profiles.wordpress.org/taupecat">Tracy Rotton</a>, <a href="http://profiles.wordpress.org/travishoffman">TravisHoffman</a>, <a href="http://profiles.wordpress.org/uuf6429">uuf6429</a>, <a href="http://profiles.wordpress.org/lightningspirit">Vitor Carvalho</a>, <a href="http://profiles.wordpress.org/wojtek">wojtek</a>, <a href="http://profiles.wordpress.org/wpewill">wpewill</a>, <a href="http://profiles.wordpress.org/wraithkenny">WraithKenny</a>, <a href="http://profiles.wordpress.org/wycks">wycks</a>, <a href="http://profiles.wordpress.org/xibe">Xavier Borderie</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/thelastcicada">Zachary Brown</a>, <a href="http://profiles.wordpress.org/tollmanz">Zack Tollman</a>, <a href="http://profiles.wordpress.org/zekeweeks">zekeweeks</a>, <a href="http://profiles.wordpress.org/ziegenberg">ziegenberg</a>, and <a href="http://profiles.wordpress.org/viniciusmassuchetto">viniciusmassuchetto</a>.</p>
<p>Time to upgrade!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2013/08/oscar/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.6 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2013/07/wordpress-3-6-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2013/07/wordpress-3-6-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Jul 2013 07:25:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2649";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:341:"The second release candidate for WordPress 3.6 is now available for download and testing. We&#8217;re down to only a few remaining issues, and the final release should be available in a matter of days. In RC2, we&#8217;ve tightened up some aspects of revisions, autosave, and the media player, and fixed some bugs that were spotted [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Mark Jaquith";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1325:"<p>The second release candidate for WordPress 3.6 is now available for download and testing.</p>
<p>We&#8217;re down to only a few remaining issues, and the final release should be available in a matter of days. In RC2, we&#8217;ve tightened up some aspects of revisions, autosave, and the media player, and fixed some bugs that were spotted in RC1. Please test this release candidate as much as you can, so we can deliver a smooth final release!</p>
<p><strong>Think you&#8217;ve found a bug?</strong> Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>.</p>
<p><strong>Developers,</strong> please continue to test your plugins and themes, so that if there is a compatibility issue, we can figure it out before the final release. You can find our <a href="http://core.trac.wordpress.org/report/6">list of known issues here</a>.</p>
<p>To test WordPress 3.6, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="http://wordpress.org/wordpress-3.6-RC2.zip">download the release candidate here (zip)</a>.</p>
<p><em>Revisions so smooth</em><br />
<em>We autosave your changes</em><br />
<em>Data loss begone!</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2013/07/wordpress-3-6-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 10 Nov 2013 01:40:55 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Tue, 29 Oct 2013 21:04:59 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130908064941";}', 'no') ; 
INSERT INTO `wp_options` VALUES (243, 'hmbkp_schedule_default-1', 'a:3:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (244, 'hmbkp_schedule_default-2', 'a:3:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (245, 'hmbkp_plugin_version', '2.3.3', 'yes') ; 
INSERT INTO `wp_options` VALUES (246, '_transient_timeout_hmbkp_plugin_data', '1379074710', 'no') ; 
INSERT INTO `wp_options` VALUES (247, '_transient_hmbkp_plugin_data', 'O:8:"stdClass":19:{s:4:"name";s:15:"BackUpWordPress";s:4:"slug";s:15:"backupwordpress";s:7:"version";s:5:"2.3.3";s:6:"author";s:47:"<a href="http://hmn.md/">Human Made Limited</a>";s:14:"author_profile";s:37:"http://profiles.wordpress.org/willmot";s:12:"contributors";a:7:{s:9:"humanmade";s:39:"http://profiles.wordpress.org/humanmade";s:7:"willmot";s:37:"http://profiles.wordpress.org/willmot";s:13:"pauldewouters";s:43:"http://profiles.wordpress.org/pauldewouters";s:8:"joehoyle";s:38:"http://profiles.wordpress.org/joehoyle";s:7:"mattheu";s:37:"http://profiles.wordpress.org/mattheu";s:9:"tcrsavage";s:39:"http://profiles.wordpress.org/tcrsavage";s:8:"cuvelier";s:0:"";}s:8:"requires";s:5:"3.3.3";s:6:"tested";s:5:"3.6.1";s:13:"compatibility";a:26:{s:5:"2.8.5";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:3:"2.9";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"2.9.1";a:1:{s:5:"0.4.5";a:3:{i:0;i:67;i:1;i:6;i:2;i:4;}}s:5:"2.9.2";a:1:{s:5:"0.4.5";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}}s:3:"3.0";a:2:{s:5:"0.4.5";a:3:{i:0;i:80;i:1;i:5;i:2;i:4;}s:5:"1.1.4";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:5:"3.0.1";a:1:{s:5:"0.4.5";a:3:{i:0;i:56;i:1;i:9;i:2;i:5;}}s:5:"3.0.2";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.0.3";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.0.4";a:2:{s:5:"0.4.5";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"1.1.4";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.0.5";a:1:{s:5:"0.4.5";a:3:{i:0;i:33;i:1;i:3;i:2;i:1;}}s:3:"3.1";a:9:{s:5:"0.4.5";a:3:{i:0;i:57;i:1;i:7;i:2;i:4;}s:5:"1.0.3";a:3:{i:0;i:50;i:1;i:2;i:2;i:1;}s:5:"1.0.4";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.0.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:3:"1.1";a:3:{i:0;i:50;i:1;i:2;i:2;i:1;}s:5:"1.1.1";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.1.2";a:3:{i:0;i:50;i:1;i:2;i:2;i:1;}s:5:"1.1.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.1.4";a:3:{i:0;i:50;i:1;i:4;i:2;i:2;}}s:5:"3.1.1";a:1:{s:5:"1.1.4";a:3:{i:0;i:90;i:1;i:10;i:2;i:9;}}s:5:"3.1.2";a:3:{s:5:"1.1.4";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:3:"1.2";a:3:{i:0;i:100;i:1;i:5;i:2;i:5;}s:3:"1.3";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}}s:5:"3.1.3";a:2:{s:3:"1.3";a:3:{i:0;i:67;i:1;i:6;i:2;i:4;}s:5:"1.3.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}}s:3:"3.2";a:3:{s:5:"0.1.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.3.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"1.6.2";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:5:"3.2.1";a:15:{s:5:"1.3.1";a:3:{i:0;i:67;i:1;i:9;i:2;i:6;}s:5:"1.3.2";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}s:8:"1.4 beta";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.4.1";a:3:{i:0;i:100;i:1;i:7;i:2;i:7;}s:3:"1.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.5.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:3:"1.6";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}s:5:"1.6.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.4";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.8";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.1.3";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}s:5:"2.2.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.2.4";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:3:"3.3";a:6:{s:3:"1.5";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"1.5.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"1.6.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.7";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.3.1";a:7:{s:5:"1.6.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.3";a:3:{i:0;i:80;i:1;i:5;i:2;i:4;}s:5:"1.6.4";a:3:{i:0;i:100;i:1;i:9;i:2;i:9;}s:5:"1.6.5";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"1.6.6";a:3:{i:0;i:63;i:1;i:19;i:2;i:12;}s:5:"1.6.7";a:3:{i:0;i:100;i:1;i:8;i:2;i:8;}}s:5:"3.3.2";a:3:{s:5:"1.6.7";a:3:{i:0;i:100;i:1;i:5;i:2;i:5;}s:5:"1.6.8";a:3:{i:0;i:92;i:1;i:12;i:2;i:11;}s:5:"2.1.3";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:3:"3.4";a:1:{s:5:"1.6.8";a:3:{i:0;i:100;i:1;i:6;i:2;i:6;}}s:5:"3.4.1";a:2:{s:5:"1.6.8";a:3:{i:0;i:100;i:1;i:12;i:2;i:12;}s:5:"1.6.9";a:3:{i:0;i:100;i:1;i:6;i:2;i:6;}}s:5:"3.4.2";a:9:{s:5:"1.6.9";a:3:{i:0;i:83;i:1;i:6;i:2;i:5;}s:8:"2.0 RC 1";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}s:5:"2.0.1";a:3:{i:0;i:45;i:1;i:22;i:2;i:10;}s:5:"2.0.3";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"2.0.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.0.6";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}s:3:"2.1";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.1.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"2.1.3";a:3:{i:0;i:83;i:1;i:6;i:2;i:5;}}s:3:"3.5";a:1:{s:5:"2.1.3";a:3:{i:0;i:100;i:1;i:7;i:2;i:7;}}s:5:"3.5.1";a:5:{s:5:"2.1.3";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}s:3:"2.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.2.1";a:3:{i:0;i:100;i:1;i:10;i:2;i:10;}s:5:"2.2.4";a:3:{i:0;i:94;i:1;i:16;i:2;i:15;}s:3:"2.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.5.2";a:3:{s:5:"2.2.4";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:3:"2.3";a:3:{i:0;i:57;i:1;i:14;i:2;i:8;}s:5:"2.3.3";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}}s:3:"3.6";a:2:{s:3:"2.3";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"2.3.3";a:3:{i:0;i:50;i:1;i:6;i:2;i:3;}}}s:6:"rating";d:90.19999999999998863131622783839702606201171875;s:11:"num_ratings";i:496;s:10:"downloaded";i:693869;s:12:"last_updated";s:10:"2013-08-22";s:5:"added";s:10:"2007-09-02";s:8:"homepage";s:30:"http://hmn.md/backupwordpress/";s:8:"sections";a:5:{s:11:"description";s:1284:"<p>BackUpWordPress will back up your entire site including your database and all your files on a schedule that suits you.</p>

<h4>Features</h4>

<ul>
<li>Manage multiple schedules.</li>
<li>Super simple to use, no setup required.</li>
<li>Uses <code>zip</code> and <code>mysqldump</code> for faster back ups if they are available.</li>
<li>Works in low memory, "shared host" environments.</li>
<li>Option to have each backup file emailed to you.</li>
<li>Works on Linux &#38; Windows Server.</li>
<li>Exclude files and folders from your back ups.</li>
<li>Good support should you need help.</li>
<li>Translations for Spanish, German, Chinese, Romanian, Russian, Serbian, Lithuanian, Italian, Czech, Dutch, French, Basque.</li>
</ul>

<h4>Help develop this plugin</h4>

<p>The BackUpWordPress plugin is hosted GitHub, if you want to help out with development or testing then head over to <a href="https://github.com/humanmade/backupwordpress/" rel="nofollow">https://github.com/humanmade/backupwordpress/</a>.</p>

<h4>Translations</h4>

<p>We\'d also love help translating the plugin into more languages, if you can help then please contact <a href="mailto:support@hmn.md">support@hmn.md</a> or visit <a href="http://translate.hmn.md/" rel="nofollow">http://translate.hmn.md/</a>.</p>";s:12:"installation";s:460:"<ol>
<li>Install BackUpWordPress either via the WordPress.org plugin directory, or by uploading the files to your server.</li>
<li>Activate the plugin.</li>
<li>Sit back and relax safe in the knowledge that your whole site will be backed up every day.</li>
</ol>

<p>The plugin will try to use the <code>mysqldump</code> and <code>zip</code> commands via shell if they are available, using these will greatly improve the time it takes to back up your site.</p>";s:11:"screenshots";s:765:"<ol>
	<li>
		<img class=\'screenshot\' src=\'http://s-plugins.wordpress.org/backupwordpress/assets/screenshot-1.png?rev=602026\' alt=\'backupwordpress screenshot 1\' />
		<p>Manage multiple schedules.</p>
	</li>
	<li>
		<img class=\'screenshot\' src=\'http://s-plugins.wordpress.org/backupwordpress/assets/screenshot-2.png?rev=602026\' alt=\'backupwordpress screenshot 2\' />
		<p>Choose your schedule, backup type, number of backups to keep and whether to recieve a notification email.</p>
	</li>
	<li>
		<img class=\'screenshot\' src=\'http://s-plugins.wordpress.org/backupwordpress/assets/screenshot-3.png?rev=602026\' alt=\'backupwordpress screenshot 3\' />
		<p>Easily manage exclude rules and see exactly which files are included and excluded from your backup.</p>
	</li>
</ol>";s:9:"changelog";s:27461:"<h4>2.3.3</h4>

<ul>
<li>Add missing colorbox assets</li>
</ul>

<h4>2.3.2</h4>

<ul>
<li>Correct version number</li>
</ul>

<h4>2.3.1</h4>

<ul>
<li>Fix a PHP strict error</li>
<li>Save and close as separate buttons</li>
<li>Fix bug that caused multiple notification emails</li>
<li>Fixes typo in database option name</li>
<li>Updated translations</li>
<li>Improve PHP docblocks</li>
<li>Make schedules class a singleton</li>
<li>Exclude popular backup plugin folders by default</li>
<li>Exclude version control folders by default</li>
<li>Fix broken localisation</li>
</ul>

<h4>2.3</h4>

<ul>
<li>Replace Fancybox with Colorbox as Fancybox 2 isn\'t GPL compatible.</li>
<li>Use the correct <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant consistently in the help section.</li>
<li>Correct filename for some mis-named translation files.</li>
<li>Show the total estimated disk space a schedule could take up (max backups * estimated site size).</li>
<li>Fix a typo (your -&#62; you\'re).</li>
<li>Use the new time Constants and define backwords compatible ones for &#62; than 3.5.</li>
<li>Play nice with custom cron intervals.</li>
<li>Main plugin file is now <code>backupwordpress.php</code> for consistency.</li>
<li>Add Paul De Wouters (<code>pauldewouters</code>) as a contributor, welcome Paul!</li>
<li>Don\'t remove non-backup files from custom backup paths.</li>
<li>Fix a regression where setting a custom path which didn\'t exist could cause you to lose existing backups.</li>
<li>When moving paths only move backup files.</li>
<li>Make some untranslatable strings translatable.</li>
<li>Don\'t allow a single schedule to run in multiple threads at once, should finally fix edge case issues where some load balancer / proxies were causing multiple backups per run.</li>
<li>Only highlight the <code>HMBKP_SCHEDULE_TIME</code> constant in help if it\'s not the default value.</li>
<li>Remove help text for deprecated <code>HMBKP_EMAIL</code>.</li>
<li>Default to allways specificing <code>--single-transaction</code> when using <code>mysqldump</code> to backup the database, can be disabled by setting the <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code> to <code>false</code>.</li>
<li>Silence a <code>PHP Warning</code> if <code>mysql_pconnect</code> has been disabled.</li>
<li>Ensure dot directories <code>.</code> &#38; <code>..</code> are always skipped when looping the filesystem.</li>
<li>Work around a warning in the latest version of MySQL when using the <code>-p</code> flag with <code>mysqldunmp</code>.</li>
<li>Fix issues on IIS that could cause the root directory to be incorrectly calculated.</li>
<li>Fix an issue on IIS that could cause the download backup url to be incorrect.</li>
<li>Fix an issue on IIS that could mean your existing backups are lost when moving backup directory.</li>
<li>Avoid a <code>PHP FATAL ERROR</code> if the <code>mysql_set_charset</code> doesn\'t exist.</li>
<li>All unit tests now pass under IIS on Windows.</li>
<li>Prefix the backup directory with <code>backupwordpress-</code> so that it\'s easier to identify.</li>
<li>Re-calculate the backup directory name on plugin update and move backups.</li>
<li>Fix some issues with how <code>HMBKP_SECURE_KEY</code> was generated.</li>
</ul>

<h4>2.2.4</h4>

<ul>
<li>Fix a fatal error on PHP 5.2, sorry! (again.)</li>
</ul>

<h4>2.2.3</h4>

<ul>
<li>Fix a parse error, sorry!</li>
</ul>

<h4>2.2.2</h4>

<ul>
<li>Fix a fatal error when uninstalling.</li>
<li>Updated translations for Brazilian, French, Danish, Spanish, Czech, Slovakian, Polish, Italian, German, Latvian, Hebrew, Chinese &#38; Dutch.</li>
<li>Fix a possible notice when using the plugin on a server without internet access.</li>
<li>Don\'t show the wp-cron error message when <code>WP_USE_ALTERNATE_CRON</code> is defined as true.</li>
<li>Ability to override the max attachment size for email notifications using the new <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant.</li>
<li>Nonce some ajax request.</li>
<li>Silence warnings created if <code>is_executable</code>, <code>escapeshellcmd</code> or <code>escapeshellarg</code> are disabled.</li>
<li>Handle situations where the mysql port is set to something wierd.</li>
<li>Fallback to <code>mysql_connect</code> on system that disable <code>mysql_pconnect</code>.</li>
<li>You can now force the <code>--single-transaction</code> param when using <code>mysqldump</code> by defining <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code>.</li>
<li>Unit tests for <code>HM_Backup::is_safe_mode_available()</code>.</li>
<li>Silence possible PHP Warnings when unlinking files.</li>
</ul>

<h4>2.2.1</h4>

<ul>
<li>Stop storing a list of unreadable files in the backup warnings as it\'s too memory intensive.</li>
<li>Revert the custom <code>RecursiveDirectoryIterator</code> as it caused an infinite loop on some servers.</li>
<li>Show all errors and warnings in the popup shown when a manual backup completes.</li>
<li>Write the .backup_error and .backup_warning files everytime an error or warning happens instead of waiting until the end of the backups process.</li>
<li>Fix a couple of <code>PHP E_STRICT</code> notices.</li>
<li>Catch more errors during the manual backup process and expose them to the user.</li>
</ul>

<h4>2.2</h4>

<ul>
<li>Don\'t repeatedly try to create the backups directory in the <code>uploads</code> if <code>uploads</code> isn\'t writable.</li>
<li>Show the correct path in the warning message when the backups path can\'t be created.</li>
<li>Include any user defined auth keys and salts when generating the HMBKP_SECURE_KEY.</li>
<li>Stop relying on the built in WordPress schedules as other plugins can mess with them.</li>
<li>Delete old backups everytime the backups page is viewed in an attempt to ensure old backups are always cleaned up.</li>
<li>Improve modals on small screens and mobile devices.</li>
<li>Use the retina spinner on retina screens.</li>
<li>Update buttons to the new 3.5 style.</li>
<li>Fix a possible fatal error caused when a symlink points to a location that is outside an <code>open_basedir</code> restriction.</li>
<li>Fix an issue that could cause backups using PclZip with a custom backups path to fail.</li>
<li>Security hardening by improving escaping, sanitizitation and validation.</li>
<li>Increase the timeout on the ajax cron check, should fix issues with cron errors showing on slow sites.</li>
<li>Only clear the cached backup filesize if the backup type changes.</li>
<li>Add unit tests for all the schedule recurrences.</li>
<li>Fix an issue which could cause weekly and monthly schedules to fail.</li>
<li>Add an <code>uninstall.php</code> file which removes all BackUpWordPress data and options.</li>
<li>Catch a possible fatal error in <code>RecursiveDirectoryIterator::hasChildren</code>.</li>
<li>Fix an issue that could cause mysqldump errors to be ignored thus causing the backup process to use an incomplete mysqldump file.</li>
</ul>

<h4>2.1.3</h4>

<ul>
<li>Fix a regression in <code>2.1.2</code> that broke previewing and adding new exclude rules.</li>
</ul>

<h4>2.1.2</h4>

<ul>
<li>Fix an issue that could stop the settings panel from closing on save on servers which return <code>\'0\'</code> for ajax requests.</li>
<li>Fix an issue that could cause the backup root to be set to <code>/</code> on sites with <code>site_url</code> and <code>home</code> set to different domains.</li>
<li>The mysqldump fallback function will now be used if <code>mysqldump</code> produces an empty file.</li>
<li>Fix a possible PHP <code>NOTICE</code> on Apache servers.</li>
</ul>

<h4>2.1.1</h4>

<ul>
<li>Fix a possible fatal error when a backup schedule is instantiated outside of wp-admin.</li>
<li>Don\'t use functions from misc.php as loading it too early can cause fatal errors.</li>
<li>Don\'t hardcode an English string in the JS, use the translated string instead.</li>
<li>Properly skip dot files, should fix fatal errors on systems with <code>open_basedir</code> restrictions.</li>
<li>Don\'t call <code>apache_mod_loaded</code> as it caused wierd DNS issue on some sites, use <code>global $is_apache</code> instead.</li>
<li>Fix a possible double full stop at the end of the schedule sentence.</li>
<li>Minor code cleanup.</li>
</ul>

<h4>2.1</h4>

<ul>
<li>Stop blocking people with <code>safe_mode = On</code> from using the plugin, instead just show a warning.</li>
<li>Fix possible fatal error when setting schedule to monthly.</li>
<li>Fix issues with download backup not working on some shared hosts.</li>
<li>Fix issuses with download backup not working on sites with strange characters in the site name.</li>
<li>Fix a bug could cause the update actions to fire on initial activation.</li>
<li>Improved reliability when changing backup paths, now with Unit Tests.</li>
<li>Generate the lists of excluded, included and unreadable files in a more memory efficient way, no more fatal errors on sites with lots of files.</li>
<li>Bring back .htaccess protection of the backups directory on <code>Apache</code> servers with <code>mod_rewrite</code> enabled.</li>
<li>Prepend a random string to the backups directory to make it harder to brute force guess.</li>
<li>Fall back to storing the backups directoy in <code>uploads</code> if <code>WP_CONTENT_DIR</code> isn\'t writable.</li>
<li>Attempt to catch <code>E_ERROR</code> level errors (Fatal errors) that happen during the backup process and offer to email them to support.</li>
<li>Provide more granular status messages during the backup process.</li>
<li>Show a spinner next to the schedule link when a backup is running on a schedule which you are not currently viewing.</li>
<li>Improve the feedback when removing an exclude rule.</li>
<li>Fix an issue that could cause an exclude rule to be marked as default when it in-fact isn\'t, thus not letting it be deleted.</li>
<li>Add a line encouraging people to rate the plugin if they like it.</li>
<li>Change the support line to point to the FAQ before recommending they contact support.</li>
<li>Fix the link to the "How to Restore" post in the FAQ.</li>
<li>Some string changes for translators, 18 changed strings.</li>
</ul>

<h4>2.0.6</h4>

<ul>
<li>Fix possible warning on plugin activation if the sites cron option is empty.</li>
<li>Don\'t show the version warning in the help for Constants as that comes from the current version.</li>
</ul>

<h4>2.0.5</h4>

<ul>
<li>Re-setup the cron schedules if they get deleted somehow.</li>
<li>Delete all BackUpWordPress cron entries when the plugin is deactivated.</li>
<li>Introduce the <code>HMBKP_SCHEDULE_TIME</code> constant to allow control over the time schedules run.</li>
<li>Make sure the schedule times and times of previous backups are shown in local time.</li>
<li>Fix a bug that could cause the legacy backup schedule to be created on every update, not just when going from 1.x to 2.x.</li>
<li>Improve the usefulness of the <code>wp-cron.php</code> response code check.</li>
<li>Use the built in <code>site_format</code> function for human readable filesizes instead of defining our own function.</li>
</ul>

<h4>2.0.4</h4>

<ul>
<li>Revert the change to the way the plugin url and path were calculated as it caused regressions on some systems.</li>
</ul>

<h4>2.0.3</h4>

<ul>
<li>Fix issues with scheduled backups not firing in some cases.</li>
<li>Better compatibility when the WP Remote plugin is active alongside BackUpWordPress.</li>
<li>Catch and display more WP Cron errors.</li>
<li>BackUpWordPress now fails to activate on WordPress 3.3.2 and below.</li>
<li>Other minor fixes and improvements.</li>
</ul>

<h4>2.0.2</h4>

<ul>
<li>Only send backup failed emails if the backup actually failed.</li>
<li>Turn off the generic "memory limit probably hit" message as it was showing for too many people.</li>
<li>Fix a possible notice when the backup running filename is blank.</li>
<li>Include the <code>wp_error</code> response in the cron check.</li>
</ul>

<h4>2.0.1</h4>

<ul>
<li>Fix fatal error on PHP 5.2.</li>
</ul>

<h4>2.0</h4>

<ul>
<li>Ability to have multiple schedules with separate settings &#38; excludes per schedule.</li>
<li>Ability to manage exclude rules and see exactly which files are included and excluded.</li>
<li>Fix an issue with sites with an <code>open_basedir</code> restriction.</li>
<li>Backups should now be much more reliable in low memory environments.</li>
<li>Lots of other minor improvements and bug fixes.</li>
</ul>

<h4>1.6.9</h4>

<ul>
<li>Updated and improved translations across the board - props @elektronikLexikon.</li>
<li>German translation - props @elektronikLexikon.</li>
<li>New Basque translation - props Unai ZC.</li>
<li>New Dutch translation - Anno De Vries.</li>
<li>New Italian translation.</li>
<li>Better support for when WordPress is installed in a sub directory - props @mattheu</li>
</ul>

<h4>1.6.8</h4>

<ul>
<li>French translation props Christophe - <a href="http://catarina.fr" rel="nofollow">http://catarina.fr</a>.</li>
<li>Updated Spanish Translation props DD666 - <a href="https://github.com/radinamatic" rel="nofollow">https://github.com/radinamatic</a>.</li>
<li>Serbian translation props StefanRistic - <a href="https://github.com/StefanRistic" rel="nofollow">https://github.com/StefanRistic</a>.</li>
<li>Lithuanian translation props Vincent G - <a href="http://www.Host1Free.com" rel="nofollow">http://www.Host1Free.com</a>.</li>
<li>Romanian translation.</li>
<li>Fix conflict with WP Remote.</li>
<li>Fix a minor issue where invalid email address\'s were still stored.</li>
<li>The root path that is backed up can now be controlled by defining <code>HMBKP_ROOT</code>.</li>
</ul>

<h4>1.6.7</h4>

<ul>
<li>Fix issue with backups being listed in reverse chronological order.</li>
<li>Fix issue with newest backup being deleted when you hit your max backups limit.</li>
<li>It\'s now possible to have backups sent to multiple email address\'s by entering them as a comma separated list.</li>
<li>Fix a bug which broke the ability to override the <code>mysqldump</code> path with <code>HMBKP_MYSQLDUMP_PATH</code>.</li>
<li>Use <code>echo</code> rather than <code>pwd</code> when testing <code>shell_exec</code> as it\'s supported cross platform.</li>
<li>Updated Spanish translation.</li>
<li>Fix a minor spelling mistake.</li>
<li>Speed up the manage backups page by caching the FAQ data for 24 hours.</li>
</ul>

<h4>1.6.6</h4>

<ul>
<li>Fix backup path issue with case sensitive filesystems.</li>
</ul>

<h4>1.6.5</h4>

<ul>
<li>Fix an issue with emailing backups that could cause the backup file to not be attached.</li>
<li>Fix an issue that could cause the backup to be marked as running for ever if emailing the backup <code>FATAL</code> error\'d.</li>
<li>Never show the running backup in the list of backups.</li>
<li>Show an error backup email failed to send.</li>
<li>Fix possible notice when deleting a backup file which doesn\'t exist.</li>
<li>Fix possible notice on older versions of <code>PHP</code> which don\'t define <code>E_DEPRECATED</code>.</li>
<li>Make <code>HMBKP_SECURE_KEY</code> override-able.</li>
<li>BackUpWordPress should now work when <code>ABSPATH</code> is <code>/</code>.</li>
</ul>

<h4>1.6.4</h4>

<ul>
<li>Don\'t show warning message as they cause to much panic.</li>
<li>Move previous methods errors to warnings in fallback methods.</li>
<li>Wrap <code>.htaccess</code> rewrite rules in if <code>mod_rewrite</code> check.</li>
<li>Add link to new restore help article to FAQ.</li>
<li>Fix issue that could cause "not using latest stable version" message to show when you were in-fact using the latest version.</li>
<li>Bug fix in <code>zip command</code> check that could cause an incorrect <code>zip</code> path to be used.</li>
<li>Detect and pass <code>MySQL</code> port to <code>mysqldump</code>.</li>
</ul>

<h4>1.6.3</h4>

<ul>
<li>Don\'t fail archive verification for errors in previous archive methods.</li>
<li>Improved detection of the <code>zip</code> and <code>mysqldump</code> commands.</li>
<li>Fix issues when <code>ABSPATH</code> is <code>/</code>.</li>
<li>Remove reliance on <code>SECURE_AUTH_KEY</code> as it\'s often not defined.</li>
<li>Use <code>warning()</code> not <code>error()</code> for issues reported by <code>zip</code>, <code>ZipArchive</code> &#38; <code>PclZip</code>.</li>
<li>Fix download zip on Windows when <code>ABSPATH</code> contains a trailing forward slash.</li>
<li>Send backup email after backup completes so that fatal errors in email code don\'t stop the backup from completing.</li>
<li>Add missing / to <code>PCLZIP_TEMPORARY_DIR</code> define.</li>
<li>Catch and display errors during <code>mysqldump</code>.</li>
</ul>

<h4>1.6.2</h4>

<ul>
<li>Track <code>PHP</code> errors as backup warnings not errors.</li>
<li>Only show warning message for <code>PHP</code> errors in BackUpWordPress files.</li>
<li>Ability to dismiss the error / warning messages.</li>
<li>Disable use of <code>PclZip</code> for full archive checking for now as it causes memory issues on some large sites.</li>
<li>Don\'t delete "number of backups" setting on update.</li>
<li>Better handling of multibyte characters in archive and database dump filenames.</li>
<li>Mark backup as running and increase callback timeout to <code>500</code> when firing backup via ajax.</li>
<li>Don\'t send backup email if backup failed.</li>
<li>Filter out duplicate exclude rules.</li>
</ul>

<h4>1.6.1</h4>

<ul>
<li>Fix fatal error on PHP =&#60; 5.3</li>
</ul>

<h4>1.6</h4>

<ul>
<li>Fixes issue with backups dir being included in backups on some Windows Servers.</li>
<li>Consistent handling of symlinks across all archive methods (they are followed).</li>
<li>Use .htaccess rewrite cond authentication to allow for secure http downloads of backup files.</li>
<li>Track errors and warnings that happen during backup and expose them through admin.</li>
<li>Fire manual backups using ajax instead of wp-cron, <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> is no longer needed and has been removed.</li>
<li>Ability to cancel a running backup.</li>
<li>Zip files are now integrity checked after every backup.</li>
<li>More robust handling of failed / corrupt zips, backup process now fallsback through the various zip methods until one works.</li>
<li>Use <code>mysql_query</code> instead of the depreciated <code>mysql_list_tables</code>.</li>
</ul>

<h4>1.5.2</h4>

<ul>
<li>Better handling of unreadable files in ZipArchive and the backup size calculation.</li>
<li>Support for wp-cli, usage: <code>wp backup [--files_only] [--database_only] [--path&#60;dir&#62;] [--root&#60;dir&#62;] [--zip_command_path=&#60;path&#62;] [--mysqldump_command_path=&#60;path&#62;]</code></li>
</ul>

<h4>1.5.1</h4>

<ul>
<li>Better detection of <code>zip</code> command.</li>
<li>Don\'t delete user settings on update / deactivate.</li>
<li>Use <code>ZipArchive</code> if <code>zip</code> is not available, still falls back to <code>PclZip</code> if neither <code>zip</code> nor <code>ZipArchive</code> are installed.</li>
<li>Better exclude rule parsing, fixes lots of edge cases, excludes now pass all 52 unit tests.</li>
<li>Improved the speed of the backup size calculation.</li>
</ul>

<h4>1.5</h4>

<ul>
<li>Re-written core backup engine should be more robust especially in edge case scenarios.</li>
<li>48 unit tests for the core backup engine, yay for unit tests.</li>
<li>Remove some extraneous status information from the admin interface.</li>
<li>Rename Advanced Options to Settings</li>
<li>New <code>Constant</code> <code>HMBKP_CAPABILITY</code> to allow the default <code>add_menu_page</code> capability to be changed.</li>
<li>Suppress possible filemtime warnings in some edge cases.</li>
<li>3.3 compatability.</li>
<li>Set proper charset of MySQL backup, props valericus.</li>
<li>Fix some inconsistencies between the estimated backup size and actual backup size when excluding files.</li>
</ul>

<h4>1.4.1</h4>

<ul>
<li>1.4 was incorrectly marked as beta.</li>
</ul>

<h4>1.4</h4>

<ul>
<li>Most options can now be set on the backups page, all options can still be set by defining them as <code>Constants</code>.</li>
<li>Russian translation, props valericus.</li>
<li>All dates are now translatable.</li>
<li>Fixed some strings which weren\'t translatable.</li>
<li>New Constant <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> which enable you to disable the use of <code>wp_cron</code> for manual backups.</li>
<li>Manual backups now work if <code>DISABLE_WP_CRON</code> is defined as <code>true</code>.</li>
</ul>

<h4>1.3.2</h4>

<ul>
<li>Spanish translation</li>
<li>Bump PHP version check to 5.2.4</li>
<li>Fallback to PHP mysqldump if shell_exec fails for any reason.</li>
<li>Silently ignore unreadable files / folders</li>
<li>Make sure binary data is properly exported when doing a mysqldump</li>
<li>Use 303 instead of 302 when redirecting in the admin.</li>
<li>Don\'t <code>set_time_limit</code> inside a loop</li>
<li>Use WordPress 3.2 style buttons</li>
<li>Don\'t pass an empty password to mysqldump</li>
</ul>

<h4>1.3.1</h4>

<ul>
<li>Check for PHP version. Deactivate plugin if running on PHP version 4.</li>
</ul>

<h4>1.3</h4>

<ul>
<li>Re-written back up engine, no longer copies everything to a tmp folder before zipping which should improve speed and reliability.</li>
<li>Support for excluding files and folders, define <code>HMBKP_EXCLUDE</code> with a comma separated list of files and folders to exclude, supports wildcards <code>*</code>, path fragments and absolute paths.</li>
<li>Full support for moving the backups directory, if you define a new backups directory then your existing backups will be moved to it.</li>
<li>Work around issues caused by low MySQL <code>wait_timeout</code> setting.</li>
<li>Add FAQ to readme.txt.</li>
<li>Pull FAQ into the contextual help tab on the backups page.</li>
<li>Block activation on old versions of WordPress.</li>
<li>Stop guessing compressed backup file size, instead just show size of site uncompressed.</li>
<li>Fix bug in <code>safe_mode</code> detection which could cause <code>Off</code> to act like <code>On</code>.</li>
<li>Better name for the database dump file.</li>
<li>Better name for the backup files.</li>
<li>Improve styling for advanced options.</li>
<li>Show examples for all advanced options.</li>
<li>Language improvements.</li>
<li>Layout tweaks.</li>
</ul>

<h4>1.2</h4>

<ul>
<li>Show live backup status in the back up now button when a back up is running.</li>
<li>Show free disk space after total used by backups.</li>
<li>Several langauge changes.</li>
<li>Work around the 1 cron every 60 seconds limit.</li>
<li>Store backup status in a 2 hour transient as a last ditch attempt to work around the "stuck on backup running" issue.</li>
<li>Show a warning and disable backups when PHP is in Safe Mode, may try to work round issues and re-enable in the future.</li>
<li>Highlight defined <code>Constants</code>.</li>
<li>Show defaults for all <code>Constants</code>.</li>
<li>Show a warning if both <code>HMBKP_FILES_ONLY</code> and <code>HMBKP_DATABASE_ONLY</code> are defined at the same time.</li>
<li>Make sure options added in 1.1.4 are cleared on de-activate.</li>
<li>Support <code>mysqldump on</code> Windows if it\'s available.</li>
<li>New option to have each backup emailed to you on completion. Props @matheu for the contribution.</li>
<li>Improved windows server support.</li>
</ul>

<h4>1.1.4</h4>

<ul>
<li>Fix a rare issue where database backups could fail when using the mysqldump PHP fallback if <code>mysql.max_links</code> is set to 2 or less.</li>
<li>Don\'t suppress <code>mysql_connect</code> errors in the mysqldump PHP fallback.</li>
<li>One time highlight of the most recent completed backup when viewing the manage backups page after a successful backup.</li>
<li>Fix a spelling error in the <code>shell_exec</code> disabled message.</li>
<li>Store the BackUpWordPress version as a <code>Constant</code> rather than a <code>Variable</code>.</li>
<li>Don\'t <code>(float)</code> the BackUpWordPress version number, fixes issues with minor versions numbers being truncated.</li>
<li>Minor PHPDoc improvements.</li>
</ul>

<h4>1.1.3</h4>

<ul>
<li>Attempt to re-connect if database connection hits a timeout while a backup is running, should fix issues with the "Back Up Now" button continuing to spin even though the backup is completed.</li>
<li>When using <code>PCLZIP</code> as the zip fallback don\'t store the files with absolute paths. Should fix issues unzipping the file archives using "Compressed (zipped) Folders" on Windows XP.</li>
</ul>

<h4>1.1.2</h4>

<ul>
<li>Fix a bug that stopped <code>HMBKP_DISABLE_AUTOMATIC_BACKUP</code> from working.</li>
</ul>

<h4>1.1.1</h4>

<ul>
<li>Fix a possible <code>max_execution_timeout</code> fatal error when attempting to calculate the path to <code>mysqldump</code>.</li>
<li>Clear the running backup status and reset the calculated filesize on update.</li>
<li>Show a link to the manage backups page in the plugin description.</li>
<li>Other general fixes.</li>
</ul>

<h4>1.1</h4>

<ul>
<li>Remove the logging facility as it provided little benefit and complicated the code, your existing logs will be deleted on update.</li>
<li>Expose the various <code>Constants</code> that can be defined to change advanced settings.</li>
<li>Added the ability to disable the automatic backups completely <code>define( \'HMBKP_DISABLE_AUTOMATIC_BACKUP\', true );</code>.</li>
<li>Added the ability to switch to file only or database only backups <code>define( \'HMBKP_FILES_ONLY\', true );</code> Or <code>define( \'HMBKP_DATABASE_ONLY\', true );</code>.</li>
<li>Added the ability to define how many old backups should be kept <code>define( \'HMBKP_MAX_BACKUPS\', 20 );</code></li>
<li>Added the ability to define the time that the daily backup should run <code>define( \'HMBKP_DAILY_SCHEDULE_TIME\', \'16:30\' );</code></li>
<li>Tweaks to the backups page layout.</li>
<li>General bug fixes and improvements.</li>
</ul>

<h4>1.0.5</h4>

<ul>
<li>Don\'t ajax load estimated backup size if it\'s already been calculated.</li>
<li>Fix time in backup complete log message.</li>
<li>Don\'t mark backup as running until cron has been called, will fix issues with backup showing as running even if cron never fired.</li>
<li>Show number of backups saved message.</li>
<li>Add a link to the backups page to the plugin action links.</li>
</ul>

<h4>1.0.4</h4>

<p>Don\'t throw PHP Warnings when <code>shell_exec</code> is disabled</p>

<h4>1.0.3</h4>

<p>Minor bug fix release.</p>

<ul>
<li>Suppress <code>filesize()</code> warnings when calculating backup size.</li>
<li>Plugin should now work when symlinked.</li>
<li>Remove all options on deactivate, you should now be able to deactivate then activate to fix issues with settings etc. becoming corrupt.</li>
<li>Call setup_defaults for users who update from backupwordpress 0.4.5 so they get new settings.</li>
<li>Don\'t ajax ping running backup status quite so often.</li>
</ul>

<h4>1.0.1 &#38; 1.0.2</h4>

<p>Fix some silly 1.0 bugs</p>

<h4>1.0</h4>

<p>1.0 represents a total rewrite &#38; rethink of the BackUpWordPress plugin with a focus on making it "Just Work". The management and development of the plugin has been taken over by <a href="http://hmn.md">Human Made Limited</a> the chaps behind <a href="https://wpremote.com">WP Remote</a></p>

<h4>Previous</h4>

<p>Version 0.4.5 and previous were developed by <a href="http://profiles.wordpress.org/users/wpdprx/">wpdprx</a></p>";s:3:"faq";s:4053:"<p><strong>Where does BackUpWordPress store the backup files?</strong></p>

<p>Backups are stored on your server in <code>/wp-content/backups</code>, you can change the directory.</p>

<p><strong>Important:</strong> By default BackUpWordPress backs up everything in your site root as well as your database, this includes any non WordPress folders that happen to be in your site root. This does means that your backup directory can get quite large.</p>

<p><strong>How do I restore my site from a backup?</strong></p>

<p>You need to download the latest backup file either by clicking download on the backups page or via <code>FTP</code>. <code>Unzip</code> the files and upload all the files to your server overwriting your site. You can then import the database using your hosts database management tool (likely <code>phpMyAdmin</code>).</p>

<p>See this post for more details <a href="http://hmn.md/backupwordpress-how-to-restore-from-backup-files/" rel="nofollow">http://hmn.md/backupwordpress-how-to-restore-from-backup-files/</a>.</p>

<p><strong>Does BackUpWordPress back up the backups directory?</strong></p>

<p>No.</p>

<p><strong>I\'m not receiving my backups by email</strong></p>

<p>Most servers have a filesize limit on email attachments, it\'s generally about 10mb. If your backup file is over that limit it won\'t be sent attached to the email, instead you should receive an email with a link to download the backup, if you aren\'t even receiving that then you likely have a mail issue on your server that you\'ll need to contact your host about.</p>

<p><strong>How many backups are stored by default?</strong></p>

<p>BackUpWordPress stores the last 10 backups by default.</p>

<p><strong>How long should a backup take?</strong></p>

<p>Unless your site is very large (many gigabytes) it should only take a few minutes to perform a back up, if your back up has been running for longer than an hour it\'s safe to assume that something has gone wrong, try de-activating and re-activating the plugin, if it keeps happening, contact support.</p>

<p><strong>What do I do if I get the wp-cron error message</strong></p>

<p>The issue is that your <code>wp-cron.php</code> is not returning a <code>200</code> response when hit with a http request originating from your own server, it could be several things, most of the time it\'s an issue with the server / site and not with BackUpWordPress.</p>

<p>Some things you can test are.</p>

<ul>
<li>Are scheduled posts working? (They use wp-cron too).</li>
<li>Are you hosted on Heart Internet? (wp-cron is known not to work with them).</li>
<li>If you click manual backup does it work?</li>
<li>Try adding <code>define( \'ALTERNATE_WP_CRON\', true ); to your</code>wp-config.php`, do automatic backups work?</li>
<li>Is your site private (I.E. is it behind some kind of authentication, maintenance plugin, .htaccess) if so wp-cron won\'t work until you remove it, if you are and you temporarily remove the authentication, do backups start working?</li>
</ul>

<p>If you have tried all these then feel free to contact support.</p>

<p><strong>How to get BackUpWordPress working in Heart Internet</strong></p>

<p>The script to be entered into the Heart Internet cPanel is: <code>/usr/bin/php5 /home/sites/yourdomain.com/public_html/wp-cron.php</code> (note the space between php5 and the location of the file). The file <code>wp-cron.php</code> <code>chmod</code> must be set to <code>711</code>.</p>

<p><strong>Further Support &#38; Feedback</strong></p>

<p>General support questions should be posted in the <a href="http://wordpress.org/tags/backupwordpress?forum_id=10">WordPress support forums, tagged with backupwordpress.</a></p>

<p>For development issues, feature requests or anybody wishing to help out with development checkout <a href="https://github.com/humanmade/backupwordpress/">BackUpWordPress on GitHub.</a></p>

<p>You can also tweet <a href="http://twitter.com/humanmadeltd">@humanmadeltd</a> or email <a href="mailto:support@hmn.md">support@hmn.md</a> for further help/support.</p>";}s:13:"download_link";s:63:"http://downloads.wordpress.org/plugin/backupwordpress.2.3.3.zip";s:4:"tags";a:10:{s:7:"archive";s:7:"archive";s:7:"back-up";s:7:"back up";s:6:"backup";s:6:"backup";s:7:"backups";s:7:"backups";s:8:"database";s:8:"database";s:2:"db";s:2:"db";s:5:"files";s:5:"files";s:9:"humanmade";s:9:"humanmade";s:6:"wp-cli";s:6:"wp-cli";s:3:"zip";s:3:"zip";}s:11:"donate_link";N;}', 'no') ; 
INSERT INTO `wp_options` VALUES (474, '_site_transient_timeout_wporg_theme_feature_list', '1384062232', 'yes') ; 
INSERT INTO `wp_options` VALUES (475, '_site_transient_wporg_theme_feature_list', 'a:5:{s:6:"Colors";a:15:{i:0;s:5:"black";i:1;s:4:"blue";i:2;s:5:"brown";i:3;s:4:"gray";i:4;s:5:"green";i:5;s:6:"orange";i:6;s:4:"pink";i:7;s:6:"purple";i:8;s:3:"red";i:9;s:6:"silver";i:10;s:3:"tan";i:11;s:5:"white";i:12;s:6:"yellow";i:13;s:4:"dark";i:14;s:5:"light";}s:7:"Columns";a:6:{i:0;s:10:"one-column";i:1;s:11:"two-columns";i:2;s:13:"three-columns";i:3;s:12:"four-columns";i:4;s:12:"left-sidebar";i:5;s:13:"right-sidebar";}s:5:"Width";a:2:{i:0;s:11:"fixed-width";i:1;s:14:"flexible-width";}s:8:"Features";a:19:{i:0;s:8:"blavatar";i:1;s:10:"buddypress";i:2;s:17:"custom-background";i:3;s:13:"custom-colors";i:4;s:13:"custom-header";i:5;s:11:"custom-menu";i:6;s:12:"editor-style";i:7;s:21:"featured-image-header";i:8;s:15:"featured-images";i:9;s:15:"flexible-header";i:10;s:20:"front-page-post-form";i:11;s:19:"full-width-template";i:12;s:12:"microformats";i:13;s:12:"post-formats";i:14;s:20:"rtl-language-support";i:15;s:11:"sticky-post";i:16;s:13:"theme-options";i:17;s:17:"threaded-comments";i:18;s:17:"translation-ready";}s:7:"Subject";a:3:{i:0;s:7:"holiday";i:1;s:13:"photoblogging";i:2;s:8:"seasonal";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (195, 'theme_mods_twentythirteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1378626744;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:0:{}s:19:"primary-widget-area";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:21:"secondary-widget-area";a:0:{}s:24:"first-footer-widget-area";a:0:{}s:25:"second-footer-widget-area";a:0:{}s:24:"third-footer-widget-area";a:0:{}s:25:"fourth-footer-widget-area";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (196, 'current_theme', 'Wing Chun', 'yes') ; 
INSERT INTO `wp_options` VALUES (197, 'theme_mods_tigertheme', 'a:7:{i:0;b:0;s:16:"header_textcolor";s:6:"e9e0e1";s:16:"background_color";s:6:"e9e0d1";s:16:"background_image";s:0:"";s:17:"background_repeat";s:6:"repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (198, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (236, '_site_transient_update_core', 'O:8:"stdClass":3:{s:7:"updates";a:1:{i:0;O:8:"stdClass":9:{s:8:"response";s:7:"upgrade";s:8:"download";s:40:"http://wordpress.org/wordpress-3.7.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":4:{s:4:"full";s:40:"http://wordpress.org/wordpress-3.7.1.zip";s:10:"no_content";s:51:"http://wordpress.org/wordpress-3.7.1-no-content.zip";s:11:"new_bundled";s:52:"http://wordpress.org/wordpress-3.7.1-new-bundled.zip";s:7:"partial";b:0;}s:7:"current";s:5:"3.7.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.6";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1384122127;s:15:"version_checked";s:5:"3.6.1";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (248, '_transient_timeout_hmbkp_schedule_default-1_filesize', '2758063022', 'no') ; 
INSERT INTO `wp_options` VALUES (249, '_transient_hmbkp_schedule_default-1_filesize', '411488', 'no') ; 
INSERT INTO `wp_options` VALUES (262, '_transient_all_the_cool_cats', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (452, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1384094554', 'no') ; 
INSERT INTO `wp_options` VALUES (453, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1384051354', 'no') ; 
INSERT INTO `wp_options` VALUES (454, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1384094554', 'no') ; 
INSERT INTO `wp_options` VALUES (455, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2013/10/wordpress-3-7-1/\' title=\'WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including: Images with captions no longer appear broken in the visual editor. Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org. Avoid fatal errors with certain plugins that were incorrectly calling some […]\'>WordPress 3.7.1 Maintenance Release</a> <span class="rss-date">October 29, 2013</span><div class=\'rssSummary\'>WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including: Images with captions no longer appear broken in the visual editor. Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org. Avoid fatal errors with certain plugins that were incorrectly calling som [&hellip;]</div></li><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2013/10/basie/\' title=\'Version 3.7 of WordPress, named “Basie” in honor of Count Basie, is available for download or update in your WordPress dashboard. This release features some of the most important architectural updates we’ve made to date. Here are the big ones: Updates while you sleep: With WordPress 3.7, you don’t have to lift a finger to […]\'>WordPress 3.7 “Basie”</a> <span class="rss-date">October 24, 2013</span><div class=\'rssSummary\'>Version 3.7 of WordPress, named “Basie” in honor of Count Basie, is available for download or update in your WordPress dashboard. This release features some of the most important architectural updates we’ve made to date. Here are the big ones: Updates while you sleep: With WordPress 3.7, you don’t have to lift a finger to […]</div></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (456, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1384094555', 'no') ; 
INSERT INTO `wp_options` VALUES (457, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Nov 2013 01:36:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your Wordpress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:122:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 7.5 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Wordfence Security is a free enterprise class security plugin that includes a firewall, virus scanning, real-time traffic with geolocation and more.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WP Super Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/wp-super-cache/#post-2572";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Nov 2007 11:40:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2572@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:73:"A very fast caching engine for WordPress that produces static html files.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Donncha O Caoimh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Ultimate TinyMCE";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://wordpress.org/plugins/ultimate-tinymce/#post-32088";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Nov 2011 09:06:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"32088@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Description: Beef up the WordPress TinyMCE content editor with a plethora of advanced options.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Josh (Ult. Tinymce)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Captcha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/captcha/#post-26129";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Apr 2011 05:53:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"26129@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:79:"This plugin allows you to implement super security captcha form into web forms.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"WP-Optimize";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wordpress.org/plugins/wp-optimize/#post-8691";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 21 Jan 2009 04:28:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8691@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:115:"This simple but effective plugin allows you to clean up your WordPress database and optimize it without phpMyAdmin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"ruhanirabin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2082@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:7:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sun, 10 Nov 2013 01:40:56 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Fri, 30 Mar 2007 20:08:18 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130908064941";}', 'no') ; 
INSERT INTO `wp_options` VALUES (444, '_transient_timeout_feed_808390979aa7eed5a9c06ad6a9dd19d0', '1384094554', 'no') ; 
INSERT INTO `wp_options` VALUES (445, '_transient_feed_808390979aa7eed5a9c06ad6a9dd19d0', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:4:"
  
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:33:"
    
    
    
    
    
    
  ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"link:http://www.andytan.net/tigers/ - Google Blog Search";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://www.google.com/search?ie=utf-8&q=link:http://www.andytan.net/tigers/&tbm=blg&tbs=sbd:1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:87:"Your search - <b>link:http://www.andytan.net/tigers/</b> - did not match any documents.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://a9.com/-/spec/opensearch/1.1/";a:3:{s:12:"totalResults";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:10:"startIndex";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:12:"itemsPerPage";a:1:{i:0;a:5:{s:4:"data";s:2:"10";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:28:"text/xml; charset=ISO-8859-1";s:4:"date";s:29:"Sun, 10 Nov 2013 01:40:56 GMT";s:7:"expires";s:2:"-1";s:13:"cache-control";s:18:"private, max-age=0";s:10:"set-cookie";a:2:{i:0;s:143:"PREF=ID=73740f8195f60eec:FF=0:TM=1384047656:LM=1384047656:S=op2CnbV6M7cqjDUU; expires=Tue, 10-Nov-2015 01:40:56 GMT; path=/; domain=.google.com";i:1;s:212:"NID=67=XSKKlObiNOXFEJyQ8gw5lUZZvyVj7zCODsmDS7PNbh1CFzlSoeELUzksQxMn850Q4jZAKFXGs61x9MNyBrhJw6IGDh5tHsE6pIw9YIQEM4kQGyaKs49K9PmNlKQE7otS; expires=Mon, 12-May-2014 01:40:56 GMT; path=/; domain=.google.com; HttpOnly";}s:3:"p3p";s:122:"CP="This is not a P3P policy! See http://www.google.com/support/accounts/bin/answer.py?hl=en&answer=151657 for more info."";s:6:"server";s:3:"gws";s:16:"x-xss-protection";s:13:"1; mode=block";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20130908064941";}', 'no') ; 
INSERT INTO `wp_options` VALUES (446, '_transient_timeout_feed_mod_808390979aa7eed5a9c06ad6a9dd19d0', '1384094554', 'no') ; 
INSERT INTO `wp_options` VALUES (447, '_transient_feed_mod_808390979aa7eed5a9c06ad6a9dd19d0', '1384051354', 'no') ; 
INSERT INTO `wp_options` VALUES (448, '_transient_timeout_dash_20494a3d90a6669585674ed0eb8dcd8f', '1384094554', 'no') ; 
INSERT INTO `wp_options` VALUES (449, '_transient_dash_20494a3d90a6669585674ed0eb8dcd8f', '<p>This dashboard widget queries <a href="http://blogsearch.google.com/">Google Blog Search</a> so that when another blog links to your site it will show up here. It has found no incoming links&hellip; yet. It&#8217;s okay &#8212; there is no rush.</p>
', 'no') ; 
INSERT INTO `wp_options` VALUES (438, '_site_transient_timeout_browser_00760e848c8aef5785b4a3f89f42352c', '1384656149', 'yes') ; 
INSERT INTO `wp_options` VALUES (439, '_site_transient_browser_00760e848c8aef5785b4a3f89f42352c', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"30.0.1599.101";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (297, 'theme_mods_wingchun', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1381755221;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";N;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (337, '_site_transient_timeout_browser_bef8ab52ade1826ae6dab4fa2976a3db', '1382358153', 'yes') ; 
INSERT INTO `wp_options` VALUES (338, '_site_transient_browser_bef8ab52ade1826ae6dab4fa2976a3db', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"30.0.1599.69";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (470, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1384094555', 'no') ; 
INSERT INTO `wp_options` VALUES (471, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1384051355', 'no') ; 
INSERT INTO `wp_options` VALUES (472, '_transient_timeout_dash_aa95765b5cc111c56d5993d476b1c2f0', '1384094555', 'no') ; 
INSERT INTO `wp_options` VALUES (473, '_transient_dash_aa95765b5cc111c56d5993d476b1c2f0', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2013/11/09/tony-perez-wordpress-security/\' title=\'    \'>WordPress.tv: Tony Perez: WordPress Security</a></li><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2013/11/09/panel-discussion-buddypress-qanda-panel/\' title=\'    \'>WordPress.tv: Panel Discussion: BuddyPress QandA Panel</a></li><li><a class=\'rsswidget\' href=\'http://www.wptavern.com/wpweekly-episode-127-roundtable-with-brad-williams-who-eats-apis-for-breakfast\' title=\' In this weeks episode, we were joined by Brad Williams of Webdevstudios and Dradcast to discuss the headlines of the week. We covered a large assortment of news items and received some updates on projects Webdevstudios is working on such as the latest release of BadgeOS. Brad is a long time participant of the WordPress Weekly show and it was great to have him back. The last time he was on the show was June 6th, 2010 when he called into the show from WordCamp Chicago. This episode reminded me how much fun it is to be part of a roundtable type of show. Stories Discussed: Breaking: New Features Selected To Merge Into WordPress 3.8 Core The Future of WordPress Widgets: A Better UI With Real-Time Previews Cart66 Launches WordPress Managed Hosting for E-Commerce My Approachable WordPress Story Should WordPress Include a Password Generator? BuddyPress 1.9 To Retire Default Theme and Add New Notifications Component GravityForms 1.8 Beta Released, Introduces API WPWeekly Meta: Next Episode: Friday, November 15th 3 P.M. Eastern – Special Guest will be Brian Gardner of StudioPress.com Subscribe To WPWeekly Via Itunes: Click here to subscribe Subscribe To WPWeekly Via RSS: Click here to subscribe Subscribe To WPWeekly Via Stitcher Radio: Click here to subscribe Listen To Episode #127: \'>WPTavern: WPWeekly Episode 127 – Roundtable With Brad Williams Who Eats API’s For Breakfast</a></li><li><a class=\'rsswidget\' href=\'http://www.wptavern.com/free-wordpress-writr-theme-now-available-on-wordpress-org\' title=\'Last week WordPress.com released Writr, a beautiful free theme that really puts your content in the spotlight. The tumblelog style is perfect for power bloggers who like to utilize post formats for different types of content.  The good news this week is that Writr is now available for self-hosted WordPress sites via its new page on WordPress.org. You can install it directly through your dashboard and take advantage of the same features the theme offers on WordPress.com.  Writr is responsive and looks absolutely stunning on any device. On smaller devices the sidebar is either displayed or hidden via a neatly tucked corner toggle. Instead of stacking the sidebar content below the list of posts, it’s always at your fingertips with one click. Test the demo by resizing your browser window to see how nicely it works.  Theme Options for Customizing Writr Writr comes with unique icons for each post type as well as 6 different color schemes: turquoise (default), blue, green, grey, purple, and red. It also has support for a custom header image, background, menu and social icons. One of my favorite features of the Writr theme is the optional wider content area. It can be easily increased by visiting the customizer and ticking the “Wider Content Area” checkbox – no CSS edits necessary!  Since Writr was originally built for use on WordPress.com and has passed the rigorous theme standards of WordPress.org, you know that it’s a high quality theme. An added benefit here is that it’s supported by professional developers so you’ll be good to go for future updates. Does Writr have you thinking about changing the theme on your blog? Install it from WordPress.org and check it out in live preview mode.\'>WPTavern: Free WordPress Writr Theme Now Available on WordPress.org</a></li><li><a class=\'rsswidget\' href=\'http://www.wptavern.com/coschedule-a-viable-alternative-to-the-edit-flow-wordpress-plugin\' title=\'I’m a huge fan of the Edit Flow plugin, especially since this site started publishing articles from multiple authors. It has all sorts of cool features such as custom post statuses, notifications, and editorial comments within posts. Unfortunately, Edit Flow is broken in a few places. I’ve been in touch with at least a few people who told me they switched to a different plugin because of the issues they encountered with Edit Flow. Thankfully, those items are being addressed and a fix should be released soon. In the mean time, I discovered a paid alternative to Edit Flow that looks to be just as good if not better than Edit Flow called CoSchedule.     CoSchedule In a Nutshell CoSchedule is a service created by Garret Moon of Todaymade that is accessible in WordPress via a plugin. It provides an editorial workflow complete with a calendar to help keep track of activity across the site. It’s $10.00 per month per WordPress site. The plan includes:  Unlimited Users Unlimited Social Accounts No hidden fees Free support The option of cancelling your account at any time, no credit card required.  New users have 14 days to try out the service. Installing And Configuring CoSchedule Installing and configuring CoSchedule was a breeze thanks in large part to a video explanation and the excellent use of pointers introduced in WordPress 3.3. It’s the first time those tips came in handy. They also disappeared once I went through the process once. When setting up for the first time, make certain you select the appropriate time zone. If you don’t, it will throw off the entire system.  Controlling Social Media And Content From One Interface Not only can writers create and manage posts through CoSchedule, they can also manager their social media presence by connecting their accounts similar to the way Publicize works in Jetpack. Unlike Jetpack, you can control when the social media message is broadcasted. Being able to control when and how your social media messages are displayed along with content is a great combination. Creating A Social Media Post As you can see from the following screenshot, social media posts show up in the calendar alongside blog posts. Changing when these events occur is as simple as clicking and dragging the post from one day to the next.   Light Grey On White Is Not A Good Combination One thing I didn’t like is the lack of bold colors for the fonts used throughout the interface. The light grey colored fonts used on top of a white background were hard to see. Even though CoSchedule ships with multiple color schemes, none of them improved the situation. In fact, some of the color schemes made the problem worse. Take this screenshot for example. I’m hoping the next version of CoSchedule experiments with bolder colors. Hard To Read Light Grey Text Not Native To WordPress But It Works The interface for managing posts whether it be the calendar view or when writing/editing a blog post is not the native WordPress interface. But it’s not a drastic departure either. In fact, I like it and it works well.  The Manager With Many Hats Just like Edit Flow, CoSchedule gives you the ability to create users and assign them specific roles. This is known as the team. The owner of the site has the power to create new users and assign them roles. One improvement that could be made here is when typing in a users name, CoSchedule looks at the WordPress users and auto suggests a match. That way, it just adds them to the team members list. I love how there is a clear explanation of what each role allows on the bottom of the Team Members page.  Controlling CoSchedule Users CoSchedule has integration support for Bitly, Google Analytics, and Google Calendar.  My Favorite Feature Of CoSchedule Just like Edit Flow, my favorite feature in CoSchedule is the ability to provide editorial comments attached to a post. This has proved to be an invaluable feature that makes collaboration easy. Besides being able to write comments, depending on your user role, you can assign tasks to that writer. For each task that is completed, the task creator will receive a notification that it’s been completed. You can also follow posts. Following a post means you’ll receive notifications for any activity that occurs on that post.  Adding Comments Or Tasks Interview With Founder Garret Moon How much functionality of CoSchedule is in the actual plugin versus the website? CoSchedule relies completely on WordPress core for post scheduling and publishing. Posts on the calendar are simply synced with your WordPress install, not moved. Social messages are handled a bit differently, and sent remotely from the CoSchedule servers.  CoSchedule is a web application that integrates deeply with WordPress through the use of the CoSchedule plugin. We aren’t 100% embedded into your WordPress install for all purposes, but this is by design. This combination provides the best possible user experience and reliability. Our goal is to allow WordPress to do what it does best, and our own service to add as much value as it possibly can.  What happens if CoSchedule stops working or the website disappears? Will data be lost? Post data is never moved to our servers and remains on your local install. Post data loss is not a possibility with CoSchedule. Scheduled social messages are stored on our servers, but data loss is still very unlikely. We maintain redundant databases at all times and complete hourly backups of user data. Our data is secured with some of the largest data providers in the world. Was Edit Flow an inspiration when creating CoSchedule? Not really. We created CoSchedule because we wanted a robust tool for scheduling social media messages and blog posts on the same calendar, and in a team environment. We also believe in WordPress as a publishing platform, so we felt that the best way to accomplish this was through a custom application that worked in-hand with WordPress. How did you arrive at the $10 per month price point?  We talked to our users a lot about this, and ultimately decided on something that would make CoSchedule available to as many people as possible, while providing the income necessary to maintain the highest quality service possible. So far, the response had been good since the $10/month price point is still very affordable for most bloggers. What are some of the features you have in the works for the next iteration of CoSchedule? We have a lot of improvements to our social scheduling in the works. We recently added Buffer and Google+ Pages integration, which was a huge win. Up next, are core enhancements to the messages that are created –specifically how they look when they are published to social networks. We also have some exciting features in the works that will make social scheduling easier and more automated.   Since we began building CoSchedule we have been very responsive to feedback, and in-tune with what our users want us to build. While we have many plans for CoSchedule, we are always looking for feedback from the community on how they want to see it grow.  Conclusion CoSchedule is a great service. The application inside of WordPress was responsive without any noticeable lag. If it were not for the price tag, I could see myself ditching Edit Flow in favor of this. But at $10.00 a month, it’s very affordable. Sites running WordPress that have multiple authors need something like CoSchedule in place to make sense of all the chaos. I discovered a few minor styling issues while testing but I’ve already let the developers know and they are in the process of fixing them. Don’t take my word for it. Give CoSchedule a try for 14 days and arrive at your own conclusion. \'>WPTavern: CoSchedule – A Viable Alternative To The Edit Flow WordPress Plugin</a></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (482, '_transient_is_multi_author', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (483, 'twp', 'a:16:{s:12:"consumer-key";s:19:"jsu4vXpRoHzNdRdrsrw";s:15:"consumer-secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:8:"username";s:0:"";s:4:"list";s:0:"";s:5:"title";s:0:"";s:5:"items";s:2:"10";s:6:"avatar";s:0:"";s:6:"errmsg";s:0:"";s:6:"showts";s:5:"86400";s:10:"dateFormat";s:14:"h:i:s A F d, Y";s:12:"showretweets";s:4:"true";s:11:"hidereplies";s:5:"false";s:8:"hidefrom";s:5:"false";s:11:"showintents";s:4:"true";s:10:"showfollow";s:4:"true";s:11:"targetBlank";s:5:"false";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (480, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (486, '_twp_request_token_3d960485ab858e08bb82835ccb9838f6', 'a:4:{s:11:"oauth_token";s:42:"t0LdHOY5SNdagZHvUy9oB2wxb60QgYwzIQJ7NgmQ7c";s:18:"oauth_token_secret";s:42:"e8Hq8T4vCFrCbT3fRXOGc6ROXXBXViBRWn9rfduTRU";s:24:"oauth_callback_confirmed";s:4:"true";s:5:"nonce";s:32:"3d960485ab858e08bb82835ccb9838f6";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (488, 'twp-authed-users', 'a:1:{s:15:"ash_skywalker10";a:4:{s:11:"oauth_token";s:50:"399730397-UUaCZnrCulookeadOgPWcpkEclDv2vZ6IMw9wf8t";s:18:"oauth_token_secret";s:45:"nHgo0EzVefbEbsp5L7FoTlcXaWjSLsu6i0gGOISYFWS7f";s:7:"user_id";s:9:"399730397";s:11:"screen_name";s:15:"ash_skywalker10";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (492, '_transient_doing_cron', '1384143817.3009910583496093750000', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Monday 11. November 2013 04:23 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (24 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2, 4, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (5, 8, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (4, 4, '_edit_lock', '1382243026:1') ; 
INSERT INTO `wp_postmeta` VALUES (6, 8, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (7, 8, '_menu_item_object_id', '8') ; 
INSERT INTO `wp_postmeta` VALUES (8, 8, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (9, 8, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (10, 8, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (11, 8, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (12, 8, '_menu_item_url', 'http://www.andytan.net/tigers/') ; 
INSERT INTO `wp_postmeta` VALUES (13, 8, '_menu_item_orphaned', '1384051406') ; 
INSERT INTO `wp_postmeta` VALUES (14, 9, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (15, 9, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (16, 9, '_menu_item_object_id', '2') ; 
INSERT INTO `wp_postmeta` VALUES (17, 9, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (18, 9, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (19, 9, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (20, 9, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (21, 9, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (22, 9, '_menu_item_orphaned', '1384051406') ; 
INSERT INTO `wp_postmeta` VALUES (23, 11, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (24, 11, '_edit_lock', '1384089066:1') ; 
INSERT INTO `wp_postmeta` VALUES (25, 11, '_wp_page_template', 'default') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Monday 11. November 2013 04:23 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (10 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2013-09-07 12:44:34', '2013-09-07 12:44:34', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2013-09-07 12:44:34', '2013-09-07 12:44:34', '', 0, 'http://www.andytan.net/tigers/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2013-09-07 12:44:34', '2013-09-07 12:44:34', 'This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2013-09-07 12:44:34', '2013-09-07 12:44:34', '', 0, 'http://www.andytan.net/tigers/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2013-10-20 03:58:23', '2013-10-20 03:58:23', '', 'Something', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2013-10-20 03:58:23', '2013-10-20 03:58:23', '', 4, 'http://www.andytan.net/tigers/uncategorized/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2013-10-20 03:58:23', '2013-10-20 03:58:23', '', 'Something', '', 'publish', 'open', 'open', '', 'something', '', '', '2013-10-20 03:58:23', '2013-10-20 03:58:23', '', 0, 'http://www.andytan.net/tigers/?p=4', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2013-11-10 02:42:32', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2013-11-10 02:42:32', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=7', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2013-11-10 02:43:26', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-10 02:43:26', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=8', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2013-11-10 02:43:26', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-10 02:43:26', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=9', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2013-11-10 11:34:36', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2013-11-10 11:34:36', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=10', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2013-11-10 11:35:02', '2013-11-10 11:35:02', '', 'Baby Ming Hao', '', 'publish', 'open', 'open', '', 'baby-ming-hao', '', '', '2013-11-10 11:35:02', '2013-11-10 11:35:02', '', 2, 'http://www.andytan.net/tigers/?page_id=11', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2013-11-10 11:35:02', '2013-11-10 11:35:02', '', 'Baby Ming Hao', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2013-11-10 11:35:02', '2013-11-10 11:35:02', '', 11, 'http://www.andytan.net/tigers/uncategorized/11-revision-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Monday 11. November 2013 04:23 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (9 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (3, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (4, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (6, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (4, 1, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Monday 11. November 2013 04:23 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (2 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'link_category', '', 0, 7) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Monday 11. November 2013 04:23 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (2 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Blogroll', 'blogroll', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Monday 11. November 2013 04:23 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (19 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'aim', '') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'yim', '') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'jabber', '') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '7') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_customize_current_theme_link,wp350_media') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'wp_user-settings', 'editor=tinymce&hidetb=1&libraryContent=browse') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'wp_user-settings-time', '1382243143') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Monday 11. November 2013 04:23 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'andy.tan2624', '$P$BIJNjFU5EZ3u/C/wMhI3gi1h/BfdvK1', 'admin', 'andy.tan2624@gmail.com', '', '2013-09-07 12:44:34', '', 0, 'admin') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

