# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Friday 13. September 2013 03:55 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Friday 13. September 2013 03:55 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (1 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2010-06-18 20:51:35', '2010-06-18 20:51:35', 'Hi, this is a comment.<br />To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Friday 13. September 2013 03:55 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (7 records)
#
 
INSERT INTO `wp_links` VALUES (1, 'http://codex.wordpress.org/', 'Documentation', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (2, 'http://wordpress.org/development/', 'WordPress Blog', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', 'http://wordpress.org/development/feed/') ; 
INSERT INTO `wp_links` VALUES (3, 'http://wordpress.org/extend/ideas/', 'Suggest Ideas', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (4, 'http://wordpress.org/support/', 'Support Forum', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (5, 'http://wordpress.org/extend/plugins/', 'Plugins', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (6, 'http://wordpress.org/extend/themes/', 'Themes', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (7, 'http://planet.wordpress.org/', 'WordPress Planet', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ;
#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Friday 13. September 2013 03:55 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=254 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (168 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'Gosford Junior Australian Football Club', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'andy.tan2624@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'links_recently_updated_prepend', '<em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'links_recently_updated_append', '</em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'links_recently_updated_time', '120', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'permalink_structure', '/%category%/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (36, 'active_plugins', 'a:2:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:45:"limit-login-attempts/limit-login-attempts.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'home', 'http://www.andytan.net/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (41, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'recently_edited', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'template', 'tigertheme', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'stylesheet', 'tigertheme', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (49, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'db_version', '24448', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'upload_path', '/home/andytann/public_html/tigers/wp-content/uploads', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (83, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'embed_size_w', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'embed_size_h', '600', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'page_on_front', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (101, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (204, '_site_transient_timeout_browser_2dd0f307078ee8a785a20cc124791357', '1379592171', 'yes') ; 
INSERT INTO `wp_options` VALUES (205, '_site_transient_browser_2dd0f307078ee8a785a20cc124791357', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"29.0.1547.65";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (102, 'ftp_credentials', 'a:3:{s:8:"hostname";s:9:"localhost";s:8:"username";N;s:15:"connection_type";s:3:"ftp";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (103, 'uninstall_plugins', 'a:0:{}', 'no') ; 
INSERT INTO `wp_options` VALUES (104, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, 'link_manager_enabled', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, 'initial_db_version', '15260', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (108, 'cron', 'a:5:{i:1379040283;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1379040414;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1379113200;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1379631600;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (117, 'rewrite_rules', 'a:72:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:31:".+?/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:".+?/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:".+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"(.+?)/([^/]+)/trackback/?$";s:57:"index.php?category_name=$matches[1]&name=$matches[2]&tb=1";s:46:"(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:41:"(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:34:"(.+?)/([^/]+)/page/?([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&paged=$matches[3]";s:41:"(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&cpage=$matches[3]";s:26:"(.+?)/([^/]+)(/[0-9]+)?/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&page=$matches[3]";s:20:".+?/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:".+?/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:".+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:26:"(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:33:"(.+?)/comment-page-([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&cpage=$matches[2]";s:8:"(.+?)/?$";s:35:"index.php?category_name=$matches[1]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (118, 'limit_login_retries', 'a:1:{s:3:"::1";i:2;}', 'no') ; 
INSERT INTO `wp_options` VALUES (237, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (251, '_site_transient_timeout_theme_roots', '1379017421', 'yes') ; 
INSERT INTO `wp_options` VALUES (252, '_site_transient_theme_roots', 'a:3:{s:10:"tigertheme";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (116, '_site_transient_update_themes', 'O:8:"stdClass":3:{s:12:"last_checked";i:1378987370;s:7:"checked";a:3:{s:10:"tigertheme";s:3:"2.0";s:14:"twentythirteen";s:3:"1.0";s:12:"twentytwelve";s:3:"1.2";}s:8:"response";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (119, 'limit_login_retries_valid', 'a:1:{s:3:"::1";i:1378669923;}', 'no') ; 
INSERT INTO `wp_options` VALUES (120, '_transient_random_seed', '05b1f52ae0bf7e1973415ec8bad6f650', 'yes') ; 
INSERT INTO `wp_options` VALUES (121, '_site_transient_timeout_browser_de48341fc1229faa5760dbf4f44462ec', '1379126815', 'yes') ; 
INSERT INTO `wp_options` VALUES (122, '_site_transient_browser_de48341fc1229faa5760dbf4f44462ec', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:12:"29.0.1547.62";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (123, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:29:"http://www.andytan.net/tigers";s:4:"link";s:105:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://www.andytan.net/tigers/";s:3:"url";s:138:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://www.andytan.net/tigers/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:26:"http://wordpress.org/news/";s:3:"url";s:31:"http://wordpress.org/news/feed/";s:5:"title";s:14:"WordPress Blog";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:28:"http://planet.wordpress.org/";s:3:"url";s:33:"http://planet.wordpress.org/feed/";s:5:"title";s:20:"Other WordPress News";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (232, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1379030575', 'no') ; 
INSERT INTO `wp_options` VALUES (233, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1378987375', 'no') ; 
INSERT INTO `wp_options` VALUES (234, '_transient_timeout_dash_aa95765b5cc111c56d5993d476b1c2f0', '1379030575', 'no') ; 
INSERT INTO `wp_options` VALUES (235, '_transient_dash_aa95765b5cc111c56d5993d476b1c2f0', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2013/09/12/brennen-byrne-employing-best-security-practices-for-wordpress-sites-2/\' title=\'     \'>WordPress.tv: Brennen Byrne: Employing Best Security Practices for WordPress Sites</a></li><li><a class=\'rsswidget\' href=\'http://lorelle.wordpress.com/2013/09/11/update-to-wordpress-3-6-1-now/\' title=\'It is upgrade time again. Time to upgrade your WordPress. WordPress 3.6.1 Maintenance and Security Release was announced today. It includes fixes to WordPress 3.6 and some security issues, so this is a mandatory update. WordPress.com users are automatically updated, as are all those on managed WordPress hosting like WP Engine. This update applies to […]\'>Lorelle on WP: Update to WordPress 3.6.1 Now</a></li><li><a class=\'rsswidget\' href=\'http://feedproxy.google.com/~r/WordpressTavern/~3/KrtiUhknbkM/wordpress-3-6-1-now-available\' title=\'WordPress 3.6.1 has been pushed out the door. This release comes 42 days after WordPress 3.6 was made available on August 1st. This is a maintenance package that contains bug and security fixes. You can find more information about this version via the Codex. If you don’t see any upgrade notices now, check again later. \'>WPTavern: WordPress 3.6.1 Now Available</a></li><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2013/09/wordpress-3-6-1/\' title=\'After nearly 7 million downloads of WordPress 3.6, we are pleased to announce the availability of version 3.6.1. This maintenance release fixes 13 bugs in version 3.6, which was a very smooth release. WordPress 3.6.1 is also a security release for all previous WordPress versions and we strongly encourage you to update your sites immediately. It addresses three issues fixed by the WordPress security team:  Block unsafe PHP unserialization that could occur in limited situations and setups, which can lead to remote code execution. Reported by Tom Van Goethem. Prevent a user with an Author role, using a specially crafted request, from being able to create a post “written by” another user. Reported by Anakorn Kyavatanakij. Fix insufficient input validation that could result in redirecting or leading a user to another website. Reported by Dave Cummo, a Northrup Grumman subcontractor for the U.S. Centers for Disease Control and Prevention.  Additionally, we’ve adjusted security restrictions around file uploads to mitigate the potential for cross-site scripting. We appreciated responsible disclosure of these issues directly to our security team. For more information on the changes, see the release notes or consult the list of changes. Download WordPress 3.6.1 or update now from the Dashboard → Updates menu in your site’s admin area.\'>Dev Blog: WordPress 3.6.1 Maintenance and Security Release</a></li><li><a class=\'rsswidget\' href=\'http://feedproxy.google.com/~r/WordpressTavern/~3/IBMI8JljEcI/open-source-alternatives-to-pressgram\' title=\'Last week’s big news was the launch of the Pressgram app which allows you to publish filtered photos to your WordPress blog. Soon after the launch, controversy sprung up concerning Pressgram’s terms of service, proprietary license and security.  Closer examination of Pressgram’s Terms of Service revealed gaping holes where the notion of owning your own data is concerned. They quickly moved to revise their TOS to clarify that they can reproduce, modify and adapt your content for use within the app to provide the social networking aspect: By submitting Content to Pressgram for inclusion on your User account, you grant Pressgram a world-wide, royalty-free, and non-exclusive license to reproduce, modify, adapt and publish the Content solely for the purpose of displaying, distributing and promoting your Content in the app (e.g. displaying your photos within the app to your social network and friends). Through all of this discussion, we discovered that many publishers have no desire to be part of another social network, so the middle man aspect of Pressgram using member photos within their app doesn’t make much sense to them. Also, despite being wholly dependent on WordPress to publish photos to the user’s blog, the app maintains a proprietary license. Those who wish to hold true to open source principles may be interested in an alternative to the Pressgram service.  Open Source Tools for Publishing Filtered Photos to WordPress Publishing filtered photos to your WordPress site is actually very easy to accomplish using only open source software. Obviously you could use the WordPress mobile app for your device, but this may be even more than you need.  One very easy way is to set up posting by email – yes, finally a fun use for a very old WordPress feature. The two components necessary for this include:   Mobile app for filtering the photos WordPress plugin for retrieving emails  This solution doesn’t take more than 5 minutes to set up. It’s ideal for those who want to publish filtered photos and own their own work entirely, without becoming part of a social network. 1. Download an open source mobile app for filtering photos. 2. Create an email address known only to you. 3. Install and configure a plugin that lets you post to WordPress via email. Open Source Mobile Apps for Filtered Photos Anypic Anypic is an open source iOS app for filtering photos, among other features. Their website actually encourages you to download the source code and tinker with it as you please.  They even offer a tutorial to help you fork their code to create your own version of Anypic.   Trovebox Trovebox, formerly known as OpenPhoto, is another open source option with apps for Android, iPhone and iPad. They offer a community edition on github that you can grab, hack, re-purpose and improve upon, if you want.  Backspaces The Backspaces app was created as an open source version of Instagram and its code is readily available on github. Their developers utilized Brad Larson’s GPUImage, an open source iOS framework for GPU-based image and video processing. If you don’t want to use the Backspaces service but just want to grab the filters, you may find DLCImagePickerController to be useful.  Putting It All Together With WordPress The great thing about all of the options mentioned above is that if you don’t want to use the service outright or don’t like the terms, you can simply grab the code, change it to suit your needs or make your own photo-sharing app. There is also a large number of filtered photo service apps that do not require you to sign up in order to use the filtering capabilities on your device. Use the app to add filters to your photos and then share via email to your WordPress site – it’s just that easy. Once you’ve selected an app to filter your photos, the next steps are very easy.  Set Up An Email Address For Sending Photos This email address should be known only to you, as it will be used to publish photos directly to your WordPress site. Don’t publish the address anywhere on the web or you will undoubtedly get a ton of spam flowing through. Keep it secret, keep it safe. ;) Configure Postie or Jetpack’s Post By Email to Publish Your Pictures For my test, I used Postie, but you could just as easily use Jetpack’s Post by Email or another plugin, depending on your needs for customizing the posts. The convenient thing about Jetpack’s Post by Email is that you don’t have to set up a separate email address. if you like, you can combine it with Publicize to automate further sharing of your filtered photos to social networks. With Postie there are many options for customizing how often WordPress checks for mail, role access for multi-author posting, category, tags, post status for incoming mails, post format, image sizing, post templates and much more. Here is a quick example of filtered photos + Postie in action on a blog:  Creating a new email and configuring the plugin took less than 5 minutes to set up. From there you can customize your WordPress site to have a unique design for your photo posts and category archives. You don’t even have to make the posts public if you don’t want to. Set them all to private via the plugin’s settings and you have an easily searchable archive of your mobile images. Advantages of Publishing Filtered Photos to WordPress via Email: There are numerous reasons why you might want to opt for posting to your own blog via email, not the least of which is privacy. If you don’t want your photos circulating within a social network, this may be the best and easiest way to ensure that all the traffic goes to your site.  You don’t have to worry about any nasty terms of service or use a middle man of any kind. The images go directly from your device to your blog. You can even have them instantly deleted from the photo email account that you set up. The posting process is also not specific to your mobile device, since all devices offer the ability to share images via email. Perhaps the most important advantage of posting your photos to WordPress via email is that this method allows you to stay true to open source principles. There’s no compromise when you don’t have to entrust your images to a third party service.  \'>WPTavern: Open Source Alternatives to Pressgram</a></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (238, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1378998998', 'yes') ; 
INSERT INTO `wp_options` VALUES (239, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3898";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2456";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2344";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1930";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1856";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1583";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1329";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1325";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1310";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1260";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1225";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1121";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1000";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"982";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"974";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"950";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"844";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"821";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"780";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"722";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"686";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"681";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"678";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"623";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"615";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"595";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"572";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"570";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"541";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"539";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"530";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"522";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"506";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"505";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"471";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"458";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"453";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"452";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"436";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"432";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (138, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (241, 'hmbkp_default_path', '/Applications/MAMP/htdocs/tigers/wp-content/backupwordpress-43bcb68547-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (242, 'hmbkp_path', '/Applications/MAMP/htdocs/tigers/wp-content/backupwordpress-43bcb68547-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (224, '_transient_timeout_feed_mod_77fa140e07ce53fe8c87136636f83d72', '1379030574', 'no') ; 
INSERT INTO `wp_options` VALUES (225, '_transient_feed_mod_77fa140e07ce53fe8c87136636f83d72', '1378987374', 'no') ; 
INSERT INTO `wp_options` VALUES (222, '_transient_timeout_feed_77fa140e07ce53fe8c87136636f83d72', '1379030574', 'no') ; 
INSERT INTO `wp_options` VALUES (223, '_transient_feed_77fa140e07ce53fe8c87136636f83d72', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/plugins/browse/new/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Sep 2013 11:50:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"MasterBlogster Scroll Top and Bottom";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/plugins/masterblogster-scroll-top-and-bottom/#post-58085";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 08 Sep 2013 06:10:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58085@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"MasterBlogster scroll top and bottom plugin adds scroll button to your WordPress website to smoothly scroll to top and bottom areas.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"shrinitech";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"Woocommerce PayBox Payment Gateway";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wordpress.org/plugins/woocommerce-paybox-gateway/#post-58054";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Sep 2013 15:59:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58054@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"PayBox payment gateway for woocommerce.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"swoelffel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"GroupDocs Comparison";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"http://wordpress.org/plugins/groupdocs-comparison/#post-58048";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Sep 2013 08:46:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58048@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"The GroupDocs Comparison plugin for WordPress allows you to embed and compare two Word documents, as well as PDF files and Excel spreadsheets from wit";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"groupdocs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Easy Contact Form Solution";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wordpress.org/plugins/easy-contact-form-solution/#post-58134";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Sep 2013 07:57:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58134@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:76:"Extremely simple Contact Form, that help you to manage your contact details.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"PankajAgarwal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Thoughts Of The Day";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/plugins/thoughts-of-the-day/#post-58135";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Sep 2013 11:45:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58135@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:143:"This Plugin is to manage and show daily thought, admin can add thoughts in each line for each day and will show the each line according to day.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Mejar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"LinkedIn Auto Publish";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.org/plugins/linkedin-auto-publish/#post-57979";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Sep 2013 09:25:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"57979@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:40:"Publish posts automatically to LinkedIn.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"f1logic";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Customize Login Image";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.org/plugins/customize-login-image/#post-58076";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 07 Sep 2013 17:40:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58076@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:95:"This plugin allows you to customize the image and the appearance of the WordPress Login Screen.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"apasionados";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WP images lazy loading";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/wp-images-lazy-loading/#post-58077";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 07 Sep 2013 17:42:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58077@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:43:"Add jQuery lazy loading to WordPress images";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Petrichorpost";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"Yet Another Social Media Icon Plugin (YASIP)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"http://wordpress.org/plugins/yasip/#post-58082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 08 Sep 2013 00:08:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58082@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"This plugin/widget allows you to insert icon links to your social profiles in any widgetized area.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"mitchbartlett";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"Link opencart";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/opencart-link/#post-58130";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Sep 2013 05:10:28 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58130@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:128:"Link opencart, is a wordpress plugin that connects to the opencart database and displays random products in your wordpress site.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"ezecom";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Contact Form 7 Tag field";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://wordpress.org/plugins/contact-form-7-tag-field/#post-57917";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Sep 2013 14:17:28 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"57917@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:112:"Contact Form 7 - Add a new field to the module that enables the user to add tags to his message via a tag field.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Apprique Ltd.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Redirect Front-end";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/redirect-front-end/#post-58052";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Sep 2013 14:22:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58052@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"A small plugin that lets you &#34;hide&#34; the front-end of a site, redirecting to the WP Dashboard.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Josh Eaton";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:13:"QQWorld Share";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/qqworld-share/#post-58063";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 07 Sep 2013 01:57:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58063@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:74:"Powerful share tools for SNS, MicroBlog, Blog, Bootmark, Mainly for China.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Michael Wang";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Remove Uppercase Accents";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://wordpress.org/plugins/remove-uppercase-accents/#post-58158";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Sep 2013 22:18:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58158@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Automatically removes accented characters from text content uppercase transformed through CSS.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:21:"Giorgos Sarigiannidis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"Teachers Notebook FREE K-12 Teaching Tips Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wordpress.org/plugins/teachers-notebook-teaching-tips-widget/#post-58036";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Sep 2013 18:58:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"58036@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:137:"Plugin to add a Teachers Notebook FREE K-12 Teaching Tips widget to the sidebar or footer, or embed into a page or post using shortcodes.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"TN-WPAdmin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:41:"http://wordpress.org/plugins/rss/view/new";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:7:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 12 Sep 2013 12:02:54 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Sun, 08 Sep 2013 06:10:43 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130908064941";}', 'no') ; 
INSERT INTO `wp_options` VALUES (226, '_transient_timeout_plugin_slugs', '1379074704', 'no') ; 
INSERT INTO `wp_options` VALUES (227, '_transient_plugin_slugs', 'a:4:{i:0;s:19:"akismet/akismet.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:2;s:9:"hello.php";i:3;s:45:"limit-login-attempts/limit-login-attempts.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (228, '_transient_timeout_dash_de3249c4736ad3bd2cd29147c4a0d43e', '1379030574', 'no') ; 
INSERT INTO `wp_options` VALUES (229, '_transient_dash_de3249c4736ad3bd2cd29147c4a0d43e', '<h4>Most Popular</h4>
<h5><a href=\'http://wordpress.org/plugins/jetpack/\'>Jetpack by WordPress.com</a></h5>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=jetpack&amp;_wpnonce=afca605ed0&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Jetpack by WordPress.com\'>Install</a>)</span>
<p>Supercharge your WordPress site with powerful features previously only available to WordPress.com users.</p>
<h4>Newest Plugins</h4>
<h5><a href=\'http://wordpress.org/plugins/thoughts-of-the-day/\'>Thoughts Of The Day</a></h5>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=thoughts-of-the-day&amp;_wpnonce=127ced73c3&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Thoughts Of The Day\'>Install</a>)</span>
<p>This Plugin is to manage and show daily thought, admin can add thoughts in each line for each day and will show the each line according to day.</p>
', 'no') ; 
INSERT INTO `wp_options` VALUES (240, '_site_transient_update_plugins', 'O:8:"stdClass":3:{s:12:"last_checked";i:1378988303;s:7:"checked";a:4:{s:19:"akismet/akismet.php";s:5:"2.5.9";s:35:"backupwordpress/backupwordpress.php";s:5:"2.3.3";s:9:"hello.php";s:3:"1.6";s:45:"limit-login-attempts/limit-login-attempts.php";s:5:"1.7.1";}s:8:"response";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (230, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1379030575', 'no') ; 
INSERT INTO `wp_options` VALUES (231, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WordPress.tv: Brennen Byrne: Employing Best Security Practices for WordPress Sites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21708";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"http://wordpress.tv/2013/09/12/brennen-byrne-employing-best-security-practices-for-wordpress-sites-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:733:"<div id="v-lQSifts6-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21708/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21708/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21708&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/12/brennen-byrne-employing-best-security-practices-for-wordpress-sites-2/"><img alt="Brennen Byrne: Employing Best Security Practices for WordPress Sites" src="http://videos.videopress.com/lQSifts6/employing-best-security-practices_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Sep 2013 10:54:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"Lorelle on WP: Update to WordPress 3.6.1 Now";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:37:"http://lorelle.wordpress.com/?p=10321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://lorelle.wordpress.com/2013/09/11/update-to-wordpress-3-6-1-now/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:517:"It is upgrade time again. Time to upgrade your WordPress. WordPress 3.6.1 Maintenance and Security Release was announced today. It includes fixes to WordPress 3.6 and some security issues, so this is a mandatory update. WordPress.com users are automatically updated, as are all those on managed WordPress hosting like WP Engine. This update applies to [&#8230;]<img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=lorelle.wordpress.com&blog=72&post=10321&subd=lorelle&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Sep 2013 04:59:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Lorelle VanFossen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WPTavern: WordPress 3.6.1 Now Available";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=9100";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://feedproxy.google.com/~r/WordpressTavern/~3/KrtiUhknbkM/wordpress-3-6-1-now-available";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:657:"<p><a href="http://wordpress.org/news/2013/09/wordpress-3-6-1/" title="http://wordpress.org/news/2013/09/wordpress-3-6-1/">WordPress 3.6.1</a> has been pushed out the door. This release comes 42 days after WordPress 3.6 was made available on August 1st. This is a maintenance package that contains bug and security fixes. You can find more information about this version <a href="http://codex.wordpress.org/Version_3.6.1" title="http://codex.wordpress.org/Version_3.6.1">via the Codex.</a> If you don&#8217;t see any upgrade notices now, check again later.</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/KrtiUhknbkM" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Sep 2013 21:05:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"Dev Blog: WordPress 3.6.1 Maintenance and Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2675";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/09/wordpress-3-6-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2020:"<p>After <a href="http://wordpress.org/download/counter/">nearly 7 million downloads</a> of WordPress 3.6, we are pleased to announce the availability of version 3.6.1. This maintenance release <a href="http://core.trac.wordpress.org/query?status=closed&group=resolution&milestone=3.6.1">fixes 13 bugs</a> in version 3.6, which was a very smooth release.</p>
<p><strong>WordPress 3.6.1 is also a security release for all previous WordPress versions</strong> and we strongly encourage you to update your sites immediately. It addresses three issues fixed by the WordPress security team:</p>
<ul>
<li>Block unsafe PHP unserialization that could occur in limited situations and setups, which can lead to remote code execution. Reported by <a href="http://vagosec.org/" rel="nofollow">Tom Van Goethem</a>.</li>
<li>Prevent a user with an Author role, using a specially crafted request, from being able to create a post &#8220;written by&#8221; another user. Reported by <a href="http://anakornk.wordpress.com/" rel="nofollow">Anakorn Kyavatanakij</a>.</li>
<li>Fix insufficient input validation that could result in redirecting or leading a user to another website. Reported by Dave Cummo, a Northrup Grumman subcontractor for the <a href="http://www.cdc.gov/" rel="nofollow">U.S. Centers for Disease Control and Prevention</a>.</li>
</ul>
<p>Additionally, we&#8217;ve adjusted security restrictions around file uploads to mitigate the potential for cross-site scripting.</p>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these issues directly to our security team. For more information on the changes, see the <a href="http://codex.wordpress.org/Version_3.6.1">release notes</a> or consult <a href="http://core.trac.wordpress.org/log/branches/3.6?stop_rev=24972&rev=25345">the list of changes</a>.</p>
<p><a href="http://wordpress.org/wordpress-3.6.1.zip">Download WordPress 3.6.1</a> or update now from the Dashboard → Updates menu in your site&#8217;s admin area.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Sep 2013 20:48:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"WPTavern: Open Source Alternatives to Pressgram";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=9033";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:99:"http://feedproxy.google.com/~r/WordpressTavern/~3/IBMI8JljEcI/open-source-alternatives-to-pressgram";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:9337:"<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/pressgram.png" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/pressgram.png?resize=150%2C150" alt="pressgram" class="alignright size-full wp-image-9070" /></a>Last week&#8217;s big news was the <a href="http://www.wptavern.com/pressgram-launches-wordpress-powered-photo-sharing-app" target="_blank">launch of the Pressgram app</a> which allows you to publish filtered photos to your WordPress blog. Soon after the launch, controversy sprung up concerning Pressgram&#8217;s <a href="http://stephanis.info/2013/09/06/pressgram-tos/" target="_blank">terms of service</a>, proprietary license and <a href="http://stephanis.info/2013/09/06/pressgram-security-concerns/" target="_blank">security</a>. <span id="more-9033"></span></p>
<p>Closer examination of Pressgram&#8217;s Terms of Service revealed gaping holes where the notion of owning your own data is concerned. They quickly moved to revise their <a href="http://blog.pressgr.am/legal/tos/" target="_blank">TOS</a> to clarify that they can reproduce, modify and adapt your content for use within the app to provide the social networking aspect:</p>
<blockquote><p>By submitting Content to Pressgram for inclusion on your User account, you grant Pressgram a world-wide, royalty-free, and non-exclusive license to reproduce, modify, adapt and publish the Content solely for the purpose of displaying, distributing and promoting your Content in the app (e.g. displaying your photos within the app to your social network and friends).</p></blockquote>
<p>Through all of this discussion, we discovered that many publishers have no desire to be part of another social network, so the middle man aspect of Pressgram using member photos within their app doesn&#8217;t make much sense to them.</p>
<p>Also, despite being wholly dependent on WordPress to publish photos to the user&#8217;s blog, the app maintains a proprietary license. Those who wish to hold true to open source principles may be interested in an alternative to the Pressgram service. </p>
<h2>Open Source Tools for Publishing Filtered Photos to WordPress</h2>
<p>Publishing filtered photos to your WordPress site is actually very easy to accomplish using only open source software. Obviously you could use the WordPress mobile app for your device, but this may be even more than you need. </p>
<p><strong>One very easy way is to set up posting by email &#8211; yes, finally a fun use for a very old WordPress feature.</strong></p>
<p>The two components necessary for this include: </p>
<ul>
<li>Mobile app for filtering the photos</li>
<li>WordPress plugin for retrieving emails</li>
</ul>
<p>This solution doesn&#8217;t take more than 5 minutes to set up. It&#8217;s ideal for those who want to publish filtered photos and own their own work entirely, without becoming part of a social network.</p>
<p>1. Download an open source mobile app for filtering photos.<br />
2. Create an email address known only to you.<br />
3. Install and configure a plugin that lets you post to WordPress via email.</p>
<h3>Open Source Mobile Apps for Filtered Photos</h3>
<h4>Anypic</h4>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/anypic-175.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/anypic-175.jpg?resize=150%2C150" alt="anypic-175" class="alignright size-thumbnail wp-image-9077" /></a><a href="https://anypic.org/" target="_blank">Anypic</a> is an open source iOS app for filtering photos, among other features. Their website actually encourages you to download the <a href="https://github.com/ParsePlatform/Anypic" target="_blank">source code</a> and tinker with it as you please. </p>
<p>They even offer a <a href="https://parse.com/tutorials/anypic" target="_blank">tutorial</a> to help you fork their code to create your own version of Anypic.  </p>
<h4>Trovebox</h4>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/trovebox.png" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/trovebox.png?resize=150%2C150" alt="trovebox" class="alignright size-thumbnail wp-image-9080" /></a><a href="https://trovebox.com/" target="_blank">Trovebox</a>, formerly known as OpenPhoto, is another open source option with apps for Android, iPhone and iPad. They offer a <a href="https://github.com/photo" target="_blank">community edition on github</a> that you can grab, hack, re-purpose and improve upon, if you want. </p>
<h4>Backspaces</h4>
<p>The <a href="http://backspac.es/" target="_blank">Backspaces</a> app was created as an open source version of Instagram and its code is readily available on <a href="https://github.com/gobackspaces" target="_blank">github</a>. Their developers utilized Brad Larson&#8217;s <a href="https://github.com/BradLarson/GPUImage" target="_blank">GPUImage</a>, an open source iOS framework for GPU-based image and video processing. If you don&#8217;t want to use the Backspaces service but just want to grab the filters, you may find <a href="https://github.com/gobackspaces/DLCImagePickerController" target="_blank">DLCImagePickerController</a> to be useful.</p>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/filters.png" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/filters.png?resize=560%2C280" alt="filters" class="aligncenter size-full wp-image-9089" /></a></p>
<h2>Putting It All Together With WordPress</h2>
<p>The great thing about all of the options mentioned above is that if you don&#8217;t want to use the service outright or don&#8217;t like the terms, you can simply grab the code, change it to suit your needs or make your own photo-sharing app.</p>
<p>There is also a large number of filtered photo service apps that do not require you to sign up in order to use the filtering capabilities on your device. Use the app to add filters to your photos and then share via email to your WordPress site &#8211; it&#8217;s just that easy.</p>
<p>Once you&#8217;ve selected an app to filter your photos, the next steps are very easy. </p>
<h5>Set Up An Email Address For Sending Photos</h5>
<p>This email address should be known only to you, as it will be used to publish photos directly to your WordPress site. Don&#8217;t publish the address anywhere on the web or you will undoubtedly get a ton of spam flowing through. <em>Keep it secret, keep it safe.</em> ;)</p>
<h5>Configure Postie or Jetpack&#8217;s Post By Email to Publish Your Pictures</h5>
<p>For my test, I used <a href="http://wordpress.org/plugins/postie/" target="_blank">Postie</a>, but you could just as easily use <a href="http://jetpack.me/support/post-by-email/" target="_blank">Jetpack&#8217;s Post by Email</a> or another plugin, depending on your needs for customizing the posts. The convenient thing about Jetpack&#8217;s Post by Email is that you don&#8217;t have to set up a separate email address. if you like, you can combine it with <a href="http://jetpack.me/support/publicize/" target="_blank">Publicize</a> to automate further sharing of your filtered photos to social networks.</p>
<p>With Postie there are many options for customizing how often WordPress checks for mail, role access for multi-author posting, category, tags, post status for incoming mails, post format, image sizing, post templates and much more.</p>
<p>Here is a quick example of filtered photos + Postie in action on a blog:</p>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/postie-example.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/postie-example.jpg?resize=560%2C664" alt="postie-example" class="aligncenter size-full wp-image-9035" /></a></p>
<p>Creating a new email and configuring the plugin took less than 5 minutes to set up. From there you can customize your WordPress site to have a unique design for your photo posts and category archives. You don&#8217;t even have to make the posts public if you don&#8217;t want to. Set them all to private via the plugin&#8217;s settings and you have an easily searchable archive of your mobile images.</p>
<h3>Advantages of Publishing Filtered Photos to WordPress via Email:</h3>
<p>There are numerous reasons why you might want to opt for posting to your own blog via email, not the least of which is privacy. If you don&#8217;t want your photos circulating within a social network, this may be the best and easiest way to ensure that all the traffic goes to your site.  You don&#8217;t have to worry about any nasty terms of service or use a middle man of any kind. The images go directly from your device to your blog. You can even have them instantly deleted from the photo email account that you set up. The posting process is also not specific to your mobile device, since all devices offer the ability to share images via email.</p>
<p>Perhaps the most important advantage of posting your photos to WordPress via email is that this method allows you to stay true to open source principles. There&#8217;s no compromise when you don&#8217;t have to entrust your images to a third party service. </p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/IBMI8JljEcI" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Sep 2013 20:27:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:106:"WordPress.tv: Mika Epstein: Lightning Talk – Rolling Your WordPress Support Character (Without Any Code)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=22194";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.tv/2013/09/11/mika-epstein-lightning-talk/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:711:"<div id="v-1ylUvDoT-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/22194/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/22194/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=22194&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/11/mika-epstein-lightning-talk/"><img alt="Mika Epstein: Lightning Talk &#8211; Rolling Your WordPress Support Character (Without Any Code)" src="http://videos.videopress.com/1ylUvDoT/3-lightning-talks-copy-02_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Sep 2013 12:51:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WordPress.tv: Eric Mann: Lightning Talk – The Future of WordPress Lies in the Past";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=22196";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://wordpress.tv/2013/09/11/eric-mann-lightning-talk-the-future-of-wordpress-lies-in-the-past/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:727:"<div id="v-DJNDyd9i-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/22196/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/22196/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=22196&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/11/eric-mann-lightning-talk-the-future-of-wordpress-lies-in-the-past/"><img alt="Eric Mann: Lightning Talk &#8211; The Future of WordPress Lies in the Past" src="http://videos.videopress.com/DJNDyd9i/3-lightning-talks-copy-03_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Sep 2013 12:44:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"Matt: On the Way to the Post Office";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=42982";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://ma.tt/2013/09/on-the-way-to-the-post-office/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:558:"<blockquote><p>I was a weird kid.</p>
<p>I’d write and painstakingly edit endless paragraphs in which I’d riff on current events and major news items. Then I’d take a floppy disk to my local copy store where I’d print out the pages and bind them with card stock covers, before heading to the post office to mail the completed tome to just about everyone I knew.</p></blockquote>
<p><a href="http://nextdraft.com/2013/09/08/a-funny-thing-happened-on-the-way-to-the-post-office/">Dave Pell: A Funny Thing Happened on the Way to the Post Office</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Sep 2013 03:36:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WPTavern: This Week On WordPress Weekly – John James Jacoby";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=9008";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:109:"http://feedproxy.google.com/~r/WordpressTavern/~3/qycRs-itLIE/this-week-on-wordpress-weekly-john-james-jacoby";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:776:"<p>On Friday September 13th, <a href="http://johnjamesjacoby.com/" title="http://johnjamesjacoby.com/">John James Jacoby</a> will be our special guest on <a href="http://www.wptavern.com/wordpress-weekly" title="http://www.wptavern.com/wordpress-weekly">WordPress Weekly</a>. This will be the first time JJJ has been on the show. We&#8217;ll have a ton to talk about such as his recent job change from Automattic to 10UP, his passion for community, and of course, what&#8217;s happening with the bb&#8217;s BuddyPress and bbPress. The only thing we&#8217;ll have to watch out for is his rumored charm! </p>
<p>As always, please submit your questions for JJJ in the comments. </p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/qycRs-itLIE" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Sep 2013 21:00:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:83:"WPTavern: WordPress 3.7 to Remove Post By Email Feature in Favor of Official Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=8974";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:135:"http://feedproxy.google.com/~r/WordpressTavern/~3/-0XcYG7asXA/wordpress-3-7-to-remove-post-by-email-feature-in-favor-of-official-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:8502:"<p>The option to post by email will be <a href="http://core.trac.wordpress.org/ticket/22942" target="_blank">removed from the WordPress core</a> in the 3.7 release. As WordPress evolves, there are some lesser-used features that would be better served as a plugin, in favor of keeping the core leaner. Such is the case with the post by email feature, but don&#8217;t worry &#8211; WordPress won&#8217;t leave current users out in the cold. A plugin is in the works that will be the official replacement, providing a virtually seamless transition for posting by email when 3.7 is released.<span id="more-8974"></span></p>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/kat-hagan.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/kat-hagan.jpg?resize=262%2C300" alt="kat-hagan" class="alignright size-medium wp-image-9005" /></a>That&#8217;s where Kat Hagan jumped in to contribute. Kat has been working as a WordPress freelancer and was recently selected for an internship with WordPress as part of the <a href="https://wiki.gnome.org/OutreachProgramForWomen" target="_blank">Free and Open Source Software Outreach Program for Women</a>. The program was inspired by <a href="http://code.google.com/soc" title="Google Summer of Code" target="_blank">Google Summer of Code</a> and was created because so few women applied for participation in GSOC. The Outreach Program for Women (OPW) sponsored Kat Hagan to work on WordPress and last week she released version 1.0 of the new <a href="http://wordpress.org/plugins/post-by-email/" title="WordPress Post By Email plugin" target="_blank">Post By Email plugin</a>.</p>
<p>I checked in with Kat to find out what she plans for the future of the plugin. I was curious as to why she selected Post By Email as the project for her internship, and she replied:</p>
<blockquote><p>I was reading through the list of suggested WP projects, and Post By Email was something that jumped out at me as having a lot of potential.</p>
<p>I knew it would give me the opportunity to learn about some areas of the WordPress code that I hadn&#8217;t had much chance to dig into, and I liked that it was very open-ended in terms of which features would be a part of the project.  I also noticed while researching it that it was sort of an abandoned feature &#8212; the code in Core was buggy, there were Trac tickets that had been open for years, but I also saw a lot of comments from folks who were using the functionality and wanted to see it revisited.  So I guess you could say it appealed to my desire to work on something that needed love.</p></blockquote>
<p>The post by email functionality in core is on track to be deprecated in 3.7. Hagan has submitted a patch, which is now awaiting review. The patch essentially removes the functionality from the WordPress core without deleting the settings. Current users of the native post by email functionality will have a seamless experience installing the new plugin and migrating their settings. </p>
<p>Hagan had a number of challenges during her internship, both in building this new plugin and adjusting to a new community workflow: </p>
<blockquote><p>I chose to incorporate a third-party library for retrieving and parsing emails, which was fairly difficult.  Documentation was scanty (when it existed at all), and the library wasn&#8217;t really written to be used in a standalone way, so I spent a lot of time digging through the source, duct-taping stuff together and figuring out how it worked by experimentation.  I&#8217;m glad I chose this route, though, since it&#8217;s saved me a lot of time in implementing new features (not to mention spared me the bugs I would certainly have introduced in reinventing this particular wheel).</p>
<p>From a non-technical standpoint, just learning how the WordPress community works was a significant challenge.  As someone who&#8217;s never worked on open source software before, I&#8217;m used to projects having a very clear hierarchy and schedule &#8212; you have a manager or a tech lead who acts as the final arbiter of what gets done, how it gets done and when.  In WordPress land, it&#8217;s much more democratic: while there are loose areas of responsibility, everyone joins in the discussion about how to implement things and what to focus on.  It was a bit overwhelming at first!</p></blockquote>
<h3>How is the Post By Email plugin different from Postie or Jetpack&#8217;s post by email feature?</h3>
<p>You may be wondering, as I was, how the new plugin differs from counterparts such as <a href="http://wordpress.org/plugins/postie/" target="_blank">Postie</a> and <a href="http://jetpack.me/support/post-by-email/" target="_blank">Jetpack&#8217;s Post By Email</a>, both of which already do almost everything one could imagine. Hagan&#8217;s plugin was built for a different purpose. </p>
<blockquote><p>For starters, it&#8217;s not as full-featured, at least not yet; we wanted a canonical plugin that, while it doesn&#8217;t necessarily have all the bells and whistles, makes it fairly easy for anyone who&#8217;s been using the existing functionality up to this point to migrate over.  I do think they fulfill slightly different needs.  Postie allows a lot of customization, almost like a template (e.g. specifying start and end, excerpts, post format) and Jetpack&#8217;s Post By Email integrates support for other features used on wordpress.com, like polls.  Jetpack also uses an auto-generated wordpress.com email address instead of connecting to a third-party email account.</p></blockquote>
<p>The good news here is that when the changes happen in WordPress 3.7, users will have a lot of options for continuing their posting by email. I asked Kat if she&#8217;ll be adding in all the new features that were outlined in her <a href="http://codebykat.wordpress.com/2013/06/15/post-by-email-proposal-v2/" target="_blank">original proposal</a> for the project. She replied, &#8220;I&#8217;m on track to finish everything, with two exceptions: multisite support was tabled for now (it&#8217;s a larger discussion) and replying to comments via email is going on the roadmap for a later version, since I know I won&#8217;t have time to do it justice.&#8221; The current version of the plugin actually adds support for HTML-formatted emails, a welcome addition for those who actively post by email.</p>
<h3>WordPress Gains a New Contributor</h3>
<p>Hagan plans to continue her support and development of the plugin after her internship has concluded. She very much enjoyed her software development internship with WordPress and looks forward to helping out in the future. &#8220;I&#8217;ve learned that WordPress is a wonderfully supportive community, and it&#8217;s been a blast meeting and working with everyone this summer,&#8221; she said.  &#8220;Open source projects can be intimidating, especially when they&#8217;re as large and active as WordPress, so I think having a more structured introduction is extremely helpful for folks who aren&#8217;t sure where to begin.  I know that having mentors and a well-defined project really made the difference for me.  I would definitely encourage anyone who&#8217;s eligible for an OPW or GSoC internship to apply to those programs.&#8221; </p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/opw.png" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/opw.png?resize=311%2C302" alt="opw" class="alignright size-full wp-image-9012" /></a>Are you interested to try your hand at an internship with WordPress or another open source project? <a href="https://wiki.gnome.org/OutreachProgramForWomen" title="Outreach Program For Women" target="_blank">Applications for OPW</a> will open in October 2013, with a deadline in early November. The next round runs from mid-December to mid-March. This is an excellent opportunity for any woman to get started contributing.  </p>
<p>The WordPress project has definitely benefited from offering mentors for interns and, in this case, the result is that the Post By Email functionality will happily live on as a plugin. Want to help out? Test the new <a href="http://wordpress.org/plugins/post-by-email/" title="WordPress Post by Email Plugin" target="_blank">Post By Email</a> plugin with a test email account and leave some feedback for Kat Hagan. </p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/-0XcYG7asXA" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Sep 2013 19:00:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:97:"WPTavern: The Daily Plugin – Remove Comment Links, Author Notes, Word File Embeds &amp; 6 More!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=8965";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:136:"http://feedproxy.google.com/~r/WordpressTavern/~3/cE9sIqDjp0U/the-daily-plugin-remove-comment-links-author-notes-word-file-embeds-6-more";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:7831:"<p>Lots of great new plugins have come across the wire in the WordPress Plugin Repository. Today we&#8217;re going to take a look at TSP Author&#8217;s Note for adding after-the-fact post notations from the author, WP No Base Permalink for removing the base /tag/ or /category/ from your permalink structure, Remove Links From Comments, a Username changer, a great way to embed Word files, tools to monitor social sharing on a per post basis, graphic visualization tools and an awesome new RSS embed plugin that I started implementing immediately after I discovered it!  Before we begin, remember to test and analyze the performance of these plugins on a staging site. You never know if plugins will play well together, or with themes for that matter. Make sure you make backups of the site and database. <span id="more-8965"></span></p>
<p><a title="TSP Author\'s Note" href="http://wordpress.org/plugins/tsp-authors-note/" target="_blank">TSP Authors Note</a> allows you to add author&#8217;s notes and after-thoughts to your blog posts and pages. This pairs with the plugin&#8217;s author box output, but the new &#8220;notes&#8221; can be added via shortcode. This enables you to go back and add your own &#8220;I told you so&#8221; passages to older posts, or the opportunity to highlight new findings, specific comments or anything else you need to reflect a new perspective on an old post. I found the plugin to be quite useful for a friend that does a lot of interviews about start-ups. He can use this for making notes on people&#8217;s later successes and milestones they faced in business along the way.</p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/rssthis.png" rel="thumbnail"><img class="alignleft  wp-image-8968" alt="RSS This Example" src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/rssthis.png?resize=165%2C180" /></a><a title="RSS This" href="http://wordpress.org/plugins/rss-this/" target="_blank">RSS This</a> is the crowning jewel for today&#8217;s batch of plugins. When building the station site for <a href="http://www.wpr.fm" title="http://www.wpr.fm">WordPress Radio</a>, I found the need to insert the most recent shows of each podcast that was featured. Using this plugin was a pleasure! It formatted each item in the site&#8217;s feed in a nice content box, including a thumbnail of the post&#8217;s featured image. The plugin is shortcode based and allows you to choose how many items are included in the feed. When used in multiple instances on the same page, the plugin&#8217;s shortcodes allow you to create a fast news or headline site from many sources on the same page. The &#8220;Read More&#8221; button goes straight back to the original article source on the home page where the feed item came from, allowing you to give proper link attribution to the feed author. For me, this is a perfect solution to save me the weekly time burden of manually adding news or content items to the site.</p>
<p><a title="WP No Base Permalink" href="http://wordpress.org/plugins/wp-no-base-permalink/" target="_blank">WP No Base Permalink</a> optionally removes the base function from your category or tags in your permalinks. The &#8220;base&#8221; is always a dead ringer for identifying an off-the-rack WordPress site and something that my development project users can&#8217;t stand. It is both Multisite and WPML compatible as well. Previously I had used two different plugins to accomplish this task, but now I can remove or rename the tag and category bases with just one plugin. If this benchmarks as a faster solution when compared to the simultaneous load time of the other 2 plugins I use, I can think of at least 50 domains I will use it on.</p>
<p><a title="Remove Links From Comments" href="http://wordpress.org/plugins/remove-links-from-comments/" target="_blank">Remove Links From Comments</a> helps to ease a bit of the spamming going on within your comments. It will remove the option to add a website within the comment form, and in addition removes all the hyperlinks within the comment content itself. Be careful with this one, as more often than not, regular commenting users will drop links in their comments to relevant sites relating to your post. This plugin would discourage that, as well as showing the home page of your comment providers.</p>
<p><a title="Username" href="http://wordpress.org/plugins/username/" target="_blank">Username</a> allows you to change the username of the admin. This has been a need of mine for some time, especially when creating sites for others. Sometimes &#8220;admin&#8221; just doesn&#8217;t click with a new WordPress user and they just need it to be &#8220;Tom&#8221; instead. This one does the trick nicely. In the instance of multiple admins, each individual administrator has the ability to change their username in the user panel. There is a degree of duplicate protection, as it will not allow you to change to a user name that already exists.</p>
<p><a title="Attachments++" href="http://wordpress.org/plugins/attachments-plus-plus/" target="_blank">Attachments++</a> allows you the option to embed popular file formats such as Excel, Word, and other kinds of audio and video media files. If you&#8217;d like the ability to publish Word files on your WordPress site, here&#8217;s the plugin for you! I tried it on a test site and it worked well with a few CSS width modifications. With the pending Health care changes here in the U.S., there will be a need for a lot of new patient forms and similar items. This plugin lets them read the document on the site with the option to download for offline printing. It would be nice to see more internal on-site print options, but overall worth a look if you need a solution for this common design request issue.</p>
<p><a title="Admin Social Shares" href="http://wordpress.org/plugins/admin-social-shares/" target="_blank">Admin Social Shares</a> is a great plugin that displays how many social shares, likes and gestures of pleasure your posts and pages have received. It displays them neatly in the post list screen so that you can keep tabs on your most popular content in the social scene. This is an admin only plugin that works really well out of the gate. It provides an easy way to report regularly updated social shares to your authors, client and contributors. You can even use it as an internal scorecard among your authors to see who gets the most social approval.</p>
<p><a title="Auto Post After Image Upload" href="http://wordpress.org/plugins/auto-post-after-image-upload/" target="_blank">Auto Post After Image Upload</a> is a great plugin for photographers that simply want to post their images without all the &#8220;upload images and then post&#8221; 2 step process. This plugin condenses the operation into one simple act. Every time you upload an image, it creates a post.</p>
<p><a title="WP GraphViz" href="http://wordpress.org/plugins/wp-graphviz/" target="_blank">WP-GraphViz</a> gives you the power to insert your own visual charts and relational site structures based on the powerful GraphViz framework. You may have seen the old social influence visibility graphs or site visibility graphs before. Now you can create your own within your WordPress posts. There are a lot of different types of niche applications for the visual representation provided by this plugin.</p>
<h2>Feedback Wanted</h2>
<p>Thanks for grinding through all these plugins with me today! I&#8217;m looking forward to reading the reaction and usage that people get from these plugins. As always you can contact me on Twitter <a title="Marcus Couch on Twitter" href="https://twitter.com/marcuscouch">@marcuscouch</a> or right here on WPTavern.com.</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/cE9sIqDjp0U" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Sep 2013 14:58:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Marcus Couch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:103:"WordPress.tv: Corey Freeman: Lightning Talk – Stop Tweaking (Setting Up a Blog Now for Success Later)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=22202";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:114:"http://wordpress.tv/2013/09/10/corey-freeman-lightning-talk-stop-tweaking-setting-up-a-blog-now-for-success-later/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:763:"<div id="v-s5dFMrZU-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/22202/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/22202/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=22202&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/10/corey-freeman-lightning-talk-stop-tweaking-setting-up-a-blog-now-for-success-later/"><img alt="Corey Freeman: Lightning Talk &#8211; Stop Tweaking (Setting Up a Blog Now for Success Later)" src="http://videos.videopress.com/s5dFMrZU/3-lightning-talks-copy-04_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Sep 2013 12:36:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:111:"WordPress.tv: Aaron Hockley: Lightning Talk – Social Photo Networking or Owning Your Content… Why Not Both?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=22203";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:120:"http://wordpress.tv/2013/09/10/aaron-hockley-lightning-talk-social-photo-networking-or-owning-your-content-why-not-both/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:777:"<div id="v-9Itm34Md-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/22203/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/22203/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=22203&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/10/aaron-hockley-lightning-talk-social-photo-networking-or-owning-your-content-why-not-both/"><img alt="Aaron Hockley: Lightning Talk &#8211; Social Photo Networking or Owning Your Content… Why Not Both?" src="http://videos.videopress.com/9Itm34Md/3-lightning-talks-copy-05_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Sep 2013 12:31:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"WPTavern: Xanga 2.0 Launches – Powered By WordPress?";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=8972";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"http://feedproxy.google.com/~r/WordpressTavern/~3/_c6XzD9VJTw/xanga-2-0-launches-powered-by-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6491:"<p>It started November 28th, 1999 before WordPress.com was even an idea. It was on this date that <a href="http://xanga.com" title="http://xanga.com">Xanga</a> launched an alpha version of their product. Before blogging really took off, there were these things called portals. Portals were websites dedicated to specific topics. To make a long story short, portals were one term used to describe blogs before they were called blogs. For more than 13 years, Xanga has existed on the web providing a home for those looking to publish their thoughts online. However, Xanga recently underwent a major restructuring both in terms of software and how they&#8217;ll do business in the future. <span id="more-8972"></span></p>
<div id="attachment_8980" class="wp-caption aligncenter"><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/Screen-Shot-2013-09-09-at-3.43.06-PM.png" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/Screen-Shot-2013-09-09-at-3.43.06-PM.png?resize=500%2C264" alt="Xanga In 1999" class="size-large wp-image-8980" /></a><p class="wp-caption-text">Xanga Launching In 1999</p></div>
<h2>Time For A Fundraiser</h2>
<p>On May 30th, 2013 <a href="http://thexangateam.xanga.com/2013/05/30/relaunching-xanga-a-fundraiser/" title="http://thexangateam.xanga.com/2013/05/30/relaunching-xanga-a-fundraiser/">Xanga announced plans</a> that contained two options. The first was to relaunch the service using WordPress as the platform while the second was to shut the site down. </p>
<blockquote><p>Door #1: We can’t afford to renew our expensive lease at our networking facility, so we would have to offer everyone a free download of their blog posts, and shut down the site. :(</p>
<p>Door #2: We would find a way to port Xanga to open source blogging software like WordPress, and reinvent the site together with the community.</p>
<p>We strongly favor Door #2, but need your help to pull it off.  It would require two things to open that door: time and money.</p></blockquote>
<p>On this same day, the <a href="https://xanga.crowdhoster.com/relaunch-xanga" title="https://xanga.crowdhoster.com/relaunch-xanga">relaunch campaign</a> was started with the goal to reach $60,000 by July 15th. During this process, John announced that if the Fundraiser could generate at least $50,000 that he would chip in the other $10,000. While the funding goal of $50,000 was exceeded ($58,640), they didn&#8217;t quite make the planned $60,000 but decided to go through with the relaunch of Xanga on the WordPress platform. </p>
<div id="attachment_8982" class="wp-caption aligncenter"><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/Screen-Shot-2013-09-09-at-7.30.15-PM.png" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/Screen-Shot-2013-09-09-at-7.30.15-PM.png?resize=500%2C248" alt="Xanga 2.0 Fundraiser" class="size-large wp-image-8982" /></a><p class="wp-caption-text">Xanga Surpasses Its Fundraising Goal</p></div>
<h2>I Know How They Feel</h2>
<p>Of particular interest to me are the comments on the relaunch post. Understandably, some people were upset while others wanted nothing to do with WordPress which is why some were using Xanga to begin with. Before I discovered WordPress, Joomla, and other Content Management Systems, I came across a site called <a href="http://web.archive.org/web/20080705143002/http://www.efx2blogs.com/" title="http://web.archive.org/web/20080705143002/http://www.efx2blogs.com/">EFx2blogs.com</a>. Knowing what WordPress.com is today, EFx2blogs was my WordPress.com. It featured a dedicated developer, an awesome tight-knit community, and an atmosphere that not only encouraged writing, but also checking out the posts of your neighbor. It was a great experience and I was really sad to see it go away. At least with Xanga, the owner/developers are sticking around and will be using WordPress as the foundation of their relaunched service. </p>
<p>As far as how Xanga will do business in the future, all new users will need to pay a subscription price in order to blog. </p>
<blockquote><p>
Because of this cost, we would have to move Xanga to a paid model, where bloggers pay for hosting for their blogs.  (Just being a member of Xanga would still be free though, so others could still subscribe to your site.)  We would enable our bloggers to pay in either money or time (through volunteering).  At first, though, we would only be able to offer money options &#8211; as we would need a significant amount of money to make the relaunch possible.  We would also include a gifting option, where you can buy a Xanga blogging membership for a friend&#8230; or earn one through volunteering, and gift that blogging membership to a friend.</p></blockquote>
<p>Paying Xanga means all blogs will be ad-free but at the cost of putting up a barrier to entry, something WordPress.com does not have. I love the idea of being able to gift certain aspects of the service to other accounts, <a href="http://en.blog.wordpress.com/2006/12/16/give-the-gift-of-wordpress-credits/" title="http://en.blog.wordpress.com/2006/12/16/give-the-gift-of-wordpress-credits/">something that WordPress.com added in 2006</a> but soon after removed.</p>
<h2>Only Time Will Tell</h2>
<p>When reading the <a href="http://thexangateam.xanga.com/2013/07/08/our-vision-for-xanga-2-0/" title="http://thexangateam.xanga.com/2013/07/08/our-vision-for-xanga-2-0/">vision for Xanga 2.0</a>, it becomes clear that initially, the service will just be a branded WordPress Multisite install. </p>
<blockquote><p>We’re incredibly excited about using the WordPress platform, as the publishing software is incredibly powerful. As we adapt it for use for Xanga 2.0, we’re working to make sure that all that power is combined with the warm fuzzy feeling of Xanga community love as well.</p></blockquote>
<p>It will be interesting to see over time how this transition works out and if the dedicated Xanga community sticks around or ends up leaving for WordPress.com, once they&#8217;ve had a taste of what the software has to offer. Then again, software is one thing and community is another. Software is easy to create, community is not. Good luck to John, the Xanga team, and all users of the service as I hope this transition helps cement their place on the web for another 13 years. </p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/_c6XzD9VJTw" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Sep 2013 00:02:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"Matt: Simplenote for Android!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=42980";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://ma.tt/2013/09/simplenote-for-android/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:193:"<p><a href="http://simplenote.com/2013/09/05/simplenote-for-android/">I&#8217;m really excited about Simplenote for Android</a>, better than any similar app I&#8217;ve seen on the platform.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 10 Sep 2013 00:00:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"Matt: NextDraft’s New Platform";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=42978";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://ma.tt/2013/09/nextdrafts-new-platform/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:264:"<p><a href="http://www.poststat.us/dave-pell-nextdraft/">Dave Pell on building the NextDraft platform</a>. Spoiler: It&#8217;s WordPress, but a really cool implementation of it across a blog, iOS app, and newsletter. I wish more publishers worked the same way.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Sep 2013 19:53:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"Akismet: Akismet &amp; Your WordPress Contact Forms";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://blog.akismet.com/?p=1046";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://blog.akismet.com/2013/09/09/akismet-and-your-wordpress-contact-forms/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3267:"<p>We often hear from Akismet users on WordPress that, even after activating our plugin, they are being flooded with spam via their contact forms. While Akismet will automatically begin checking all comments submitted on your post and page comment forms, we can&#8217;t simply hook into any contact form plugin (or theme) and handle those submissions, as well. The good news is that there are some really great (and free!) contact form plugins out there that include Akismet integration, and we thought that we&#8217;d let you know about them in case you&#8217;re in the market.</p>
<p><a title="Jetpack by WordPress.com" href="http://wordpress.org/plugins/jetpack/">Jetpack by WordPress.com</a><br />
Although Jetpack brings you <a href="http://jetpack.me/">a ton of other features</a> that are native to WordPress.com, it includes a simple and powerful contact form module that is automatically integrated with the Akismet service. You&#8217;ll also notice that the submission queue has been designed to mirror the native WordPress comment queue as closely as possible to ensure ease of use and moderation. What&#8217;s more, Jetpack and Akismet are developed under the same roof by <a href="http://automattic.com">Automattic</a>, which means that you can rest easy knowing that the integration is as tight as possible.</p>
<p><a title="Contact Form 7" href="http://wordpress.org/plugins/contact-form-7/">Contact Form 7</a><br />
Another powerful &#8211; and ever so popular &#8211; option is Contact Form 7 by <a href="http://profiles.wordpress.org/takayukister/">Takayuki Miyoshi</a>. It boasts a great amount of flexibility, some really nifty features, is surprisingly easy to configure, and has been downloaded over 12 million times. Setting up the plugin to send data to our service will take some manual configuration, but the steps are fairly simple and are clearly outlined <a href="http://contactform7.com/spam-filtering-with-akismet/">here</a>.</p>
<p><a title="Fast Secure Contact Form" href="http://wordpress.org/plugins/si-contact-form/">Fast Secure Contact Form</a><br />
If you&#8217;re looking for an incredible amount of options and still wish to have the peace of mind that Akismet is checking form submissions, Fast Secure Contact Form by <a href="http://profiles.wordpress.org/mikechallis/">Mike Challis</a> may be a plugin to explore. The plugin even allows you to customize how Akismet handles spam submissions and includes customizable CAPTCHA as an additional line of defense.</p>
<p>Note that, with all of the plugins mentioned above, you will need to have Akismet installed and activated for the integration to work. And while we are unable to provide technical support for Contact Form 7 or FS Contact Form, we&#8217;re always more than happy to help you through any potential problems with Akismet functionality. <a href="http://akismet.com/contact/">Give us a shout</a>!</p>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1046/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1046/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=blog.akismet.com&blog=116920&post=1046&subd=akismet&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Sep 2013 15:51:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:7:"Anthony";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:94:"WordPress.tv: Paul Clark: Lightning Talk – How WordPress Saves Lives &amp; Moves Governments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=22193";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"http://wordpress.tv/2013/09/09/paul-clark-lightning-talk-how-wordpress-saves-lives-moves-governments/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:737:"<div id="v-kg53gIx7-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/22193/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/22193/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=22193&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/09/paul-clark-lightning-talk-how-wordpress-saves-lives-moves-governments/"><img alt="Paul Clark: Lightning Talk &#8211; How WordPress Saves Lives & Moves Governments" src="http://videos.videopress.com/kg53gIx7/3-lightning-talks-copy-01_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Sep 2013 12:14:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"Alex King: Drafts Dropdown and MP6";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=18255";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://alexking.org/blog/2013/09/08/drafts-dropdown-and-mp6";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:680:".threads-post-notice {
	background: #e8e8e8;
	padding: 10px;
}
.threads-post-notice a {
	font-weight: bold;
}

<p>If you&#8217;re using my <a href="http://alexking.org/project/drafts-dropdown">Drafts Dropdown plugin</a> and the MP6 admin UI plugin, you probably want to grab the latest from <a href="https://github.com/crowdfavorite/wp-drafts-dropdown/tree/feature/mp6">this feature branch</a>. This updates Drafts Dropdown&#8217;s styling to better match the styling in MP6.</p>
<p class="threads-post-notice">This post is part of the project: <a href="http://alexking.org/project/drafts-dropdown">Drafts Dropdown</a>. View the project timeline for more context on this post.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 08 Sep 2013 17:44:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:71:"WordPress.tv: Steven Word: Why PHP Developers Should Leverage WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=22106";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://wordpress.tv/2013/09/08/steven-word-why-php-developers-should-leverage-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:698:"<div id="v-XrIZgCjR-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/22106/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/22106/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=22106&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/08/steven-word-why-php-developers-should-leverage-wordpress/"><img alt="Steven Word: Why PHP Developers Should Leverage WordPress" src="http://videos.videopress.com/XrIZgCjR/video-47ea0307c8_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 08 Sep 2013 11:59:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:62:"WordPress.tv: Jake Goldman: Publishing Workflows for WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21706";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://wordpress.tv/2013/09/08/jake-goldman-publishing-workflows-for-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:678:"<div id="v-TLD8teDM-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21706/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21706/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21706&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/08/jake-goldman-publishing-workflows-for-wordpress/"><img alt="Publishing Workflows for WordPress" src="http://videos.videopress.com/TLD8teDM/publishing-workflows-for-wordpress_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 08 Sep 2013 10:56:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WPTavern: WPWeekly Episode 120 – Interview With Swiftype Not The Teapot";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=8958";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:121:"http://feedproxy.google.com/~r/WordpressTavern/~3/6FKMTp_v38Y/wpweekly-episode-120-interview-with-swiftype-not-the-teapot";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2987:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2.jpg?resize=150%2C150" alt="WordPress Weekly Cover Art" class="alignright size-thumbnail wp-image-8715" /></a> The first time in a long time where I won&#8217;t be doing the show solo anymore! Sarah Gooding who has recently been hired to write for WPTavern is also my new co-host. This week, we discussed her hiring and what she&#8217;ll be doing on the site, Pressgram launching,  and why WordCamp Detroit 2013 was cancelled. The second half of the show was an interview with Quin Hoxie of <a href="http://www.swiftype.com" title="http://www.swiftype.com">Swiftype</a> to talk about how their service is making search inside of WordPress better. As an aside, I apologize for the howling sound heard throughout the show although it would have been a cool background noise effect for the Friday the 13th edition! I tried to remove the loudest parts of the howling noise but it&#8217;s still noticeable. We&#8217;ll have this fixed before the next episode. <span id="more-8958"></span></p>
<h2>Stories Discussed:</h2>
<p><a href="http://www.wptavern.com/exclusive-sarah-gooding-moves-to-the-wordpress-tavern" title="http://www.wptavern.com/exclusive-sarah-gooding-moves-to-the-wordpress-tavern">Sarah Gooding Joins WPTavern</a><br />
<a href="http://www.wptavern.com/why-wordcamp-detroit-2013-was-cancelled" title="http://www.wptavern.com/why-wordcamp-detroit-2013-was-cancelled">Why WordCamp Detroit 2013 Was Cancelled</a><br />
<a href="http://www.wptavern.com/pressgram-launches-wordpress-powered-photo-sharing-app" title="http://www.wptavern.com/pressgram-launches-wordpress-powered-photo-sharing-app">Pressgram Launches</a><br />
<a href="http://stephanis.info/2013/09/06/pressgram-security-concerns/" title="http://stephanis.info/2013/09/06/pressgram-security-concerns/">Pressgram Security Concerns</a><br />
<a href="http://stephanis.info/2013/09/06/pressgram-tos/" title="http://stephanis.info/2013/09/06/pressgram-tos/">Pressgram Terms Of Service Worries</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, September 13th 9P.M. Eastern &#8211; Special Guest John James Jacoby</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #120:</strong><br />
</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/6FKMTp_v38Y" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 07 Sep 2013 17:26:39 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WordPress.tv: John James Jacoby: Wonderful WordPress Workflow";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21690";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://wordpress.tv/2013/09/07/john-james-jacoby-wonderful-wordpress-workflow/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:689:"<div id="v-gJv1BHf5-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21690/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21690/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21690&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/07/john-james-jacoby-wonderful-wordpress-workflow/"><img alt="John James Jacoby: Wonderful WordPress Workflowkflow" src="http://videos.videopress.com/gJv1BHf5/wonderful-wordpress-workflow_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 07 Sep 2013 11:03:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WordPress.tv: Brennen Byrne: Employing Best Security Practices for WordPress Sites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21716";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:99:"http://wordpress.tv/2013/09/07/brennen-byrne-employing-best-security-practices-for-wordpress-sites/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:731:"<div id="v-lQSifts6-2" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21716/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21716/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21716&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/07/brennen-byrne-employing-best-security-practices-for-wordpress-sites/"><img alt="Brennen Byrne: Employing Best Security Practices for WordPress Sites" src="http://videos.videopress.com/lQSifts6/employing-best-security-practices_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 07 Sep 2013 10:49:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:63:"WPTavern: Password Free Login With Clef Hits All The High Notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=8766";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:115:"http://feedproxy.google.com/~r/WordpressTavern/~3/n04-e-RlBu8/password-free-login-with-clef-hits-all-the-high-notes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4953:"<p>Recently I have been reviewing a number of wp-admin login alternatives that allow for login via phone. The first among the plugins tested was <a title="LaunchKey WordPress Plugin" href="http://wordpress.org/plugins/launchkey/" target="_blank">LaunchKey</a>, which I spoke about in this <a title="LaunchKey Review" href="http://www.wptavern.com/the-daily-plugin-launchkey-user-languages-buy-him-a-beer" target="_blank">LaunchKey Review</a> post. Though the functionality of LaunchKey was promising, it seemed to explode on the launching pad when it came to initial setup. Even with the valiant efforts in an hour-long back-and-forth exchange with their support team on Twitter to get me going, it seemed that the setup challenges were the biggest obstacles. It was so frustrating that I opted to delete LaunchKey altogether and forever give up on the idea of secure, remote smartphone-enabled logins. <span id="more-8766"></span></p>
<p>Sensing my frustration and desire to get this technology implemented in my installations, the team over at <a title="Clef Home Page" href="http://getclef.com" target="_blank">GetClef.com</a> decided to get to work. They created something for me that not only had every piece of functionality that I was looking for, but they did it with an installation process that took no more than 60 seconds to install the app on my iPhone, install the plugin and have them both talking to each other. OK, so they didn&#8217;t create it for me specifically, but from how beautifully this integrates, it sure feels like they completely read my mind in regards to the functionality and ease of use that I was looking for!</p>
<p>To begin, you simply navigate to the Clef app page which asks for your mobile number. Once entered, Clef will text you the link to install the app on your phone. Currently both iOS and Android versions are available for integration with the Clef plugin. Once installed, the app will have you set up a pin number to protect anyone from using it to login to your sites. So even if you lose your phone, you won&#8217;t have to worry that someone out there can login to all your sites.</p>
<p><a title="Clef" href="http://wordpress.org/plugins/wpclef/" target="_blank">Clef</a> is touted as the simplest way to login to multiple sites without passwords in a secure, encrypted way that is as easy to use as taking a photo. Here&#8217;s Clef&#8217;s <a title="Brenned Byrne on Twitter" href="https://twitter.com/brennenbyrne" target="_blank">Brennen Byrne</a> giving us a quick walk-through on how the system works and what it does.</p>
<div class="aligncenter"></div>
<p>As stated in the video, one scan of the QR code enables complete login of <strong>ALL</strong> your WordPress installations. If you login to one site that is Clef-Enabled, you have access to every other Clef-capable site in your network without having to login again. I can&#8217;t stress enough how much of a time-saving feature this is. Often I work with collaboration teams and outsource workers that often require access to one or several of my WordPress web properties. This tool allows me to easily add and remove credentials for an individual within Clef on a network wide basis, so I can assign a person specific properties to work on. When they are finished with the tasks and milestones assigned, I can simply remove them network wide and not have to be burdened to login to each individual site to remove the user credentials or their permissions.</p>
<p>From a designer and developer perspective, this is a really great selling point to include in your design proposals and specs to clients. Larger companies and organizations can easily manage user roles and login capabilities by implementing Clef for their WordPress installs. It&#8217;s just one more tool that gives WordPress the decided advantage over using other CMS platforms.</p>
<p>Let&#8217;s also talk about the security reinforcement of this app/plugin combo. How many of you out there use the same admin password for all your installations? Come on, I know there are lots of you out there that do this. It&#8217;s a bad practice to get into because once one of your sites is compromised, they all are. Most of us don&#8217;t like to use different passwords, especially if our network is 50-100 installations deep. Clef can make it easier for you to keep your logins in one place without exposing yourself by using duplicate passwords across your network.</p>
<p>Even if you are just passively intrigued at the concept of remote gadget WordPress logins, Clef is worth investigating. With remarkably quick setup and ease of use, this plugin has earned a permanent spot in my everyday plugin roster. I love the advancements that WordPress is making with device integration and Clef is just another great reinforcement as to why we love using WordPress so much!</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/n04-e-RlBu8" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Sep 2013 23:00:12 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Marcus Couch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WPTavern: 7 Surprising Results From The 2013 BuddyPress Codex Survey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=8885";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:120:"http://feedproxy.google.com/~r/WordpressTavern/~3/8TOECMZ944s/7-surprising-results-from-the-2013-buddypress-codex-survey";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:7031:"<p>The results of the BuddyPress codex survey are in! 178 BuddyPress developers participated in the survey and the information they provided will help the team to prioritize short-term and long-term tasks for improving the BP Codex. Community developers <a href="http://buddypress.org/community/members/hnla/" target="_blank">@hnla</a> and <a href="http://buddypress.org/community/members/mercime/" target="_blank">@mercime</a> are spearheading the effort to improve the BuddyPress codex for the BP 1.9 release.</p>
<p>While this survey is packed full of fascinating <a href="http://buddypress.org/2013/09/2013-buddypress-codex-survey-results/" target="_blank">results</a>, I&#8217;d like to highlight just a few of them here:<span id="more-8885"></span></p>
<h2>Nearly 50% of BuddyPress sites are in languages other than English.</h2>
<p>Respondents hailed from 36 different countries and results show that 56% of BuddyPress sites are built using English as the language and the other half is comprised of various languages from around the world. The top 10 include:  1) English (56%), 2) Spanish, 3) Italian, 4) French, 5) German, 6) Dutch, 7) Swedish, 8) Portugese, 9) Chinese, and 10) Greek.</p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/international.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/international.jpg?resize=560%2C307" alt="international" class="aligncenter size-full wp-image-8920" /></a></p>
<p>It&#8217;s clear to see that BuddyPress is an international community. We&#8217;re spread out all over the globe! If you&#8217;re a BuddyPress plugin developer, you need to <a href="http://buddypress.org/support/topic/localize-your-buddypress-plugins/" target="_blank">localize your plugins</a>. Hopefully we can include some more detailed references on localization when it comes time to revamp the codex.</p>
<h2>Only 15% of BuddyPress sites surveyed make use of the Friends component.</h2>
<p>When you think about social networks, oftentimes the friends component is what you might assume would be the most important. This survey reveals otherwise:</p>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/components.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/components.jpg?resize=493%2C291" alt="components" class="aligncenter size-full wp-image-8925" /></a></p>
<p>I was surprised that the Groups component wasn&#8217;t activated on more sites, as it is probably the most flexible and has the most extensions. These numbers might indicate that many people are using BuddyPress for its more robust profile and account management capabilities, rather than for its social features. Not one of the social components reached more than 20%.</p>
<h2>90% of BuddyPress developers surveyed are male.</h2>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/gender.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/gender.jpg?resize=560%2C118" alt="gender" class="aligncenter size-full wp-image-8930" /></a></p>
<p>Do these numbers surprise you? I would have imagined there would be a few more female developers who responded, but perhaps the survey did not reach them. However, these numbers really should not deter female developers from getting involved. From my experience attending BuddyCamp Vancouver, the BuddyPress community is made up of some of the nicest people you will ever meet. Even in the support forums you will find that people are generally very welcoming and helpful to new developers. BuddyPress is still a relatively small community and it&#8217;s easy to start getting involved and making a difference.</p>
<h2>People prefer to learn BuddyPress through written tutorials.</h2>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/tutorials.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/tutorials.jpg?resize=560%2C301" alt="tutorials" class="aligncenter size-full wp-image-8939" /></a></p>
<p>This has been my suspicion for awhile and now it is confirmed. Developers are not looking for fancy video tutorials and they are only marginally interested in books and in-person training when it comes to learning about BuddydPress. They want written tutorials, references and guides that they can quickly scan and come back to when needed.</p>
<h2>39% of BuddyPress sites are installed within a WordPress multisite network.</h2>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/bp-site-root.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/bp-site-root.jpg?resize=560%2C408" alt="bp-site-root" class="aligncenter size-full wp-image-8933" /></a></p>
<p>Perhaps this one isn&#8217;t much of a surprise, given that in the beginning you could only use BuddyPress with WordPress multisite. After BuddyPress was made to be compatible with single site WordPress installations, one would have thought that they would become the vast majority, since it&#8217;s the easiest way to set up WordPress. But it appears that usage on multisite vs. single site is almost 50/50. What this tells me is that blogs are still a very important aspect of BuddyPress social networks. </p>
<p>What does this mean for the codex? We absolutely need more documentation on using BuddyPress within a multisite environment. </p>
<h2>The biggest complaint about the codex is that the documentation is incomplete and difficult to navigate.</h2>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/codex-issues.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/codex-issues.jpg?resize=560%2C306" alt="codex-issues" class="aligncenter size-full wp-image-8937" /></a></p>
<p>It looks like the largest task at hand will be to fill in any bald spots in the codex and improve the navigation. It&#8217;s not so much that the content is unclear or outdated but rather it&#8217;s just not there at all. Creating new sections and adding to existing ones will probably be the main focus in improving the codex.</p>
<h2>35% of BuddyPress developers surveyed are willing to contribute to the codex.</h2>
<p>Wow, that&#8217;s an amazing response from the BuddyPress community developers who are ready and willing to help make the codex a more useful resource. Many thanks to <a href="http://buddypress.org/community/members/hnla/" target="_blank">@hnla</a> and <a href="http://buddypress.org/community/members/mercime/" target="_blank">@mercime</a> for all their hard work in analyzing the responses from the survey and providing these handy graphs for these results. By far, one of the biggest complaints about BuddyPress is the lack of documentation. With all the capable volunteers stepping forward, things are about to change for the better.</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/8TOECMZ944s" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Sep 2013 22:24:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: Coming Soon: Inline Documentation For All WordPress Hooks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=8832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:118:"http://feedproxy.google.com/~r/WordpressTavern/~3/Zf81S3bXaFY/coming-soon-inline-documentation-for-all-wordpress-hooks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3412:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/all-the-hooks.png" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/all-the-hooks.png?resize=299%2C298" alt="all-the-hooks" class="alignright size-full wp-image-8851" /></a>Something exciting is happening in the world of WordPress documentation. Very soon all of the hooks used throughout the core are going to be documented. An initiative is now underway to bring inline docs for hooks into the upcoming WordPress 3.7 release. I can see some of you jumping up and down and celebrating wildly right now. But there are probably more than a few of you who are wondering <strong>&#8220;What in the world is a hook?&#8221;</strong><span id="more-8832"></span></p>
<p>You will see the terms &#8220;actions/filters&#8221; and &#8220;hooks&#8221; throughout the codex and it can get a little confusing. Hooks are split into <a href="http://codex.wordpress.org/Plugin_API/Action_Reference" title="WordPress Action Reference" target="_blank">actions</a> and <a href="http://codex.wordpress.org/Plugin_API/Filter_Reference" title="WordPress Filter Reference" target="_blank">filters</a>. Essentially, hooks are events that allow you to &#8220;hook&#8221; into WordPress and make it do stuff. The codex <a href="http://codex.wordpress.org/Plugin_API/Action_Reference" title="Codex Action Reference" target="_blank">Plugin API/Action Reference</a> page lists all existing hooks, some of which have been documented.</p>
<p>Inline documentation of hooks will make it much easier for developers to extend WordPress. Each hook gets a quick explanation and the @since version added as a comment. For example, check out the notes for <em>do_action( &#8216;welcome_panel&#8217; );</em></p>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/welcome-panel.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/welcome-panel.jpg?resize=560%2C329" alt="welcome-panel" class="aligncenter size-full wp-image-8882" /></a></p>
<p>If you wanted to add some content to the WordPress welcome panel but didn&#8217;t know how, this inline documentation will help to point you in the right direction.</p>
<p>A handful of contributors are currently tackling a massive list of hooks in 195 files. If you can help, leave a comment on the <a href="http://make.wordpress.org/core/2013/09/05/add-inline-docs-for-hooks/" target="_blank">make.wordpress.org</a> post to claim the files you&#8217;ll be working on and then add separate patches for each to the <a href="http://core.trac.wordpress.org/ticket/25229" target="_blank">Add Inline Docs for Hooks</a> trac ticket. Make sure to review the <a href="http://make.wordpress.org/core/handbook/inline-documentation-standards/php-documentation-standards/#4-hooks-actions-and-filters" target="_blank">hook documentation standards</a> before submitting a patch.</p>
<p>Developers always say that if you want to learn WordPress, the best way to start is by going through the core to find out how it all works. Inline documentation for hooks will make this easier than ever. Although it&#8217;s a monumental task to coordinate, the end result is that WordPress will be much more approachable for developers who are new to the platform.</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/Zf81S3bXaFY" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Sep 2013 14:00:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:119:"WordPress.tv: T. Michael Tracy: What’s the WebGL Thing? An Introduction to Using Interactive 3D Graphics in WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21726";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:131:"http://wordpress.tv/2013/09/06/t-michael-tracy-whats-the-webgl-thing-an-introduction-to-using-interactive-3d-graphics-in-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:803:"<div id="v-bOhqwEtF-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21726/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21726/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21726&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/06/t-michael-tracy-whats-the-webgl-thing-an-introduction-to-using-interactive-3d-graphics-in-wordpress/"><img alt="T. Michael Tracy: What’s the WebGL Thing? An Introduction to Using Interactive 3D Graphics in WordPress" src="http://videos.videopress.com/bOhqwEtF/web-gl-interactive-3d-graphics-in-wp_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Sep 2013 10:44:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WordPress.tv: Dave Ross: Optimize Image Files Like a Pro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21728";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.tv/2013/09/06/dave-ross-optimize-image-files-like-a-pro/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:672:"<div id="v-TqDCJmoq-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21728/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21728/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21728&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/06/dave-ross-optimize-image-files-like-a-pro/"><img alt="Dave Ross: Optimize Image Files Like a Pro" src="http://videos.videopress.com/TqDCJmoq/optimize-image-files_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Sep 2013 10:43:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"BuddyPress: 2013 BuddyPress Codex Survey Results";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://buddypress.org/?p=170911";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://buddypress.org/2013/09/2013-buddypress-codex-survey-results/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:32417:"<p>This report presents the results from the 2013 BuddyPress Codex Survey held from August 16 &#8211; 26, 2013. One hundred seventy-eight developers from thirty-six countries responded to provide valuable information about BP usage and documentation requirements. Thank you all.</p>
<h3>A. Background</h3>
<p>At the beginning of the development cycle for BP version 1.9, <a href="http://buddypress.org/community/members/hnla/" rel="nofollow">@hnla</a> and <a href="http://buddypress.org/community/members/mercime/" rel="nofollow">@mercime</a> were put in charge of improving the current BP Codex. Feedback was scarce on the proposed codex outline and the timeline posted by <a href="http://buddypress.org/community/members/hnla/" rel="nofollow">@hnla</a> at <a href="http://bpdevel.wordpress.com" title="bpdevel.wordpress.com">bpdevel.wordpress.com</a>. It was at this stage that the decision was made to create and deploy a BP codex survey even when it was not originally included in the timeline.</p>
<h3>B. Goal of Survey</h3>
<p>Gather data to determine priority tasks and to identify resources necessary to complete the project to clean up and refresh the BP codex.</p>
<p>Objectives:</p>
<ul>
<li>Improve information architecture of BP Codex</li>
<li>Learn more about BP usage to assess information requirements of the community</li>
<li>Determine users’ preferred methods of learning BP to prioritize short-term and long-term tasks</li>
<li>Identify developers who are willing to author articles in BP Codex</li>
</ul>
<p><span id="more-170911"></span></p>
<h3>C. Survey Design/Method</h3>
<p>The first-ever BP survey included 21 questions in three sections namely: You and BuddyPress (8), BP codex (10), and about the survey (3). In effect, questions were designed to gather feedback on the usability of current available documentation with regards to the survey’s goal and objectives mentioned above. A wide variety of survey question types were employed to gather the data required: multiple choices, check boxes, matrices, and open‐ended/comments.</p>
<p>The survey was originally designed using Google Forms and submitted to the BP Project/Lead Developers for comments/approval. Upon approval, the survey was copied over to the Polldaddy.com account for public access. Huge props to Siobhan McKeown (<a href="http://buddypress.org/community/members/siobhan/" rel="nofollow">@siobhan</a>) for the survey consult. Special thanks to Automattic and Polldaddy.com for the upgraded account.</p>
<p>Polldaddy, the survey tool used, has excellent reporting and filtering functions available in real time with quantitative data and allowed for the export of such data in different file formats. Additional chart types, tag clouds and further analyses of qualitative data collected from the survey were implemented using Microsoft Excel, Google Charts and tagxedo.com.</p>
<h3>D. Survey Results</h3>
<p><strong>General Information</strong>: One hundred seventy-eight BP developers/designers from thirty-six countries participated in this survey. The majority of respondents (37%) took the survey in the United States, followed by Germany (6%) then Italy, United Kingdom and Australia at 4% each. Of those respondents from the U.S., 28% took the survey in California, followed by New York (5%), then New Jersey and Massachusetts at 4% each.</p>
<p><a href="http://mercime.files.wordpress.com/2013/09/00-country1.jpg"><img class="aligncenter size-full wp-image-901" alt="00-country" src="http://mercime.files.wordpress.com/2013/09/00-country1.jpg" width="700" height="383" /></a></p>
<p><strong>1. Gender: </strong></p>
<p><a href="http://mercime.files.wordpress.com/2013/09/01-gender1.jpg"><img class="aligncenter size-full wp-image-902" alt="01-gender" src="http://mercime.files.wordpress.com/2013/09/01-gender1.jpg" width="700" height="147" /></a></p>
<p><strong>2. Where did you first learn about BuddyPress?</strong></p>
<p>Inclusion in the WP Plugin Repository brought about the largest number of BP users.<br />
Note: &#8220;Google/Search&#8221; (7.3%) for social networks and &#8220;Cannot Remember&#8221;/not sure (5.1%) were brought out from the &#8220;Other Option&#8221; results to be included in comparison with other choices.</p>
<p><a href="http://mercime.files.wordpress.com/2013/09/02-where-1st-learn1.jpg"><img class="aligncenter size-full wp-image-903" alt="02-where--1st-learn" src="http://mercime.files.wordpress.com/2013/09/02-where-1st-learn1.jpg" width="491" height="294" /></a></p>
<p><strong>3. When did you first use BuddyPress in a site? (BP version)</strong></p>
<p>BuddyPress alpha/beta to BP 1.1+ versions worked in WP Multi-User (WPMU) installations only and required manual transfer of theme folders.  The release of BuddyPress 1.2 expanded the user/developer base when BP could be used for both single WP and WPMU installations and one could install BP in three steps (no longer requiring  manual configuration of folders in server). BuddyPress 1.5 further expanded user/developer base with new features and component classes, enhancements and bug fixes and closed 1001 BP Trac tickets in all. </p>
<p><a href="http://mercime.files.wordpress.com/2013/09/03-when-1stbpversion1.jpg"><img class="aligncenter size-full wp-image-904" alt="03-when-1stBPversion" src="http://mercime.files.wordpress.com/2013/09/03-when-1stbpversion1.jpg" width="700" height="378" /></a></p>
<p><strong>4. How are you using BuddyPress?</strong></p>
<p><a href="http://mercime.files.wordpress.com/2013/09/04-user-types1.jpg"><img class="aligncenter size-full wp-image-905" alt="04-user-types" src="http://mercime.files.wordpress.com/2013/09/04-user-types1.jpg" width="700" height="314" /></a></p>
<p><strong>5. Where have you installed BuddyPress?</strong></p>
<p><a href="http://mercime.files.wordpress.com/2013/09/05-bpinwp1.jpg"><img class="aligncenter size-full wp-image-921" alt="05-BPinWP" src="http://mercime.files.wordpress.com/2013/09/05-bpinwp1.jpg" width="700" height="509" /></a></p>
<p><strong>6. What types of BuddyPress sites have you built?</strong></p>
<p>This tag cloud incorporates the original types listed in the survey and all the other types added by the respondents in the &#8220;Other option&#8221; form. The top 10 types of BP networks created are: 1) Generic, 2) Academic, 3) Artistic, 4) Sports, 5) Gaming, 6) Religious, 7) Scientific, 8) Business, 9) Niche community, and 10) Non-profit.</p>
<p><a href="http://mercime.files.wordpress.com/2013/09/06-bpsitetypes1.jpg"><img class="aligncenter size-full wp-image-907" alt="06-bpsitetypes" src="http://mercime.files.wordpress.com/2013/09/06-bpsitetypes1.jpg" width="700" height="376" /></a></p>
<p><strong>7. In what language is your BuddyPress site?</strong></p>
<p>This tag cloud incorporates the original languages listed in the survey and all the other languages added by the respondents in the &#8220;Other option&#8221; form. The top 10 languages used in BP installations are: 1) English (56%), 2) Spanish, 3) Italian, 4) French, 5) German, 6) Dutch, 7) Swedish, 8) Portugese, 9) Chinese, and 10) Greek.</p>
<p><a href="http://mercime.files.wordpress.com/2013/09/07-what-lang-bpsite1.jpg"><img class="aligncenter size-full wp-image-908" alt="07-what-lang-BPsite" src="http://mercime.files.wordpress.com/2013/09/07-what-lang-bpsite1.jpg" width="699" height="376" /></a></p>
<p><strong>8. What components and features are activated in your sites? (Default Active Components: Extended Profiles and Activity Streams)</strong></p>
<p><a href="http://mercime.files.wordpress.com/2013/09/08-components-activated1.jpg"><img class="aligncenter size-full wp-image-909" alt="08-components-activated" src="http://mercime.files.wordpress.com/2013/09/08-components-activated1.jpg" width="493" height="291" /></a></p>
<p><strong>9. What BuddyPress documentation do you currently use?</strong></p>
<p><a href="http://mercime.files.wordpress.com/2013/09/09-documentation-used-curre1.jpg"><img class="aligncenter size-full wp-image-910" alt="09-documentation-used-curre" src="http://mercime.files.wordpress.com/2013/09/09-documentation-used-curre1.jpg" width="700" height="340" /></a></p>
<p><strong>10. How would you prefer to learn BuddyPress?</strong></p>
<p><a href="http://mercime.files.wordpress.com/2013/09/10-learning-preference1.jpg"><img class="aligncenter size-full wp-image-911" alt="10-learning-preference" src="http://mercime.files.wordpress.com/2013/09/10-learning-preference1.jpg" width="700" height="955" /></a></p>
<p><strong>11. Where do you look first for answers to your BuddyPress questions?</strong></p>
<p><a href="http://mercime.files.wordpress.com/2013/09/11-first-look1.jpg"><img class="aligncenter size-full wp-image-912" alt="11-first-look" src="http://mercime.files.wordpress.com/2013/09/11-first-look1.jpg" width="472" height="295" /></a></p>
<p><strong>12. How useful is the current BuddyPress Codex?</strong></p>
<p><a href="http://mercime.files.wordpress.com/2013/09/12-codex-usefulness.jpg"><img class="aligncenter size-full wp-image-913" alt="12-codex-usefulness" src="http://mercime.files.wordpress.com/2013/09/12-codex-usefulness.jpg" width="490" height="301" /></a></p>
<p><strong>13. What sections of the current BuddyPress Codex do you find most useful?</strong></p>
<p><a href="http://mercime.files.wordpress.com/2013/09/13-codex-useful-sections1.jpg"><img class="aligncenter size-full wp-image-914" alt="13-codex-useful-sections" src="http://mercime.files.wordpress.com/2013/09/13-codex-useful-sections1.jpg" width="645" height="344" /></a></p>
<p><strong>14. What issues do you find in the BuddyPress Codex?</strong></p>
<p><a href="http://mercime.files.wordpress.com/2013/09/14-codex-issues1.jpg"><img class="aligncenter size-full wp-image-915" alt="14-codex-issues" src="http://mercime.files.wordpress.com/2013/09/14-codex-issues1.jpg" width="611" height="334" /></a></p>
<p><strong>15. What documentation would you like to see in the BuddyPress Codex?</strong></p>
<p><a href="http://mercime.files.wordpress.com/2013/09/15-documentation-requested1.jpg"><img class="aligncenter size-full wp-image-916" alt="15-documentation-requested" src="http://mercime.files.wordpress.com/2013/09/15-documentation-requested1.jpg" width="700" height="894" /></a></p>
<p><strong>16. Have you contributed to the BuddyPress Codex?</strong><br />
Yes: 13%. No: 87%.</p>
<p><strong>17. Would you like to Contribute to the BuddyPress Codex?</strong><br />
Yes: 35%. No: 65%</p>
<blockquote><p>Thirty-two developers/designers indicated interest in contributing to the BP codex.<br />
<a href="http://buddypress.org/community/members/boonebgorges/" rel="nofollow">@boonebgorges</a>, <a href="http://buddypress.org/community/members/bowromir/" rel="nofollow">@bowromir</a>, @charisevl, <a href="http://buddypress.org/community/members/chouf1/" rel="nofollow">@chouf1</a>, <a href="http://buddypress.org/community/members/damoncook/" rel="nofollow">@damoncook</a>, <a href="http://buddypress.org/community/members/dcavins/" rel="nofollow">@dcavins</a>, <a href="http://buddypress.org/community/members/dcrabill/" rel="nofollow">@dcrabill</a>, <a href="http://buddypress.org/community/members/ddean/" rel="nofollow">@ddean</a>, <a href="http://buddypress.org/community/members/defries/" rel="nofollow">@defries</a>, <a href="http://buddypress.org/community/members/dianakc/" rel="nofollow">@dianakc</a>,  <a href="http://buddypress.org/community/members/djpaul/" rel="nofollow">@djpaul</a>, <a href="http://buddypress.org/community/members/espellcaste/" rel="nofollow">@espellcaste</a>, <a href="http://buddypress.org/community/members/grimmwerks/" rel="nofollow">@grimmwerks</a>, <a href="http://buddypress.org/community/members/hnla/" rel="nofollow">@hnla</a>, <a href="http://buddypress.org/community/members/imath/" rel="nofollow">@imath</a>, <a href="http://buddypress.org/community/members/jjones7/" rel="nofollow">@jjones7</a>, <a href="http://buddypress.org/community/members/johnjamesjacoby/" rel="nofollow">@johnjamesjacoby</a>,<a href="http://buddypress.org/community/members/karmatosed/" rel="nofollow">@karmatosed</a>, <a href="http://buddypress.org/community/members/mercime/" rel="nofollow">@mercime</a>, <a href="http://buddypress.org/community/members/pollyplummer/" rel="nofollow">@pollyplummer</a>, <a href="http://buddypress.org/community/members/r-a-y/" rel="nofollow">@r-a-y</a>, <a href="http://buddypress.org/community/members/themightymo/" rel="nofollow">@themightymo</a>, <a href="http://buddypress.org/community/members/sbrajesh/" rel="nofollow">@sbrajesh</a>, <a href="http://buddypress.org/community/members/slaffik/" rel="nofollow">@slaFFik</a>, <a href="http://buddypress.org/community/members/svenl77/" rel="nofollow">@svenl77</a>, <a href="http://buddypress.org/community/members/ubernaut/" rel="nofollow">@ubernaut</a> and #markfincg, #vanseodesign, #simon-noesi, #gladiatorsuits, #AShenkar, #cidadesonho</p></blockquote>
<blockquote><p>
For those who said no, some reasons given were:<br />
~ &#8220;Not sure how I could contribute other than offering my experience so far. I&#8217;m not a programmer so can&#8217;t write plugins, etc (yet).&#8221;- &#8220;Like I said before BuddyPress is not like WordPress code -wise. If you have a solid understanding of HTML + CSS you can work your way around in almost any &#8216;regular&#8217; WordPress theme because most PHP code is in between the HTML elements. In BuddyPress there is almost none PHP and just a single line ( Action ) that calls a lot of HTML to be included. Thats what makes it so difficult to do whatever you want with BuddyPress.&#8221;<br />
~ &#8220;I wouldn&#8217;t be able to contribute to the Codex since I&#8217;m not a programmer nor do I have extensive time. That&#8217;s why I depend on devs and people who are way more knowledgeable than I am.&#8221;<br />
~ &#8220;I&#8217;ll let you know when i&#8217;m ready. <img src="http://buddypress.org/wp-includes/images/smilies/icon_smile.gif" alt=":)" class="wp-smiley" />  &#8220;</p></blockquote>
<p><strong>18. How did you learn about this survey?</strong><br />
Huge props to Sarah Gooding (<a href="http://buddypress.org/community/members/pollyplummer/" rel="nofollow">@pollyplummer</a>) for bringing in 34% of total respondents via her timely blog post about this survey at wpmu.org. We raised wpmu.org from among the sources listed in the &#8220;Other option&#8221; form as seen below.</p>
<p><a href="http://mercime.files.wordpress.com/2013/09/18-survey-learn-where1.jpg"><img class="aligncenter size-full wp-image-917" alt="18-survey-learn-where" src="http://mercime.files.wordpress.com/2013/09/18-survey-learn-where1.jpg" width="586" height="324" /></a></p>
<p><strong>19. This BuddyPress survey is:</strong><br />
Just right: 90%<br />
Too long: 8%<br />
Too short: 2%</p>
<p><strong>20. Will you be willing to take another BuddyPress survey 6 months from now?</strong><br />
Yes: 81%.<br />
Maybe: 19%<br />
No: 1%</p>
<p><strong>21. Any last thoughts on improving the BuddyPress Codex: </strong></p>
<p>Following are some suggestions collected at random. Enjoy.</p>
<blockquote><p>What would be nice on the Codex is to identify all foreign BP translators (the active one at least) or the foreign BP usage oriented sites. I remember back to 2009 the german, italian, spanish BP sites. Where are they actually?</p></blockquote>
<blockquote><p>Improve the search on buddypress.org. It&#8217;s practically impossible to find relevant info in the codex, forum posts and blogs. Need lots more tutorials. See cakephp docs,as a good example.</p></blockquote>
<blockquote><p>If tutorials =&gt; level of complexity<br />
Future: a home for translated codex (fr,&#8230;)<br />
i&#8217;m not sure about video training/tuto<br />
I like the quick starting guide idea<br />
I love the phpdoc one</p></blockquote>
<blockquote><p>I think having examples; i.e., rather than just code examples in a class, perhaps a write up of a certain function or real life application with pointers to the appropriate docs</p></blockquote>
<blockquote><p>Codex is essential for leveraging the power of BP. Currently the entry barrier is too high.</p></blockquote>
<blockquote><p>
Need much more information about what BuddyPress is, what features it offers (see http://bbpress.org/about/features/ for an example from bbPress), and other things that help people figure out what its useful for and how to use it. Also provide some more entry level articles. The learning curve is pretty steep, even for a pretty experienced multiple WordPress and phpBB site owner like me.</p></blockquote>
<blockquote><p>I&#8217;m just glad that you want to improve the Codex.</p></blockquote>
<blockquote><p>1. Improve navigation &#8211; sidebar links should not be the only way to find and access content (if they&#8217;re not, then there&#8217;s another issue).<br />
2. Make updating it a priority &#8211; it is very disheartening to read something like &#8220;We&#8217;ve made major changes since x.x version&#8221; and then see the docs haven&#8217;t been updated for 1000 days. I&#8217;m 100% positive that BP would have a much larger (and more knowledgeable) developer base if documentation was correct and current &#8211; growth in user base would undoubtedly follow.</p></blockquote>
<blockquote><p>Thanks for all the wonderful work &#8211; BuddyPress and its documentation already do contribute to make a difference in this world <img src="http://buddypress.org/wp-includes/images/smilies/icon_smile.gif" alt=":)" class="wp-smiley" /> </p></blockquote>
<blockquote><p>
Not just think about developers or assume themes are developers &#8211; I&#8217;m very worried this is happening. We also need to not overwhelm fist time users, developers and designers. We all need to remember what the first time using BuddyPress and then pushing its use was like.</p></blockquote>
<blockquote><p>Be more clear, give chance to people to participate in it. Bring more new features. More customization.</p></blockquote>
<blockquote><p>Complete code examples with multiple usage scenarios.<br />
Complete &#8220;How to&#8221; creating themes the PROPER way with 1.7+<br />
More &#8220;How To&#8221;s.<br />
Detailed &#8220;How To&#8221;s.</p></blockquote>
<blockquote><p>Make everything easier to navigate and more inline with WordPress Codex. Make information on developing themes and plugins clearer maybe by establishing a best practices section.</p></blockquote>
<blockquote><p>Look forward to seeing where it&#8217;s going. And Thank you.</p></blockquote>
<blockquote><p>More content would be great but first and foremost it just needs to be accurate for the version it is on. So much outdated material. I shouldn&#8217;t have to search around the internet for basic documentation that should be on the BuddyPress site.</p></blockquote>
<blockquote><p>Working examples of plugin development using checkboxes, radio buttons, dropdown menu&#8217;s etc. So one can have a look to see how to begin a plugin.</p></blockquote>
<blockquote><p>I&#8217;ve been a very intermittent dev with BP, and just got back into it. I was in the codex today and was like 0-for-10 on finding anything at all. I found somebodies hooks reference on Github and that was closest I got to help.  I think it is great that you&#8217;re making it a priority to improve the codex and would love to try to help.</p></blockquote>
<blockquote><p>As on WP Codex, I look for usage of hooks/loops but not found (or not easily) on BP Codex. Would love to see hook/loop and expected output.</p></blockquote>
<blockquote><p>It will be awesome to have some written guidelines on how to edit codex properly. It is not very clear at the moment. Also, think about increasing the visibility of documentation. I love what I have seen on the new document structure proposed [in bpdevel]. I really hope that it becomes reality.</p></blockquote>
<blockquote><p>I&#8217;m all for a new Codex and I say thinking plenty before heading into the writing phase is best. Please make something scalable that won&#8217;t be obsolete by the time 1.9 comes out!</p></blockquote>
<blockquote><p>Go developer.buddypress.org while you&#8217;re at it.</p></blockquote>
<blockquote><p>Go BP Codex Team!</p></blockquote>
<h3>E. Moving Forward</h3>
<p>We asked. You answered quite clearly! Now we&#8217;re going back to our planning board and work in the details necessary to push this project onwards and upwards.</p>
<p>In the next BP Codex update at <a href="http://bpdevel.wordpress.com" title="bpdevel.wordpress.com">bpdevel.wordpress.com</a>  <a href="http://buddypress.org/community/members/hnla/" rel="nofollow">@hnla</a> will be posting the updated Table of Contents where you can indicate which section/topic you&#8217;d like to create/update at <a href="http://codex.buddypress.org/" target="_blank">codex.buddypress.org</a> &#8211; though please feel free to post your area of interest in comments below. Among others, we&#8217;ll also be providing some guidelines for contributions to the codex along with recommendations arising from this survey.</p>
<p>Thank you again for participating in our first BuddyPress Codex Survey <img src="http://buddypress.org/wp-includes/images/smilies/icon_wink.gif" alt=";-)" class="wp-smiley" /> </p>
<p>P.S. To #markfincg, #vanseodesign, #simon-noesi, #gladiatorsuits, #AShenkar, and #cidadesonho: Apologies, couldn&#8217;t find your WP/BP usernames. Please post in comment below if you are still interested in contributing to the BP Codex. Thanks.</p>
<h2>Discussion</h2>

<div id="bbpress-forums">

	
	
		
		
			

<div class="bbp-pagination">
	<div class="bbp-pagination-count">

		Viewing 6 posts - 1 through 6 (of 6 total)
	</div>

	<div class="bbp-pagination-links">

		
	</div>
</div>


			
<ul id="topic-170926-replies" class="forums bbp-replies">

	<li class="bbp-body">

		
			
<div id="post-170926" class="post-170926 topic type-topic status-publish hentry odd bbp-parent-forum-2074 bbp-parent-topic-170926 bbp-reply-position-1 user-id-187497 topic-author">

	<div class="bbp-reply-author">

		
		<a href="http://buddypress.org/community/members/mercime/" title="View @mercime\'s profile" class="bbp-author-avatar" rel="nofollow"><img src="http://gravatar.com/avatar/fae451be6708241627983570a1a1817a?d=http://buddypress.org/wp-content/plugins/buddypress/bp-core/images/mystery-man.jpg&s=100&r=G" class="avatar user-187497-avatar avatar-100 photo" width="100" height="100" alt="Avatar of @mercime" /></a><br /><a href="http://buddypress.org/community/members/mercime/" title="View @mercime\'s profile" class="bbp-author-name" rel="nofollow">@mercime</a><br /><div class="bbp-author-role">Keymaster</div>
		<p class="bbp-user-nicename">@mercime</p>
		<p class="bbp-reply-post-date"><a href="http://buddypress.org/support/topic/2013-buddypress-codex-survey-results/#post-170926" title="#170926" class="bbp-reply-permalink">6 days, 6 hours ago</a></p>

		
		
	</div><!-- .bbp-reply-author -->

	<div class="bbp-reply-content">

		
		<p>The 2013 BP Codex Survey report is now available. Read more about it at <a href="http://buddypress.org/2013/09/2013-buddypress-codex-survey-results/" rel="nofollow">http://buddypress.org/2013/09/2013-buddypress-codex-survey-results/</a></p>

		
	</div><!-- .bbp-reply-content -->

	<span class="bbp-admin-links"></span>
</div><!-- #post-170926 -->

		
			
<div id="post-170929" class="post-170929 reply type-reply status-publish hentry even bbp-parent-forum-2074 bbp-parent-topic-170926 bbp-reply-position-2 user-id-11701205">

	<div class="bbp-reply-author">

		
		<a href="http://buddypress.org/community/members/bphelp/" title="View bp-help\'s profile" class="bbp-author-avatar" rel="nofollow"><img src="http://gravatar.com/avatar/a24df1f1f1c7cbd63096036d6c84cec6?d=http://buddypress.org/wp-content/plugins/buddypress/bp-core/images/mystery-man.jpg&s=100&r=G" class="avatar user-11701205-avatar avatar-100 photo" width="100" height="100" alt="Avatar of bp-help" /></a><br /><a href="http://buddypress.org/community/members/bphelp/" title="View bp-help\'s profile" class="bbp-author-name" rel="nofollow">bp-help</a><br /><div class="bbp-author-role">Participant</div>
		<p class="bbp-user-nicename">@bphelp</p>
		<p class="bbp-reply-post-date"><a href="http://buddypress.org/support/topic/2013-buddypress-codex-survey-results/#post-170929" title="#170929" class="bbp-reply-permalink">6 days, 5 hours ago</a></p>

		
		
	</div><!-- .bbp-reply-author -->

	<div class="bbp-reply-content">

		
		<p><a href="http://buddypress.org/community/members/mercime/" rel="nofollow">@mercime</a><br />
Great data from the survey! Congrats to all!</p>

		
	</div><!-- .bbp-reply-content -->

	<span class="bbp-admin-links"></span>
</div><!-- #post-170929 -->

		
			
<div id="post-170932" class="post-170932 reply type-reply status-publish hentry odd bbp-parent-forum-2074 bbp-parent-topic-170926 bbp-reply-position-3 user-id-9022563">

	<div class="bbp-reply-author">

		
		<a href="http://buddypress.org/community/members/danbp/" title="View chouf1\'s profile" class="bbp-author-avatar" rel="nofollow"><img src="http://gravatar.com/avatar/0deae2e7003027fbf153500cd3fa5501?d=http://buddypress.org/wp-content/plugins/buddypress/bp-core/images/mystery-man.jpg&s=100&r=G" class="avatar user-9022563-avatar avatar-100 photo" width="100" height="100" alt="Avatar of danbp" /></a><br /><a href="http://buddypress.org/community/members/danbp/" title="View chouf1\'s profile" class="bbp-author-name" rel="nofollow">chouf1</a><br /><div class="bbp-author-role">Participant</div>
		<p class="bbp-user-nicename">@danbp</p>
		<p class="bbp-reply-post-date"><a href="http://buddypress.org/support/topic/2013-buddypress-codex-survey-results/#post-170932" title="#170932" class="bbp-reply-permalink">6 days, 3 hours ago</a></p>

		
		
	</div><!-- .bbp-reply-author -->

	<div class="bbp-reply-content">

		
		<p>Thank you <a href="http://buddypress.org/community/members/mercime/" rel="nofollow">@mercime</a> and <a href="http://buddypress.org/community/members/hnla/" rel="nofollow">@hnla</a> for this long, serious and detailed work ! Very interesting datas.<br />
Hope that the next survey will come out of a holiday period !:D</p>
<p>Salut !</p>

		
	</div><!-- .bbp-reply-content -->

	<span class="bbp-admin-links"></span>
</div><!-- #post-170932 -->

		
			
<div id="post-170936" class="post-170936 reply type-reply status-publish hentry even bbp-parent-forum-2074 bbp-parent-topic-170926 bbp-reply-position-4 user-id-7564761">

	<div class="bbp-reply-author">

		
		<a href="http://buddypress.org/community/members/sooskriszta/" title="View OC2PS\'s profile" class="bbp-author-avatar" rel="nofollow"><img src="http://gravatar.com/avatar/6ae41315a1c52ed387a0d80db0491435?d=http://buddypress.org/wp-content/plugins/buddypress/bp-core/images/mystery-man.jpg&s=100&r=G" class="avatar user-7564761-avatar avatar-100 photo" width="100" height="100" alt="Avatar of OC2PS" /></a><br /><a href="http://buddypress.org/community/members/sooskriszta/" title="View OC2PS\'s profile" class="bbp-author-name" rel="nofollow">OC2PS</a><br /><div class="bbp-author-role">Participant</div>
		<p class="bbp-user-nicename">@sooskriszta</p>
		<p class="bbp-reply-post-date"><a href="http://buddypress.org/support/topic/2013-buddypress-codex-survey-results/#post-170936" title="#170936" class="bbp-reply-permalink">6 days, 3 hours ago</a></p>

		
		
	</div><!-- .bbp-reply-author -->

	<div class="bbp-reply-content">

		
		<p>I would be happy to contribute to codex as well. But to a user codex as opposed to a developer codex. Even though BuddyPress is now easier than it used to be, there are plenty of things new users (site admins) ask again and again &#8211; these are recurring themes on the forums. If you look at the WordPress &#8220;documentation&#8221;, it explains concepts in a clear and simple manner accessible by even novice users.I would be happy to contribute to codex as well. But to a user codex as opposed to a developer codex. Even though BuddyPress is now easier than it used to be, there are plenty of things new users (site admins) ask again and again &#8211; these are recurring themes on the forums. If you look at the WordPress &#8220;documentation&#8221;, it explains concepts in a clear and simple manner accessible by even novice users.</p>

		
	</div><!-- .bbp-reply-content -->

	<span class="bbp-admin-links"></span>
</div><!-- #post-170936 -->

		
			
<div id="post-170939" class="post-170939 reply type-reply status-publish hentry odd bbp-parent-forum-2074 bbp-parent-topic-170926 bbp-reply-position-4 user-id-5462165">

	<div class="bbp-reply-author">

		
		<a href="http://buddypress.org/community/members/hnla/" title="View Hugo\'s profile" class="bbp-author-avatar" rel="nofollow"><img src="http://gravatar.com/avatar/3860c955aa3f79f13b92826ae47d07fe?d=http://buddypress.org/wp-content/plugins/buddypress/bp-core/images/mystery-man.jpg&s=100&r=G" class="avatar user-5462165-avatar avatar-100 photo" width="100" height="100" alt="Avatar of Hugo" /></a><br /><a href="http://buddypress.org/community/members/hnla/" title="View Hugo\'s profile" class="bbp-author-name" rel="nofollow">Hugo</a><br /><div class="bbp-author-role">Moderator</div>
		<p class="bbp-user-nicename">@hnla</p>
		<p class="bbp-reply-post-date"><a href="http://buddypress.org/support/topic/2013-buddypress-codex-survey-results/#post-170939" title="#170939" class="bbp-reply-permalink">6 days, 3 hours ago</a></p>

		
		
	</div><!-- .bbp-reply-author -->

	<div class="bbp-reply-content">

		
		<p><a href="http://buddypress.org/community/members/sooskriszta/" rel="nofollow">@sooskriszta</a> yes it&#8217;s intended that the user setup / configuration, basic principles etc type pages be expanded and your offer of help appreciated, we&#8217;ll call out to everyone who offered to help  and those that want to when we get the next TOC outline up with a clearer idea of structure and new pages required.</p>
<p>I want to add a big thanks to Mercime on the survey as it was mainly her work in pulling this together and producing the results which make for interesting reading and will help us to plan out the revised TOC &amp; new pages.</p>

		
	</div><!-- .bbp-reply-content -->

	<span class="bbp-admin-links"></span>
</div><!-- #post-170939 -->

		
			
<div id="post-170961" class="post-170961 reply type-reply status-publish hentry even bbp-parent-forum-2074 bbp-parent-topic-170926 bbp-reply-position-6 user-id-7349734">

	<div class="bbp-reply-author">

		
		<a href="http://buddypress.org/community/members/ubernaut/" title="View @ubernaut\'s profile" class="bbp-author-avatar" rel="nofollow"><img src="http://gravatar.com/avatar/e715c0ee9082add252b5246f7af712ac?d=http://buddypress.org/wp-content/plugins/buddypress/bp-core/images/mystery-man.jpg&s=100&r=G" class="avatar user-7349734-avatar avatar-100 photo" width="100" height="100" alt="Avatar of @ubernaut" /></a><br /><a href="http://buddypress.org/community/members/ubernaut/" title="View @ubernaut\'s profile" class="bbp-author-name" rel="nofollow">@ubernaut</a><br /><div class="bbp-author-role">Participant</div>
		<p class="bbp-user-nicename">@ubernaut</p>
		<p class="bbp-reply-post-date"><a href="http://buddypress.org/support/topic/2013-buddypress-codex-survey-results/#post-170961" title="#170961" class="bbp-reply-permalink">5 days, 20 hours ago</a></p>

		
		
	</div><!-- .bbp-reply-author -->

	<div class="bbp-reply-content">

		
		<p>Nice work very interesting the word cloud and the multisite usage break down i found especially interesting. Question on #8 though surely there must be some overlap in component usage not sure the pie chart tells me very much, maybe i&#8217;m being slow again.<br />
 <img src="http://buddypress.org/wp-includes/images/smilies/icon_razz.gif" alt=":P" class="wp-smiley" /> </p>

		
	</div><!-- .bbp-reply-content -->

	<span class="bbp-admin-links"></span>
</div><!-- #post-170961 -->

		
	</li><!-- .bbp-body -->

</ul><!-- #topic-170926-replies -->


			

<div class="bbp-pagination">
	<div class="bbp-pagination-count">

		Viewing 6 posts - 1 through 6 (of 6 total)
	</div>

	<div class="bbp-pagination-links">

		
	</div>
</div>


		
		


	<div id="no-reply-170926" class="bbp-no-reply">
		<div class="bbp-template-notice">
			<p>You must be logged in to reply to this topic.</p>
		</div>
	</div>



	
	
</div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Sep 2013 05:31:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"@mercime";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:60:"WordPress.tv: Jesse Friedman: Real-Time Site Personalization";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21698";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.tv/2013/09/05/jesse-friedman-real-time-site-personalization/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:684:"<div id="v-WNfjxQ4w-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21698/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21698/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21698&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/05/jesse-friedman-real-time-site-personalization/"><img alt="Jesse Friedman: Real-Time Site Personalization" src="http://videos.videopress.com/WNfjxQ4w/real-time-site-personalization_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Sep 2013 01:59:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WordPress.tv: K Adam White: Evolving Your JavaScript with Backbone.js";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21684";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:86:"http://wordpress.tv/2013/09/05/k-adam-white-evolving-your-javascript-with-backbone-js/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:710:"<div id="v-UwReWU0w-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21684/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21684/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21684&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/05/k-adam-white-evolving-your-javascript-with-backbone-js/"><img alt="K Adam White: Evolving Your JavaScript with Backbone.js" src="http://videos.videopress.com/UwReWU0w/evolving-your-javascript-with-backbone_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 06 Sep 2013 01:58:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"Matt: Mission to Democratize Publishing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=42969";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://ma.tt/2013/09/mission-to-democratize-publishing/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:250:"<p>I spoke to Robin Hough at the Guardian about <a href="http://www.theguardian.com/media-network/media-network-blog/2013/sep/03/democratise-publishing-matt-mullenwegg-cloud">WordPress and Automattic&#8217;s mission to democratize publishing</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Sep 2013 21:01:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: Pressgram Launches WordPress-Powered Photo-Sharing App";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=8801";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:116:"http://feedproxy.google.com/~r/WordpressTavern/~3/RWB28xAPVyI/pressgram-launches-wordpress-powered-photo-sharing-app";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:10970:"<p>Everyone has been waiting on the edge of their seats for the <a href="http://pressgr.am/" target="_blank">Pressgram app</a> to be accepted in the app store and today it finally happened. Billed as &#8220;An Image Sharing App Built for an Independent Web&#8221;, Pressgram has received some major <a href="http://www.forbes.com/sites/toyota/2013/08/19/entrepreneur-develops-new-way-to-share-images-online/" title="Pressgram on Forbes" target="_blank">national attention</a>, given its direct confrontation of the very unpopular policies of Facebook and Instagram. The project was fully funded on <a href="http://www.kickstarter.com/projects/tentblogger/pressgram-an-image-sharing-app-built-for-an-indepe" target="_blank">Kickstarter</a> within 30 days, due to the support of a community that is passionate about owning their own data with full creative control.<br />
<span id="more-8801"></span></p>
<h3>What is Pressgram?</h3>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/11-user-profile-2.png" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/11-user-profile-2.png?resize=281%2C500" alt="11-user-profile-2" class="alignright size-large wp-image-8813" /></a>In case you haven&#8217;t been following, Pressgram is a photo-sharing app for iOS, created by Atlanta-based developer John Saddington. It is similar to Instagram but with a few serious distinctions: </p>
<ul>
<li> Powered by WordPress + iOS with Filtered Photos added in</li>
<li> Users will own their own data &#8211; your content is always yours</li>
<li> The target users are publishers</li>
<li> Currently makes use of open source photo filters</li>
</ul>
<p>When you use the Pressgram app in combination with the Pressgram WordPress plugin, the images are published to your blog through the typical post publishing process and are stored in the WordPress media folder. They are also stored in Amazon&#8217;s cloud storage and delivered to the Pressgram social network from there in order to create a consistent experience for the user within the application.</p>
<p>For now the <a href="http://wordpress.org/plugins/pressgram/" title="WordPress Pressgram plugin" target="_blank">Pressgram plugin for WordPress</a> simply de-clutters the homepage so that Pressgram posts don&#8217;t get mixed in with your longer-form content. In the future, Saddington plans to add more features based on user feedback and suggestions from the community.</p>
<h3>An Interview with John Saddington on Community and the Future of Pressgram</h3>
<p><div id="attachment_8817" class="wp-caption alignleft"><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/john-saddington.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/john-saddington.jpg?resize=300%2C300" alt="John Saddington, creator of Pressgram" class="size-medium wp-image-8817" /></a><p class="wp-caption-text">John Saddington, creator of Pressgram</p></div>I spoke with John Saddington on the eve of Pressgram&#8217;s launch into the app store. He was intent on building Pressgram, whether anyone was interested in it or not. He felt so strongly about owning his own data that he long ago cancelled his Facebook and Instagram accounts. </p>
<p>His Kickstarter initiative outlines the many compelling reasons for owning your own data by refusing to &#8220;line the pockets of another&#8217;s purse&#8221;, as he put it. The clear success of the fundraising efforts show that he is not alone in his thinking:</p>
<blockquote><p>&#8220;I was pleasantly surprised by how many other online publishers really &#8220;got&#8221; my intention and where I was headed with the application. They could see the value of posting images directly to their WordPress blogs and also the philosophical intent. Naturally I&#8217;m happy that it reached its funding goal but I would have still built the application out if I didn&#8217;t and that&#8217;s because I had originally intended on provisioning it on my own device for myself alone.&#8221; </p></blockquote>
<p>Pressgram also shares the community aspect that you&#8217;ve seen with Instagram and Saddington has already hand-picked a select few who will be offering their time and resources to help moderate, manage and grow the community that is springing up around this app. &#8220;This is so much bigger than just an &#8216;app&#8217;,&#8221; he said. &#8220;It&#8217;s a movement of creatives and artists and digital publishers who are rebelling against the unashamed commercial interests.&#8221;</p>
<h3>Why isn&#8217;t there an Android app?</h3>
<p>Given Instagram&#8217;s massive success after launching in the Android market, I was curious as to why Saddington didn&#8217;t start there first. I asked him how soon he&#8217;d be releasing an Android app. He said:</p>
<blockquote><p>The answer is quite simple &#8211; I know Objective-C programming as I&#8217;ve built a few apps in that environment but I&#8217;ve never built an Android app. And besides, I&#8217;ve only owned iOS-devices so the intent was to first scratch my own itch and then scratch other people&#8217;s if the interest was warranted and big enough. Apparently it&#8217;s quite large as there are a number of Kickstarter backers who are Android users and who are waiting for it to be released! I will have to build out a team though if I&#8217;m going to get to Android and that takes time and money.</p></blockquote>
<p>Since I am an Android user, I won&#8217;t be able to try it and will be depending on our readers for some initial reviews. </p>
<h4>Using Pressgram Without WordPress</h4>
<p><div id="attachment_8821" class="wp-caption alignright"><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/17-edit-image.png" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/17-edit-image.png?resize=281%2C500" alt="Photo filters on the Pressgram app" class="size-large wp-image-8821" /></a><p class="wp-caption-text">Photo filters on the Pressgram app are available even without using WordPress</p></div>Not everyone hosts their own blog. In fact, if Pressgram ever hopes to gain mass appeal, there must be an option for using it by itself. This is why Saddington made sure to account for non-WordPress users in his app:</p>
<blockquote><p>You can use Pressgram without ever connecting it directly to a WordPress blog &#8211; I believe many users will do this as the philosophical nature of not being part of the Facebook network where they monetize every single thing (<a href="http://blog.pressgr.am/soul/" target="_blank">and if they could have your soul they would</a>) that you are and do. Some users will just want to be part of a better social network as well as having the capabilities of filtering photos and sharing them.</p></blockquote>
<p>Saddington left Facebook and Instagram due to the licensing and policies that he did not agree with, but he still wanted to take pictures and add filters to them and wanted others to have the freedoms afforded to self-publishers who are not dependent on social networks. The <a href="http://blog.pressgr.am/">Pressgram blog</a> has been diligently pumping out posts on why any user, whether connected to WordPress or not, should carefully consider forsaking the data-hungry social networks and find a new way to share online. They&#8217;ve been driving a strong campaign for the open web and only time and downloads will tell how successful the app will be.</p>
<h3>Initial Proprietary License: Possible Open Source Licensing in the Future</h3>
<p>The Pressgram app is currently free to download and Saddington has confirmed that it will be so forever. So the philosophy behind Pressgram is all about freedom &#8211; for the user and the publisher. But what about the software itself?</p>
<p>During the final days of the project&#8217;s fundraising campaign, the largest backer of the project withdrew when he learned that it would not be open source:</p>
<blockquote class="twitter-tweet"><p>I canceled my pledge for <a href="https://twitter.com/Pressgram">@Pressgram</a> (10k) because project will be proprietary, not OS like I expected. Sorry for misunderstanding.</p>
<p>&mdash; Matt Mullenweg (@photomatt) <a href="https://twitter.com/photomatt/statuses/321729470346186752">April 9, 2013</a></p></blockquote>
<p></p>
<p>When I asked John if the project will ever move to an open source license he said that he is willing to consider it. Given his heavy involvement in working with OS in the past, I was curious as to what aspect of the project necessitates a proprietary license. For him it boils down to a matter of workflow and speed in getting the software out the door:</p>
<blockquote><p>&#8220;It was simply a personal decision that I made that would allow me to move faster in the way that I develop, engineer, and ship products. But again, this was a deeply personal project that had no intentions of being a publicly-used application at first. No one knew that I was working on it for 6 months (starting in September of 2012)! It was a &#8220;night and weekend&#8221; passion project that has grown into a little monster! In regards to making it OS in the future &#8211; I&#8217;m not sure yet. I can see the validity from both sides being experienced and a big part of open source for a very long time.</p></blockquote>
<p>This brings us to a very interesting question &#8211; should the developer&#8217;s workflow be a factor in the licensing of his project? I guess this is a very personal decision.  My hope is that John will opt for an open source license in the future and receive all the benefits of having contributors. You never know how many developers would be happy to submit bug fixes and new features to a worthy OS project, putting it much further down the road than one developer could ever go by himself.</p>
<p>Saddington hopes to reclaim lost freedoms for users in offering them a way to publish their photos to their own sites with full ownership. It&#8217;s a very special thing that he chose to use the WordPress platform to help people regain these freedoms. </p>
<p>However, WordPress wouldn&#8217;t be the fantastic application-building framework that it is today without its open source license. There&#8217;s no getting around that fact. Pressgram is entirely dependent on WordPress in order to deliver photos to the user&#8217;s home on the web. Is there any reason why Pressgram couldn&#8217;t benefit from those same open source principles that have made WordPress a resounding success?</p>
<p>These are interesting questions to consider. Congrats to Saddington and his team on launching the app today. Pressgram is an amazing example of how WordPress can be used to power a creative application with mass appeal. We&#8217;re likely to see many such apps in the future.</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/RWB28xAPVyI" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 05 Sep 2013 14:09:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"WPTavern: This Week On WPWeekly – Swiftype";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=8829";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://feedproxy.google.com/~r/WordpressTavern/~3/I50ByMaYXa4/this-week-on-wpweekly-swiftype";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1056:"<p>On this weeks edition of WordPress Weekly, <a href="https://swiftype.com/" title="https://swiftype.com/">Swiftype</a> will be our special guest. I <a href="http://www.wptavern.com/review-swiftype-search-plugin" title="http://www.wptavern.com/review-swiftype-search-plugin">reviewed their plugin/service</a> back in May. We plan on talking about why the search in WordPress is not as good as it should be, what makes search hard, the performance impacts of search and of course, the benefits of using search as a service versus the sites database. We&#8217;ll also cover the headlines of the week. If you have any questions about WordPress search, search, or Swiftype in particular, please place them in the comments. The show will air live this <strong>Friday at 9P.M. Eastern time</strong> and you can follow along via the <a href="http://www.wptavern.com/wordpress-weekly" title="http://www.wptavern.com/wordpress-weekly">WPWeekly Podcast page</a>.  </p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/I50ByMaYXa4" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Sep 2013 23:16:33 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WPTavern: Why WordCamp Detroit 2013 Was Cancelled";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=8799";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"http://feedproxy.google.com/~r/WordpressTavern/~3/JsYnol29nSM/why-wordcamp-detroit-2013-was-cancelled";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6761:"<p>It looks like the plug has been pulled on <a title="http://2013.detroit.wordcamp.org/wordcamp-detroit-2013-cancelled/" href="http://2013.detroit.wordcamp.org/wordcamp-detroit-2013-cancelled/">WordCamp Detroit 2013.</a> In a blog post published on September 3rd, 2013 TJList one of the organizers has announced that they have canceled this year&#8217;s WordCamp. The primary reason given was that they were not ready to put on a high-quality event. Those who have already purchased tickets will be refunded in full, including sponsors.</p>
<p>It&#8217;s not often I hear news of a WordCamp event being cancelled. In fact, I asked Andrea Middleton of WordCamp Central if this was the first WordCamp to be cancelled this year and she said yes. I got in touch with TJList to see if he could provide more insight into the cancellation and what lessons if any he learned throughout this whole ordeal so that other WordCamp organizers could avoid the same fate. <span id="more-8799"></span></p>
<p><strong>I know you outlined that this years event would not be able to meet high expectations that WordCamp attendees are accustomed to. Is there anyway you could share some more information with me that I could share with others that lead to this decision? Was it poor planning, lack of focus, or just not enough time to get things hammered out? Was the foundation helpful at all or were they one of the reasons for not being able to meet expectations? Any lessons learned that you can give other WordCamp organizers to avoid the same fate?</strong></p>
<p>In previous years, the lead organizer for WordCamp Detroit had experience organizing events. He is working on other things this year. Most of this year&#8217;s team had worked on previous events, but nobody had managed the big picture.The people at the WordPress Foundation responded quickly and were helpful, when we asked. We didn&#8217;t do that enough. </p>
<div id="attachment_4720" class="wp-caption aligncenter"><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2010/10/20101012-050426.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2010/10/20101012-050426.jpg?resize=225%2C300" alt="WordCamp Detroit 2010 Day 2" class="size-medium wp-image-4720" /></a><p class="wp-caption-text">WordCamp Detroit 2010 Day 2</p></div>
<p>When I took on the role of lead organizer, I greatly underestimated the amount of work required and the number of details to be considered. The team was also busy with life and work. The designer who did last year&#8217;s logo and theme was busy with some major projects in his business. I was wrapping up a year-long leadership development program that took a lot of my time. </p>
<p>We did not have anyone assigned to creating content and updating news. Publicity was limited to a few tweets and a couple of Facebook posts. Speaker applications were left with no response. No work was being done to contact sponsors. If it weren&#8217;t for multi-event sponsors we would not have had any event at all. Despite all that, we had a great initial response when the site went live. We sold nearly 20 tickets and had 18 applications to speak.</p>
<p>When my course ended and I started breathing again at the end of August, the ladies on the team said, &#8220;<em>We need to talk about this. Can we really pull this off?</em>&#8221; The answer, sadly enough, was &#8220;<em>No. Not without killing ourselves. Not with the level of quality we want to provide.</em>&#8221;</p>
<p><strong>My top 5 lessons learned:</strong><br />
<strong>1. Do your homework! </strong><br />
Read the helpful hints and suggestions that other WordCamp organizers have so generously left behind. There are a lot of killer resources out there. Use them.</p>
<p><strong>2. Start early. </strong><br />
Six months might be enough. Ask us that next summer and see if the answer changes.</p>
<p><strong>3. Ask for help. </strong><br />
Then do it again. And again.</p>
<p><strong>4. Create a detailed project plan. </strong><br />
Establish key milestones at the beginning of the process. Date, venue, theme for the conference, theme, website live date, cut-off dates for speaker submissions, etc. will all impact the quality of the event.</p>
<p><strong>5. Ask, don&#8217;t assume. </strong><br />
Get commitments from the key organizers and volunteers. What can they realistically deliver? We&#8217;re talking about doing this again in 2014. I&#8217;m starting fresh with number 1 from my list.</p>
<h2>The Importance Of Strong Leadership</h2>
<p>Ask anyone who has organized a WordCamp or any large event for that matter and they won&#8217;t tell you it was easy. Putting on these types of events requires strong leadership skills. Being a leader means you get things done, keep tabs on all of the work your organizers are accomplishing, provide a clear direction of tasks needing to be completed, and being an effective communicator. One of the last things TJ mentioned to me that he stressed I share with everyone else was the following:</p>
<blockquote><p>In all fairness to the other organizers, I was the source of the breakdown for the planning failure. I was unwilling and/or unable to communicate effectively, and I was not open with the rest of the team about my limited availability. Put bluntly, my early failure to lead and provide direction caused the planning to fall so far behind that we could not recover the event.</p></blockquote>
<p>Despite the event falling apart, I thank TJ for being open and honest about the situation. I hope other WordCamp organizers read this post and get a grasp as to how important being a leader is to facilitate a successful event. With the lessons learned, I can&#8217;t see how WordCamp Detroit 2014 would be anything but a success. </p>
<p>Back in 2010 during the first ever WordCamp Detroit, I interviewed lead organizer Anthony Montalbano where we briefly chatted about organizing the event. </p>
<div class="aligncenter"><div id="v-DlTshvAZ-1" class="video-player"><div><img alt="Interview With Anthony Montalbano" src="http://i1.wp.com/videos.videopress.com/DlTshvAZ/wcdetanthonyinterview_dvd.original.jpg?resize=560%2C420" /></div><p class="robots-nocontent">You do not have sufficient <a rel="nofollow" href="http://www.gnu.org/philosophy/free-sw.html">freedom levels</a> to view this video. Support free software and upgrade.</p></div></div>
<p>You can also read my <a href="http://www.wptavern.com/wordcamp-detroit-was-a-good-time" title="http://www.wptavern.com/wordcamp-detroit-was-a-good-time">review of WordCamp Detroit 2010</a> to get a sense of how well the event was run during its first year. </p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/JsYnol29nSM" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Sep 2013 19:13:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WordPress.tv: Panel Discussion: Big Business in the Smallest State";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21724";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://wordpress.tv/2013/09/04/panel-discussion-big-business-in-the-smallest-state/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:700:"<div id="v-tHWxgS8G-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21724/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21724/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21724&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/04/panel-discussion-big-business-in-the-smallest-state/"><img alt="Panel Discussion: Big Business in the Smallest State" src="http://videos.videopress.com/tHWxgS8G/big-business-in-the-smallest-state_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Sep 2013 10:35:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WordPress.tv: Reiko Beach: Digital Branding: You and Your Business";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21686";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wordpress.tv/2013/09/04/reiko-beach-digital-branding-you-and-your-business/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:703:"<div id="v-dRUo8z9j-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21686/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21686/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21686&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/04/reiko-beach-digital-branding-you-and-your-business/"><img alt="Reiko Beach: Digital Branding: You and Your Business" src="http://videos.videopress.com/dRUo8z9j/digital-branding-you-and-your-business_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 04 Sep 2013 10:33:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:80:"WPTavern: WPWeekly Episode 119 – The Triple A Of WordPress Support, WPSitecare";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=8762";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:127:"http://feedproxy.google.com/~r/WordpressTavern/~3/Uu8fsL5RdbI/wpweekly-episode-119-the-triple-a-of-wordpress-support-wpsitecare";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2650:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2.jpg?resize=150%2C150" alt="WordPress Weekly Cover Art" class="alignright size-thumbnail wp-image-8715" /></a> In this episode of WordPress Weekly we covered the headlines of the week and then spent the second half the show talking with Rami Abraham and Ryan Sullivan of <a href="http://www.wpsitecare.com/" title="http://www.wpsitecare.com/">WPSitecare.com</a>. As a company that specializes in supporting WordPress users in all sorts of situations, I thought it would be great to talk to them about what they are finding in terms of what is causing the most support queries. Themes, plugins, or WordPress. We discussed a number of topics such as webhosting, support, pricing, and general issues we have all faced with WordPress. <span id="more-8762"></span></p>
<h2>Stories Discussed:</h2>
<p><a href="http://www.wptavern.com/automatic-updates-possible-in-wordpress-3-7" title="http://www.wptavern.com/automatic-updates-possible-in-wordpress-3-7">Automatic Updates For WordPress 3.7</a><br />
<a href="http://www.wptavern.com/ben-sibley-on-the-state-of-wordpress-themes-2013" title="http://www.wptavern.com/ben-sibley-on-the-state-of-wordpress-themes-2013">State Of WordPress Themes</a><br />
<a href="http://www.wptavern.com/mollom-security-breach" title="http://www.wptavern.com/mollom-security-breach">Mollom Security Breach</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, September 6th 9P.M. Eastern &#8211; Interview With Swiftype</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Length Of Episode:</strong> 1 Hour 13 Minutes</p>
<p><strong>Download The Show:</strong> <a href="http://www.wptavern.com/wp-content/uploads/2013/09/EPISODE-119-The-Triple-A-Of-WordPress-Support-WPSitecare.mp3" target="_blank">EPISODE 119 &#8211; The Triple A Of WordPress Support.mp3</a></p>
<p><strong>Listen To Episode #119:</strong><br />
</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/Uu8fsL5RdbI" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Sep 2013 23:36:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Matt: Fear of Risk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=42967";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:34:"http://ma.tt/2013/09/fear-of-risk/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:410:"<p>Bruce Schneier has a remarkably clear essay on <a href="http://www.schneier.com/blog/archives/2013/09/our_newfound_fe.html">Our Newfound Fear of Risk</a> which could as easily be about corporations, finance, or relationships as it is about its chosen topic. It reminded me a lot of one of the better books I read this year, <a href="http://www.amazon.com/dp/B0083DJWGO/">Antifragile by Nassim Taleb</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Sep 2013 21:49:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Matt";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"Alex King: WordPress 3.6 Contributor T-shirts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=18209";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://alexking.org/blog/2013/09/03/wordpress-3-6-contributor-t-shirts";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:574:"<p><a href="http://alexking.org/blog/2013/09/03/wordpress-3-6-contributor-t-shirts"><img width="510" height="382" src="http://alexking.org/wp-content/uploads/2013/09/001-20130831-IMG_3789-510x382.jpg" class="attachment-medium-img wp-post-image" alt="WP 3.6 Contributor" /></a></p>
<p>I distributed t-shirts to the members of <a href="http://crowdfavorite.com">my team</a> that got patches in for WordPress 3.6 in our monthly team meeting today. We do this for each major release to encourage involvement in the community and to help continually build a better WordPress.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Sep 2013 18:54:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: EXCLUSIVE: Sarah Gooding Moves To The WordPress Tavern";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=8774";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:115:"http://feedproxy.google.com/~r/WordpressTavern/~3/MltI6jQxBr4/exclusive-sarah-gooding-moves-to-the-wordpress-tavern";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1884:"<p><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/09/wptavern.jpg?resize=300%2C300" alt="wptavern" class="alignright size-medium wp-image-8775" />Hello WordPress Tavern readers! Some of you may know me as a word wrangling WordPress writer from WPMU.org, where I spent the last four years writing about everything from WordPress and BuddyPress news to theme and product reviews, tutorials, and everything in between. Today, however, I&#8217;m excited to announce that I have officially moved to the Tavern.<span id="more-8774"></span></p>
<p>I&#8217;ve been using WordPress since 2008. For the past several years I have spent my time scouring the web for all the latest WordPress news and innovations. Plain and simple, I love staying on the front lines of WordPress. So when Matt Mullenweg invited me to join Jeffro and the team at the Tavern to report on WordPress news, I couldn&#8217;t say no. I am thrilled at the chance to chronicle WordPress history as it&#8217;s unfolding right now around the web.  </p>
<p>It&#8217;s also a great privilege to work with Jeffro, the Tavern Keeper, since he&#8217;s been doing this faithfully for ages. We&#8217;re teaming up to bring you the the best and most interesting WordPress news out there. So if you&#8217;ve been a fan of my articles in the past, please make sure to <a href="http://feeds2.feedburner.com/WordpressTavern" title="WPTavern Feed" target="_blank">subscribe here</a>, where you will be able to follow my new adventures at the Tavern. With WordPress powering roughly 20% of the web, there&#8217;s something awesome happening in this community every day and we&#8217;re going to make sure that you know about it. Grab a pint, pull up a chair and let&#8217;s start up some conversations about WordPress.</p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/MltI6jQxBr4" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Sep 2013 18:52:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:37:"WPTavern: Edit Flow, Jetpack, And MP6";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://www.wptavern.com/?p=8769";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://feedproxy.google.com/~r/WordpressTavern/~3/pOEZyGzfIso/edit-flow-jetpack-and-mp6";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3344:"<p>The following plugins have either been recently updated or have an update pending. I use all three and know a bunch of other people who use them as well. Jetpack 2.4 in combination with Photon is causing problems on certain websites where images are showing at their full size instead of their specified dimensions. Meanwhile, Edit Flow has been acting up for me since upgrading to WordPress 3.6. I just wanted to share my findings on each plugin thus far. <span id="more-8769"></span></p>
<p><strong>Edit Flow</strong> &#8211; After upgrading to WordPress 3.6, I discovered that I could not preview posts using the custom post status of Pitch. This took me forever to diagnose and figure out but it has something to do with the plugin not generating a revision which is shown as the post preview when the preview button is selected. I have demonstrated this bug to the developers at Automattic who are in control of this plugin and they are currently developing a fix. If you experience this problem with Edit Flow, I suggest you set your <em>Default</em> post status to Draft since the Draft post status works as expected. </p>
<p><strong>Jetpack 2.4</strong> &#8211; While 2.4 introduced the awesome <a href="http://www.wptavern.com/jetpack-2-4-adds-widget-visibility-module" title="http://www.wptavern.com/jetpack-2-4-adds-widget-visibility-module">Widget Visibility module</a>, it unfortunately caused images on websites to be displayed at their full size which has been determined to be an issue with Photo as outlined in <a href="http://wordpress.org/support/topic/jetpack-update-messes-up-photos?replies=17" title="http://wordpress.org/support/topic/jetpack-update-messes-up-photos?replies=17">this support thread</a>. If you&#8217;re experiencing the same issue after upgrading Jetpack to 2.4, you&#8217;re encouraged to disable Photon until an update is pushed out. </p>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/09/GearIcon.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/09/GearIcon.jpg?resize=145%2C150" alt="Gear Icons" class="alignright size-thumbnail wp-image-8770" /></a><strong>MP6 2.0</strong> MP6 2.0 was recently released and I&#8217;ve noticed a number of icons disappear from my menu which have been replaced with default Gear icons. I initially reported this as a bug on the <a href="http://wordpress.org/support/topic/mp6-20-replaced-menu-icons-with-gear-icon?replies=1" title="http://wordpress.org/support/topic/mp6-20-replaced-menu-icons-with-gear-icon?replies=1">support forums</a> but after reading the <a href="http://make.wordpress.org/ui/2013/08/31/mp6-2-0/" title="http://make.wordpress.org/ui/2013/08/31/mp6-2-0/">announcement post</a>, I see this is expected behaviour. Theme and plugin developers are encouraged to generate new menu icons that are compatible with MP6. Utilizing <a href="http://halfelf.org/2013/mp6uccess-tips-and-tricks/" title="http://halfelf.org/2013/mp6uccess-tips-and-tricks/">Mika Epstein&#8217;s post</a> as well as the <a href="https://github.com/tillkruess/MP6-Icon-Examples" title="https://github.com/tillkruess/MP6-Icon-Examples">MP6 icon examples</a> within the Git repository should provide a head start. </p>
<img src="http://feeds.feedburner.com/~r/WordpressTavern/~4/pOEZyGzfIso" height="1" width="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Sep 2013 14:03:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WordPress.tv: Lindsay Branscombe: Navigating the Forest of E-commerce: A Guided Tour";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21720";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:100:"http://wordpress.tv/2013/09/03/lindsay-branscombe-navigating-the-forest-of-e-commerce-a-guided-tour/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:733:"<div id="v-erZZhSL0-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21720/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21720/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21720&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/03/lindsay-branscombe-navigating-the-forest-of-e-commerce-a-guided-tour/"><img alt="Lindsay Branscombe: Navigating the Forest of E-commerce: A Guided Tour" src="http://videos.videopress.com/erZZhSL0/e-commerce-navigating-the-forest_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Sep 2013 10:47:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WordPress.tv: Sam Hotchkiss: WordPress Security: Preventing a Lot of Attacks";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21722";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://wordpress.tv/2013/09/03/sam-hotchkiss-wordpress-security-preventing-alot-of-attacks/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:723:"<div id="v-KFu6q2DD-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21722/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21722/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21722&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/03/sam-hotchkiss-wordpress-security-preventing-alot-of-attacks/"><img alt="Sam Hotchkiss: WordPress Security: Preventing a Lot of Attacks" src="http://videos.videopress.com/KFu6q2DD/wp-security-preventing-a-lot-of-attacks_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 03 Sep 2013 10:45:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"Joseph: Mike Adams on Three Security Issues You Thought You’d Fixed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"https://josephscott.org/?p=8826";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:100:"https://josephscott.org/archives/2013/09/mike-adams-on-three-security-issues-you-thought-youd-fixed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:625:"<p>Mike Adams spoke about <a href="http://wordpress.tv/2013/08/09/mike-adams-three-security-issues-you-thought-youd-fixed/">Three Security Issues You Thought You&#8217;d Fixed</a> at <a href="http://2013.sf.wordcamp.org/">WordCamp San Francisco 2013</a>.  Although this was at a WordPress event, the security issues he talks about apply more broadly to PHP and web sites in general.</p>
<p></p>
<p>I work with Mike at Automattic and we are <a href="http://automattic.com/work-with-us/">hiring</a>.  If you enjoy bunny puns you should check out our list of <a href="http://automattic.com/work-with-us/">open positions</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Sep 2013 17:44:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Joseph Scott";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WordPress.tv: Steph Yiu: VIP Tools for Writers and Editors";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21714";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.tv/2013/09/02/steph-yiu-vip-tools-for-writers-and-editors/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:673:"<div id="v-9O8YRv5j-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21714/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21714/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21714&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/02/steph-yiu-vip-tools-for-writers-and-editors/"><img alt="Steph Yiu: VIP Tools for Writers and Editors" src="http://videos.videopress.com/9O8YRv5j/borrowing-from-the-vips_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Sep 2013 10:50:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WordPress.tv: Jonathan Desrosiers: Plugin Development – Stirred not Shaken";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21718";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wordpress.tv/2013/09/02/jonathan-desrosiers-plugin-development/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:676:"<div id="v-wDymnUvQ-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21718/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21718/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21718&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/02/jonathan-desrosiers-plugin-development/"><img alt="Jon Desrosiers: Plugin Development – Stirred not Shaken" src="http://videos.videopress.com/wDymnUvQ/plugin-development_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 02 Sep 2013 10:48:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WordPress.tv: Jared Novack: How We Built 17,170,200 Websites in 6 Months";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21947";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:89:"http://wordpress.tv/2013/09/01/jared-novack-how-we-built-17170200-websites-in-6-months-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:650:"<div id="v-if2QpA7c-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21947/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21947/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21947&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/01/jared-novack-how-we-built-17170200-websites-in-6-months-2/"><img alt="jarednovak.mp4" src="http://videos.videopress.com/if2QpA7c/video-36d6b8ba58_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Sep 2013 13:57:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:97:"WordPress.tv: Matthew Boynes: Rewrite Recipes: Exploring Advanced Permalink Structures by Example";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=21704";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:113:"http://wordpress.tv/2013/09/01/matthew-boynes-rewrite-recipes-exploring-advanced-permalink-structures-by-example/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:767:"<div id="v-mg6WDwhx-1" class="video-player">
</div>
<br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/21704/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/21704/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=21704&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/09/01/matthew-boynes-rewrite-recipes-exploring-advanced-permalink-structures-by-example/"><img alt="Matthew Boynes: Rewrite Recipes: Exploring Advanced Permalink Structures by Example" src="http://videos.videopress.com/mg6WDwhx/rewrite-recipes-exploring-adv-structures_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 01 Sep 2013 10:57:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 12 Sep 2013 12:02:53 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"180110";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Thu, 12 Sep 2013 12:00:16 GMT";s:4:"x-nc";s:11:"HIT lax 250";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20130908064941";}', 'no') ; 
INSERT INTO `wp_options` VALUES (206, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1379030573', 'no') ; 
INSERT INTO `wp_options` VALUES (207, '_transient_timeout_feed_808390979aa7eed5a9c06ad6a9dd19d0', '1379030573', 'no') ; 
INSERT INTO `wp_options` VALUES (208, '_transient_feed_808390979aa7eed5a9c06ad6a9dd19d0', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:4:"
  
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:33:"
    
    
    
    
    
    
  ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"link:http://www.andytan.net/tigers/ - Google Blog Search";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://www.google.com/search?ie=utf-8&q=link:http://www.andytan.net/tigers/&tbm=blg&tbs=sbd:1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:87:"Your search - <b>link:http://www.andytan.net/tigers/</b> - did not match any documents.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://a9.com/-/spec/opensearch/1.1/";a:3:{s:12:"totalResults";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:10:"startIndex";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:12:"itemsPerPage";a:1:{i:0;a:5:{s:4:"data";s:2:"10";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:28:"text/xml; charset=ISO-8859-1";s:4:"date";s:29:"Thu, 12 Sep 2013 12:02:53 GMT";s:7:"expires";s:2:"-1";s:13:"cache-control";s:18:"private, max-age=0";s:10:"set-cookie";a:2:{i:0;s:143:"PREF=ID=10027d587664176d:FF=0:TM=1378987373:LM=1378987373:S=tOJ0l5piaHFZYagV; expires=Sat, 12-Sep-2015 12:02:53 GMT; path=/; domain=.google.com";i:1;s:212:"NID=67=FEW2RTvRzu8C6KAdPfSuvVYOlVn1SlVX14IjZ9xo07hGxdhFeBBEl6tBIIXc9RuAZGmVYt2Uyq7rrEqh_R9qZ0F_G2l_RQIpm-Cc55--q5WNtGEVqWh2plAnZo8YL7WU; expires=Fri, 14-Mar-2014 12:02:53 GMT; path=/; domain=.google.com; HttpOnly";}s:3:"p3p";s:122:"CP="This is not a P3P policy! See http://www.google.com/support/accounts/bin/answer.py?hl=en&answer=151657 for more info."";s:6:"server";s:3:"gws";s:16:"x-xss-protection";s:13:"1; mode=block";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20130908064941";}', 'no') ; 
INSERT INTO `wp_options` VALUES (209, '_transient_timeout_feed_mod_808390979aa7eed5a9c06ad6a9dd19d0', '1379030573', 'no') ; 
INSERT INTO `wp_options` VALUES (210, '_transient_feed_mod_808390979aa7eed5a9c06ad6a9dd19d0', '1378987373', 'no') ; 
INSERT INTO `wp_options` VALUES (211, '_transient_timeout_dash_20494a3d90a6669585674ed0eb8dcd8f', '1379030573', 'no') ; 
INSERT INTO `wp_options` VALUES (212, '_transient_dash_20494a3d90a6669585674ed0eb8dcd8f', '<p>This dashboard widget queries <a href="http://blogsearch.google.com/">Google Blog Search</a> so that when another blog links to your site it will show up here. It has found no incoming links&hellip; yet. It&#8217;s okay &#8212; there is no rush.</p>
', 'no') ; 
INSERT INTO `wp_options` VALUES (213, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:50:"
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Sep 2013 21:01:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:39:"http://wordpress.org/?v=3.7-alpha-25343";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress 3.6.1 Maintenance and Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/09/wordpress-3-6-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2013/09/wordpress-3-6-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Sep 2013 20:48:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2675";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:353:"After nearly 7 million downloads of WordPress 3.6, we are pleased to announce the availability of version 3.6.1. This maintenance release fixes 13 bugs in version 3.6, which was a very smooth release. WordPress 3.6.1 is also a security release for all previous WordPress versions and we strongly encourage you to update your sites immediately. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2033:"<p>After <a href="http://wordpress.org/download/counter/">nearly 7 million downloads</a> of WordPress 3.6, we are pleased to announce the availability of version 3.6.1. This maintenance release <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.6.1">fixes 13 bugs</a> in version 3.6, which was a very smooth release.</p>
<p><strong>WordPress 3.6.1 is also a security release for all previous WordPress versions</strong> and we strongly encourage you to update your sites immediately. It addresses three issues fixed by the WordPress security team:</p>
<ul>
<li>Block unsafe PHP unserialization that could occur in limited situations and setups, which can lead to remote code execution. Reported by <a href="http://vagosec.org/" rel="nofollow">Tom Van Goethem</a>.</li>
<li>Prevent a user with an Author role, using a specially crafted request, from being able to create a post &#8220;written by&#8221; another user. Reported by <a href="http://anakornk.wordpress.com/" rel="nofollow">Anakorn Kyavatanakij</a>.</li>
<li>Fix insufficient input validation that could result in redirecting or leading a user to another website. Reported by Dave Cummo, a Northrup Grumman subcontractor for the <a href="http://www.cdc.gov/" rel="nofollow">U.S. Centers for Disease Control and Prevention</a>.</li>
</ul>
<p>Additionally, we&#8217;ve adjusted security restrictions around file uploads to mitigate the potential for cross-site scripting.</p>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these issues directly to our security team. For more information on the changes, see the <a href="http://codex.wordpress.org/Version_3.6.1">release notes</a> or consult <a href="http://core.trac.wordpress.org/log/branches/3.6?stop_rev=24972&amp;rev=25345">the list of changes</a>.</p>
<p><a href="http://wordpress.org/wordpress-3.6.1.zip">Download WordPress 3.6.1</a> or update now from the Dashboard → Updates menu in your site&#8217;s admin area.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/09/wordpress-3-6-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.6 “Oscar”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2013/08/oscar/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2013/08/oscar/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Aug 2013 21:43:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2661";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:368:"The latest and greatest WordPress, version 3.6, is now live to the world and includes a beautiful new blog-centric theme, bullet-proof autosave and post locking, a revamped revision browser, native support for audio and video embeds, and improved integrations with Spotify, Rdio, and SoundCloud. Here&#8217;s a video that shows off some of the features using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:18626:"<p>The latest and greatest WordPress, version 3.6, is now <a href="http://wordpress.org/download/">live to the world</a> and includes a beautiful new blog-centric theme, bullet-proof autosave and post locking, a revamped revision browser, native support for audio and video embeds, and improved integrations with Spotify, Rdio, and SoundCloud. Here&#8217;s a video that shows off some of the features using our cast of professional actors:</p>
<div id="v-UmhwbWJH-1" class="video-player"><embed id="v-UmhwbWJH-1-video" src="http://s0.videopress.com/player.swf?v=1.03&amp;guid=UmhwbWJH&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" title="Introducing WordPress 3.6 &quot;Oscar&quot;" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<p>We&#8217;re calling this release &#8220;Oscar&#8221; in honor of the great jazz pianist <a href="http://en.wikipedia.org/wiki/Oscar_Peterson">Oscar Peterson</a>. Here&#8217;s a bit more about some of the new features, which you can also find on the about page in your dashboard after you upgrade.</p>
<h3>User Features</h3>
<p><img class="alignright" alt="" src="https://wordpress.org/images/core/3.6/twentythirteen.png" width="300" /></p>
<ul>
<li>The <strong>new Twenty Thirteen theme</strong> inspired by modern art puts focus on your content with a colorful, single-column design made for media-rich blogging.</li>
<li><strong>Revamped Revisions</strong> save every change and the new interface allows you to scroll easily through changes to see line-by-line who changed what and when.</li>
<li><strong>Post Locking</strong> and <strong>Augmented Autosave</strong> will especially be a boon to sites where more than a single author is working on a post. Each author now has their own autosave stream, which stores things locally as well as on the server (so much harder to lose something) and there&#8217;s an interface for taking over editing of a post, as demonstrated beautifully by our bearded buddies in the video above.</li>
<li><strong>Built-in HTML5 media player</strong> for native audio and video embeds with no reliance on external services.</li>
<li>The <strong>Menu Editor</strong> is now much easier to understand and use.</li>
</ul>
<h3>Developer features</h3>
<ul>
<li>A new audio/video API gives you access to metadata like ID3 tags.</li>
<li>You can now choose HTML5 markup for things like comment and search forms, and comment lists.</li>
<li>Better filters for how revisions work, so you can store a different amount of history for different post types.</li>
<li>Tons more <a href="http://codex.wordpress.org/Version_3.6">listed on the Codex</a>, and of course you can always <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.6">browse the over 700 closed tickets</a>.</li>
</ul>
<h3>The Band</h3>
<p>This release was led by <a href="http://markjaquith.com/">Mark Jaquith</a> and <a href="http://geekreprieve.com/">Aaron Campbell</a>, and included contributions from the following fine folks. Pull up some Oscar Peterson on your music service of choice, or vinyl if you have it, and check out some of their profiles:</p>
<p><a href="http://profiles.wordpress.org/technosailor">Aaron Brazell</a>, <a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/aaronholbrook">Aaron Holbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/adamsilverstein">adamsilverstein</a>, <a href="http://profiles.wordpress.org/akted">AK Ted</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/alexkingorg">Alex King</a>, <a href="http://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="http://profiles.wordpress.org/momo360modena">Amaury Balmer</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/anatolbroder">Anatol Broder</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/andrewryno">Andrew Ryno</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/gorgoglionemeister">Antonio</a>, <a href="http://profiles.wordpress.org/apimlott">apimlott</a>, <a href="http://profiles.wordpress.org/awellis13">awellis13</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/beaulebens">Beau Lebens</a>, <a href="http://profiles.wordpress.org/belloswan">BelloSwan</a>, <a href="http://profiles.wordpress.org/bilalcoder">bilalcoder</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy (bananastalktome)</a>, <a href="http://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="http://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brianlayman">Brian Layman</a>, <a href="http://profiles.wordpress.org/beezeee">Brian Zeligson</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/chmac">Callum Macdonald</a>, <a href="http://profiles.wordpress.org/carldanley">Carl Danley</a>, <a href="http://profiles.wordpress.org/caspie">Caspie</a>, <a href="http://profiles.wordpress.org/charlestonsw">Charleston Software Associates</a>, <a href="http://profiles.wordpress.org/cheeserolls">cheeserolls</a>, <a href="http://profiles.wordpress.org/chipbennett">Chip Bennett</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/cochran">Christopher Cochran</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/chriswallace">Chris Wallace</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/crazycoders">crazycoders</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/mzaweb">Daniel Dvorkin (MZAWeb)</a>, <a href="http://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="http://profiles.wordpress.org/daniloercoli">daniloercoli</a>, <a href="http://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="http://profiles.wordpress.org/csixty4">Dave Ross</a>, <a href="http://profiles.wordpress.org/dfavor">David Favor</a>, <a href="http://profiles.wordpress.org/jdtrower">David Trower</a>, <a href="http://profiles.wordpress.org/davidwilliamson">David Williamson</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/dllh">dllh</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling (ocean90)</a>, <a href="http://profiles.wordpress.org/dovyp">dovyp</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes (DrewAPicture)</a>, <a href="http://profiles.wordpress.org/dvarga">dvarga</a>, <a href="http://profiles.wordpress.org/cais">Edward Caissie</a>, <a href="http://profiles.wordpress.org/elfin">elfin</a>, <a href="http://profiles.wordpress.org/empireoflight">Empireoflight</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/faishal">faishal</a>, <a href="http://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/f-j-kaiser">Franz Josef Kaiser</a>, <a href="http://profiles.wordpress.org/fstop">FStop</a>, <a href="http://profiles.wordpress.org/mintindeed">Gabriel Koen</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/gcorne">gcorne</a>, <a href="http://profiles.wordpress.org/geertdd">GeertDD</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/gish">gish</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hbanken">hbanken</a>, <a href="http://profiles.wordpress.org/hebbet">hebbet</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/helgatheviking">helgatheviking</a>, <a href="http://profiles.wordpress.org/hirozed">hirozed</a>, <a href="http://profiles.wordpress.org/hurtige">hurtige</a>, <a href="http://profiles.wordpress.org/hypertextranch">hypertextranch</a>, <a href="http://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/jakub">jakub</a>, <a href="http://profiles.wordpress.org/h4ck3rm1k3">James Michael DuPont</a>, <a href="http://profiles.wordpress.org/jbutkus">jbutkus</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jerrysarcastic">Jerry Bates (JerrySarcastic)</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (Jayjdk)</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/joen">Joen Asmussen</a>, <a href="http://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn (johnbillion)</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/desrosj">Jonathan Desrosiers</a>, <a href="http://profiles.wordpress.org/jonbishop">Jon Bishop</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jcastaneda">Jose Castaneda</a>, <a href="http://profiles.wordpress.org/josephscott">Joseph Scott</a>, <a href="http://profiles.wordpress.org/jvisick77">Josh Visick</a>, <a href="http://profiles.wordpress.org/jrbeilke">jrbeilke</a>, <a href="http://profiles.wordpress.org/jrf">jrf</a>, <a href="http://profiles.wordpress.org/devesine">Justin de Vesine</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">kadamwhite</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/karmatosed">karmatosed</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/keoshi">keoshi</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/ktdreyer">ktdreyer</a>, <a href="http://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="http://profiles.wordpress.org/kwight">kwight</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis (leewillis77)</a>, <a href="http://profiles.wordpress.org/lessbloat">lessbloat</a>, <a href="http://profiles.wordpress.org/settle">Mantas Malcius</a>, <a href="http://profiles.wordpress.org/maor">Maor Chasen</a>, <a href="http://profiles.wordpress.org/macbrink">Marcel Brinkkemper</a>, <a href="http://profiles.wordpress.org/marcuspope">MarcusPope</a>, <a href="http://profiles.wordpress.org/mark-k">Mark-k</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markmcwilliams">Mark McWilliams</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="http://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="http://profiles.wordpress.org/matthewruddy">MatthewRuddy</a>, <a href="http://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/mgibbs189">mgibbs189</a>, <a href="http://profiles.wordpress.org/fanquake">Michael</a>, <a href="http://profiles.wordpress.org/mdawaffe">Michael Adams (mdawaffe)</a>, <a href="http://profiles.wordpress.org/tw2113">Michael Beckwith</a>, <a href="http://profiles.wordpress.org/mfields">Michael Fields</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/najamelan">najamelan</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="http://profiles.wordpress.org/nickdaugherty">Nick Daugherty</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/ninnypants">ninnypants</a>, <a href="http://profiles.wordpress.org/norcross">norcross</a>, <a href="http://profiles.wordpress.org/paradiseporridge">ParadisePorridge</a>, <a href="http://profiles.wordpress.org/pauldewouters">Paul</a>, <a href="http://profiles.wordpress.org/pdclark">Paul Clark</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/petemall">Pete Mall</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/phill_brown">Phill Brown</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/pollett">Pollett</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/programmin">programmin</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="http://profiles.wordpress.org/redpixelstudios">redpixelstudios</a>, <a href="http://profiles.wordpress.org/reidburke">reidburke</a>, <a href="http://profiles.wordpress.org/retlehs">retlehs</a>, <a href="http://profiles.wordpress.org/greuben">Reuben Gunday</a>, <a href="http://profiles.wordpress.org/rlerdorf">rlerdorf</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/roulandf">roulandf</a>, <a href="http://profiles.wordpress.org/rovo89">rovo89</a>, <a href="http://profiles.wordpress.org/ryanduff">Ryan Duff</a>, <a href="http://profiles.wordpress.org/ryanhellyer">Ryan Hellyer</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/zeo">Safirul Alredha</a>, <a href="http://profiles.wordpress.org/saracannon">sara cannon</a>, <a href="http://profiles.wordpress.org/scholesmafia">scholesmafia</a>, <a href="http://profiles.wordpress.org/sc0ttkclark">Scott Kingsley Clark</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/tenpura">Seisuke Kuraishi (tenpura)</a>, <a href="http://profiles.wordpress.org/sergej">Sergej</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/sim">Simon Hampel</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/slene">slene</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/srinig">SriniG</a>, <a href="http://profiles.wordpress.org/stephenh1988">Stephen Harris</a>, <a href="http://profiles.wordpress.org/storkontheroof">storkontheroof</a>, <a href="http://profiles.wordpress.org/sunnyratilal">Sunny Ratilal</a>, <a href="http://profiles.wordpress.org/sweetie089">sweetie089</a>, <a href="http://profiles.wordpress.org/tar">Tar</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/thomasvanderbeek">Thomas van der Beek</a>, <a href="http://profiles.wordpress.org/n7studios">Tim Carr</a>, <a href="http://profiles.wordpress.org/tjsingleton">tjsingleton</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/toscho">toscho</a>, <a href="http://profiles.wordpress.org/taupecat">Tracy Rotton</a>, <a href="http://profiles.wordpress.org/travishoffman">TravisHoffman</a>, <a href="http://profiles.wordpress.org/uuf6429">uuf6429</a>, <a href="http://profiles.wordpress.org/lightningspirit">Vitor Carvalho</a>, <a href="http://profiles.wordpress.org/wojtek">wojtek</a>, <a href="http://profiles.wordpress.org/wpewill">wpewill</a>, <a href="http://profiles.wordpress.org/wraithkenny">WraithKenny</a>, <a href="http://profiles.wordpress.org/wycks">wycks</a>, <a href="http://profiles.wordpress.org/xibe">Xavier Borderie</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/thelastcicada">Zachary Brown</a>, <a href="http://profiles.wordpress.org/tollmanz">Zack Tollman</a>, <a href="http://profiles.wordpress.org/zekeweeks">zekeweeks</a>, <a href="http://profiles.wordpress.org/ziegenberg">ziegenberg</a>, and <a href="http://profiles.wordpress.org/viniciusmassuchetto">viniciusmassuchetto</a>.</p>
<p>Time to upgrade!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2013/08/oscar/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.6 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2013/07/wordpress-3-6-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2013/07/wordpress-3-6-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Jul 2013 07:25:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2649";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:341:"The second release candidate for WordPress 3.6 is now available for download and testing. We&#8217;re down to only a few remaining issues, and the final release should be available in a matter of days. In RC2, we&#8217;ve tightened up some aspects of revisions, autosave, and the media player, and fixed some bugs that were spotted [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Mark Jaquith";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1325:"<p>The second release candidate for WordPress 3.6 is now available for download and testing.</p>
<p>We&#8217;re down to only a few remaining issues, and the final release should be available in a matter of days. In RC2, we&#8217;ve tightened up some aspects of revisions, autosave, and the media player, and fixed some bugs that were spotted in RC1. Please test this release candidate as much as you can, so we can deliver a smooth final release!</p>
<p><strong>Think you&#8217;ve found a bug?</strong> Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>.</p>
<p><strong>Developers,</strong> please continue to test your plugins and themes, so that if there is a compatibility issue, we can figure it out before the final release. You can find our <a href="http://core.trac.wordpress.org/report/6">list of known issues here</a>.</p>
<p>To test WordPress 3.6, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="http://wordpress.org/wordpress-3.6-RC2.zip">download the release candidate here (zip)</a>.</p>
<p><em>Revisions so smooth</em><br />
<em>We autosave your changes</em><br />
<em>Data loss begone!</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2013/07/wordpress-3-6-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.6 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2013/07/wordpress-3-6-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2013/07/wordpress-3-6-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 13 Jul 2013 03:23:17 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2639";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:344:"The first release candidate for WordPress 3.6 is now available. We hope to ship WordPress 3.6 in a couple weeks. But to do that, we really need your help! If you haven&#8217;t tested 3.6 yet, there&#8217;s no time like the present. (But please: not on a live production site, unless you&#8217;re feeling especially adventurous.) Think [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Mark Jaquith";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1504:"<p>The first release candidate for WordPress 3.6 is now available.</p>
<p>We hope to ship WordPress 3.6 in a couple weeks. But to do that, we really need your help! If you haven&#8217;t tested 3.6 yet, there&#8217;s no time like the present. (But please: not on a live production site, unless you&#8217;re feeling especially adventurous.)</p>
<p><strong>Think you&#8217;ve found a bug?</strong> Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="http://core.trac.wordpress.org/report/6">find them here</a>. <strong>Developers,</strong> please test your plugins and themes, so that if there is a compatibility issue, we can sort it out before the final release.</p>
<p>To test WordPress 3.6, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="http://wordpress.org/wordpress-3.6-RC1.zip">download the release candidate here (zip)</a>.</p>
<p>As you may have heard, we backed the Post Format UI feature out of the release. On the other hand, our slick new revisions browser had some extra time to develop. You should see it with 200+ revisions loaded — scrubbing back and forth at lightning speed is a thing of beauty.</p>
<p><em>Delayed, but still loved</em><br />
<em>The release will be out soon</em><br />
<em>Test it, por favor</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2013/07/wordpress-3-6-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"Annual WordPress Survey &amp; WCSF";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/news/2013/07/annual-wordpress-survey-wcsf/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wordpress.org/news/2013/07/annual-wordpress-survey-wcsf/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 09 Jul 2013 23:50:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"Events";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2625";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:347:"It&#8217;s time for our third annual user and developer survey! If you&#8217;re a WordPress user, developer, or business, we want your feedback. Just like previous years, we&#8217;ll share the data at the upcoming WordCamp San Francisco (WCSF). Results will also be sent to each survey respondent. It only takes a few minutes to fill out [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1242:"<p><img class="alignright" alt="" align="right" src="http://wpdotorg.files.wordpress.com/2013/07/wcsf-2013.jpg" width="278" height="185" />It&#8217;s time for our third annual user and developer survey! If you&#8217;re a WordPress user, developer, or business, we want your feedback. Just like previous years, we&#8217;ll share the data at the upcoming <a href="http://2013.sf.wordcamp.org/">WordCamp San Francisco</a> (WCSF). Results will also be sent to each survey respondent.</p>
<p>It only takes a few minutes to <a href="http://wp-survey.polldaddy.com/s/wp-2013">fill out the survey</a>, which will provide an overview of how people use WordPress.</p>
<p>If you missed past State of the Word keynotes, be sure to check out them out for survey results from <a href="http://wordpress.org/news/2011/08/state-of-the-word/">2011</a> and <a href="http://ma.tt/2012/08/state-of-the-word-2012/">2012</a>.</p>
<p>Speaking of WCSF, if you didn&#8217;t get a ticket or are too far away to attend, you can still <a href="http://2013.sf.wordcamp.org/tickets/">get a ticket for the live stream</a>! Watch the live video stream from the comfort of your home on July 26 and 27; WCSF t-shirt, or any shirt, optional.</p>
<p>I hope to see you there.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2013/07/annual-wordpress-survey-wcsf/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress 3.5.2 Maintenance and Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/06/wordpress-3-5-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2013/06/wordpress-3-5-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 21 Jun 2013 19:54:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2612";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:380:"WordPress 3.5.2 is now available. This is the second maintenance release of 3.5, fixing 12 bugs. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. The WordPress security team resolved seven security issues, and this release also contains some additional security hardening. The security fixes included: [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2549:"<p>WordPress 3.5.2 is now available. This is the second maintenance release of 3.5, fixing <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.5.2">12 bugs</a>. <strong>This is a security release for all previous versions and we strongly encourage you to update your sites immediately.</strong> The WordPress security team resolved seven security issues, and this release also contains some additional security hardening.</p>
<p>The security fixes included:</p>
<ul>
<li>Blocking server-side request forgery attacks, which could potentially enable an attacker to gain access to a site.</li>
<li>Disallow contributors from improperly publishing posts, reported by <a href="http://kovshenin.com/">Konstantin Kovshenin</a>, or reassigning the post&#8217;s authorship, reported by <a href="http://www.sharefaith.com/">Luke Bryan</a>.</li>
<li>An update to the SWFUpload external library to fix cross-site scripting vulnerabilities. Reported by <a href="http://ma.la">mala</a> and <a href="http://mars.iti.pk.edu.pl/~grucha/">Szymon Gruszecki</a>. (Developers: More on SWFUpload <a href="http://make.wordpress.org/core/2013/06/21/secure-swfupload/">here</a>.)</li>
<li>Prevention of a denial of service attack, affecting sites using password-protected posts.</li>
<li>An update to an external TinyMCE library to fix a cross-site scripting vulnerability. Reported by <a href="http://twitter.com/rinakikun">Wan Ikram</a>.</li>
<li>Multiple fixes for cross-site scripting. Reported by <a href="http://webapplicationsecurity.altervista.org/">Andrea Santese</a> and Rodrigo.</li>
<li>Avoid disclosing a full file path when a upload fails. Reported by <a href="http://hauntit.blogspot.de/">Jakub Galczyk</a>.</li>
</ul>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these issues directly to our security team. For more information on the changes, see the <a href="http://codex.wordpress.org/Version_3.5.2">release notes</a> or consult <a href="http://core.trac.wordpress.org/log/branches/3.5?rev=24498&amp;stop_rev=23347">the list of changes</a>.</p>
<p><a href="http://wordpress.org/wordpress-3.5.2.zip">Download WordPress 3.5.2</a> or update now from the Dashboard → Updates menu in your site’s admin area.</p>
<p><em>Also:</em> <strong>WordPress 3.6 Beta 4:</strong> If you are testing WordPress 3.6, please note that <a href="http://wordpress.org/wordpress-3.6-beta4.zip">WordPress 3.6 Beta 4</a> (zip) includes fixes for these security issues.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/06/wordpress-3-5-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Ten Good Years";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2013/05/ten-good-years/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/news/2013/05/ten-good-years/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 31 May 2013 17:54:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:4:"Meta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2606";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:343:"It&#8217;s been ten years since we started this thing, and what a long way we&#8217;ve come. From a discussion between myself and Mike Little about forking our favorite blogging software, to powering 18% of the web. It&#8217;s been a crazy, exciting, journey, and one that won&#8217;t stop any time soon. At ten years, it&#8217;s fun [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:9852:"<p><img class="alignright" alt="" align="right" src="http://wpdotorg.files.wordpress.com/2013/05/wp10.jpg" width="316" height="164" />It&#8217;s been ten years since we started this thing, and what a long way we&#8217;ve come. From a discussion between myself and <a href="http://mikelittle.org/">Mike Little</a> about <a href="http://ma.tt/2003/01/the-blogging-software-dilemma/">forking our favorite blogging software</a>, to powering 18% of the web. It&#8217;s been a crazy, exciting, journey, and one that won&#8217;t stop any time soon.</p>
<p>At ten years, it&#8217;s fun to reflect on our beginnings. We launched WordPress on 27th May 2003, but that wasn&#8217;t inception. Go back far enough, and you can <a href="http://zengun.org/weblog/archives/2001/06/post1958/">read a post by Michel Valdrighi</a> who, frustrated by the self-hosted blogging platforms available, decided to write his own software; &#8220;b2, a PHP+MySQL alternative to Blogger and GreyMatter.&#8221; b2 was easy to install, easy to configure, and easy for developers to extend. Of all the blogging platforms out there, <a href="http://cafelog.com">b2</a> was the right one for me: I could write my content and get it on the web quickly and painlessly.</p>
<p>Sometimes, however, life gets in the way. In 2002, Michel stopped maintaining b2. Over time, security flaws became apparent and updates were needed and, while the b2 community could write patches and fixes, no one was driving the software forward. We were lucky that Michel decided to release b2 under the GPL; the software may have been abandoned, but we weren&#8217;t without options. A fork was always a possibility. That was where it stood in January 2003, when <a href="http://ma.tt/2003/01/the-blogging-software-dilemma/">I posted about forking b2</a> and <a href="http://ma.tt/2003/01/the-blogging-software-dilemma/#comment-445">Mike responded</a>. The rest, as they say, is history.</p>
<p>From the very beginning to the present day, I&#8217;ve been impressed by the thought, care, and dedication that WordPress&#8217; developers have demonstrated. Each one has brought his or her unique perspective, each individual has strengthened the whole. It would be impossible to thank each of them here individually, but their achievements speak for themselves. In WordPress 1.2 the new Plugin API made it easy for developers to extend WordPress. In the same release <code>gettext()</code> internationalization opened WordPress up to every language (hat tip: <a href="http://ryan.boren.me/">Ryan Boren</a> for spending hours wrapping strings with gettext). In WordPress 1.5 our Theme system made it possible for WordPress users to quickly change their site&#8217;s design: there was huge resistance to the theme system from the wider community at the time, but can you imagine WordPress without it? Versions 2.7, 2.8, and 2.9 saw improvements that let users install and update their plugins and themes with one click. WordPress has seen a redesign by <a href="http://v2.happycog.com/create/wordpress/?p=design/wordpress/">happycog</a> (2.3) and gone under extensive user testing and redesign (<a href="http://www.slideshare.net/edanzico/riding-the-crazyhorse-future-generation-wordpress-presentation">Crazyhorse</a>, Liz Danzico and Jen Mylo, WordPress 2.5). In WordPress 3.0 we merged WordPress MU with WordPress &#8212; a huge job but 100% worth it. And in WordPress 3.5 we revamped the media uploader to make it easier for people to get their images, video, and media online.</p>
<p>In sticking to our commitment to user experience, we&#8217;ve done a few things that have made us unpopular. The <a href="http://tech.gaeatimes.com/index.php/archive/wordpress-wysiwyg-editor-is-a-disaster/">WYSIWYG editor</a> was hated by many, especially those who felt that if you have a blog you should know HTML. Some developers hated that we stuck with our code, refusing to rewrite, but it&#8217;s always been the users that matter: better a developer lose sleep than a site break for a user. Our code isn&#8217;t always beautiful, after all, when WordPress was created most of us were still learning PHP, but we try to make a flawless experience for users.</p>
<p>It&#8217;s not all about developers. WordPress&#8217; strength lies in the diversity of its community. From the start, we wanted a low barrier to entry and we came up with our &#8220;famous 5 minute install&#8221;. This brought on board users from varied technical background: people who didn&#8217;t write code wanted to help make WordPress better. If you couldn&#8217;t write code, it didn&#8217;t matter: you could answer a question in the support forums, write documentation, translate WordPress, or build your friends and family a WordPress website. There is <a href="https://make.wordpress.org/">space in the community</a> for anyone with a passion for WordPress.</p>
<p>It&#8217;s been wonderful to see all of the people who have used WordPress to build their home on the internet. Early on <a href="http://wordpress.org/news/2004/04/switchers/">we got excited</a> by <a href="http://wordpress.org/news/2004/04/more-switchers/">switchers</a>. From a community of tinkerers we grew, as writers such as <a href="http://ma.tt/2004/05/om-malik/">Om Malik</a>, <a href="http://dougal.gunters.org/blog/2004/05/15/mark-pilgrim-switches/">Mark Pilgrim</a>, and <a href="http://ma.tt/2004/07/mollycom-switches/">Molly Holzschlag</a> made the switch to WordPress. Our commitment to effortless publishing quickly paid off and has continued to do so: <strong>the WordPress 1.2 release saw 822 downloads per day, our latest release, WordPress 3.5, has seen 145,692 per day.</strong></p>
<p>I&#8217;m continually amazed by what people have built with WordPress. I&#8217;ve seen <a href="http://justintimberlake.com/main/">musicians</a> and <a href="http://ma.tt/2013/01/neil-leifer-on-wordpress/">photographers</a>, magazines such as <a href="http://life.time.com/">Life</a>, <a href="http://boingboing.net/">BoingBoing</a>, and the <a href="http://observer.com/">New York Observer</a>, <a href="http://www.compliance.gov/">government websites</a>, a <a href="http://josephscott.org/archives/2011/05/pressfs-a-wordpress-filesystem/">filesystem</a>, <a href="http://www.ymcanyc.org/association/pages/y-mvp"> mobile applications</a>, and even <a href="http://www.viper007bond.com/2010/06/12/so-apparently-wordpress-can-guide-missiles/">seen WordPress guide missiles</a>.</p>
<p>As the web evolves, WordPress evolves. Factors outside of our control will always influence WordPress&#8217; development: today it&#8217;s mobile devices and retina display, tomorrow it could be Google Glass or technology not yet conceived. A lot can happen in ten years! As technology changes and advances, WordPress has to change with it while remaining true to its core values: making publishing online easy for everyone. How we rise to these challenges will be what defines WordPress over the coming ten years.</p>
<p><strong>To celebrate ten years of WordPress, we&#8217;re working on a book about our history.</strong> We&#8217;re carrying out interviews with people who have involved with the community from the very beginning, those who are still around, and those who have left. It&#8217;s a huge project, but we wanted to have something to share with you on the 10th anniversary. To learn about the very early days of WordPress, just after Mike and I forked b2 <a href="http://wordpress.org/about/history/">you can download Chapter 3 right here</a>. We&#8217;ll be releasing the rest of the book serially, so watch out as the story of the last ten years emerges.</p>
<p>In the meantime, <a href="http://ma.tt/2013/05/dear-wordpress/"> I penned my own letter to WordPress</a> and other community members have been sharing their thoughts:</p>
<ul>
<li><a href="http://zed1.com/journalized/archives/2013/01/25/wordpress-a-10-year-journey/">Mike Little on our Ten Year Journey</a>.</li>
<li>Core contributor Helen Hou-Sandi <a href="http://helen.wordpress.com/2013/05/27/happy-10th-wordpress-and-thanks-from-my-little-family/">wishes WordPress happy birthday</a>.</li>
<li>Peter Westwood on <a href="http://blog.ftwr.co.uk/archives/2013/05/27/a-decade-gone-more-to-come/">a decade gone</a>.</li>
<li>Support rep Mika Epstein <a href="http://ipstenu.org/2013/you-me-and-wp/">on her WordPress journey</a>.</li>
<li>Dougal Campbell <a href="http://dougal.gunters.org/blog/2013/05/27/instagram-my-wife-suzecampbell-and-i-celebrating-the-wordpress-10th-anniversary-with-bbq-in-our-wordpress-shirts-wp10/">celebrating with his wife, Suze</a>.</li>
<li>Otto on <a href="http://ottodestruct.com/blog/2013/how-wp-affected-me/">how WordPress affected him</a>.</li>
</ul>
<p>You can see how WordPress&#8217; 10th Anniversary was celebrated all over the world <a href="http://wp10.wordpress.net/">by visiting the wp10 website</a>, according to Meetup we had 4,999 celebrators.</p>
<p>To finish, I just want to say thank you to everyone: to the developers who write the code, to the designers who make WordPress sing, to the worldwide community translating WordPress into so many languages, to volunteers who answer support questions, to those who make WordPress accessible, to the systems team and the plugin and theme reviewers, to documentation writers, event organisers, evangelists, detractors, supporters and friends. Thanks to the jazzers whose music inspired us and whose names are at the heart of WordPress. Thanks to everyone who uses WordPress to power their blog or website, and to everyone who will in the future. Thanks to WordPress and its community that I&#8217;m proud to be part of.</p>
<p>Thank you. I can&#8217;t wait to see what the next ten years bring.</p>
<p><em>Final thanks to <a href="http://siobhanmckeown.com/">Siobhan McKeown</a> for help with this post.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/news/2013/05/ten-good-years/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"The Next 10 Starts Now";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://wordpress.org/news/2013/05/the-next-10-starts-now/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2013/05/the-next-10-starts-now/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 27 May 2013 20:47:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2594";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:365:"All around the globe today, people are celebrating the 10th anniversary of the first WordPress release, affectionately known as #wp10. Watching the feed of photos, tweets, and posts from Auckland to Zambia is incredible; from first-time bloggers to successful WordPress-based business owners, people are coming out in droves to raise a glass and share the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"Jen Mylo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3901:"<p>All around the globe today, people are celebrating the 10th anniversary of the first WordPress release, affectionately known as #wp10. <a href="http://wp10.wordpress.net">Watching the feed</a> of photos, tweets, and posts from Auckland to Zambia is incredible; from first-time bloggers to successful WordPress-based business owners, people are coming out in droves to raise a glass and share the &#8220;holiday&#8221; with their local communities. With hundreds of parties going on today, it&#8217;s more visible than ever just how popular WordPress has become.</p>
<p><strong>Thank you to everyone who has ever contributed to this project: your labors of love made this day possible.</strong></p>
<p>But today isn&#8217;t just about reflecting on how we got this far (though I thought <a href="http://ma.tt/2013/05/dear-wordpress/">Matt&#8217;s reflection on the first ten years</a> was lovely). We are constantly moving forward. As each release cycle begins and ends (3.6 will be here soon, promise!), we always see an ebb and flow in the contributor pool. Part of ensuring the longevity of WordPress means mentoring new contributors, continually bringing new talent and fresh points of view to our family table.</p>
<p>I am beyond pleased to announce that this summer we will be mentoring 8 interns, most of them new contributors, through <a href="http://www.google-melange.com/gsoc/homepage/google/gsoc2013">Google Summer of Code</a> and the <a href="https://live.gnome.org/OutreachProgramForWomen/2013/JuneSeptember">Gnome Outreach Program for Women</a>. Current contributors, who already volunteer their time working on WordPress, will provide the guidance and oversight for a variety of exciting projects  this summer. Here are the people/projects involved in the summer internships:</p>
<ul>
<li><strong><strong>Ryan McCue</strong>, </strong>from Australia, working on a JSON-based REST API. Mentors will be Bryan Petty and Eric Mann, with a reviewer assist from Andrew Norcross.</li>
<li><strong>Kat Hagan</strong>, from the United States, working on a Post by Email plugin to replace the core function. Mentors will be Justin Shreve and George Stephanis, with an assist from Peter Westwood.</li>
<li><strong>Siobhan Bamber</strong>, from Wales, working on a support (forums, training, documentation) internship. Mentors will be Mika Epstein and Hanni Ross.</li>
<li><strong>Frederick Ding</strong>, from the United States, working on improving portability. Mentors will be Andrew Nacin and Mike Schroder.</li>
<li><strong>Sayak Sakar</strong>, from India, working on porting WordPress for WebOS to Firefox OS. Mentor will be Eric Johnson.</li>
<li><strong>Alex Höreth</strong>, from Germany, working on  adding WordPress native revisions to the theme and plugin code editors. Mentors will be Dominik Schilling and Aaron Campbell, with a reviewer assist from Daniel Bachhuber.</li>
<li><strong>Mert Yazicioglu</strong>, from Turkey, working on ways to improve our community profiles at profiles.wordpress.org. Mentors will be Scott Reilly and Boone Gorges.</li>
<li><strong>Daniele Maio</strong>, from Italy, working on a native WordPress app for Blackberry 10. Mentor will be Danilo Ercoli.</li>
</ul>
<p>Did you notice that our summer cohort is as international as the #wp10 parties going on today? I can only think that this is a good sign.</p>
<p>It&#8217;s always a difficult process to decide which projects to mentor through these programs. There are always more applicants with interesting ideas with whom we&#8217;d like to work than there are opportunities. Luckily, WordPress is a free/libre open source software project, and anyone can begin contributing at any time. Is this the year for you? We&#8217;d love for you to join us as we work toward #wp20. <img src=\'http://wordpress.org/news/wp-includes/images/smilies/icon_wink.gif\' alt=\';)\' class=\'wp-smiley\' /> </p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.org/news/2013/05/the-next-10-starts-now/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.6 Beta 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/05/wordpress-3-6-beta-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/05/wordpress-3-6-beta-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 11 May 2013 03:44:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2584";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:374:"WordPress 3.6 Beta 3 is now available! This is software still in development and we really don’t recommend that you run it on a production site — set up a test site just to play with the new version. To test WordPress 3.6, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can download the beta here (zip). Beta [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Mark Jaquith";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2452:"<p>WordPress 3.6 Beta 3 is now available!</p>
<p>This is software still in development and <strong>we <em>really</em> don’t recommend that you run it on a production site</strong> — set up a test site just to play with the new version. To test WordPress 3.6, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.6-beta3.zip">download the beta here</a> (zip).</p>
<p>Beta 3 contains about a hundred changes, including improvements to the image Post Format flow (yay, drag-and-drop image upload!), a more polished revision comparison screen, and a more quote-like quote format for Twenty Thirteen.</p>
<p>As a bonus, we now have oEmbed support for the popular music-streaming services <a href="http://www.rdio.com/">Rdio</a> and <a href="http://www.spotify.com/">Spotify</a> (the latter of which kindly created an oEmbed endpoint a mere 24 hours after we lamented their lack of one). Here&#8217;s an album that&#8217;s been getting a lot of play as I&#8217;ve been working on WordPress 3.6:</p>
<p><iframe width="500" height="250" src="https://rd.io/i/Qj5r8SE//?source=oembed" frameborder="0"></iframe></p>
<p><iframe src="https://embed.spotify.com/?uri=spotify:album:6dJZDZMNdBPZrJcNv57bEq" width="300" height="380" frameborder="0" allowtransparency="true"></iframe></p>
<p>Plugin developers, theme developers, and WordPress hosts should be testing beta 3 extensively. The more you test the beta, the more stable our release candidates and our final release will be.</p>
<p>As always, if you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.6">everything we&#8217;ve fixed</a> so far.</p>
<p>We&#8217;re looking forward to your feedback. If you find a bug, please report it, and if you’re a developer, try to help us fix it. We&#8217;ve already had more than 150 contributors to version 3.6 — it&#8217;s not too late to join in!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/05/wordpress-3-6-beta-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.6 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/04/wordpress-3-6-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/04/wordpress-3-6-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 29 Apr 2013 22:48:55 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2579";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:373:"WordPress 3.6 Beta 2 is now available! This is software still in development and we really don’t recommend that you run it on a production site — set up a test site just to play with the new version. To test WordPress 3.6, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can download the beta here (zip). The [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Mark Jaquith";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2057:"<p>WordPress 3.6 Beta 2 is now available!</p>
<p>This is software still in development and <strong>we <em>really</em> don’t recommend that you run it on a production site</strong> — set up a test site just to play with the new version. To test WordPress 3.6, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.6-beta2.zip">download the beta here</a> (zip).</p>
<p>The longer-than-usual delay between beta 1 and beta 2 was due to poor user testing results with the Post Formats UI. Beta 2 contains a modified approach for format choosing and switching, which has done well in user testing. We&#8217;ve also made the Post Formats UI hide-able via Screen Options, and set a reasonable default based on what your theme supports.</p>
<p>There were a lot of bug fixes and polishing tweaks done for beta 2 as well, so definitely check it out if you had an issues with beta 1.</p>
<p>Plugin developers, theme developers, and WordPress hosts should be testing beta 2 extensively. The more you test the beta, the more stable our release candidates and our final release will be.</p>
<p>As always, if you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.6">everything we&#8217;ve fixed</a> so far.</p>
<p>We&#8217;re looking forward to your feedback. If you find a bug, please report it, and if you’re a developer, try to help us fix it. We&#8217;ve already had more than 150 contributors to version 3.6 — it&#8217;s not too late to join in!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/04/wordpress-3-6-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 12 Sep 2013 12:02:52 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Wed, 11 Sep 2013 21:01:43 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130908064941";}', 'no') ; 
INSERT INTO `wp_options` VALUES (214, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1379030573', 'no') ; 
INSERT INTO `wp_options` VALUES (215, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1378987373', 'no') ; 
INSERT INTO `wp_options` VALUES (216, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1379030573', 'no') ; 
INSERT INTO `wp_options` VALUES (217, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2013/09/wordpress-3-6-1/\' title=\'After nearly 7 million downloads of WordPress 3.6, we are pleased to announce the availability of version 3.6.1. This maintenance release fixes 13 bugs in version 3.6, which was a very smooth release. WordPress 3.6.1 is also a security release for all previous WordPress versions and we strongly encourage you to update your sites immediately. […]\'>WordPress 3.6.1 Maintenance and Security Release</a> <span class="rss-date">September 11, 2013</span><div class=\'rssSummary\'>After nearly 7 million downloads of WordPress 3.6, we are pleased to announce the availability of version 3.6.1. This maintenance release fixes 13 bugs in version 3.6, which was a very smooth release. WordPress 3.6.1 is also a security release for all previous WordPress versions and we strongly encourage you to update your sites immediately. […]</div></li><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2013/08/oscar/\' title=\'The latest and greatest WordPress, version 3.6, is now live to the world and includes a beautiful new blog-centric theme, bullet-proof autosave and post locking, a revamped revision browser, native support for audio and video embeds, and improved integrations with Spotify, Rdio, and SoundCloud. Here’s a video that shows off some of the features using […]\'>WordPress 3.6 “Oscar”</a> <span class="rss-date">August 1, 2013</span><div class=\'rssSummary\'>The latest and greatest WordPress, version 3.6, is now live to the world and includes a beautiful new blog-centric theme, bullet-proof autosave and post locking, a revamped revision browser, native support for audio and video embeds, and improved integrations with Spotify, Rdio, and SoundCloud. Here’s a video that shows off some of the features using […]</div></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (218, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1379030574', 'no') ; 
INSERT INTO `wp_options` VALUES (219, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 12 Sep 2013 11:53:15 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:24:"Michael Adams (mdawaffe)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:86:"WordPress SEO plugin to automatically optimize your Wordpress blog for Search Engines.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:122:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 7.5 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Captcha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/captcha/#post-26129";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Apr 2011 05:53:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"26129@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:79:"This plugin allows you to implement super security captcha form into web forms.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"W3 Total Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/w3-total-cache/#post-12073";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 29 Jul 2009 18:46:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"12073@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"Easy Web Performance Optimization (WPO) using caching: browser, page, object, database, minify and content delivery network support.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"WP Smush.it";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wp-smushit/#post-7936";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 04 Dec 2008 00:00:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"7936@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:88:"Reduce image file sizes and improve performance using the Smush.it API within WordPress.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alex Dunae";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Fast Secure Contact Form";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/si-contact-form/#post-12636";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 27 Aug 2009 01:20:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"12636@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"A super customizable contact form that lets your visitors send you email. Blocks all automated spammers. No templates to mess with.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Mike Challis";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:12:"Contact Form";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/plugins/contact-form-plugin/#post-26890";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 26 May 2011 07:34:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"26890@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:43:"Add Contact Form to your WordPress website.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Really Simple CAPTCHA";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"http://wordpress.org/plugins/really-simple-captcha/#post-9542";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Mar 2009 02:17:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"9542@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:138:"Really Simple CAPTCHA is a CAPTCHA module intended to be called from other plugins. It is originally created for my Contact Form 7 plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:7:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Thu, 12 Sep 2013 12:02:53 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Thu, 20 Jan 2011 02:21:38 GMT";s:4:"x-nc";s:11:"HIT lax 250";}s:5:"build";s:14:"20130908064941";}', 'no') ; 
INSERT INTO `wp_options` VALUES (220, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1379030574', 'no') ; 
INSERT INTO `wp_options` VALUES (221, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1378987374', 'no') ; 
INSERT INTO `wp_options` VALUES (158, '_transient_is_multi_author', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (243, 'hmbkp_schedule_default-1', 'a:3:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (244, 'hmbkp_schedule_default-2', 'a:3:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (245, 'hmbkp_plugin_version', '2.3.3', 'yes') ; 
INSERT INTO `wp_options` VALUES (246, '_transient_timeout_hmbkp_plugin_data', '1379074710', 'no') ; 
INSERT INTO `wp_options` VALUES (247, '_transient_hmbkp_plugin_data', 'O:8:"stdClass":19:{s:4:"name";s:15:"BackUpWordPress";s:4:"slug";s:15:"backupwordpress";s:7:"version";s:5:"2.3.3";s:6:"author";s:47:"<a href="http://hmn.md/">Human Made Limited</a>";s:14:"author_profile";s:37:"http://profiles.wordpress.org/willmot";s:12:"contributors";a:7:{s:9:"humanmade";s:39:"http://profiles.wordpress.org/humanmade";s:7:"willmot";s:37:"http://profiles.wordpress.org/willmot";s:13:"pauldewouters";s:43:"http://profiles.wordpress.org/pauldewouters";s:8:"joehoyle";s:38:"http://profiles.wordpress.org/joehoyle";s:7:"mattheu";s:37:"http://profiles.wordpress.org/mattheu";s:9:"tcrsavage";s:39:"http://profiles.wordpress.org/tcrsavage";s:8:"cuvelier";s:0:"";}s:8:"requires";s:5:"3.3.3";s:6:"tested";s:5:"3.6.1";s:13:"compatibility";a:26:{s:5:"2.8.5";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:3:"2.9";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"2.9.1";a:1:{s:5:"0.4.5";a:3:{i:0;i:67;i:1;i:6;i:2;i:4;}}s:5:"2.9.2";a:1:{s:5:"0.4.5";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}}s:3:"3.0";a:2:{s:5:"0.4.5";a:3:{i:0;i:80;i:1;i:5;i:2;i:4;}s:5:"1.1.4";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:5:"3.0.1";a:1:{s:5:"0.4.5";a:3:{i:0;i:56;i:1;i:9;i:2;i:5;}}s:5:"3.0.2";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.0.3";a:1:{s:5:"0.4.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.0.4";a:2:{s:5:"0.4.5";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"1.1.4";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.0.5";a:1:{s:5:"0.4.5";a:3:{i:0;i:33;i:1;i:3;i:2;i:1;}}s:3:"3.1";a:9:{s:5:"0.4.5";a:3:{i:0;i:57;i:1;i:7;i:2;i:4;}s:5:"1.0.3";a:3:{i:0;i:50;i:1;i:2;i:2;i:1;}s:5:"1.0.4";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.0.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:3:"1.1";a:3:{i:0;i:50;i:1;i:2;i:2;i:1;}s:5:"1.1.1";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.1.2";a:3:{i:0;i:50;i:1;i:2;i:2;i:1;}s:5:"1.1.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.1.4";a:3:{i:0;i:50;i:1;i:4;i:2;i:2;}}s:5:"3.1.1";a:1:{s:5:"1.1.4";a:3:{i:0;i:90;i:1;i:10;i:2;i:9;}}s:5:"3.1.2";a:3:{s:5:"1.1.4";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:3:"1.2";a:3:{i:0;i:100;i:1;i:5;i:2;i:5;}s:3:"1.3";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}}s:5:"3.1.3";a:2:{s:3:"1.3";a:3:{i:0;i:67;i:1;i:6;i:2;i:4;}s:5:"1.3.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}}s:3:"3.2";a:3:{s:5:"0.1.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.3.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"1.6.2";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:5:"3.2.1";a:15:{s:5:"1.3.1";a:3:{i:0;i:67;i:1;i:9;i:2;i:6;}s:5:"1.3.2";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}s:8:"1.4 beta";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.4.1";a:3:{i:0;i:100;i:1;i:7;i:2;i:7;}s:3:"1.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.5.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:3:"1.6";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}s:5:"1.6.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.4";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.8";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.1.3";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}s:5:"2.2.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.2.4";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:3:"3.3";a:6:{s:3:"1.5";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"1.5.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"1.6.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.7";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.3.1";a:7:{s:5:"1.6.1";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:5:"1.6.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"1.6.3";a:3:{i:0;i:80;i:1;i:5;i:2;i:4;}s:5:"1.6.4";a:3:{i:0;i:100;i:1;i:9;i:2;i:9;}s:5:"1.6.5";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"1.6.6";a:3:{i:0;i:63;i:1;i:19;i:2;i:12;}s:5:"1.6.7";a:3:{i:0;i:100;i:1;i:8;i:2;i:8;}}s:5:"3.3.2";a:3:{s:5:"1.6.7";a:3:{i:0;i:100;i:1;i:5;i:2;i:5;}s:5:"1.6.8";a:3:{i:0;i:92;i:1;i:12;i:2;i:11;}s:5:"2.1.3";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}}s:3:"3.4";a:1:{s:5:"1.6.8";a:3:{i:0;i:100;i:1;i:6;i:2;i:6;}}s:5:"3.4.1";a:2:{s:5:"1.6.8";a:3:{i:0;i:100;i:1;i:12;i:2;i:12;}s:5:"1.6.9";a:3:{i:0;i:100;i:1;i:6;i:2;i:6;}}s:5:"3.4.2";a:9:{s:5:"1.6.9";a:3:{i:0;i:83;i:1;i:6;i:2;i:5;}s:8:"2.0 RC 1";a:3:{i:0;i:0;i:1;i:1;i:2;i:0;}s:5:"2.0.1";a:3:{i:0;i:45;i:1;i:22;i:2;i:10;}s:5:"2.0.3";a:3:{i:0;i:67;i:1;i:3;i:2;i:2;}s:5:"2.0.5";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.0.6";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}s:3:"2.1";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.1.1";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"2.1.3";a:3:{i:0;i:83;i:1;i:6;i:2;i:5;}}s:3:"3.5";a:1:{s:5:"2.1.3";a:3:{i:0;i:100;i:1;i:7;i:2;i:7;}}s:5:"3.5.1";a:5:{s:5:"2.1.3";a:3:{i:0;i:86;i:1;i:7;i:2;i:6;}s:3:"2.2";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}s:5:"2.2.1";a:3:{i:0;i:100;i:1;i:10;i:2;i:10;}s:5:"2.2.4";a:3:{i:0;i:94;i:1;i:16;i:2;i:15;}s:3:"2.3";a:3:{i:0;i:100;i:1;i:1;i:2;i:1;}}s:5:"3.5.2";a:3:{s:5:"2.2.4";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}s:3:"2.3";a:3:{i:0;i:57;i:1;i:14;i:2;i:8;}s:5:"2.3.3";a:3:{i:0;i:100;i:1;i:2;i:2;i:2;}}s:3:"3.6";a:2:{s:3:"2.3";a:3:{i:0;i:100;i:1;i:3;i:2;i:3;}s:5:"2.3.3";a:3:{i:0;i:50;i:1;i:6;i:2;i:3;}}}s:6:"rating";d:90.19999999999998863131622783839702606201171875;s:11:"num_ratings";i:496;s:10:"downloaded";i:693869;s:12:"last_updated";s:10:"2013-08-22";s:5:"added";s:10:"2007-09-02";s:8:"homepage";s:30:"http://hmn.md/backupwordpress/";s:8:"sections";a:5:{s:11:"description";s:1284:"<p>BackUpWordPress will back up your entire site including your database and all your files on a schedule that suits you.</p>

<h4>Features</h4>

<ul>
<li>Manage multiple schedules.</li>
<li>Super simple to use, no setup required.</li>
<li>Uses <code>zip</code> and <code>mysqldump</code> for faster back ups if they are available.</li>
<li>Works in low memory, "shared host" environments.</li>
<li>Option to have each backup file emailed to you.</li>
<li>Works on Linux &#38; Windows Server.</li>
<li>Exclude files and folders from your back ups.</li>
<li>Good support should you need help.</li>
<li>Translations for Spanish, German, Chinese, Romanian, Russian, Serbian, Lithuanian, Italian, Czech, Dutch, French, Basque.</li>
</ul>

<h4>Help develop this plugin</h4>

<p>The BackUpWordPress plugin is hosted GitHub, if you want to help out with development or testing then head over to <a href="https://github.com/humanmade/backupwordpress/" rel="nofollow">https://github.com/humanmade/backupwordpress/</a>.</p>

<h4>Translations</h4>

<p>We\'d also love help translating the plugin into more languages, if you can help then please contact <a href="mailto:support@hmn.md">support@hmn.md</a> or visit <a href="http://translate.hmn.md/" rel="nofollow">http://translate.hmn.md/</a>.</p>";s:12:"installation";s:460:"<ol>
<li>Install BackUpWordPress either via the WordPress.org plugin directory, or by uploading the files to your server.</li>
<li>Activate the plugin.</li>
<li>Sit back and relax safe in the knowledge that your whole site will be backed up every day.</li>
</ol>

<p>The plugin will try to use the <code>mysqldump</code> and <code>zip</code> commands via shell if they are available, using these will greatly improve the time it takes to back up your site.</p>";s:11:"screenshots";s:765:"<ol>
	<li>
		<img class=\'screenshot\' src=\'http://s-plugins.wordpress.org/backupwordpress/assets/screenshot-1.png?rev=602026\' alt=\'backupwordpress screenshot 1\' />
		<p>Manage multiple schedules.</p>
	</li>
	<li>
		<img class=\'screenshot\' src=\'http://s-plugins.wordpress.org/backupwordpress/assets/screenshot-2.png?rev=602026\' alt=\'backupwordpress screenshot 2\' />
		<p>Choose your schedule, backup type, number of backups to keep and whether to recieve a notification email.</p>
	</li>
	<li>
		<img class=\'screenshot\' src=\'http://s-plugins.wordpress.org/backupwordpress/assets/screenshot-3.png?rev=602026\' alt=\'backupwordpress screenshot 3\' />
		<p>Easily manage exclude rules and see exactly which files are included and excluded from your backup.</p>
	</li>
</ol>";s:9:"changelog";s:27461:"<h4>2.3.3</h4>

<ul>
<li>Add missing colorbox assets</li>
</ul>

<h4>2.3.2</h4>

<ul>
<li>Correct version number</li>
</ul>

<h4>2.3.1</h4>

<ul>
<li>Fix a PHP strict error</li>
<li>Save and close as separate buttons</li>
<li>Fix bug that caused multiple notification emails</li>
<li>Fixes typo in database option name</li>
<li>Updated translations</li>
<li>Improve PHP docblocks</li>
<li>Make schedules class a singleton</li>
<li>Exclude popular backup plugin folders by default</li>
<li>Exclude version control folders by default</li>
<li>Fix broken localisation</li>
</ul>

<h4>2.3</h4>

<ul>
<li>Replace Fancybox with Colorbox as Fancybox 2 isn\'t GPL compatible.</li>
<li>Use the correct <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant consistently in the help section.</li>
<li>Correct filename for some mis-named translation files.</li>
<li>Show the total estimated disk space a schedule could take up (max backups * estimated site size).</li>
<li>Fix a typo (your -&#62; you\'re).</li>
<li>Use the new time Constants and define backwords compatible ones for &#62; than 3.5.</li>
<li>Play nice with custom cron intervals.</li>
<li>Main plugin file is now <code>backupwordpress.php</code> for consistency.</li>
<li>Add Paul De Wouters (<code>pauldewouters</code>) as a contributor, welcome Paul!</li>
<li>Don\'t remove non-backup files from custom backup paths.</li>
<li>Fix a regression where setting a custom path which didn\'t exist could cause you to lose existing backups.</li>
<li>When moving paths only move backup files.</li>
<li>Make some untranslatable strings translatable.</li>
<li>Don\'t allow a single schedule to run in multiple threads at once, should finally fix edge case issues where some load balancer / proxies were causing multiple backups per run.</li>
<li>Only highlight the <code>HMBKP_SCHEDULE_TIME</code> constant in help if it\'s not the default value.</li>
<li>Remove help text for deprecated <code>HMBKP_EMAIL</code>.</li>
<li>Default to allways specificing <code>--single-transaction</code> when using <code>mysqldump</code> to backup the database, can be disabled by setting the <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code> to <code>false</code>.</li>
<li>Silence a <code>PHP Warning</code> if <code>mysql_pconnect</code> has been disabled.</li>
<li>Ensure dot directories <code>.</code> &#38; <code>..</code> are always skipped when looping the filesystem.</li>
<li>Work around a warning in the latest version of MySQL when using the <code>-p</code> flag with <code>mysqldunmp</code>.</li>
<li>Fix issues on IIS that could cause the root directory to be incorrectly calculated.</li>
<li>Fix an issue on IIS that could cause the download backup url to be incorrect.</li>
<li>Fix an issue on IIS that could mean your existing backups are lost when moving backup directory.</li>
<li>Avoid a <code>PHP FATAL ERROR</code> if the <code>mysql_set_charset</code> doesn\'t exist.</li>
<li>All unit tests now pass under IIS on Windows.</li>
<li>Prefix the backup directory with <code>backupwordpress-</code> so that it\'s easier to identify.</li>
<li>Re-calculate the backup directory name on plugin update and move backups.</li>
<li>Fix some issues with how <code>HMBKP_SECURE_KEY</code> was generated.</li>
</ul>

<h4>2.2.4</h4>

<ul>
<li>Fix a fatal error on PHP 5.2, sorry! (again.)</li>
</ul>

<h4>2.2.3</h4>

<ul>
<li>Fix a parse error, sorry!</li>
</ul>

<h4>2.2.2</h4>

<ul>
<li>Fix a fatal error when uninstalling.</li>
<li>Updated translations for Brazilian, French, Danish, Spanish, Czech, Slovakian, Polish, Italian, German, Latvian, Hebrew, Chinese &#38; Dutch.</li>
<li>Fix a possible notice when using the plugin on a server without internet access.</li>
<li>Don\'t show the wp-cron error message when <code>WP_USE_ALTERNATE_CRON</code> is defined as true.</li>
<li>Ability to override the max attachment size for email notifications using the new <code>HMBKP_ATTACHMENT_MAX_FILESIZE</code> constant.</li>
<li>Nonce some ajax request.</li>
<li>Silence warnings created if <code>is_executable</code>, <code>escapeshellcmd</code> or <code>escapeshellarg</code> are disabled.</li>
<li>Handle situations where the mysql port is set to something wierd.</li>
<li>Fallback to <code>mysql_connect</code> on system that disable <code>mysql_pconnect</code>.</li>
<li>You can now force the <code>--single-transaction</code> param when using <code>mysqldump</code> by defining <code>HMBKP_MYSQLDUMP_SINGLE_TRANSACTION</code>.</li>
<li>Unit tests for <code>HM_Backup::is_safe_mode_available()</code>.</li>
<li>Silence possible PHP Warnings when unlinking files.</li>
</ul>

<h4>2.2.1</h4>

<ul>
<li>Stop storing a list of unreadable files in the backup warnings as it\'s too memory intensive.</li>
<li>Revert the custom <code>RecursiveDirectoryIterator</code> as it caused an infinite loop on some servers.</li>
<li>Show all errors and warnings in the popup shown when a manual backup completes.</li>
<li>Write the .backup_error and .backup_warning files everytime an error or warning happens instead of waiting until the end of the backups process.</li>
<li>Fix a couple of <code>PHP E_STRICT</code> notices.</li>
<li>Catch more errors during the manual backup process and expose them to the user.</li>
</ul>

<h4>2.2</h4>

<ul>
<li>Don\'t repeatedly try to create the backups directory in the <code>uploads</code> if <code>uploads</code> isn\'t writable.</li>
<li>Show the correct path in the warning message when the backups path can\'t be created.</li>
<li>Include any user defined auth keys and salts when generating the HMBKP_SECURE_KEY.</li>
<li>Stop relying on the built in WordPress schedules as other plugins can mess with them.</li>
<li>Delete old backups everytime the backups page is viewed in an attempt to ensure old backups are always cleaned up.</li>
<li>Improve modals on small screens and mobile devices.</li>
<li>Use the retina spinner on retina screens.</li>
<li>Update buttons to the new 3.5 style.</li>
<li>Fix a possible fatal error caused when a symlink points to a location that is outside an <code>open_basedir</code> restriction.</li>
<li>Fix an issue that could cause backups using PclZip with a custom backups path to fail.</li>
<li>Security hardening by improving escaping, sanitizitation and validation.</li>
<li>Increase the timeout on the ajax cron check, should fix issues with cron errors showing on slow sites.</li>
<li>Only clear the cached backup filesize if the backup type changes.</li>
<li>Add unit tests for all the schedule recurrences.</li>
<li>Fix an issue which could cause weekly and monthly schedules to fail.</li>
<li>Add an <code>uninstall.php</code> file which removes all BackUpWordPress data and options.</li>
<li>Catch a possible fatal error in <code>RecursiveDirectoryIterator::hasChildren</code>.</li>
<li>Fix an issue that could cause mysqldump errors to be ignored thus causing the backup process to use an incomplete mysqldump file.</li>
</ul>

<h4>2.1.3</h4>

<ul>
<li>Fix a regression in <code>2.1.2</code> that broke previewing and adding new exclude rules.</li>
</ul>

<h4>2.1.2</h4>

<ul>
<li>Fix an issue that could stop the settings panel from closing on save on servers which return <code>\'0\'</code> for ajax requests.</li>
<li>Fix an issue that could cause the backup root to be set to <code>/</code> on sites with <code>site_url</code> and <code>home</code> set to different domains.</li>
<li>The mysqldump fallback function will now be used if <code>mysqldump</code> produces an empty file.</li>
<li>Fix a possible PHP <code>NOTICE</code> on Apache servers.</li>
</ul>

<h4>2.1.1</h4>

<ul>
<li>Fix a possible fatal error when a backup schedule is instantiated outside of wp-admin.</li>
<li>Don\'t use functions from misc.php as loading it too early can cause fatal errors.</li>
<li>Don\'t hardcode an English string in the JS, use the translated string instead.</li>
<li>Properly skip dot files, should fix fatal errors on systems with <code>open_basedir</code> restrictions.</li>
<li>Don\'t call <code>apache_mod_loaded</code> as it caused wierd DNS issue on some sites, use <code>global $is_apache</code> instead.</li>
<li>Fix a possible double full stop at the end of the schedule sentence.</li>
<li>Minor code cleanup.</li>
</ul>

<h4>2.1</h4>

<ul>
<li>Stop blocking people with <code>safe_mode = On</code> from using the plugin, instead just show a warning.</li>
<li>Fix possible fatal error when setting schedule to monthly.</li>
<li>Fix issues with download backup not working on some shared hosts.</li>
<li>Fix issuses with download backup not working on sites with strange characters in the site name.</li>
<li>Fix a bug could cause the update actions to fire on initial activation.</li>
<li>Improved reliability when changing backup paths, now with Unit Tests.</li>
<li>Generate the lists of excluded, included and unreadable files in a more memory efficient way, no more fatal errors on sites with lots of files.</li>
<li>Bring back .htaccess protection of the backups directory on <code>Apache</code> servers with <code>mod_rewrite</code> enabled.</li>
<li>Prepend a random string to the backups directory to make it harder to brute force guess.</li>
<li>Fall back to storing the backups directoy in <code>uploads</code> if <code>WP_CONTENT_DIR</code> isn\'t writable.</li>
<li>Attempt to catch <code>E_ERROR</code> level errors (Fatal errors) that happen during the backup process and offer to email them to support.</li>
<li>Provide more granular status messages during the backup process.</li>
<li>Show a spinner next to the schedule link when a backup is running on a schedule which you are not currently viewing.</li>
<li>Improve the feedback when removing an exclude rule.</li>
<li>Fix an issue that could cause an exclude rule to be marked as default when it in-fact isn\'t, thus not letting it be deleted.</li>
<li>Add a line encouraging people to rate the plugin if they like it.</li>
<li>Change the support line to point to the FAQ before recommending they contact support.</li>
<li>Fix the link to the "How to Restore" post in the FAQ.</li>
<li>Some string changes for translators, 18 changed strings.</li>
</ul>

<h4>2.0.6</h4>

<ul>
<li>Fix possible warning on plugin activation if the sites cron option is empty.</li>
<li>Don\'t show the version warning in the help for Constants as that comes from the current version.</li>
</ul>

<h4>2.0.5</h4>

<ul>
<li>Re-setup the cron schedules if they get deleted somehow.</li>
<li>Delete all BackUpWordPress cron entries when the plugin is deactivated.</li>
<li>Introduce the <code>HMBKP_SCHEDULE_TIME</code> constant to allow control over the time schedules run.</li>
<li>Make sure the schedule times and times of previous backups are shown in local time.</li>
<li>Fix a bug that could cause the legacy backup schedule to be created on every update, not just when going from 1.x to 2.x.</li>
<li>Improve the usefulness of the <code>wp-cron.php</code> response code check.</li>
<li>Use the built in <code>site_format</code> function for human readable filesizes instead of defining our own function.</li>
</ul>

<h4>2.0.4</h4>

<ul>
<li>Revert the change to the way the plugin url and path were calculated as it caused regressions on some systems.</li>
</ul>

<h4>2.0.3</h4>

<ul>
<li>Fix issues with scheduled backups not firing in some cases.</li>
<li>Better compatibility when the WP Remote plugin is active alongside BackUpWordPress.</li>
<li>Catch and display more WP Cron errors.</li>
<li>BackUpWordPress now fails to activate on WordPress 3.3.2 and below.</li>
<li>Other minor fixes and improvements.</li>
</ul>

<h4>2.0.2</h4>

<ul>
<li>Only send backup failed emails if the backup actually failed.</li>
<li>Turn off the generic "memory limit probably hit" message as it was showing for too many people.</li>
<li>Fix a possible notice when the backup running filename is blank.</li>
<li>Include the <code>wp_error</code> response in the cron check.</li>
</ul>

<h4>2.0.1</h4>

<ul>
<li>Fix fatal error on PHP 5.2.</li>
</ul>

<h4>2.0</h4>

<ul>
<li>Ability to have multiple schedules with separate settings &#38; excludes per schedule.</li>
<li>Ability to manage exclude rules and see exactly which files are included and excluded.</li>
<li>Fix an issue with sites with an <code>open_basedir</code> restriction.</li>
<li>Backups should now be much more reliable in low memory environments.</li>
<li>Lots of other minor improvements and bug fixes.</li>
</ul>

<h4>1.6.9</h4>

<ul>
<li>Updated and improved translations across the board - props @elektronikLexikon.</li>
<li>German translation - props @elektronikLexikon.</li>
<li>New Basque translation - props Unai ZC.</li>
<li>New Dutch translation - Anno De Vries.</li>
<li>New Italian translation.</li>
<li>Better support for when WordPress is installed in a sub directory - props @mattheu</li>
</ul>

<h4>1.6.8</h4>

<ul>
<li>French translation props Christophe - <a href="http://catarina.fr" rel="nofollow">http://catarina.fr</a>.</li>
<li>Updated Spanish Translation props DD666 - <a href="https://github.com/radinamatic" rel="nofollow">https://github.com/radinamatic</a>.</li>
<li>Serbian translation props StefanRistic - <a href="https://github.com/StefanRistic" rel="nofollow">https://github.com/StefanRistic</a>.</li>
<li>Lithuanian translation props Vincent G - <a href="http://www.Host1Free.com" rel="nofollow">http://www.Host1Free.com</a>.</li>
<li>Romanian translation.</li>
<li>Fix conflict with WP Remote.</li>
<li>Fix a minor issue where invalid email address\'s were still stored.</li>
<li>The root path that is backed up can now be controlled by defining <code>HMBKP_ROOT</code>.</li>
</ul>

<h4>1.6.7</h4>

<ul>
<li>Fix issue with backups being listed in reverse chronological order.</li>
<li>Fix issue with newest backup being deleted when you hit your max backups limit.</li>
<li>It\'s now possible to have backups sent to multiple email address\'s by entering them as a comma separated list.</li>
<li>Fix a bug which broke the ability to override the <code>mysqldump</code> path with <code>HMBKP_MYSQLDUMP_PATH</code>.</li>
<li>Use <code>echo</code> rather than <code>pwd</code> when testing <code>shell_exec</code> as it\'s supported cross platform.</li>
<li>Updated Spanish translation.</li>
<li>Fix a minor spelling mistake.</li>
<li>Speed up the manage backups page by caching the FAQ data for 24 hours.</li>
</ul>

<h4>1.6.6</h4>

<ul>
<li>Fix backup path issue with case sensitive filesystems.</li>
</ul>

<h4>1.6.5</h4>

<ul>
<li>Fix an issue with emailing backups that could cause the backup file to not be attached.</li>
<li>Fix an issue that could cause the backup to be marked as running for ever if emailing the backup <code>FATAL</code> error\'d.</li>
<li>Never show the running backup in the list of backups.</li>
<li>Show an error backup email failed to send.</li>
<li>Fix possible notice when deleting a backup file which doesn\'t exist.</li>
<li>Fix possible notice on older versions of <code>PHP</code> which don\'t define <code>E_DEPRECATED</code>.</li>
<li>Make <code>HMBKP_SECURE_KEY</code> override-able.</li>
<li>BackUpWordPress should now work when <code>ABSPATH</code> is <code>/</code>.</li>
</ul>

<h4>1.6.4</h4>

<ul>
<li>Don\'t show warning message as they cause to much panic.</li>
<li>Move previous methods errors to warnings in fallback methods.</li>
<li>Wrap <code>.htaccess</code> rewrite rules in if <code>mod_rewrite</code> check.</li>
<li>Add link to new restore help article to FAQ.</li>
<li>Fix issue that could cause "not using latest stable version" message to show when you were in-fact using the latest version.</li>
<li>Bug fix in <code>zip command</code> check that could cause an incorrect <code>zip</code> path to be used.</li>
<li>Detect and pass <code>MySQL</code> port to <code>mysqldump</code>.</li>
</ul>

<h4>1.6.3</h4>

<ul>
<li>Don\'t fail archive verification for errors in previous archive methods.</li>
<li>Improved detection of the <code>zip</code> and <code>mysqldump</code> commands.</li>
<li>Fix issues when <code>ABSPATH</code> is <code>/</code>.</li>
<li>Remove reliance on <code>SECURE_AUTH_KEY</code> as it\'s often not defined.</li>
<li>Use <code>warning()</code> not <code>error()</code> for issues reported by <code>zip</code>, <code>ZipArchive</code> &#38; <code>PclZip</code>.</li>
<li>Fix download zip on Windows when <code>ABSPATH</code> contains a trailing forward slash.</li>
<li>Send backup email after backup completes so that fatal errors in email code don\'t stop the backup from completing.</li>
<li>Add missing / to <code>PCLZIP_TEMPORARY_DIR</code> define.</li>
<li>Catch and display errors during <code>mysqldump</code>.</li>
</ul>

<h4>1.6.2</h4>

<ul>
<li>Track <code>PHP</code> errors as backup warnings not errors.</li>
<li>Only show warning message for <code>PHP</code> errors in BackUpWordPress files.</li>
<li>Ability to dismiss the error / warning messages.</li>
<li>Disable use of <code>PclZip</code> for full archive checking for now as it causes memory issues on some large sites.</li>
<li>Don\'t delete "number of backups" setting on update.</li>
<li>Better handling of multibyte characters in archive and database dump filenames.</li>
<li>Mark backup as running and increase callback timeout to <code>500</code> when firing backup via ajax.</li>
<li>Don\'t send backup email if backup failed.</li>
<li>Filter out duplicate exclude rules.</li>
</ul>

<h4>1.6.1</h4>

<ul>
<li>Fix fatal error on PHP =&#60; 5.3</li>
</ul>

<h4>1.6</h4>

<ul>
<li>Fixes issue with backups dir being included in backups on some Windows Servers.</li>
<li>Consistent handling of symlinks across all archive methods (they are followed).</li>
<li>Use .htaccess rewrite cond authentication to allow for secure http downloads of backup files.</li>
<li>Track errors and warnings that happen during backup and expose them through admin.</li>
<li>Fire manual backups using ajax instead of wp-cron, <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> is no longer needed and has been removed.</li>
<li>Ability to cancel a running backup.</li>
<li>Zip files are now integrity checked after every backup.</li>
<li>More robust handling of failed / corrupt zips, backup process now fallsback through the various zip methods until one works.</li>
<li>Use <code>mysql_query</code> instead of the depreciated <code>mysql_list_tables</code>.</li>
</ul>

<h4>1.5.2</h4>

<ul>
<li>Better handling of unreadable files in ZipArchive and the backup size calculation.</li>
<li>Support for wp-cli, usage: <code>wp backup [--files_only] [--database_only] [--path&#60;dir&#62;] [--root&#60;dir&#62;] [--zip_command_path=&#60;path&#62;] [--mysqldump_command_path=&#60;path&#62;]</code></li>
</ul>

<h4>1.5.1</h4>

<ul>
<li>Better detection of <code>zip</code> command.</li>
<li>Don\'t delete user settings on update / deactivate.</li>
<li>Use <code>ZipArchive</code> if <code>zip</code> is not available, still falls back to <code>PclZip</code> if neither <code>zip</code> nor <code>ZipArchive</code> are installed.</li>
<li>Better exclude rule parsing, fixes lots of edge cases, excludes now pass all 52 unit tests.</li>
<li>Improved the speed of the backup size calculation.</li>
</ul>

<h4>1.5</h4>

<ul>
<li>Re-written core backup engine should be more robust especially in edge case scenarios.</li>
<li>48 unit tests for the core backup engine, yay for unit tests.</li>
<li>Remove some extraneous status information from the admin interface.</li>
<li>Rename Advanced Options to Settings</li>
<li>New <code>Constant</code> <code>HMBKP_CAPABILITY</code> to allow the default <code>add_menu_page</code> capability to be changed.</li>
<li>Suppress possible filemtime warnings in some edge cases.</li>
<li>3.3 compatability.</li>
<li>Set proper charset of MySQL backup, props valericus.</li>
<li>Fix some inconsistencies between the estimated backup size and actual backup size when excluding files.</li>
</ul>

<h4>1.4.1</h4>

<ul>
<li>1.4 was incorrectly marked as beta.</li>
</ul>

<h4>1.4</h4>

<ul>
<li>Most options can now be set on the backups page, all options can still be set by defining them as <code>Constants</code>.</li>
<li>Russian translation, props valericus.</li>
<li>All dates are now translatable.</li>
<li>Fixed some strings which weren\'t translatable.</li>
<li>New Constant <code>HMBKP_DISABLE_MANUAL_BACKUP_CRON</code> which enable you to disable the use of <code>wp_cron</code> for manual backups.</li>
<li>Manual backups now work if <code>DISABLE_WP_CRON</code> is defined as <code>true</code>.</li>
</ul>

<h4>1.3.2</h4>

<ul>
<li>Spanish translation</li>
<li>Bump PHP version check to 5.2.4</li>
<li>Fallback to PHP mysqldump if shell_exec fails for any reason.</li>
<li>Silently ignore unreadable files / folders</li>
<li>Make sure binary data is properly exported when doing a mysqldump</li>
<li>Use 303 instead of 302 when redirecting in the admin.</li>
<li>Don\'t <code>set_time_limit</code> inside a loop</li>
<li>Use WordPress 3.2 style buttons</li>
<li>Don\'t pass an empty password to mysqldump</li>
</ul>

<h4>1.3.1</h4>

<ul>
<li>Check for PHP version. Deactivate plugin if running on PHP version 4.</li>
</ul>

<h4>1.3</h4>

<ul>
<li>Re-written back up engine, no longer copies everything to a tmp folder before zipping which should improve speed and reliability.</li>
<li>Support for excluding files and folders, define <code>HMBKP_EXCLUDE</code> with a comma separated list of files and folders to exclude, supports wildcards <code>*</code>, path fragments and absolute paths.</li>
<li>Full support for moving the backups directory, if you define a new backups directory then your existing backups will be moved to it.</li>
<li>Work around issues caused by low MySQL <code>wait_timeout</code> setting.</li>
<li>Add FAQ to readme.txt.</li>
<li>Pull FAQ into the contextual help tab on the backups page.</li>
<li>Block activation on old versions of WordPress.</li>
<li>Stop guessing compressed backup file size, instead just show size of site uncompressed.</li>
<li>Fix bug in <code>safe_mode</code> detection which could cause <code>Off</code> to act like <code>On</code>.</li>
<li>Better name for the database dump file.</li>
<li>Better name for the backup files.</li>
<li>Improve styling for advanced options.</li>
<li>Show examples for all advanced options.</li>
<li>Language improvements.</li>
<li>Layout tweaks.</li>
</ul>

<h4>1.2</h4>

<ul>
<li>Show live backup status in the back up now button when a back up is running.</li>
<li>Show free disk space after total used by backups.</li>
<li>Several langauge changes.</li>
<li>Work around the 1 cron every 60 seconds limit.</li>
<li>Store backup status in a 2 hour transient as a last ditch attempt to work around the "stuck on backup running" issue.</li>
<li>Show a warning and disable backups when PHP is in Safe Mode, may try to work round issues and re-enable in the future.</li>
<li>Highlight defined <code>Constants</code>.</li>
<li>Show defaults for all <code>Constants</code>.</li>
<li>Show a warning if both <code>HMBKP_FILES_ONLY</code> and <code>HMBKP_DATABASE_ONLY</code> are defined at the same time.</li>
<li>Make sure options added in 1.1.4 are cleared on de-activate.</li>
<li>Support <code>mysqldump on</code> Windows if it\'s available.</li>
<li>New option to have each backup emailed to you on completion. Props @matheu for the contribution.</li>
<li>Improved windows server support.</li>
</ul>

<h4>1.1.4</h4>

<ul>
<li>Fix a rare issue where database backups could fail when using the mysqldump PHP fallback if <code>mysql.max_links</code> is set to 2 or less.</li>
<li>Don\'t suppress <code>mysql_connect</code> errors in the mysqldump PHP fallback.</li>
<li>One time highlight of the most recent completed backup when viewing the manage backups page after a successful backup.</li>
<li>Fix a spelling error in the <code>shell_exec</code> disabled message.</li>
<li>Store the BackUpWordPress version as a <code>Constant</code> rather than a <code>Variable</code>.</li>
<li>Don\'t <code>(float)</code> the BackUpWordPress version number, fixes issues with minor versions numbers being truncated.</li>
<li>Minor PHPDoc improvements.</li>
</ul>

<h4>1.1.3</h4>

<ul>
<li>Attempt to re-connect if database connection hits a timeout while a backup is running, should fix issues with the "Back Up Now" button continuing to spin even though the backup is completed.</li>
<li>When using <code>PCLZIP</code> as the zip fallback don\'t store the files with absolute paths. Should fix issues unzipping the file archives using "Compressed (zipped) Folders" on Windows XP.</li>
</ul>

<h4>1.1.2</h4>

<ul>
<li>Fix a bug that stopped <code>HMBKP_DISABLE_AUTOMATIC_BACKUP</code> from working.</li>
</ul>

<h4>1.1.1</h4>

<ul>
<li>Fix a possible <code>max_execution_timeout</code> fatal error when attempting to calculate the path to <code>mysqldump</code>.</li>
<li>Clear the running backup status and reset the calculated filesize on update.</li>
<li>Show a link to the manage backups page in the plugin description.</li>
<li>Other general fixes.</li>
</ul>

<h4>1.1</h4>

<ul>
<li>Remove the logging facility as it provided little benefit and complicated the code, your existing logs will be deleted on update.</li>
<li>Expose the various <code>Constants</code> that can be defined to change advanced settings.</li>
<li>Added the ability to disable the automatic backups completely <code>define( \'HMBKP_DISABLE_AUTOMATIC_BACKUP\', true );</code>.</li>
<li>Added the ability to switch to file only or database only backups <code>define( \'HMBKP_FILES_ONLY\', true );</code> Or <code>define( \'HMBKP_DATABASE_ONLY\', true );</code>.</li>
<li>Added the ability to define how many old backups should be kept <code>define( \'HMBKP_MAX_BACKUPS\', 20 );</code></li>
<li>Added the ability to define the time that the daily backup should run <code>define( \'HMBKP_DAILY_SCHEDULE_TIME\', \'16:30\' );</code></li>
<li>Tweaks to the backups page layout.</li>
<li>General bug fixes and improvements.</li>
</ul>

<h4>1.0.5</h4>

<ul>
<li>Don\'t ajax load estimated backup size if it\'s already been calculated.</li>
<li>Fix time in backup complete log message.</li>
<li>Don\'t mark backup as running until cron has been called, will fix issues with backup showing as running even if cron never fired.</li>
<li>Show number of backups saved message.</li>
<li>Add a link to the backups page to the plugin action links.</li>
</ul>

<h4>1.0.4</h4>

<p>Don\'t throw PHP Warnings when <code>shell_exec</code> is disabled</p>

<h4>1.0.3</h4>

<p>Minor bug fix release.</p>

<ul>
<li>Suppress <code>filesize()</code> warnings when calculating backup size.</li>
<li>Plugin should now work when symlinked.</li>
<li>Remove all options on deactivate, you should now be able to deactivate then activate to fix issues with settings etc. becoming corrupt.</li>
<li>Call setup_defaults for users who update from backupwordpress 0.4.5 so they get new settings.</li>
<li>Don\'t ajax ping running backup status quite so often.</li>
</ul>

<h4>1.0.1 &#38; 1.0.2</h4>

<p>Fix some silly 1.0 bugs</p>

<h4>1.0</h4>

<p>1.0 represents a total rewrite &#38; rethink of the BackUpWordPress plugin with a focus on making it "Just Work". The management and development of the plugin has been taken over by <a href="http://hmn.md">Human Made Limited</a> the chaps behind <a href="https://wpremote.com">WP Remote</a></p>

<h4>Previous</h4>

<p>Version 0.4.5 and previous were developed by <a href="http://profiles.wordpress.org/users/wpdprx/">wpdprx</a></p>";s:3:"faq";s:4053:"<p><strong>Where does BackUpWordPress store the backup files?</strong></p>

<p>Backups are stored on your server in <code>/wp-content/backups</code>, you can change the directory.</p>

<p><strong>Important:</strong> By default BackUpWordPress backs up everything in your site root as well as your database, this includes any non WordPress folders that happen to be in your site root. This does means that your backup directory can get quite large.</p>

<p><strong>How do I restore my site from a backup?</strong></p>

<p>You need to download the latest backup file either by clicking download on the backups page or via <code>FTP</code>. <code>Unzip</code> the files and upload all the files to your server overwriting your site. You can then import the database using your hosts database management tool (likely <code>phpMyAdmin</code>).</p>

<p>See this post for more details <a href="http://hmn.md/backupwordpress-how-to-restore-from-backup-files/" rel="nofollow">http://hmn.md/backupwordpress-how-to-restore-from-backup-files/</a>.</p>

<p><strong>Does BackUpWordPress back up the backups directory?</strong></p>

<p>No.</p>

<p><strong>I\'m not receiving my backups by email</strong></p>

<p>Most servers have a filesize limit on email attachments, it\'s generally about 10mb. If your backup file is over that limit it won\'t be sent attached to the email, instead you should receive an email with a link to download the backup, if you aren\'t even receiving that then you likely have a mail issue on your server that you\'ll need to contact your host about.</p>

<p><strong>How many backups are stored by default?</strong></p>

<p>BackUpWordPress stores the last 10 backups by default.</p>

<p><strong>How long should a backup take?</strong></p>

<p>Unless your site is very large (many gigabytes) it should only take a few minutes to perform a back up, if your back up has been running for longer than an hour it\'s safe to assume that something has gone wrong, try de-activating and re-activating the plugin, if it keeps happening, contact support.</p>

<p><strong>What do I do if I get the wp-cron error message</strong></p>

<p>The issue is that your <code>wp-cron.php</code> is not returning a <code>200</code> response when hit with a http request originating from your own server, it could be several things, most of the time it\'s an issue with the server / site and not with BackUpWordPress.</p>

<p>Some things you can test are.</p>

<ul>
<li>Are scheduled posts working? (They use wp-cron too).</li>
<li>Are you hosted on Heart Internet? (wp-cron is known not to work with them).</li>
<li>If you click manual backup does it work?</li>
<li>Try adding <code>define( \'ALTERNATE_WP_CRON\', true ); to your</code>wp-config.php`, do automatic backups work?</li>
<li>Is your site private (I.E. is it behind some kind of authentication, maintenance plugin, .htaccess) if so wp-cron won\'t work until you remove it, if you are and you temporarily remove the authentication, do backups start working?</li>
</ul>

<p>If you have tried all these then feel free to contact support.</p>

<p><strong>How to get BackUpWordPress working in Heart Internet</strong></p>

<p>The script to be entered into the Heart Internet cPanel is: <code>/usr/bin/php5 /home/sites/yourdomain.com/public_html/wp-cron.php</code> (note the space between php5 and the location of the file). The file <code>wp-cron.php</code> <code>chmod</code> must be set to <code>711</code>.</p>

<p><strong>Further Support &#38; Feedback</strong></p>

<p>General support questions should be posted in the <a href="http://wordpress.org/tags/backupwordpress?forum_id=10">WordPress support forums, tagged with backupwordpress.</a></p>

<p>For development issues, feature requests or anybody wishing to help out with development checkout <a href="https://github.com/humanmade/backupwordpress/">BackUpWordPress on GitHub.</a></p>

<p>You can also tweet <a href="http://twitter.com/humanmadeltd">@humanmadeltd</a> or email <a href="mailto:support@hmn.md">support@hmn.md</a> for further help/support.</p>";}s:13:"download_link";s:63:"http://downloads.wordpress.org/plugin/backupwordpress.2.3.3.zip";s:4:"tags";a:10:{s:7:"archive";s:7:"archive";s:7:"back-up";s:7:"back up";s:6:"backup";s:6:"backup";s:7:"backups";s:7:"backups";s:8:"database";s:8:"database";s:2:"db";s:2:"db";s:5:"files";s:5:"files";s:9:"humanmade";s:9:"humanmade";s:6:"wp-cli";s:6:"wp-cli";s:3:"zip";s:3:"zip";}s:11:"donate_link";N;}', 'no') ; 
INSERT INTO `wp_options` VALUES (193, '_site_transient_timeout_wporg_theme_feature_list', '1378637544', 'yes') ; 
INSERT INTO `wp_options` VALUES (194, '_site_transient_wporg_theme_feature_list', 'a:5:{s:6:"Colors";a:15:{i:0;s:5:"black";i:1;s:4:"blue";i:2;s:5:"brown";i:3;s:4:"gray";i:4;s:5:"green";i:5;s:6:"orange";i:6;s:4:"pink";i:7;s:6:"purple";i:8;s:3:"red";i:9;s:6:"silver";i:10;s:3:"tan";i:11;s:5:"white";i:12;s:6:"yellow";i:13;s:4:"dark";i:14;s:5:"light";}s:7:"Columns";a:6:{i:0;s:10:"one-column";i:1;s:11:"two-columns";i:2;s:13:"three-columns";i:3;s:12:"four-columns";i:4;s:12:"left-sidebar";i:5;s:13:"right-sidebar";}s:5:"Width";a:2:{i:0;s:11:"fixed-width";i:1;s:14:"flexible-width";}s:8:"Features";a:19:{i:0;s:8:"blavatar";i:1;s:10:"buddypress";i:2;s:17:"custom-background";i:3;s:13:"custom-colors";i:4;s:13:"custom-header";i:5;s:11:"custom-menu";i:6;s:12:"editor-style";i:7;s:21:"featured-image-header";i:8;s:15:"featured-images";i:9;s:15:"flexible-header";i:10;s:20:"front-page-post-form";i:11;s:19:"full-width-template";i:12;s:12:"microformats";i:13;s:12:"post-formats";i:14;s:20:"rtl-language-support";i:15;s:11:"sticky-post";i:16;s:13:"theme-options";i:17;s:17:"threaded-comments";i:18;s:17:"translation-ready";}s:7:"Subject";a:3:{i:0;s:7:"holiday";i:1;s:13:"photoblogging";i:2;s:8:"seasonal";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (195, 'theme_mods_twentythirteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1378626744;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:0:{}s:19:"primary-widget-area";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:21:"secondary-widget-area";a:0:{}s:24:"first-footer-widget-area";a:0:{}s:25:"second-footer-widget-area";a:0:{}s:24:"third-footer-widget-area";a:0:{}s:25:"fourth-footer-widget-area";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (196, 'current_theme', 'Shape 2', 'yes') ; 
INSERT INTO `wp_options` VALUES (197, 'theme_mods_tigertheme', 'a:7:{i:0;b:0;s:16:"header_textcolor";s:6:"e9e0e1";s:16:"background_color";s:6:"e9e0d1";s:16:"background_image";s:0:"";s:17:"background_repeat";s:6:"repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (198, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (236, '_site_transient_update_core', 'O:8:"stdClass":3:{s:7:"updates";a:1:{i:0;O:8:"stdClass":9:{s:8:"response";s:6:"latest";s:8:"download";s:40:"http://wordpress.org/wordpress-3.6.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":4:{s:4:"full";s:40:"http://wordpress.org/wordpress-3.6.1.zip";s:10:"no_content";s:51:"http://wordpress.org/wordpress-3.6.1-no-content.zip";s:11:"new_bundled";s:52:"http://wordpress.org/wordpress-3.6.1-new-bundled.zip";s:7:"partial";b:0;}s:7:"current";s:5:"3.6.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.6";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1379015621;s:15:"version_checked";s:5:"3.6.1";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (248, '_transient_timeout_hmbkp_schedule_default-1_filesize', '2758063022', 'no') ; 
INSERT INTO `wp_options` VALUES (249, '_transient_hmbkp_schedule_default-1_filesize', '411488', 'no') ; 
INSERT INTO `wp_options` VALUES (253, '_transient_doing_cron', '1379044503.2635259628295898437500', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Friday 13. September 2013 03:55 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (1 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Friday 13. September 2013 03:55 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (3 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2013-09-07 12:44:34', '2013-09-07 12:44:34', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2013-09-07 12:44:34', '2013-09-07 12:44:34', '', 0, 'http://www.andytan.net/tigers/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2013-09-07 12:44:34', '2013-09-07 12:44:34', 'This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2013-09-07 12:44:34', '2013-09-07 12:44:34', '', 0, 'http://www.andytan.net/tigers/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (3, 1, '2013-09-07 02:46:55', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2013-09-07 02:46:55', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=3', 0, 'post', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Friday 13. September 2013 03:55 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (8 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (3, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (4, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (6, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Friday 13. September 2013 03:55 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (2 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'link_category', '', 0, 7) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Friday 13. September 2013 03:55 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (2 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Blogroll', 'blogroll', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Friday 13. September 2013 03:55 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (17 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'aim', '') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'yim', '') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'jabber', '') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '3') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_customize_current_theme_link') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'wp_user-settings', 'editor=tinymce') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'wp_user-settings-time', '1378626728') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Friday 13. September 2013 03:55 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'andy.tan2624', '$P$BIJNjFU5EZ3u/C/wMhI3gi1h/BfdvK1', 'admin', 'andy.tan2624@gmail.com', '', '2013-09-07 12:44:34', '', 0, 'admin') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

