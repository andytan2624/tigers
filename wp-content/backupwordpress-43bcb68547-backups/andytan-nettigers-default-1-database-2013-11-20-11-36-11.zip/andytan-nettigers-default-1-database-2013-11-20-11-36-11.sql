# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Wednesday 20. November 2013 11:36 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Wednesday 20. November 2013 11:36 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (2 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2010-06-18 20:51:35', '2010-06-18 20:51:35', 'Hi, this is a comment.<br />To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ; 
INSERT INTO `wp_comments` VALUES (2, 4, 'admin', 'andy.tan2624@gmail.com', '', '::1', '2013-11-16 12:21:15', '2013-11-16 12:21:15', 'DECHEN GENDUN', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.101 Safari/537.36', '', 0, 1) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Wednesday 20. November 2013 11:36 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (7 records)
#
 
INSERT INTO `wp_links` VALUES (1, 'http://codex.wordpress.org/', 'Documentation', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (2, 'http://wordpress.org/development/', 'WordPress Blog', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', 'http://wordpress.org/development/feed/') ; 
INSERT INTO `wp_links` VALUES (3, 'http://wordpress.org/extend/ideas/', 'Suggest Ideas', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (4, 'http://wordpress.org/support/', 'Support Forum', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (5, 'http://wordpress.org/extend/plugins/', 'Plugins', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (6, 'http://wordpress.org/extend/themes/', 'Themes', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (7, 'http://planet.wordpress.org/', 'WordPress Planet', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ;
#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Wednesday 20. November 2013 11:36 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=795 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (195 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'Gosford Tigers Australian Football Club', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'andy.tan2624@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'links_recently_updated_prepend', '<em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'links_recently_updated_append', '</em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'links_recently_updated_time', '120', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'permalink_structure', '/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (36, 'active_plugins', 'a:9:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:2;s:36:"contact-form-7/wp-contact-form-7.php";i:3;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:4;s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";i:5;s:30:"lightbox-plus/lightboxplus.php";i:6;s:45:"limit-login-attempts/limit-login-attempts.php";i:7;s:23:"ml-slider/ml-slider.php";i:8;s:40:"twitter-widget-pro/wp-twitter-widget.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'home', 'http://www.andytan.net/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (41, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'recently_edited', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'template', 'expound', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'stylesheet', 'expound', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (49, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'db_version', '25824', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'upload_path', '/home/andytann/public_html/tigers/wp-content/uploads', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (83, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'embed_size_w', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'embed_size_h', '600', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'page_on_front', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (101, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:9:"twitter-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (102, 'ftp_credentials', 'a:3:{s:8:"hostname";s:9:"localhost";s:8:"username";N;s:15:"connection_type";s:3:"ftp";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (103, 'uninstall_plugins', 'a:2:{s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";s:22:"hupso_plugin_uninstall";s:30:"lightbox-plus/lightboxplus.php";s:12:"UninstallLBP";}', 'no') ; 
INSERT INTO `wp_options` VALUES (104, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, 'link_manager_enabled', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, 'initial_db_version', '15260', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (108, 'cron', 'a:7:{i:1384915483;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1384915614;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1384919855;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1384974000;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1384988400;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}i:1385074800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (664, '_transient_timeout_feed_a09314b1a57acfaba9faaca775e0e5d2', '1384649721', 'no') ; 
INSERT INTO `wp_options` VALUES (665, '_transient_feed_a09314b1a57acfaba9faaca775e0e5d2', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Range:  Week in WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:13:"http://ran.ge";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:45:"High quality design and WordPress development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 22:18:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=3.7.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"Brian guest appears on a podcast  Week in WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/11/01/brian-guest-appears-on-a-podcast/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:67:"http://ran.ge/2013/11/01/brian-guest-appears-on-a-podcast/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 21:03:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4131";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:167:"Our own Brian Krogsgard talked to Matt Medeiros and Scott Sousa of Slocum Studio on Week in WordPress, a podcast about the news of the week in the WordPress ecosystem.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:555:"<p>Our own Brian Krogsgard talked to Matt Medeiros and Scott Sousa of <a href="http://slocumstudio.com/">Slocum Studio</a> on Week in WordPress, a podcast about the news of the week in the WordPress ecosystem.</p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/81i_v73ONgQ?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:63:"http://ran.ge/2013/11/01/brian-guest-appears-on-a-podcast/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Ranger Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://ran.ge/2013/10/13/ranger-brian-krogsgard/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:57:"http://ran.ge/2013/10/13/ranger-brian-krogsgard/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 13 Oct 2013 17:45:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:5:"Range";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4112";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:348:"Hey y&#8217;all. My name is Brian Krogsgard, and I&#8217;m happy to be joining Range as a Junior Partner. I&#8217;m looking forward to working with the outstanding team here. I&#8217;ve followed Range since its inception, and I&#8217;ve always loved their mentality that a small company could do big things. So, who am I? I graduated from [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1658:"<p><span style="line-height: 1.5;">Hey y&#8217;all. My name is Brian Krogsgard, and I&#8217;m happy to be joining Range as a Junior Partner. I&#8217;m looking forward to working with the outstanding team here.</span></p>
<p>I&#8217;ve followed Range since its inception, and I&#8217;ve always loved their mentality that a small company could do big things.</p>
<p>So, who am I?</p>
<p>I graduated from Auburn University with an Industrial Engineering degree, and for a few years web development was purely a hobby for me. My first job was as a technical sales engineer in the manufacturing industry, where I got my feet wet learning the value of effectively managing customer relationships and complex projects from start to finish.</p>
<p>But eventually I made the leap and turned my web development hobby into my career. Today, I bring experience building websites large and small across a variety of industries. I specialize in theme and light plugin development.</p>
<p>I also keep a keen eye on what&#8217;s happening in the WordPress community. I run a WordPress news blog called Post Status, which helps me learn more about my craft, share what I learn, and get to know many wonderful people that make the WordPress ecosystem great.</p>
<p>I&#8217;m based out of Birmingham, Alabama, where I live with my wife, Erica, and our blue Great Dane, Lucy May. I organize the Birmingham WordPress Meetup Group and co-organize WordCamp Birmingham.</p>
<p>At Range, I&#8217;ll wear many hats, just like Sara, Pete, and Aaron. My skill set compliments theirs nicely, and I really look forward to learning from them and bringing my best efforts to the table.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ran.ge/2013/10/13/ranger-brian-krogsgard/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"Disney Books relaunches on WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://ran.ge/2013/10/10/disney-books-relaunches-on-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:71:"http://ran.ge/2013/10/10/disney-books-relaunches-on-wordpress/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Oct 2013 14:32:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:8:"Branding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"Design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"Front End";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:17:"Project Spotlight";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4082";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:348:"Disney Publishing Worldwide has relaunched it&#8217;s books site, books.disney.com, on WordPress. When Disney came to us, we were excited, but it was clear that the biggest struggle was going to be the timeline. They wanted to build an all new books.disney.com on WordPress, and they needed it in less than a month. It was a tall order, [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Pete Mall";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1719:"<p><img class="size-large alignright" alt="disney-books-iphone" style="box-shadow: none;" src="http://s1.ran.ge/content/uploads/2013/10/disney-books-iphone-241x500.png" width="241" height="500" /><br />
Disney Publishing Worldwide has relaunched it&#8217;s books site, <a title="Disney Publishing Worldwide" href="http://books.disney.com/">books.disney.com</a>, on WordPress. When Disney came to us, we were excited, but it was clear that the biggest struggle was going to be the timeline. They wanted to build an all new books.disney.com on WordPress, and they needed it in less than a month. It was a tall order, but we pulled it off. From concept, to wireframing, design, development, and launch, Range put in a team effort to design and build the new books.disney.com.</p>
<p>In order to keep such a tight timeline, we knew wireframes needed to be done in less than a week, and the design needed to be finished just a week after that. Sara Cannon stepped up to the plate to lead the wireframes and design, and kept the schedule right on track. The design is also responsive, so it looks great on every device.</p>
<p>The development team pulled some crazy hours for a little while there, but the end result is an amazing site that meets our client&#8217;s needs and was delivered on time. We couldn&#8217;t have done it without Disney, who was a great partner. They held up their end of the bargain to trust our instincts and give quick feedback every time we needed it.</p>
<p>We are proud of the end result, and we hope you like it too. Be sure to <a title="Disney Publishing Worldwide" href="http://books.disney.com/">check out the site</a>, and who knows, you may find a new book for you and your family.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:67:"http://ran.ge/2013/10/10/disney-books-relaunches-on-wordpress/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Sara Cannon’s Be the Unicorn Published on Torque";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ran.ge/2013/07/29/sara-cannons-be-the-unicorn/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:62:"http://ran.ge/2013/07/29/sara-cannons-be-the-unicorn/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 30 Jul 2013 04:35:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:7:"Writing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"unicorns";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"writing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4024";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:342:"Check Out the full post on Torque at WCSF! Be The Unicorn by Sara Cannon What’s all this talk about Unicorns? Beautiful, sparkling, Golden Unicorns. My beginnings in Web Design and Development surfaced out of a love for technology an art. I was an artist and print designer with a thirst for something more. Because I wanted to [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2904:"<p><strong>Check Out the full post on <a href="http://torquemag.io/be-the-unicorn/">Torque</a> at WCSF!</strong></p>
<h3 style="padding-left: 60px;">Be The Unicorn by Sara Cannon</h3>
<p style="padding-left: 60px;">What’s all this talk about Unicorns? Beautiful, sparkling, Golden Unicorns.</p>
<p dir="ltr" style="padding-left: 60px;">My beginnings in Web Design and Development surfaced out of a love for technology an art. I was an artist and print designer with a thirst for something more. Because I wanted to be relevant and engaged, I ended up diving head first into the fast moving waters of web design and development. To get things done, I hunkered down, studied, imitated, and learned. To be completely self-sustainable, you end up learning bits of everything. I strived to become a renaissance woman. I wanted to build and create, without needing to rely on others to achieve my goals.</p>
<p dir="ltr" style="padding-left: 60px;">A few years later, I was hired by a small agency that really needed a one woman show. They did not want to need to rely multiple departments and titles to get the job done.</p>
<h3 dir="ltr" style="padding-left: 60px;">They needed a Golden Unicorn<img alt="" src="https://lh4.googleusercontent.com/Kf7Lg_5t9odG5Kjj7LF1MPQA39rSG3P_Thk7egmbWK8GEwAJ9hQ6lFcCZbFxbE3__nTgYNeF7qdMWcXI0Y0bl_lDQQFjQFsnrh_J2bZiyJGK_H-tNbPZbgZ8" width="223px;" height="233px;" /></h3>
<p dir="ltr" style="padding-left: 60px;">They wanted someone who could not only always solve the technical problems at hand, but had an eye for design and user experience. Someone who could say “yes that can happen” without hesitation and then google it right after making the promise. Since then, I decided to strive to be the unicorn.</p>
<p dir="ltr" style="padding-left: 60px;">In the industry now, there seems to be a long standing tension between designers and developers. This tension is manifested in the workplace, in social settings, but it is also within ourselves – with how we think. It is the longstanding battle of the left brain and right brain. The left side of the brain is known to be logical, analytical, and objective (hello technical directors!) while the right side is known to be intuitive, thoughtful, and subjective (creative thinkers). But the one thing both sides of our brains have in common is Problem Solving. Even though both sides are radically different, there is a common thread there. No one wants to be a code monkey or a pixel pusher. We want to solve problems, and do great work.</p>
<p dir="ltr" style="padding-left: 60px;"><img alt="" src="https://lh3.googleusercontent.com/Qw9xPk_1Ao-OXe8S2SSW0Qe78766iau8sXfgAQxvW46rljL5hG-ejlInKKnFFLPpSslgx0TYxyN-kS2lJ_T6l6tupzlWf0uaethYaGfFDW1yKzFWo1QLqx0X" width="652px;" height="484px;" /></p>
<p><strong>Check Out the rest of the Post on <a href="http://torquemag.io/be-the-unicorn/">Torque</a></strong></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/07/29/sara-cannons-be-the-unicorn/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"Pete Mall to talk about the YouTube Upload Widget Live today at 10am PDT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://ran.ge/2013/07/10/pete-mall-to-talk-about-the-youtube-upload-widget/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:84:"http://ran.ge/2013/07/10/pete-mall-to-talk-about-the-youtube-upload-widget/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 10 Jul 2013 16:26:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:5:"Range";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=3996";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:351:"Join Ran.ge and YouTube this week to find out more about our open source upload widget for WordPress. We will show you how it works and walk you through the source code for the widget itself. Tune in to @YouTube Developers Live at 10am PDT https://developers.google.com/live/shows/38132276-6003 &#160; update: check out the video of the show [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:840:"<p>Join Ran.ge and YouTube this week to find out more about our open source upload widget for WordPress. We will show you how it works and walk you through the source code for the widget itself.</p>
<p>Tune in to @YouTube Developers Live at 10am PDT</p>
<p><a title="Range and YouTube" href="https://developers.google.com/live/shows/38132276-6003">https://developers.google.com/live/shows/38132276-6003</a></p>
<p>&nbsp;</p>
<p><em>update: check out the video of the show &amp; demo below!</em></p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/LXYwLo4fkIA?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:80:"http://ran.ge/2013/07/10/pete-mall-to-talk-about-the-youtube-upload-widget/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"Sara Cannon to Speak in Montreal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/04/17/sara-cannon-to-speak-in-montreal/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:67:"http://ran.ge/2013/04/17/sara-cannon-to-speak-in-montreal/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 17 Apr 2013 18:01:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:25:"http://dev.ran.ge/?p=3916";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:320:"I can&#8217;t tell you how excited I am to be able to speak at the Montreal WordPress Developers Meetup and the Montreal Girl Geeks! On Tuesday, April 23: The Future of UI: How Mobile Design is Shaping the Web Web design is not an interactive brochure anymore. Smart mobile devices have forever changed the way [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4096:"<p>I can&#8217;t tell you how excited I am to be able to speak at the <a href="http://wpmtl.org/2013/04/montreal-wordpress-developer_meetup-april-23rd-2013/">Montreal WordPress Developers Meetup</a> and the <a href="http://montrealgirlgeeks.com/2013/04/18/april-event/">Montreal Girl Geeks</a>!</p>
<hr />
<p><img class="size-full wp-image-3918 alignleft" alt="wcmtl-developer-meetup-facebook-size-179px" src="http://s1.ran.ge/content/uploads/2013/05/wcmtl-developer-meetup-facebook-size-179px.png" width="179" height="126" />On Tuesday, April 23:</p>
<p><strong>The Future of UI: How Mobile Design is Shaping the Web</strong></p>
<p>Web design is not an interactive brochure anymore. Smart mobile devices have forever changed the way we think and interact with websites. Now you have to consider an array of things you didn’t have to worry about before, such as HiDPI graphics, UI/UX patterns, touch target sizes, gestures, and managing expectations. All the while not losing track of what’s important: Content.</p>
<p>We’re going to discuss the influence of mobile on design, trends, and implementation methods, as well as how touch is changing our lives. As designers and developers, we can benefit from learning about how mobile is changing the way we interact with websites, and what that means for the future of UI. <a href="http://wpmtl.org/2013/04/montreal-wordpress-developer_meetup-april-23rd-2013/" target="_blank" rel="nofollow nofollow">http://wpmtl.org/2013/04/montreal-wordpress-developer_meetup-april-23rd-2013/</a></p>
<p><iframe style="border: 1px solid #CCC; border-width: 1px 1px 0; margin-bottom: 5px;" src="http://www.slideshare.net/slideshow/embed_code/19911427" height="356" width="427" allowfullscreen="" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></p>
<div style="margin-bottom: 5px;"><strong> <a title="The Future of UI - How Mobile Design is Shaping The Web 2" href="http://www.slideshare.net/saracannon/the-future-of-ui-how-mobile-design-is-shaping-the-web-2" target="_blank">The Future of UI &#8211; How Mobile Design is Shaping The Web 2</a> </strong> from <strong><a href="http://www.slideshare.net/saracannon" target="_blank">Sara Cannon</a></strong></div>
<hr />
<p><img class="alignleft size-full wp-image-3917" alt="MTLGGbarcode1-300x300" src="http://s1.ran.ge/content/uploads/2013/05/MTLGGbarcode1-300x300.jpg" width="300" height="300" />On Thursday, April 25:</p>
<p><strong>Font Swoon!</strong></p>
<p>Times New Roman. Helvetica. Comic Sans. We’ve all got fonts we love to use or love to hate. Typography is one of those topics that’s easy to overlook, but when you bring it up, everyone has an opinion. Sara’s talk is not just for designers spending hours debating on the slant of a curly-quote or the perfect sans serif – it’s for anyone who’s ever typed, read, or even just stared at the screen or page. Because typography is essential to how we read, consume, convey, and process the written word and it’s BFF, design.</p>
<p>Let’s take our relationship with web typography to the next level and crush on the latest fonts, check out some awesome CSS3 implementations, and find incredible inspiration for interaction, refinement and our next dates with negative space. Come fall head over heels with us at Font Swoon! <a href="http://montrealgirlgeeks.com/2013/04/18/april-event/" target="_blank" rel="nofollow nofollow">http://montrealgirlgeeks.com/2013/04/18/april-event/</a></p>
<p><iframe style="border: 1px solid #CCC; border-width: 1px 1px 0; margin-bottom: 5px;" src="http://www.slideshare.net/slideshow/embed_code/19994942" height="356" width="427" allowfullscreen="" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></p>
<div style="margin-bottom: 5px;"><strong> <a title="Font swoon" href="http://www.slideshare.net/saracannon/font-swoon" target="_blank">Font swoon</a> </strong> from <strong><a href="http://www.slideshare.net/saracannon" target="_blank">Sara Cannon</a></strong></div>
<p>If you are in Montreal, come on out &#8211; I&#8217;d love to meet you!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:63:"http://ran.ge/2013/04/17/sara-cannon-to-speak-in-montreal/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Join Me at WordSesh Tonight!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ran.ge/2013/04/12/join-me-at-wordsesh-tonight/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:62:"http://ran.ge/2013/04/12/join-me-at-wordsesh-tonight/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 12 Apr 2013 21:24:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"be the unicorn";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"WordSesh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=1844";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:365:"Tonight I&#8217;m going to be speaking at the first ever WordSesh online WordPress Conference! WordSesh is a day of live WordPress presentations from all over the world streamed live, and it&#8217;s free! Tune in at 4UTC 12am EST (midnight tonight!) to join me in my talk &#8220;Be the Unicorn.&#8221; I&#8217;m really looking forward to hearing all the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:519:"<p>Tonight I&#8217;m going to be speaking at the first ever <a href="http://wordsesh.org/">WordSesh</a> online WordPress Conference! WordSesh is a day of live WordPress presentations from all over the world streamed live, and it&#8217;s free! Tune in at 4UTC 12am EST (midnight tonight!) to join me in my talk &#8220;Be the Unicorn.&#8221;</p>
<p>I&#8217;m really looking forward to hearing all the other awesome speakers! If you can&#8217;t make it, don&#8217;t worry, all the sessions will be recorded. #WPYall</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/04/12/join-me-at-wordsesh-tonight/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"Re-thinking WordPress Post Format UI An Exercise ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://ran.ge/2013/04/11/re-thinking-wordpress-post-format-ui-an-exercise/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:83:"http://ran.ge/2013/04/11/re-thinking-wordpress-post-format-ui-an-exercise/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 11 Apr 2013 07:30:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:7:"UI / UX";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"WordPress Core";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=1771";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"Post Formats are slated to drop in 3.6 and are currently in Beta. I love how WordPress is standardizing formats so that when you change your theme, the content format and metadata associated with that format is preserved. This opens up new doors and possibilities for bloggers who want a unique look without having to customize [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:12714:"<div id="attachment_1818" style="width: 1034px" class="wp-caption alignleft"><a href="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach.jpg"><img class="size-large wp-image-1818" alt="Post Format Modal" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach-1024x698.jpg" width="1024" height="698" /></a><p class="wp-caption-text">Post Format Modal</p></div>
<p>Post Formats are slated to drop in 3.6 and are currently in Beta. I love how WordPress is standardizing formats so that when you change your theme, the content format and metadata associated with that format is preserved. This opens up new doors and possibilities for bloggers who want a unique look without having to customize a category display.</p>
<p><img class="alignleft size-full wp-image-1772" alt="3.5 post formats enabled" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.51.52-AM.png" width="299" height="253" />Post formats are currently in WordPress 3.5 but are just in a tiny modal box to you right (if your theme has them enabled)</p>
<p>They don&#8217;t change the metaboxes for use with the content (aka make a &#8220;Video URL&#8221; field when selecting) but in 3.6 they will &#8211; which is exciting.</p>
<p>There has been lots of discussion and wireframes about the Post Formats UI and user testing&#8230; I decided to do an exercise that might address some of the pain points of the current UI&#8217;s iteration.</p>
<h2>Researching Other similar tools</h2>
<h2><strong>WordPress.com New Dash</strong></h2>
<p>Taking a look at the simplified blogging tool for WordPress.com &#8211; they deal with Post Formats right away.</p>
<div id="attachment_1776" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1776" alt="WordPress.com New Dash - Screen right after you hit &quot;New Post&quot;" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.58.11-AM-1024x438.png" width="1024" height="438" /><p class="wp-caption-text">WordPress.com New Dash &#8211; Screen right after you hit &#8220;New Post&#8221;</p></div>
<div id="attachment_1775" style="width: 1068px" class="wp-caption alignleft"><img class=" wp-image-1775" alt="WordPress.com New Dash - Post Page" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.58.22-AM.png" width="1058" height="567" /><p class="wp-caption-text">WordPress.com New Dash &#8211; Post Page :: a simplified version of the one in the admin</p></div>
<div id="attachment_1774" style="width: 1061px" class="wp-caption alignleft"><img class=" wp-image-1774" alt="WordPress.com New Dash - Screen" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.58.36-AM.png" width="1051" height="553" /><p class="wp-caption-text">WordPress.com New Dash &#8211; Video Post Selected<br />note the customized interface just for uploading photos</p></div>
<h2><strong style="font-size: 1.2em;"><strong style="font-size: 1.2em;">Tumblr</strong></strong></h2>
<div id="attachment_1784" style="width: 954px" class="wp-caption alignleft"><img class="size-full wp-image-1784" alt="Tumblr.com Dashboard - choose the format from the icons across before posting" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.16.27-AM.png" width="944" height="453" /><p class="wp-caption-text">Tumblr.com Dashboard &#8211; choose the format from the icons across before posting</p></div>
<div id="attachment_1783" style="width: 977px" class="wp-caption alignleft"><img class="size-full wp-image-1783" alt="tumblr.com Post a Video Screen" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.16.41-AM.png" width="967" height="482" /><p class="wp-caption-text">tumblr.com Post a Video Screen</p></div>
<p>The glaring similarities between WordPress.com New Dash and Tumblr is that they are 1) making a post format decision  before they get to the editor and 2) the editor is only giving them the modals and upload buttons that they need. If we think about #1 philosophically from a UX point of view &#8211; the formats are action-centric. They are not passively opening up the post editor then wondering what they are going to post &#8211; they are forced to make a decision, an action, and therefore the UI they are given is tailored to this decision making for a better UX.</p>
<p>Neither Tumblr or New Dash have a way of changing the post formats &#8211; which I think is good because they would lose all the data that they put in there to the custom modals. (more on this later)</p>
<h2><strong style="font-size: 1.2em;"></strong>Current 3.6 Iteration in Beta</h2>
<div id="attachment_1786" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1786" alt="WordPress.com 3.6 Beta" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.28.04-AM-1024x414.png" width="1024" height="414" /><p class="wp-caption-text">WordPress.com 3.6 Beta</p></div>
<p>The current iteration of the new Post-Formats UI that is now in 3.6 Beta has icons for each of the 10 formats spread across the top of the post editor. They are currently passive button-like selectors with a label to the right. Dave Martin ran some user tests on the current UI and the results were <a href="http://make.wordpress.org/ui/2013/04/09/post-formats-usability-test-round-4/">not good</a>.</p>
<p>I decided to do some action-centric decision-first based UI exercises to explore some options.</p>
<h2>Decision Based Approach &#8211; Working Within the Current Menu System</h2>
<p>The first exercise is one based on just using the current menu system. It turns out that it *could* in theory work &#8211; but in reality there are just way too many post formats.</p>
<div id="attachment_1790" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1790" alt="Action-Centric Dashboard Menu" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-h-copy-1024x695.jpg" width="1024" height="695" /><p class="wp-caption-text">Action-Centric Dashboard Menu</p></div>
<div id="attachment_1792" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1792" alt="Post Page - Sub Menu" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-p-copy-1024x698.jpg" width="1024" height="698" /><p class="wp-caption-text">Post Page &#8211; Sub Menu</p></div>
<p>Basically in this iteration, we make the choice in the menu and then the post screen will have just what you need.</p>
<div id="attachment_1794" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1794" alt="Video Post Format - note the simplified interface, the title changes to include the word &quot;video&quot; in it , and the labels are inside the boxes" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-video-post-1024x699.jpg" width="1024" height="699" /><p class="wp-caption-text">Video Post Format &#8211; note the simplified interface, the title changes to include the word &#8220;video&#8221; in it , and the labels are inside the boxes</p></div>
<h2>Changing Formats</h2>
<p>In the above screenshot &#8211; there is a way to change formats (unlike new dash or tumblr.) It is in the publish meta box. This is a more passive-switch than an in-your-face one which is important, as someone would have to completely change their mind to use it. It also falls under the same importance as the other items in the publish meta box.</p>
<div id="attachment_1799" style="width: 307px" class="wp-caption aligncenter"><img class="size-large wp-image-1799 " alt="Post Format Switching" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.57.34-AM.png" width="297" height="270" /><p class="wp-caption-text">Post Format Switching</p></div>
<div id="attachment_1797" style="width: 306px" class="wp-caption aligncenter"><img class="size-full wp-image-1797 " alt="Post Format Switching - drop down option" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.59.19-AM.png" width="296" height="313" /><p class="wp-caption-text">Post Format Switching &#8211; drop down option</p></div>
<div id="attachment_1798" style="width: 304px" class="wp-caption aligncenter"><img class="size-full wp-image-1798 " alt="Post Format Switching - radio button option" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.58.42-AM.png" width="294" height="541" /><p class="wp-caption-text">Post Format Switching &#8211; radio button option</p></div>
<p>Exploring both radio buttons for switching or a drop-down &#8211; That meta box currently uses both as a standard, but I think I prefer the radio simply because the icons are visual cues.</p>
<h2>Explorations outside of the current navigation pattern</h2>
<p>So, seeing that the navigation above is a bit cramped - I decided to explore in-page and modal decision patterns.</p>
<div id="attachment_1803" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1803" alt="In Page decision with post editor greyed out. Icons will go away and the &quot;switching&quot; will be in the siidebar like above" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-i-copy-1024x698.jpg" width="1024" height="698" /><p class="wp-caption-text">In Page decision with post editor greyed out. Icons will go away and the &#8220;switching&#8221; will be in the sidebar like above</p></div>
<div id="attachment_1804" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1804" alt="not greyed out but post editor fades in after decision" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-i-copy1-1024x698.jpg" width="1024" height="698" /><p class="wp-caption-text">not greyed out but post editor fades in after decision</p></div>
<div id="attachment_1805" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1805" alt="without labels - cursor rollover changes page title" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-in-page-approach-with-cursor-rollover-1024x355.jpg" width="1024" height="355" /><p class="wp-caption-text">without labels &#8211; cursor rollover changes page title</p></div>
<p>While all this is interesting &#8211; I&#8217;m not sure if it feels quite right as it is outside of the typical WordPress interface, but could be explored further.</p>
<h2>Modal Window</h2>
<p>So our natural progression here is to try out a modal. Usually I&#8217;m not-a-fan of modals at all. They tend to be disruptive. After the new media editor launched last release, its made me re-think modals. Lightbox was so terrible and slow &#8211; but using a modal for this action kind of makes sense as you can be on any page and receive it before hitting the post editor, without another page load or coming from any add post action. (think top nav bar add new)</p>
<div id="attachment_1818" style="width: 1034px" class="wp-caption alignleft"><a href="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach.jpg"><img class="size-large wp-image-1818" alt="Post Format Modal" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach-1024x698.jpg" width="1024" height="698" /></a><p class="wp-caption-text">Post Format Modal</p></div>
<p>At this point, I am leaning towards a fast modal with a few caveats. 1) you can turn the modal off if you don&#8217;t use other formats as much and just want to use the passive switcher. 2) you can turn all post formats off from within core settings to override what your theme set. 3) you can filter list tables by format (like you do categories.) The last two I think this should be an option regardless of the approach.</p>
<p>However, that being said, I know we are in Beta for 3.6 and the modal window approach might be a bit out of reach for this release. If I were to have a #2 I would say the greyed out post edit UI with the larger icons. approach might be viable (after the decision is made, the icons go away, post editor fades in, and the format switching is in the publish meta box.)</p>
<p>In conclusion, I hope to get some conversation going and hear what everyone else thinks so that we can make WordPress amazing together.</p>
<p><strong><em>update: if anyone else wants to tinker, here are my thrown together photoshop files etc s.sar.ac/071P0S3r2H2Q</em></strong></p>
<p>Update 2: Mark Jaquith is asking for feedback on the Make UI Blog <a href="http://make.wordpress.org/ui/2013/04/11/saracannon-has-posted-her-take-on-a-new/">http://make.wordpress.org/ui/2013/04/11/saracannon-has-posted-her-take-on-a-new/</a></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:79:"http://ran.ge/2013/04/11/re-thinking-wordpress-post-format-ui-an-exercise/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"29";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"Globalnews.ca Data Migration The MSSQL to MySQL Delima";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://ran.ge/2013/03/26/globalnews-ca-data-migration-and-the-mssql-to-mysql-delima/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:93:"http://ran.ge/2013/03/26/globalnews-ca-data-migration-and-the-mssql-to-mysql-delima/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Mar 2013 16:19:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Migration";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:5:"MSSQL";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:5:"MySQL";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:25:"http://dev.ran.ge/?p=3844";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:350:"Recently Globalnews.ca made the move to WordPress and we were tasked with migrating all their data from their existing custom MSSQL-based environment to the new WordPress environment hosted with WordPress.com VIP. We have a normal process for this kind of thing, and it goes something like this: Create a local WordPress install and get rid [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Aaron D. Campbell";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3593:"<p>Recently Globalnews.ca made the move to WordPress and we were tasked with migrating all their data from their existing custom MSSQL-based environment to the new WordPress environment hosted with <a href="http://vip.wordpress.com/">WordPress.com VIP</a>. We have a normal process for this kind of thing, and it goes something like this:</p>
<ol>
<li>Create a local WordPress install and get rid of the default posts, comments, and meta data.</li>
<li>Put the clients old data into tables in the same WordPress database.</li>
<li>Write a script that pulls the data from the old tables and uses a combination of WordPress functions and direct database queries to put it into the WordPress install.</li>
<li>Check the data and if it&#8217;s not quite right blast out the posts, comments, and meta data and go back to step 3.</li>
<li>When the data is exactly what we want in WordPress we use <a href="http://wp-cli.org/">wp-cli</a> to export the data in <abbr title="WordPress eXtended Rss">WXR</abbr> format, and submit those files to WordPress.com VIP.</li>
</ol>
<p>It sounds pretty straight forward, and usually it is, with the most difficult part obviously being the script that imports the data from the old tables into WordPress. Not this time however. This time the most difficult part turned out to be step 2, putting the clients data into the same database as WordPress. The problem was that the conversion from MSSQL to MySQL was no trivial matter.</p>
<p>Often you can use <a href="http://www.mysql.com/products/workbench/">MySQL Workbench</a> to migrate data from MSSQL to MySQL, so we started by spinning up a Windows cloud server with MSSQL. We imported the data into an MSSQL database on this new server, and then we installed MySQL and the MySQL Workbench. Due to the large amount of data being converted, we ran into memory issues several times and had to resize the cloud server, but once the memory issues were under control we realized that MySQL Workbench simply could not migrate many of the tables that we needed.</p>
<p>After many hours of digging and research, I finally found the problem. It turns out that there were a couple data types that were causing things to choke. In our case that was mostly limited to nvarchar and ntext. Why? Well because MSSQL doesn&#8217;t actually support UTF-8. What?! I know&#8230;I was surprised too, but it seems MSSQL doesn&#8217;t support the standard in character encoding. Instead it has nvarchar and ntext that don&#8217;t store as UTF-8 but offer similar output in a classic Microsoft-proprietary way.</p>
<p>I was able to work around this limitation by creating duplicate tables for each table that contained one of these field types, using nvarchar in place of varchar and ntext in place of text. Then I ran queries to select the data from the old tables and insert it into these newly created tables.</p>
<pre class="brush: sql; title: ; notranslate">
CREATE TABLE [dbo].[ImportFixed](
	[RowNum] [bigint] NULL,
	[post_title] [nvarchar](200) NOT NULL, -- Previously varchar
	[content_html] [ntext] NULL -- Previously text
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
----------------------
INSERT INTO [import].[dbo].[ImportFixed](
	[RowNum],
	[post_title],
	[content_html]
)
SELECT
	[RowNum],
	[post_title],
	[content_html]
FROM [import].[dbo].[Import]
GO
</pre>
<p>This then allowed MySQL Workbench to properly handle the encoding during it&#8217;s migration from MSSQL to MySQL. Even once the process is known it&#8217;s tedious and time consuming at best, but it seems to be very reliable and stable.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:89:"http://ran.ge/2013/03/26/globalnews-ca-data-migration-and-the-mssql-to-mysql-delima/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"Sara Cannon to Speak at WordCamp Atlanta on Saturday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://ran.ge/2013/03/12/sara-cannon-to-speak-at-wordcamp-atlanta-on-saturday/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:87:"http://ran.ge/2013/03/12/sara-cannon-to-speak-at-wordcamp-atlanta-on-saturday/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Mar 2013 22:57:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:16:"WordCamp Atlanta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=1684";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:317:"I&#8217;m so excited to be speaking at WordCamp Atlanta this Saturday! If you haven&#8217;t got tickets, its already SOLD OUT at 450 people. WOW. If you&#8217;re in the South and you missed it, be sure to keep an eye on 2013.Birmingham.WordCamp.org for a date announcement &#38; early tickets for late summer. &#160;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:657:"<p><a href="http://2013.Atlanta.WordCamp.org"><img class="size-full wp-image-3744 alignleft" alt="WCBadge2013-Speaker" src="http://sara-cannon.com/wp-content/uploads/2013/03/WCBadge2013-Speaker.jpg" width="150" height="150" /></a>I&#8217;m so excited to be speaking at <a href="http://2013.atlanta.wordcamp.org/">WordCamp Atlanta</a> this Saturday! If you haven&#8217;t got tickets, its already SOLD OUT at 450 people. WOW. If you&#8217;re in the South and you missed it, be sure to keep an eye on <a href="http://2013.Birmingham.WordCamp.org">2013.Birmingham.WordCamp.org</a> for a date announcement &amp; early tickets for late summer.</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:83:"http://ran.ge/2013/03/12/sara-cannon-to-speak-at-wordcamp-atlanta-on-saturday/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:19:"http://ran.ge/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 16 Nov 2013 11:53:22 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";a:2:{i:0;s:15:"Accept-Encoding";i:1;s:6:"Cookie";}s:13:"cache-control";s:28:"max-age=169, must-revalidate";s:12:"x-powered-by";s:21:"PHP/5.4.19-1~dotdeb.0";s:10:"x-pingback";s:27:"http://ran.ge/wp/xmlrpc.php";s:13:"last-modified";s:29:"Fri, 01 Nov 2013 22:18:21 GMT";s:4:"etag";s:34:""21a61201f9b1815ebe86a76fe4ece902"";s:4:"node";s:20:"web11.dfw.wphost.com";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (118, 'limit_login_retries', 'a:1:{s:3:"::1";i:1;}', 'no') ; 
INSERT INTO `wp_options` VALUES (237, 'recently_activated', 'a:1:{s:23:"wowslider/wowslider.php";i:1384640867;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (793, '_site_transient_timeout_theme_roots', '1384949168', 'yes') ; 
INSERT INTO `wp_options` VALUES (794, '_site_transient_theme_roots', 'a:5:{s:7:"expound";s:7:"/themes";s:10:"tigertheme";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";s:14:"ultimatetigers";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (119, 'limit_login_retries_valid', 'a:1:{s:3:"::1";i:1381796543;}', 'no') ; 
INSERT INTO `wp_options` VALUES (120, '_transient_random_seed', '05b1f52ae0bf7e1973415ec8bad6f650', 'yes') ; 
INSERT INTO `wp_options` VALUES (123, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:29:"http://www.andytan.net/tigers";s:4:"link";s:105:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://www.andytan.net/tigers/";s:3:"url";s:138:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://www.andytan.net/tigers/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:26:"http://wordpress.org/news/";s:3:"url";s:31:"http://wordpress.org/news/feed/";s:5:"title";s:14:"WordPress Blog";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:28:"http://planet.wordpress.org/";s:3:"url";s:33:"http://planet.wordpress.org/feed/";s:5:"title";s:20:"Other WordPress News";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (374, 'twp_version', '2.6.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (610, '_transient_timeout_feed_mod_c809918297b2c893fd8504c06adcaf00', '1384561427', 'no') ; 
INSERT INTO `wp_options` VALUES (611, '_transient_feed_mod_c809918297b2c893fd8504c06adcaf00', '1384518227', 'no') ; 
INSERT INTO `wp_options` VALUES (613, 'cpt_custom_post_types', 'a:1:{i:0;a:21:{s:4:"name";s:4:"work";s:5:"label";s:4:"Work";s:14:"singular_label";s:7:"project";s:11:"description";s:0:"";s:6:"public";s:1:"1";s:7:"show_ui";s:1:"1";s:11:"has_archive";s:1:"0";s:19:"exclude_from_search";s:1:"0";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:1:"0";s:7:"rewrite";s:1:"1";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:9:"query_var";s:1:"1";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:1:"1";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:0:"";i:0;a:11:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:7:"excerpt";i:3;s:10:"trackbacks";i:4;s:13:"custom-fields";i:5;s:8:"comments";i:6;s:9:"revisions";i:7;s:9:"thumbnail";i:8;s:6:"author";i:9;s:15:"page-attributes";i:10;s:12:"post-formats";}i:1;N;i:2;a:12:{s:9:"menu_name";s:0:"";s:7:"add_new";s:0:"";s:12:"add_new_item";s:0:"";s:4:"edit";s:0:"";s:9:"edit_item";s:0:"";s:8:"new_item";s:0:"";s:4:"view";s:0:"";s:9:"view_item";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:6:"parent";s:0:"";}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (636, 'rewrite_rules', 'a:81:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:32:"work/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"work/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"work/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"work/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"work/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:25:"work/([^/]+)/trackback/?$";s:31:"index.php?work=$matches[1]&tb=1";s:33:"work/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?work=$matches[1]&paged=$matches[2]";s:40:"work/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?work=$matches[1]&cpage=$matches[2]";s:25:"work/([^/]+)(/[0-9]+)?/?$";s:43:"index.php?work=$matches[1]&page=$matches[2]";s:21:"work/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"work/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"work/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"work/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"work/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (637, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (746, '_transient_plugins_delete_result_1', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (750, '_transient_is_multi_author', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (749, 'ml-slider_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (748, 'metaslider_systemcheck', 'a:2:{s:16:"wordPressVersion";b:0;s:12:"imageLibrary";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (631, 'theme_mods_ultimatetigers', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1384609949;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:9:"twitter-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (617, 'acf_version', '4.3.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (241, 'hmbkp_default_path', '/Applications/MAMP/htdocs/tigers/wp-content/backupwordpress-43bcb68547-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (242, 'hmbkp_path', '/Applications/MAMP/htdocs/tigers/wp-content/backupwordpress-43bcb68547-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (608, '_transient_timeout_feed_c809918297b2c893fd8504c06adcaf00', '1384561427', 'no') ; 
INSERT INTO `wp_options` VALUES (609, '_transient_feed_c809918297b2c893fd8504c06adcaf00', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:50:"
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:4:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"WebDevStudios.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:24:"http://webdevstudios.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:40:"WordPress Website Development and Design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 20:25:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=3.6.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"WDS Welcomes Cristina Cannon!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://webdevstudios.com/2013/11/14/wds-welcomes-cristina-cannon/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:74:"http://webdevstudios.com/2013/11/14/wds-welcomes-cristina-cannon/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 20:25:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:13:"WebDevStudios";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7909";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:406:"WebDevStudios is happy to announce our newest member of the team, Cristina, who will be taking on the role of Project Manager! Cristina Cannon has over 6 years of experience in project management; running new business projects and full marketing &#8230; <a class="more-link" href="http://webdevstudios.com/2013/11/14/wds-welcomes-cristina-cannon/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1537:"<p>WebDevStudios is happy to announce our newest member of the team, Cristina, who will be taking on the role of Project Manager!</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2013/11/CMC2.png"><img class="alignleft size-full wp-image-7905" alt="CMC2" src="http://webdevstudios.com/wp-content/uploads/2013/11/CMC2.png" width="210" height="230" /></a><a title="Cristina Cannon" href="http://webdevstudios.com/team/cristina-cannon/">Cristina Cannon</a> has over 6 years of experience in project management; running new business projects and full marketing campaigns within digital media, SEO, email, website development and database management &#8211; across multiple industries. Cristina has demonstrated a unique ability for problem solving and her strong leadership skills bring passion, reliability, and innovation to WDS, which is imperative for project success. Because of her energetic and collaborative style, Cristina will be a great addition to the WDS team! Cristina is excited to expand on her website development knowledge and learn WordPress inside and out.</p>
<p>After living in NJ for over a decade she recently moved to St. Louis to be closer to family. She have a 17-month old son, Trystan and wonderful boyfriend Jason. In her spare time she likes to read, hike, snowboard, dabble in yoga and go to the park with her awesome son!</p>
<p>WDS is excited to welcome Cristina to our ever growing team. Project management is an extremely important part of our business and we know she is going to rock it!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:70:"http://webdevstudios.com/2013/11/14/wds-welcomes-cristina-cannon/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Products We Love: Sucuri Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://webdevstudios.com/2013/11/07/products-we-love-sucuri-security/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:78:"http://webdevstudios.com/2013/11/07/products-we-love-sucuri-security/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 18:56:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:16:"Products We Love";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:6:"Sucuri";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7893";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:419:"Sucuri Security is a security-based company ran by Dre Armeda, Daniel Cid, and Tony Perez. They specialize in keeping websites secure and clean of hacks and offer services such as Monitoring, Alerting, and Removal. They also feature a Website Application &#8230; <a class="more-link" href="http://webdevstudios.com/2013/11/07/products-we-love-sucuri-security/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2798:"<p><img class="alignleft size-medium wp-image-7896" alt="Screenshot_on_11.7.2013_at_10.52.06_AM" src="http://webdevstudios.com/wp-content/uploads/2013/11/Screenshot_on_11.7.2013_at_10.52.06_AM-300x247.png" width="300" height="247" /><a title="Website Security Monitoring" href="http://sucuri.net/">Sucuri Security</a> is a security-based company ran by <a href="https://twitter.com/dremeda">Dre Armeda</a>, <a href="https://twitter.com/danielcid">Daniel Cid</a>, and <a href="https://twitter.com/perezbox">Tony Perez</a>. They specialize in keeping websites secure and clean of hacks and offer services such as Monitoring, Alerting, and Removal. They also feature a Website Application Firewall and Website Backups. You can find the complete details on what services they offer on their <a href="http://sucuri.net/services">Services page</a>.</p>
<p>We use their services for all of our websites including the one you are on right now- WebDevStudios.com. We know that our site is being monitored by <a href="http://sucuri.net/">Sucuri</a> 24/7, which gives us peace of mind. Also, if we were to be hacked, <a href="http://sucuri.net/">Sucuri</a> would alert us of the issue right away, and it&#8217;s good to know that we have that security bla<a href="http://webdevstudios.com/wp-content/uploads/2013/11/Screenshot_on_11.7.2013_at_11.10.35_AM.png"><img class="alignright size-medium wp-image-7897" alt="Screenshot_on_11.7.2013_at_11.10.35_AM" src="http://webdevstudios.com/wp-content/uploads/2013/11/Screenshot_on_11.7.2013_at_11.10.35_AM-250x300.png" width="250" height="300" /></a>nket in place.</p>
<p>Sucuri offers a free <a href="http://sitecheck.sucuri.net/scanner/">website security scanner</a> that everyone should take advantage of. This scanner allows you to check for blacklisting status, out-of-date software, known malware and website errors if your site is on WordPress or any other platform.</p>
<p>Anyone who has attended one of <a href="http://wordpress.tv/2013/06/24/brad-williams-security/">Brad Williams&#8217; security presentations</a> at WordCamp, know that he is extremely knowledgeable in the best practices of WordPress website security and he cannot say enough good things about using <a href="http://webdevstudios.com/go/sucuri">Sucuri</a> for your website. He says:</p>
<blockquote><p>&#8220;Sucuri is a service anyone serious about their website should have.&#8221;</p></blockquote>
<p>Here at WebDevStudios, we recommend to all of our clients that they sign up Sucuri monitoring services because we strongly trust in their capabilities as a company. If you&#8217;re looking to have affordable peace of mind for your website security, check out <a href="http://sucuri.net/">Sucuri Security</a> today. We promise you won&#8217;t be disappointed!</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:74:"http://webdevstudios.com/2013/11/07/products-we-love-sucuri-security/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"Announcing the PayPal Pro add-on for iThemes Exchange";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://webdevstudios.com/2013/11/01/announcing-the-paypal-pro-add-on-for-ithemes-exchange/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:99:"http://webdevstudios.com/2013/11/01/announcing-the-paypal-pro-add-on-for-ithemes-exchange/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 14:27:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:7:"Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Products";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"ecommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:8:"Exchange";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:7:"iThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7878";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:427:"We are very excited to announce the release of our first iThemes Exchange premium add-on: PayPal Pro With the PayPal Pro Add-On, you can easily accept credit cards directly from your website with the iThemes Exchange eCommerce plugin. We all &#8230; <a class="more-link" href="http://webdevstudios.com/2013/11/01/announcing-the-paypal-pro-add-on-for-ithemes-exchange/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2762:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/10/paypalpro2-440x440.png"><img class="alignleft  wp-image-7879" alt="paypalpro2-440x440" src="http://webdevstudios.com/wp-content/uploads/2013/10/paypalpro2-440x440-150x150.png" width="65" height="65" /></a>We are very excited to announce the release of our first <a href="http://ithemes.com/exchange/" target="_blank">iThemes Exchange</a> premium add-on: <a href="http://ithemes.com/purchase/paypal-pro/" title="PayPal Pro for iThemes Exchange WordPress eCommerce" target="_blank">PayPal Pro</a></p>
<div id="attachment_7881" class="wp-caption alignright" style="width: 288px"><a href="http://webdevstudios.com/wp-content/uploads/2013/10/paypal-cc-input.png"><img class="size-medium wp-image-7881 " alt="paypal-cc-input" src="http://webdevstudios.com/wp-content/uploads/2013/10/paypal-cc-input-278x300.png" width="278" height="300" /></a><p class="wp-caption-text">PayPal Pro Credit Card Input</p></div>
<p>With the <a href="http://ithemes.com/purchase/paypal-pro/">PayPal Pro Add-On</a>, you can easily accept credit cards directly from your website with the <a href="http://ithemes.com/exchange/">iThemes Exchange</a> eCommerce plugin. We all know how wary we feel when we have to be directed off of a site to pay for what we&#8217;re purchasing. <a href="http://ithemes.com/purchase/paypal-pro/">PayPal Pro</a> takes that worry away by allowing you to stay on the site in which you&#8217;re purchasing from.</p>
<h2>Features of the PayPal Pro Add-On</h2>
<ul>
<li><em>Accept payments directly on your website.</em></li>
<li><em><a href="http://webdevstudios.com/wp-content/uploads/2013/10/paypal-pro-settings1.png"><img class="alignright  wp-image-7880" alt="paypal-pro-settings1" src="http://webdevstudios.com/wp-content/uploads/2013/10/paypal-pro-settings1.png" width="278" height="419" /></a>Support for PayPal’s transaction sale methods: authorize and capture the payment, charge the total to the credit card or authorize the payment amount and capture that amount via PayPal Pro’s admin later.</em></li>
<li><em>Enable or disable PayPal Pro Sandbox Mode for testing your payments.</em></li>
<li><em>Easily change the “Purchase” button text to whatever you want like “Pay with Card” or “Pay Like a Pro.”</em></li>
</ul>
<p>&nbsp;</p>
<p>Learn more about the iThemes Exchange plugin on their website at <a href="http://ithemes.com/exchange/" target="_blank"> http://ithemes.com/exchange</a> and the PayPal Pro add-on at <a href="http://ithemes.com/purchase/paypal-pro/" title="PayPal Pro WordPress eCommerce Exchange" target="_blank">http://ithemes.com/purchase/paypal-pro/</a>. We are very proud to be part of Exchange and will be releasing additional add-ons very soon!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:95:"http://webdevstudios.com/2013/11/01/announcing-the-paypal-pro-add-on-for-ithemes-exchange/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"WDS Helps To Improve Documentation in WordPress 3.7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://webdevstudios.com/2013/10/28/wds-helps-to-improve-documentation-in-wordpress-3-7/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:97:"http://webdevstudios.com/2013/10/28/wds-helps-to-improve-documentation-in-wordpress-3-7/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 28 Oct 2013 15:49:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7866";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:452:"For the 3.7 release, WebDevStudios&#8217; own Brian Richards and dozens of others turned their collective focus to documenting the many hooks that WordPress provides for developers. The hooks docs initiative was birthed from a conversation between Andrew Nacin and Jon &#8230; <a class="more-link" href="http://webdevstudios.com/2013/10/28/wds-helps-to-improve-documentation-in-wordpress-3-7/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3166:"<p>For the 3.7 release, WebDevStudios&#8217; own <a title="Brian Richards" href="http://webdevstudios.com/team/brian-richards/">Brian Richards</a> and dozens of others turned their collective focus to documenting the many hooks that WordPress provides for developers.</p>
<blockquote><p>The hooks docs initiative was birthed from a conversation between <a href="https://twitter.com/nacin">Andrew Nacin</a> and <a href="https://twitter.com/joncave">Jon Cave</a> that I overheard during the WordCamp San Francisco After Party. They were talking about something called a &#8220;hash notation&#8221; for easily documenting arrays in inline docs, and improving the documentation efforts of WordPress, and I wanted to know more. By the end of the night I was convinced this would be a perfect way to document the multitude of hooks littered throughout WordPress Core, and a perfect way for me (and others) to contribute to WordPress. &#8211; Brian Richards</p></blockquote>
<p>During WordCamp San Fransisco contributor day, Brian connected with <a href="https://twitter.com/nacin">Andrew Nacin</a>, <a href="https://twitter.com/joncave">Jon Cave</a>, <a href="https://twitter.com/ericandrewlewis">Eric Lewis</a>, and <a href="https://twitter.com/DrewAPicture">Drew Jaynes. </a>They sat down and began working out the logistics of updating the documentation together.</p>
<p>Fast-forward several weeks, <a href="https://twitter.com/DrewAPicture">Drew Jaynes</a> and <a href="https://twitter.com/kimparsell">Kim Parsell</a> put in a lot of hours writing and refining PHP Documentation Standards pages for the WordPress handbook. <a href="https://twitter.com/rzen">Brian Richards</a> helped define and create the Hook Documentation standards portion, and they wrote up a few leading posts for make.wordpress.org/core. After this they hit the ground running.</p>
<blockquote><p><a href="https://twitter.com/ericandrewlewis">Eric</a>, <a href="https://twitter.com/kimparsell">Kim</a>, <a href="https://twitter.com/DrewAPicture">Drew</a> and myself comprised the core hook docs team, and we&#8217;ve held meetings every week since the project started. Drew and Kim shouldered much of the work reviewing other peoples patches, and Drew was even granted temporary commit access to help make the process flow more smoothly (congrats, Drew!).</p>
<p>At this moment, 74 of the 185 files containing hooks have been documented. There is still much to be done, and this initiative will continue to thrive well into (and possibly through) WordPress 3.8. &#8211; Brian Richards</p></blockquote>
<p>We want to thank everyone who contributed to the release of WordPress 3.7 including WDS&#8217; <a title="Brian Richards" href="http://webdevstudios.com/team/brian-richards/">Brian Richards</a> and <a title="Michael Beckwith" href="http://webdevstudios.com/team/michael-beckwith/">Michael Beckwith</a>. There is still a lot more work to do and anyone looking to help can get involved by reading this post on make/core: <a href="http://make.wordpress.org/core/2013/09/05/add-inline-docs-for-hooks/" target="_blank">http://make.wordpress.org/core/2013/09/05/add-inline-docs-for-hooks/</a></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:93:"http://webdevstudios.com/2013/10/28/wds-helps-to-improve-documentation-in-wordpress-3-7/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Brian Messenlehner Speaking at WordCamp Sofia 2013";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://webdevstudios.com/2013/10/23/brian-messenlehner-speaking-at-wordcamp-sofia-2013/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:96:"http://webdevstudios.com/2013/10/23/brian-messenlehner-speaking-at-wordcamp-sofia-2013/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Oct 2013 17:37:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7842";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:410:"Brian Messenlehner is speaking at WordCamp Sofia this year! WordCamp Sofia 2013 is being held on Friday, October 26th at The Hall of Telerik Academy. Brian&#8217;s talk will be held in the general track at 2:30pm and he will be &#8230; <a class="more-link" href="http://webdevstudios.com/2013/10/23/brian-messenlehner-speaking-at-wordcamp-sofia-2013/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2320:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/10/Screenshot_on_10.17.2013_at_11.56.02_AM.png"><img class="aligncenter size-full wp-image-7843" alt="Screenshot_on_10.17.2013_at_11.56.02_AM" src="http://webdevstudios.com/wp-content/uploads/2013/10/Screenshot_on_10.17.2013_at_11.56.02_AM.png" width="856" height="184" /></a></p>
<p><a title="Brian Messenlehner" href="http://webdevstudios.com/team/brian-messenlehner/">Brian Messenlehner</a> is speaking at <a href="http://2013.sofia.wordcamp.org/">WordCamp Sofia</a> this year! <a href="http://2013.sofia.wordcamp.org/">WordCamp Sofia 2013</a> is being held on Friday, October 26th at The Hall of Telerik Academy.</p>
<p>Brian&#8217;s talk will be held in the general track at 2:30pm and he will be speaking (in English!) about: <a href="http://2013.sofia.wordcamp.org/session/wordpress-as-an-application-framework/">WordPress as an Application Framework</a>:</p>
<blockquote><p>Despite starting out as a blogging platform and currently existing primarily as a content management system, WordPress is powerful enough and flexible enough to run any type of web application. Whether you&#8217;re a novice WordPress user or an experienced web developer you can leverage WordPress in many non-traditional ways. We will go over how to rapidly build scalable and secure applications and how to save time and money doing so. We will also showcase some really cool applications and examples of building things with WordPress while thinking out of the box.</p></blockquote>
<p>This topic will be expanded on and explainied in depth in Brian&#8217;s upcoming book <a href="http://www.amazon.com/Building-Apps-WordPress-Brian-Messenlehner/dp/1449364071/ref=sr_1_1?ie=UTF8&amp;qid=1382548056&amp;sr=8-1&amp;keywords=Brian+messenlehner">Building Web Apps with WordPress</a>. The book will be available on Amazon in the next few weeks &#8211; but you are able to<a href="http://www.amazon.com/Building-Apps-WordPress-Brian-Messenlehner/dp/1449364071/ref=sr_1_1?ie=UTF8&amp;qid=1382548056&amp;sr=8-1&amp;keywords=Brian+messenlehner"> pre-order it right now</a>!</p>
<p>If you&#8217;re attending WordCamp Sofia, make sure you stop by and say hey to Brian! As always, he&#8217;s excited to meet new people and catch up with those he&#8217;s already met.</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:92:"http://webdevstudios.com/2013/10/23/brian-messenlehner-speaking-at-wordcamp-sofia-2013/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:34:"WebDevStudios Welcomes Brad Parbs!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://webdevstudios.com/2013/10/21/webdevstudios-welcomes-brad-parbs/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:79:"http://webdevstudios.com/2013/10/21/webdevstudios-welcomes-brad-parbs/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 Oct 2013 14:30:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7844";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:427:"WebDevStudios is proud to announce another great addition to our team &#8211; Welcome to Brad Parbs! Brad  is a WordPress fanatic. He is involved with the WordPress community in a number of ways including organizing various events, speaking about WordPress at &#8230; <a class="more-link" href="http://webdevstudios.com/2013/10/21/webdevstudios-welcomes-brad-parbs/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1593:"<p>WebDevStudios is proud to announce another great addition to our team &#8211; Welcome to <a href="http://webdevstudios.com/team/brad-parbs/">Brad Parbs</a>!</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2013/10/brad-parbs-profile-square.jpg"><img class="alignleft size-full wp-image-7849" alt="brad-parbs-profile-square" src="http://webdevstudios.com/wp-content/uploads/2013/10/brad-parbs-profile-square.jpg" width="253" height="253" /></a>Brad  is a WordPress fanatic. He is involved with the WordPress community in a number of ways including organizing various events, speaking about WordPress at conferences, contributing to WordPress core and writing and maintaining plugins.</p>
<p>Brad is co-organizer for both the <a href="http://www.wpmke.com/" target="_blank">WordPress Milwaukee</a> &amp; <a href="http://www.meetup.com/web414/" target="_blank">Web414</a> monthly meetups, as well as WordCamp Milwaukee <a href="http://2012.milwaukee.wordcamp.org/" target="_blank">2012</a> and <a href="http://2013.milwaukee.wordcamp.org/" target="_blank">2013</a>.</p>
<blockquote><p>I&#8217;m super excited to be joining Web Dev Studios. Ever since I first started freelancing, I&#8217;ve always looked up to WDS as a company I would one day work for. I can&#8217;t wait to work with some of the smartest people in the community, on some really fun projects. &#8211; Brad Parbs</p></blockquote>
<p>We are also very excited to have Brad joining the team! With his expertise and passion, we know he is going to be an excellent addition to our WDS family!</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:75:"http://webdevstudios.com/2013/10/21/webdevstudios-welcomes-brad-parbs/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:38:"Lisa Sabin-Wilson at PressNomics 2013!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://webdevstudios.com/2013/10/14/lisa-sabin-wilson-at-pressnomics-2013/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:83:"http://webdevstudios.com/2013/10/14/lisa-sabin-wilson-at-pressnomics-2013/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Oct 2013 18:46:08 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7833";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:424:"For those of you who don&#8217;t already know what PressNomics is &#8211; The conference for those that power the WordPress Economy There is a diverse group of passionate and very successful entrepreneurs creating the products and services that drive the &#8230; <a class="more-link" href="http://webdevstudios.com/2013/10/14/lisa-sabin-wilson-at-pressnomics-2013/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2060:"<p>For those of you who don&#8217;t already know what PressNomics is &#8211;</p>
<blockquote><p>The conference for those that power the WordPress Economy<br />
There is a diverse group of passionate and very successful entrepreneurs creating the products and services that drive the WordPress economy. PressNomics is a 3 day event for these folks to collaborate, learn, and relax.</p>
<p>&nbsp;</p>
<p><a href="http://webdevstudios.com/wp-content/uploads/2013/10/pressnomics-logos_06.png"><img class="aligncenter size-medium wp-image-7834" alt="pressnomics-logos_06" src="http://webdevstudios.com/wp-content/uploads/2013/10/pressnomics-logos_06-300x47.png" width="300" height="47" /></a></p></blockquote>
<p>An awesome thing about PressNomics is that it&#8217;s a <em>not-just-for-profit </em>event. The 2012 Event donated $5,126 to <a href="http://www.stjude.org">St. Jude Children&#8217;s Research Hospital</a>.</p>
<p>PressNomics is being held from Thursday, October 16th until Saturday, October 19th at the Tempe Mission Palms Hotel.</p>
<p>Lisa&#8217;s presentation begins on Friday, October 17th at 1:30pm</p>
<p>In her talk at PressNomics this year, Lisa Sabin-Wilson will be sharing the process and outcome of her decision to merge with WDS.  She is planning on talking about the decision making process and considerations for her to take her one-woman operation at <a href="http://ewebscapes.com">eWebscapes</a> and merge with a larger team, taking on not one, but two partners in the process.  What did it take to get there and reflections now, almost a year later, on how she has made the transition.</p>
<p>Lisa has been doing WordPress design/development since 2003 with the business she founded at <a href="http://ewebscapes.com">eWebscapes</a>. In 2012, Lisa, Brad and Brian began talks about merging eWebscapes with WebDevStudios to pull their collective brain power and resources together to form WD3, a.k.a. WebDevStudios.</p>
<p>If you are planning on being in Tempe, AZ for the PressNomics conference &#8211; find Lisa and say hello!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:79:"http://webdevstudios.com/2013/10/14/lisa-sabin-wilson-at-pressnomics-2013/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WebDevStudios Presents a Free WordPress Security Webinar";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://webdevstudios.com/2013/09/25/webdevstudios-presents-a-free-wordpress-security-webinar/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:102:"http://webdevstudios.com/2013/09/25/webdevstudios-presents-a-free-wordpress-security-webinar/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 25 Sep 2013 15:00:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7808";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:451:"Brad  and Brian,two out of the three owners behind WebDevStudios, are hosting a webinar on WordPress security offered by SiteGround. Brad and Brian have extensive experience in dealing with website security and WordPress. This will be a great webinar to attend &#8230; <a class="more-link" href="http://webdevstudios.com/2013/09/25/webdevstudios-presents-a-free-wordpress-security-webinar/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1691:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/09/siteground.png"><img class="size-medium wp-image-7816 alignright" alt="siteground" src="http://webdevstudios.com/wp-content/uploads/2013/09/siteground-300x87.png" width="300" height="87" /></a><a href="http://webdevstudios.com/team/brad-williams/">Brad</a>  and <a title="Brian Messenlehner" href="http://webdevstudios.com/team/brian-messenlehner/">Brian</a>,two out of the three owners behind WebDevStudios, are hosting a webinar on WordPress security offered by <a href="http://www.siteground.com" target="_blank">SiteGround</a>. Brad and Brian have extensive experience in dealing with website security and WordPress. This will be a great webinar to attend if you want to learn how to beef up security on your WordPress website and to learn what to look out for to avoid security venerabilities. This event is taking place on <em>Thursday, September 26th</em> at <em>4pm EDT</em>. The session will include a 40 minute presentation followed by Q&amp;A.</p>
<h2 style="text-align: center"><a href="https://attendee.gotowebinar.com/register/2233504293348347905">Click Here to Register</a></h2>
<p>The WordPress Security webinar will include:</p>
<ul>
<li>WordPress Security Threats and trends</li>
<li>WordPress admin Security settings</li>
<li>Securing files, folders and databases</li>
<li>Bulletproof passwords</li>
<li>Web Server Vulnerabilities</li>
<li>Vulnerable WordPress extensions</li>
<li>Recommended Plugins and Services</li>
<li>Q &amp; A</li>
</ul>
<p>If you are interested in attending <a href="https://attendee.gotowebinar.com/register/2233504293348347905">click here</a> and sign up today!</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:98:"http://webdevstudios.com/2013/09/25/webdevstudios-presents-a-free-wordpress-security-webinar/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WordPress Web Design for Dummies (2nd edition) Giveaway!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://webdevstudios.com/2013/09/24/wordpress-web-design-for-dummies-2nd-edition-giveaway/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:99:"http://webdevstudios.com/2013/09/24/wordpress-web-design-for-dummies-2nd-edition-giveaway/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 24 Sep 2013 14:56:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:7:"General";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Giveaway";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7804";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:469:"Lisa Sabin-Wilson; a co-owner here at WebDevStudios has written yet another helpful WordPress book.  WordPress Web Design for Dummies (2nd edition) is Lisa&#8217;s 11th dummies book based around WordPress! Updated, full-color guide to creating dynamic websites with WordPress 3.6 In &#8230; <a class="more-link" href="http://webdevstudios.com/2013/09/24/wordpress-web-design-for-dummies-2nd-edition-giveaway/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3529:"<p><a title="Lisa Sabin-Wilson" href="http://webdevstudios.com/team/lisa-sabin-wilson/">Lisa Sabin-Wilson</a>; a co-owner here at WebDevStudios has written yet another helpful WordPress book.  <a href="http://www.amazon.com/WordPress-Design-Dummies-Computer-Tech/dp/111854661X/ref=sr_1_1?s=books&amp;ie=UTF8&amp;qid=1380029870&amp;sr=1-1&amp;keywords=wordpress+web+design+for+dummies+2nd+edition">WordPress Web Design for Dummies (2nd edition)</a> is Lisa&#8217;s 11th dummies book based around WordPress!</p>
<blockquote>
<div id="outer_postBodyPS">
<div id="postBodyPS">
<div>
<p><b><a href="http://webdevstudios.com/wp-content/uploads/2013/09/Screen_Shot_2013-09-24_at_08.50.40.png"><img class="alignleft size-medium wp-image-7805" alt="Screen_Shot_2013-09-24_at_08.50.40" src="http://webdevstudios.com/wp-content/uploads/2013/09/Screen_Shot_2013-09-24_at_08.50.40-240x300.png" width="240" height="300" /></a>Updated, full-color guide to creating dynamic websites with WordPress 3.6</b></p>
<p>In this updated new edition, bestselling <i>For Dummies</i> author and WordPress expert Lisa Sabin-Wilson makes it easy for anyone with a basic knowledge of the WordPress software to create a custom site using complementary technologies such as CSS, HTML, PHP, and MySQL. You&#8217;ll not only get up to speed on essential tools and technologies and further advance your own design skills, this book also gives you pages of great case studies, so you can see just how other companies and individuals are creating compelling, customized, and cost-effective websites with WordPress.</p>
<ul>
<li>Shows you how to incorporate WordPress templates, graphic design principles, HTML, CSS, and PHP to build one-of-a-kind websites</li>
<li>Explains how to create an effective navigation system, choose the right color palette and fonts, and select different layouts</li>
<li>Reveals how you can tweak existing website designs with available themes, both free and premium</li>
<li>Provides numerous case studies to illustrate techniques and processes, and the effects you can achieve</li>
<li>Discusses how you can translate your design skills into paid work</li>
</ul>
<p>Want to create cost-effective and fantastic websites with WordPress? This do-it-yourself book will get you there.</p>
</div>
</div>
</div>
</blockquote>
<div id="outer_postBodyPS">
<div id="postBodyPS">
<div>
<p> We are giving away a copy of this awesome book!</p>
<h1>How to enter:</h1>
<ul>
<li>All you have to do is <strong>comment on this post</strong> about how one of Lisa&#8217;s books has helped you, or why you would like this book to help in your WordPress web design.</li>
<li>The giveaway with be running from 11 AM EDT today (Tuesday September 24th) until Thursday, September 26th at 3 PM EDT.</li>
<li>We will announce a winner at 4pm EDT on Thursday the 26th.</li>
<li>You will receive one copy of WordPress Web Design for Dummies (2nd edition) <strong>autographed</strong> by Lisa Sabin-Wilson.</li>
<li>US submissions only.</li>
<li>Employees and family members of WDS are encouraged to submit an entry, but are not eligible to win.</li>
</ul>
<p>We look forward to reading about how Lisa&#8217;s books have helped you or why this book would improve your WordPress web design!</p>
<p>Also, make sure to check out the entire list of books that WebDevStudios has under our belt (with more to come in the not so distant future!) <a href="http://webdevstudios.com/wordpress/books/">http://webdevstudios.com/wordpress/books/</a></p>
</div>
</div>
</div>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:95:"http://webdevstudios.com/2013/09/24/wordpress-web-design-for-dummies-2nd-edition-giveaway/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"14";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"WordCamp Baltimore 2013!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://webdevstudios.com/2013/09/19/wordcamp-baltimore-2013/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:69:"http://webdevstudios.com/2013/09/19/wordcamp-baltimore-2013/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 19 Sep 2013 14:14:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:4:"Team";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://webdevstudios.com/?p=7797";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:386:"Add another WordCamp chalk line on the board for the WDS team &#8212; Brad Williams and Jayvie Canono will be attending WordCamp Baltimore 2013 this year! The event is happening on Saturday, September 21st and is being held at the &#8230; <a class="more-link" href="http://webdevstudios.com/2013/09/19/wordcamp-baltimore-2013/">Continue reading <span class="meta-nav">&#8594;</span></a>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Melissa Hoppe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2104:"<p><a href="http://webdevstudios.com/wp-content/uploads/2013/09/baltimore.png"><img class="alignleft size-full wp-image-7798" alt="baltimore" src="http://webdevstudios.com/wp-content/uploads/2013/09/baltimore.png" width="305" height="248" /></a>Add another WordCamp chalk line on the board for the WDS team &#8212; <a title="Brad Williams" href="http://webdevstudios.com/team/brad-williams/">Brad Williams</a> and <a title="Jayvie Canono" href="http://webdevstudios.com/team/jayvie-canono/">Jayvie Canono</a> will be attending <a href="http://2013.baltimore.wordcamp.org/">WordCamp Baltimore 2013</a> this year! The event is happening on Saturday, September 21st and is being held at the University of Baltimore in the Thumel Business Center. We would like to give a big round of applause to the organizers; <a href="https://twitter.com/theandystratton">Andy Stratton</a> and <a href="https://twitter.com/BmoreDrew">Drew Poland</a>, along with the <a href="http://2013.baltimore.wordcamp.org/sponsors/">sponsors</a>, for making this event possible!</p>
<p>Now, we already know that Brad Williams and Jayvie Canono of WDS will be going to this event, but make sure you check out the entire list of <a href="http://2013.baltimore.wordcamp.org/attendees/">attendees</a> and <a href="http://2013.baltimore.wordcamp.org/speakers/">speakers</a> that you will be learning from and getting to know. Also, have a look at the full <a href="http://2013.baltimore.wordcamp.org/schedule/">schedule</a> so you know which presentations you would like to attend and you can plan accordingly.</p>
<p>What would a WordCamp be without an after party? When you&#8217;re finished having a long day of cramming your brain full of WordPress knowledge, it&#8217;s time to relax. The after party is being held at the The Waterfront Hotel in Baltimore’s historic Fell’s Point starting at 7:30pm.</p>
<p>If you plan on attending WordCamp Baltimore 2013, make sure you find Brad and Jayvie in the crowd and say hey. As always, they are looking forward to meeting new people and reunited with the ones they have already met!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:65:"http://webdevstudios.com/2013/09/19/wordcamp-baltimore-2013/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:2:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";s:4:"href";s:41:"http://feeds.feedburner.com/webdevstudios";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:2:{s:3:"rel";s:3:"hub";s:4:"href";s:32:"http://pubsubhubbub.appspot.com/";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:42:"http://rssnamespace.org/feedburner/ext/1.0";a:3:{s:4:"info";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:1:{s:3:"uri";s:13:"webdevstudios";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:14:"emailServiceId";a:1:{i:0;a:5:{s:4:"data";s:13:"webdevstudios";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:18:"feedburnerHostname";a:1:{i:0;a:5:{s:4:"data";s:28:"http://feedburner.google.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:4:"etag";s:27:"ckZROX+iCad1haqhYYrTOh5TsbE";s:13:"last-modified";s:29:"Fri, 15 Nov 2013 10:19:09 GMT";s:4:"date";s:29:"Fri, 15 Nov 2013 11:21:53 GMT";s:7:"expires";s:29:"Fri, 15 Nov 2013 11:21:53 GMT";s:13:"cache-control";s:18:"private, max-age=0";s:22:"x-content-type-options";s:7:"nosniff";s:16:"x-xss-protection";s:13:"1; mode=block";s:6:"server";s:3:"GSE";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (689, '_transient_timeout_plugin_slugs', '1384727357', 'no') ; 
INSERT INTO `wp_options` VALUES (690, '_transient_plugin_slugs', 'a:11:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:19:"akismet/akismet.php";i:2;s:35:"backupwordpress/backupwordpress.php";i:3;s:36:"contact-form-7/wp-contact-form-7.php";i:4;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:5;s:9:"hello.php";i:6;s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";i:7;s:30:"lightbox-plus/lightboxplus.php";i:8;s:45:"limit-login-attempts/limit-login-attempts.php";i:9;s:23:"ml-slider/ml-slider.php";i:10;s:40:"twitter-widget-pro/wp-twitter-widget.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (695, '_transient_timeout_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1384649788', 'no') ; 
INSERT INTO `wp_options` VALUES (696, '_transient_feed_mod_867bd5c64f85878d03a060509cd2f92c', '1384606588', 'no') ; 
INSERT INTO `wp_options` VALUES (697, '_transient_timeout_dash_aa95765b5cc111c56d5993d476b1c2f0', '1384649788', 'no') ; 
INSERT INTO `wp_options` VALUES (698, '_transient_dash_aa95765b5cc111c56d5993d476b1c2f0', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://www.wptavern.com/crowd-favorite-acquired-by-velomedia\' title=\'PostStat.us is reporting that Crowd Favorite, the WordPress consultancy company created by Alex King has been acquired by VeloMedia. VeloMedia much like Crowd Favorite does most of its business within the enterprise sector. According to the report, Alex King will be the CTO of the company while Karim Marucchi will remain the CEO. In response to the acquisition, Alex King had this to say: I’m really excited to be joining forces with VeloMedia. I feel the culture and focus on craftsmanship at Crowd Favorite is special, and was thrilled to find that VeloMedia shares our values. We look forward to a continued focus on development excellence, employee culture and, most importantly, top notch service for our clients. Congratulations to Alex King and Crowd Favorite on being acquired. I hope this move allows Alex to continue doing what he loves with WordPress. This is one of the first major WordPress consultancy acquisitions in the WordPress community and it certainly won’t be the last. \'>WPTavern: Crowd Favorite Acquired By VeloMedia</a></li><li><a class=\'rsswidget\' href=\'http://www.wptavern.com/wpweekly-episode-128-catching-up-with-lorelle-vanfossen\' title=\'Clark College WordPress Class of 2013 In this edition of WordPress Weekly, we covered the headlines of the week such as what features will be in WordPress 3.8, the default BuddyPress theme being retired in 1.9, and when to expect 3.8 to be released. During the second half of the show, we were joined by Lorelle VanFossen. We found out what she’s been up to during the past few years and learned about her new endeavor teaching WordPress at Clark College in Vancouver, WA. This episode is long in length and not edited but I encourage you to listen to the complete show or at least the interview with Lorelle as I believe what she is doing at Clark College to be very important. Stories Discussed: WordPress 3.8 Is On Schedule WordPress 3.8 Merge Window Closed: New Features Now Locked In Themify Announces Security Vulnerability With Fix WordPress For Android Gets a Major Update RIP BuddyPress Default Theme: Finally Laid to Rest in 1.9 WPWeekly Meta: Next Episode: Friday, November 22nd 3 P.M. Eastern – Special Guest Tom McFarlin Subscribe To WPWeekly Via Itunes: Click here to subscribe Subscribe To WPWeekly Via RSS: Click here to subscribe Subscribe To WPWeekly Via Stitcher Radio: Click here to subscribe Listen To Episode #128: \'>WPTavern: WPWeekly Episode 128 – Catching Up With Lorelle VanFossen</a></li><li><a class=\'rsswidget\' href=\'http://wordpress.tv/2013/11/15/gordon-wright-wordpress-goes-to-college-a-case-study/\' title=\'    \'>WordPress.tv: Gordon Wright: WordPress Goes to College: A Case Study</a></li><li><a class=\'rsswidget\' href=\'http://www.wptavern.com/how-to-prevent-buddypress-from-changing-comment-author-urls\' title=\' Did you know that BuddyPress changes the URL for comment authors to point to the user’s BuddyPress profile? It does this by filtering the ‘comments_array’ in the bp-core-filters.php file to insert BuddyPress URLs for blog post comments: add_filter( &#039;comments_array&#039;, &#039;bp_core_filter_comments&#039;, 10, 2 ); For most BuddyPress sites this is a good thing, since it emphasizes users’ profiles and interaction on the site, helping members connect to each other on the social network. However, there are some WordPress sites that take a different approach to comments. People don’t always leave comments purely to join a conversation. Unfortunately, many users are motivated, at least partially, by having a link back to their own sites.  If you want to stop BuddyPress from changing the comment author URL to the profile link, it’s as simple as removing the filter: remove_filter( &#039;comments_array&#039;, &#039;bp_core_filter_comments&#039;, 10, 2 ); Add that to your bp-custom.php file or create your own little functionality plugin for it. Once activated you should see that the comments now pull the url from the admin area profile.php page or the URL the user has entered in the comment form. \'>WPTavern: How to Prevent BuddyPress From Changing Comment Author URLs</a></li><li><a class=\'rsswidget\' href=\'http://www.wptavern.com/wordpress-theme-review-team-makes-controversial-change\' title=\'Chip Bennett announced on the Make.WordPress.org website that the theme review guidelines have been updated. Specifically, the theme unit tests have been reduced from required, to recommended. This change was inspired by a passionate conversation, started by Lance Willett. In that conversation they debated whether or not guidelines were hard and fast rules.  I asked Chip Bennett to explain in plain English what these changes mean for both theme reviewers and authors. This is what he had to say. No changes have been made to the overall Guidelines, except that the Theme Unit Tests have been reduced in criticality from “Required” to “Recommended”. Developers should still test their Themes against the TUT before submission, and Reviewers will still test Themes against the TUT during reviews. The only difference is that, now, any observed issues will be noted as recommended fixes, rather than as issues required to address before Theme approval. These changes come on the heels of a recent blog post published by Mario Peshev where he explained his experience participating in the theme review process for the past two and half years. According to Mario, some of the guidelines still contain too much subjectivity, especially when it comes to credit links located within themes. A side effect of the theme review guidelines is the large amount of themes in the directory that cater to blogging. The argument is that the guidelines do not provide enough leeway to embrace variety. However, Chip noted in the comments: There’s nothing in the Guidelines that prohibit “business” Themes, or one-page Themes, or WooCommerce/EDD Themes, etc. If there are minor things that need exceptions (such as allowing the screenshot to display a static front page), developers can always ask for such exceptions. Between the recent change with the theme unit tests and the engaging discussions taking place amongst the theme review community, steps are being taken in the right direction to make the theme review process easier for everyone involved. It’s worthy to note that all of the WordPress theme reviewers are volunteers helping to make the directory a better place. \'>WPTavern: WordPress Theme Review Team Makes Controversial Change</a></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (687, '_transient_timeout_feed_mod_77fa140e07ce53fe8c87136636f83d72', '1384649788', 'no') ; 
INSERT INTO `wp_options` VALUES (688, '_transient_feed_mod_77fa140e07ce53fe8c87136636f83d72', '1384606588', 'no') ; 
INSERT INTO `wp_options` VALUES (691, '_transient_timeout_dash_de3249c4736ad3bd2cd29147c4a0d43e', '1384649788', 'no') ; 
INSERT INTO `wp_options` VALUES (692, '_transient_dash_de3249c4736ad3bd2cd29147c4a0d43e', '<h4>Most Popular</h4>
<h5><a href=\'http://wordpress.org/plugins/captcha/\'>Captcha</a></h5>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=captcha&amp;_wpnonce=00e99ba83d&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Captcha\'>Install</a>)</span>
<p>This plugin allows you to implement super security captcha form into web forms.</p>
<h4>Newest Plugins</h4>
<h5><a href=\'http://wordpress.org/plugins/formidable-customizations/\'>Formidable Customizations</a></h5>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=formidable-customizations&amp;_wpnonce=18af2bb8e6&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Formidable Customizations\'>Install</a>)</span>
<p>A compendium of useful customizations and extensions for Formidable Pro. Easily customize your form fields from one location.</p>
', 'no') ; 
INSERT INTO `wp_options` VALUES (693, '_transient_timeout_feed_867bd5c64f85878d03a060509cd2f92c', '1384649788', 'no') ; 
INSERT INTO `wp_options` VALUES (694, '_transient_feed_867bd5c64f85878d03a060509cd2f92c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:61:"
	
	
	
	




















































";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"WordPress Planet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:28:"http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:2:"en";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:47:"WordPress Planet - http://planet.wordpress.org/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:50:{i:0;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"WPTavern: Crowd Favorite Acquired By VeloMedia";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11661";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"http://www.wptavern.com/crowd-favorite-acquired-by-velomedia";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1629:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/crowdfavoritelogo.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/crowdfavoritelogo.jpg?resize=198%2C45" alt="Crowd favorite logo" class="alignright size-full wp-image-11663" /></a><a href="http://www.poststat.us/crowd-favorite-acquired-velomedia/" title="http://www.poststat.us/crowd-favorite-acquired-velomedia/">PostStat.us is reporting</a> that <a href="http://crowdfavorite.com/" title="http://crowdfavorite.com/">Crowd Favorite</a>, the WordPress consultancy company created by Alex King has been acquired by <a href="http://www.velomedia.com/" title="http://www.velomedia.com/">VeloMedia</a>. VeloMedia much like Crowd Favorite does most of its business within the enterprise sector. According to the report, Alex King will be the CTO of the company while Karim Marucchi will remain the CEO. In response to the acquisition, Alex King had this to say:</p>
<blockquote><p>I’m really excited to be joining forces with VeloMedia. I feel the culture and focus on craftsmanship at Crowd Favorite is special, and was thrilled to find that VeloMedia shares our values. We look forward to a continued focus on development excellence, employee culture and, most importantly, top notch service for our clients.</p></blockquote>
<p>Congratulations to Alex King and Crowd Favorite on being acquired. I hope this move allows Alex to continue doing what he loves with WordPress. This is one of the first major WordPress consultancy acquisitions in the WordPress community and it certainly won&#8217;t be the last. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 16 Nov 2013 05:35:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: WPWeekly Episode 128 – Catching Up With Lorelle VanFossen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11653";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:79:"http://www.wptavern.com/wpweekly-episode-128-catching-up-with-lorelle-vanfossen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3107:"<p><div id="attachment_11655" class="wp-caption aligncenter"><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/hello-wp-tavern-from-clark-college-wordpress-class-2013.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/hello-wp-tavern-from-clark-college-wordpress-class-2013.jpg?resize=500%2C281" alt="hello wp tavern from clark college wordpress class 2013" class="size-large wp-image-11655" /></a><p class="wp-caption-text">Clark College WordPress Class of 2013</p></div> In this edition of WordPress Weekly, we covered the headlines of the week such as what features will be in WordPress 3.8, the default BuddyPress theme being retired in 1.9, and when to expect 3.8 to be released. During the second half of the show, we were joined by Lorelle VanFossen. We found out what she&#8217;s been up to during the past few years and learned about her new endeavor teaching WordPress at <a href="http://www.clark.edu/" title="http://www.clark.edu/">Clark College</a> in Vancouver, WA. This episode is long in length and not edited but I encourage you to listen to the complete show or at least the interview with Lorelle as I believe what she is doing at Clark College to be very important.<span id="more-11653"></span></p>
<h2>Stories Discussed:</h2>
<p><a href="http://www.wptavern.com/wordpress-3-8-is-on-schedule" title="http://www.wptavern.com/wordpress-3-8-is-on-schedule">WordPress 3.8 Is On Schedule</a><br />
<a href="http://www.wptavern.com/wordpress-3-8-merge-window-closed-new-features-now-locked-in" title="http://www.wptavern.com/wordpress-3-8-merge-window-closed-new-features-now-locked-in">WordPress 3.8 Merge Window Closed: New Features Now Locked In</a><br />
<a href="http://www.wptavern.com/themify-announces-security-vulnerability-with-fix" title="http://www.wptavern.com/themify-announces-security-vulnerability-with-fix">Themify Announces Security Vulnerability With Fix</a><br />
<a href="http://www.wptavern.com/wordpress-for-android-gets-a-major-update" title="http://www.wptavern.com/wordpress-for-android-gets-a-major-update">WordPress For Android Gets a Major Update</a><br />
<a href="http://www.wptavern.com/rip-buddypress-default-theme-finally-laid-to-rest-in-1-9" title="http://www.wptavern.com/rip-buddypress-default-theme-finally-laid-to-rest-in-1-9">RIP BuddyPress Default Theme: Finally Laid to Rest in 1.9</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, November 22nd 3 P.M. Eastern &#8211; Special Guest Tom McFarlin</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #128:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 16 Nov 2013 03:54:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:68:"WordPress.tv: Gordon Wright: WordPress Goes to College: A Case Study";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25312";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://wordpress.tv/2013/11/15/gordon-wright-wordpress-goes-to-college-a-case-study/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:684:"<div id="v-Zfr5YugR-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25312/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25312/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25312&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/15/gordon-wright-wordpress-goes-to-college-a-case-study/"><img alt="Gordon Wright: WordPress Goes to College: A Case Study" src="http://videos.videopress.com/Zfr5YugR/video-b4fddbcbab_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Nov 2013 23:33:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:69:"WPTavern: How to Prevent BuddyPress From Changing Comment Author URLs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11638";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://www.wptavern.com/how-to-prevent-buddypress-from-changing-comment-author-urls";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1836:"<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/bp-comments-filter.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/bp-comments-filter.jpg?resize=491%2C239" alt="bp-comments-filter" class="aligncenter size-full wp-image-11644" /></a></p>
<p>Did you know that BuddyPress changes the URL for comment authors to point to the user&#8217;s BuddyPress profile? It does this by filtering the &#8216;comments_array&#8217; in the <em><a href="http://buddypress.trac.wordpress.org/browser/tags/1.8.1/bp-core/bp-core-filters.php#L123" target="_blank">bp-core-filters.php</a></em> file to insert BuddyPress URLs for blog post comments:</p>
<pre>add_filter( \'comments_array\', \'bp_core_filter_comments\', 10, 2 );</pre>
<p>For most BuddyPress sites this is a good thing, since it emphasizes users&#8217; profiles and interaction on the site, helping members connect to each other on the social network. However, there are some WordPress sites that take a different approach to comments. People don&#8217;t always leave comments purely to join a conversation. Unfortunately, many users are motivated, at least partially, by having a link back to their own sites. <span id="more-11638"></span></p>
<p>If you want to stop BuddyPress from changing the comment author URL to the profile link, it&#8217;s as simple as removing the filter:</p>
<pre>remove_filter( \'comments_array\', \'bp_core_filter_comments\', 10, 2 );</pre>
<p>Add that to your <em>bp-custom.php</em> file or create your own little <a href="http://wpcandy.com/teaches/how-to-create-a-functionality-plugin/" target="_blank">functionality plugin</a> for it. Once activated you should see that the comments now pull the url from the admin area <em>profile.php</em> page or the URL the user has entered in the comment form. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Nov 2013 22:09:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:64:"WPTavern: WordPress Theme Review Team Makes Controversial Change";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11478";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://www.wptavern.com/wordpress-theme-review-team-makes-controversial-change";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3250:"<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPorgThemeDirectory.jpg" rel="thumbnail"><img class="alignright size-medium wp-image-11594" alt="WordPress Theme Directory" src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPorgThemeDirectory.jpg?resize=300%2C165" /></a>Chip Bennett <a title="http://make.wordpress.org/themes/2013/11/12/theme-unit-tests-recommended/" href="http://make.wordpress.org/themes/2013/11/12/theme-unit-tests-recommended/">announced on the Make.WordPress.org website</a> that the theme review guidelines have been updated. Specifically, the theme unit tests have been reduced from <strong>required</strong>, to <strong>recommended</strong>. This change was inspired by a <a title="http://make.wordpress.org/themes/2013/11/10/guidelines-shouldnt-fail-a-theme/" href="http://make.wordpress.org/themes/2013/11/10/guidelines-shouldnt-fail-a-theme/">passionate conversation</a>, started by Lance Willett. In that conversation they debated whether or not <a title="http://make.wordpress.org/themes/guidelines/" href="http://make.wordpress.org/themes/guidelines/">guidelines</a> were hard and fast rules. <span id="more-11478"></span></p>
<p>I asked Chip Bennett to explain in plain English what these changes mean for both theme reviewers and authors. This is what he had to say.</p>
<blockquote><p>No changes have been made to the overall Guidelines, except that the Theme Unit Tests have been reduced in criticality from &#8220;Required&#8221; to &#8220;Recommended&#8221;. Developers should still test their Themes against the TUT before submission, and Reviewers will still test Themes against the TUT during reviews. The only difference is that, now, any observed issues will be noted as recommended fixes, rather than as issues required to address before Theme approval.</p></blockquote>
<p>These changes come on the heels of a <a href="http://devwp.eu/theme-reviews-guidelines-community/" title="http://devwp.eu/theme-reviews-guidelines-community/">recent blog post</a> published by Mario Peshev where he explained his experience participating in the theme review process for the past two and half years. According to Mario, some of the guidelines still contain too much subjectivity, especially when it comes to credit links located within themes. A side effect of the theme review guidelines is the large amount of themes in the directory that cater to blogging. The argument is that the guidelines do not provide enough leeway to embrace variety. However, Chip noted in the comments:</p>
<blockquote><p>There’s nothing in the Guidelines that prohibit “business” Themes, or one-page Themes, or WooCommerce/EDD Themes, etc. If there are minor things that need exceptions (such as allowing the screenshot to display a static front page), developers can always ask for such exceptions.</p></blockquote>
<p>Between the recent change with the theme unit tests and the engaging discussions taking place amongst the theme review community, steps are being taken in the right direction to make the theme review process easier for everyone involved. It&#8217;s worthy to note that all of the WordPress theme reviewers are volunteers helping to make the directory a better place. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Nov 2013 21:42:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"WPTavern: A New Website For Test Driving BuddyPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11558";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://www.wptavern.com/a-new-website-for-test-driving-buddypress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3202:"<p>The official <a href="http://testbp.org " target="_blank">BuddyPress Test Drive</a> site, located at testbp.org, had been around since the early days of BuddyPress before it was taken down. Testbp.org was always running the latest version of BuddyPress and served as a place where users could try out the plugin in a live environment. </p>
<p>Three years ago, when <a href="http://buddypress.org/2010/02/introducing-buddypress-1-2/" target="_blank">BuddyPress 1.2</a> was released, the site had accumulated more than 15,000 members. A good chunk of these users were probably spam or test signups. When I asked BuddyPress lead developer John James Jacoby why they took the site down, he replied, &#8220;<strong>TestBP.org  was popular for spammers, an echo chamber for misplaced support, and less moderated.</strong>&#8220;<span id="more-11558"></span></p>
<p>Taking TestBP.org down was probably for the best, as the site was becoming a bit unruly, but that left a need for a generic example site running the latest version of BP.</p>
<h3>BPTestDrive.org is Born</h3>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/bptestdrive.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/bptestdrive.jpg?resize=277%2C300" alt="bptestdrive" class="alignright size-medium wp-image-11617" /></a><a href="https://twitter.com/dimensionmedia" target="_blank">David Bisset</a>, BuddyPress developer and creator of <a href="http://www.wptavern.com/monitor-wordcamps-online-with-wp-armchair" target="_blank">WP Armchair</a>, decided to jump in and recreate the site on a new domain: <a href="http://bptestdrive.org/" target="_blank">BPTestDrive.org</a>. Part of the reason was because he is giving a presentation at WordCamp Orlando and needed something people could test drive. </p>
<p><a href="http://bptestdrive.org/" target="_blank">BPTestDrive.org</a> currently runs the Twenty Twelve default theme and a very minimal set of plugins. The goal is to provide an example of what BuddyPress looks like “right out of the box.&#8221; Bisset plans to wipe the site regularly in order to keep the spam under control. If spam registration gets out of control, he is considering replacing the default registration with a Gravity Form. Although this is not ideal, since it&#8217;s not default BuddyPress, Bisset said, &#8220;So far I&#8217;ve gotten almost zero BP register spam when I&#8217;ve done that.&#8221;</p>
<p>In light of the <a href="http://www.wptavern.com/rip-buddypress-default-theme-finally-laid-to-rest-in-1-9" target="_blank">BP Default theme being retired</a> in BuddyPress 1.9, the new BP Test Drive site is a valuable reference for people who just want to check out how the plugin works. All the components are in place and users who are new to BuddyPress can easily test out the registration and login process. The Test Drive site is a much easier option for casual exploration than having to install BuddyPress and set all the pages up for components. Many thanks to David Bisset for taking this on. Here&#8217;s hoping he can maintain <a href="http://bptestdrive.org/" target="_blank">BPTestDrive.org</a> as a long term resource.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Nov 2013 16:10:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"WPTavern: WordPress Core Adopts Sass CSS Preprocessor";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11532";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://www.wptavern.com/wordpress-core-adopts-sass-css-preprocessor";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3344:"<p>Nearly a year ago, <a href="http://profiles.wordpress.org/chriswallace" target="_blank">Chris Wallace</a> proposed that the WordPress core adopt a CSS Preprocessor to help move admin UI CSS into the future. Including a CSS preprocessor allows developers to speed up tasks with the use of variables in stylesheets. Variables will make tasks like reskinning the WordPress admin a breeze. Wallace argued strongly for <a href="http://sass-lang.com/" target="_blank">Sass</a> in his ticket because of its relatively low barrier for entry, due to the fact that it follows the conventions of CSS at its core.</p>
<p>With the inclusion of MP6 finally a lock for WordPress 3.8, <a href="http://profiles.wordpress.org/helen" target="_blank">Helen Hou-Sandi</a> reignited the discussion on CSS preprocessors by <a href="http://make.wordpress.org/core/2013/11/05/22862-consider-a-css-preprocessor/" target="_blank">highlighting</a> Wallace&#8217;s original ticket on the make.wordpress.org core development blog. After an epic debate of <a href="http://sass-lang.com/" target="_blank">Sass</a> vs. <a href="http://lesscss.org/" title="LESS" target="_blank">LESS</a>, it seems that Sass has won out and <a href="http://core.trac.wordpress.org/changeset/26137" target="_blank">will be adopted</a> as WordPress&#8217; CSS preprocessor moving forward.</p>
<div id="attachment_11599" class="wp-caption aligncenter"><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/sass.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/sass.jpg?resize=512%2C341" alt="photo credit: Cre8ive Commando" class="size-full wp-image-11599" /></a><p class="wp-caption-text">photo credit: <a href="http://www.cre8ivecommando.com/">Cre8ive Commando</a></p></div>
<h3>Why Sass?</h3>
<p>Proponents of <a href="http://sass-lang.com/" target="_blank">Sass</a> cited many reasons why it would be a better fit for WordPress than other CSS preprocessors. To quickly summarize the discussion, I&#8217;ve outlined just a few of the important arguments for a CSS preprocessor in general and for Sass in particular:<span id="more-11532"></span></p>
<ul>
<li>Allows for the use of variables to calculate layout widths, generate color schemes, font sizes, etc.</li>
<li>Reduces HTTP requests when stylesheets are combined into one</li>
<li>Easily minify generated CSS files in bundled versions of WordPress to speed up load times</li>
<li>Sass is GPL-compatible, licensed under the MIT license</li>
<li>Sass is backwards compatible with all versions of CSS</li>
<li>Sass supports more advanced logic &#8211; ability to include if/then/else and for/while/each statements</li>
</ul>
<p>The main challenge with Sass is that it is dependent upon Ruby and the Sass Ruby gem. Efforts to <a href="http://core.trac.wordpress.org/changeset/26143" target="_blank">sort out the Ruby dependency</a> have <a href="http://core.trac.wordpress.org/changeset/26145" target="_blank">landed</a> on the use of <a href="https://github.com/sindresorhus/grunt-sass" target="_blank">grunt-sass</a>, which allows for compiling .scss files without Ruby. </p>
<p>The inclusion of Sass capabilities in WordPress 3.8 will bring a bright new day for front-end developers. Are you excited about Sass use in WordPress? Or were you on the other side of the debate?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 22:46:47 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: RIP BuddyPress Default Theme: Finally Laid to Rest in 1.9";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11576";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:80:"http://www.wptavern.com/rip-buddypress-default-theme-finally-laid-to-rest-in-1-9";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3424:"<p><div id="attachment_11138" class="wp-caption alignright"><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/bp-default.png" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/bp-default.png?resize=300%2C225" alt="BP Default, May you rest in peace" class="size-full wp-image-11138" /></a><p class="wp-caption-text">BP Default, May you rest in peace</p></div>The BuddyPress Default Theme passed away at his home in the BuddyPress trunk on <a href="http://buddypress.trac.wordpress.org/changeset/7569/" target="_blank">November 13, 2013</a>, surrounded by family. BP Default is predeceased by his parents and relatives, the 1.1 themes, the wire, and the status components. Born on February 16th, 2010, during the golden era of <a href="http://buddypress.org/2010/02/introducing-buddypress-1-2/" target="_blank">BuddyPress 1.2</a>, the BP Default theme was three years old.</p>
<p>In his day, BP Default was considered &#8220;clean and stylish&#8221;. He could build a social network straight out of the box like nobody&#8217;s business. BP Default was a dapper fellow, often seen about town sporting a fashion-forward blue gradient, fancy widgets and featured images. </p>
<p>The BuddyPress default theme is survived by hundreds of child themes that will go on living without him. A service was held on the BuddyPress development blog earlier this week. In lieu of flowers, the family has asked that you send pizza, beer or donations to any one of their Amazon wishlists.  <span id="more-11576"></span></p>
<p>Choking back tears, BuddyPress developer Boone Gorges spoke at BP Default&#8217;s funeral, <a href="http://bpdevel.wordpress.com/2013/11/13/the-future-of-the-bp-default-theme/" target="_blank">saying</a>: </p>
<blockquote><p>I think I speak for everyone who has worked extensively with bp-default and its derivatives when I say that this is something of a bittersweet moment. bp-default was often a bear to work with, but it also proved to be a remarkably flexible and powerful foundation for building BuddyPress sites. And oh, that beautiful blue header gradient!</p></blockquote>
<p>Also in attendance was Hugo Ashmore, who thanked BP Default for his service and spoke of the future:</p>
<blockquote><p>bp-default served with honour and deserves a well earned rest :) This is the right way to go to keep core code and attention focused on theme compat and not offer too many alternatives to have to consider and support. Moving to WP theme repo would be optimum scenario and short of a few hurdles shouldn’t be too hard to achieve.</p></blockquote>
<p>It is with fond remembrance that we lay BP Default to rest this week. While the theme will continue to be packaged with the BuddyPress download, it is no longer supported by the core development team. </p>
<p>BP Default will still receive critical fixes and security updates but will not get any bug fixes or new features. New installations and sites where bp-default is not already in use will no longer see BP Default in the <strong>Dashboard > Appearance</strong> screen. It&#8217;s possible that the theme will be laid to rest on wordpress.org, but that has not yet been decided. We&#8217;ll keep you updated about its <a href="http://buddypress.trac.wordpress.org/ticket/5212" target="_blank">final resting place</a>. In the meantime, raise a glass to BP Default. Thanks for all the good times.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 19:17:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"WPTavern: New Forum Available For WordCamp Organizers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://www.wptavern.com/new-forum-available-for-wordcamp-organizers";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2368:"<p>Good news for WordCamp organizers! There is now an <a href="http://plan.wordcamp.org/forums/" title="http://plan.wordcamp.org/forums/">official forum</a> where WordCamp organizers can share tips, advice, and work together. Announced on the <a href="https://make.wordpress.org/community/2013/11/13/wordcamp-organizer-forums-open/" title="https://make.wordpress.org/community/2013/11/13/wordcamp-organizer-forums-open/">Make.WordPress.community website</a> by Andrea Middleton, new organizers are encouraged to ask questions while past organizers are asked to share their knowledge. <span id="more-11539"></span></p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WordCampPlanningForum.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WordCampPlanningForum.jpg?resize=500%2C315" alt="WordCamp Planning Forum" class="aligncenter size-large wp-image-11578" /></a></p>
<p>In order to participate on the forum, you&#8217;ll need to log in using your WordPress.org account credentials. The forum is using a fresh install of bbPress. When I asked Andrea who is moderating the discussions, she told me that she&#8217;s hoping they will be largely community-moderated. However, if things get backed up, she&#8217;ll make a call for moderators. I also asked if WordCamp attendees would be able to participate on the forum.</p>
<blockquote><p>Well, anyone with a wordpress.org account can participate, but the intention is for these forums to be a place for WordCamp organizers to share knowledge and experiences. If attendees are interested in the nitty-gritty of WordCamp organizing, I hope the forums will inspire them to join their local meetup group and get involved in organizing an upcoming event.</p></blockquote>
<p>Andrea also had this to say: </p>
<blockquote><p>I&#8217;m excited to have a place where organizers&#8217; frustrations can be shared and hopefully, halved. I hope this forum becomes a great repository of tips, hacks, and lessons learned. Together we are stronger.</p></blockquote>
<p>I think it&#8217;s important that attendees participate in the forum alongside organizers. After all, attendees are the real judges behind what worked and what didn&#8217;t. With both sides taking an active role in discussions, WordCamps will likely become better events for everyone involved. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 18:45:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WPTavern: WordPress Hosting Company ZippyKid Rebrands Company As Pressable";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11367";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:88:"http://www.wptavern.com/wordpress-hosting-company-zippykid-rebrands-company-as-pressable";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2704:"<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/ZippykidLogo.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/ZippykidLogo.jpg?resize=300%2C94" alt="ZippyKid logo" class="alignright size-medium wp-image-11564" /></a>WordPress hosting company <a href="http://www.zippykid.com" title="http://www.zippykid.com">ZippyKid</a> has announced that it will be operating under the name of <a title="http://pressable.com/" href="http://pressable.com/">Pressable</a>. Accompanying this major shift in rebranding will be a newly designed website. ZippyKid was started in 2010 by Vid Luther, who at the time just wanted to help out a few friends who were spending too much time configuring servers. <span id="more-11367"></span></p>
<p>While the mission of WordPress is to democratize publishing, Pressable wants to simplify the publishing process on the web. </p>
<blockquote><p>Pressable’s mission is to simplify the publishing processes on the Internet, effectively changing the way publishers use WordPress and what they expect from a hosting provider. “We’re working on a number of new features to help us achieve this mission,” says Vid. “The new name and branding helps set the stage for these projects, which we will be unveiling in 2014.</p></blockquote>
<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/PressableLogo.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/PressableLogo.jpg?resize=246%2C104" alt="PressableLogo" class="aligncenter size-full wp-image-11562" /></a></p>
<p>Pressable has some recognizable names investing in their company such as: <a href="http://www.rackspace.com/" title="http://www.rackspace.com/">Rackspace</a> co­founders, Pat Condon and Dirk Elmendorf, <a href="http://automattic.com/" title="http://automattic.com/">Automattic</a>, the company behind WordPress.com, <a href="https://duckduckgo.com/" title="https://duckduckgo.com/">DuckDuckGo</a> founder Gabriel Weinberg, <a href="http://37signals.com/founderstories/slicehost" title="http://37signals.com/founderstories/slicehost">Slicehost</a> founder Jason Seats, and <a href="http://500.co/" title="http://500.co/">500Startups</a>.</p>
<p>I asked Vid Luther why he decided to use Pressable as the new name for the company. He responded <em>&#8220;picking the new name wasn&#8217;t easy. When we were down to our last four, I knew Pressable was the one because it appealed to the geek in me. It&#8217;s a tongue-in-cheek tip of the hat to &#8220;Scalable&#8221; and WordPress&#8221;</em>. </p>
<p>What are your thoughts on the new name? Is it better or worse than ZippyKid?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 17:30:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Matt: Your Phone’s Second OS";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43177";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:43:"http://ma.tt/2013/11/your-phones-second-os/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:495:"<blockquote><p>It&#8217;s kind of a sobering thought that mobile communications, the cornerstone of the modern world in both developed and developing regions, pivots around software that is of dubious quality, poorly understood, entirely proprietary, and wholly insecure by design.</p></blockquote>
<p>Thom Holwerda writes about <a href="http://www.osnews.com/story/27416/The_second_operating_system_hiding_in_every_mobile_phone">the second operating system hiding in every mobile phone</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 17:01:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:55:"WordPress.tv: Al Davis: The New User Guide To WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25307";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wordpress.tv/2013/11/14/al-davis-the-new-user-guide-to-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:665:"<div id="v-EpRxeNik-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25307/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25307/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25307&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/14/al-davis-the-new-user-guide-to-wordpress/"><img alt="Al Davis: The New User Guide To WordPress" src="http://videos.videopress.com/EpRxeNik/video-967867e202_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 15:10:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"WordPress.tv: Simone D’amico: Gestire pagine di opzioni personalizzate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=17331";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:86:"http://wordpress.tv/2013/11/14/simone-damico-gestire-pagine-di-opzioni-personalizzate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:690:"<div id="v-PtJczfmH-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/17331/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/17331/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=17331&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/14/simone-damico-gestire-pagine-di-opzioni-personalizzate/"><img alt="Simone D’amico: Gestire pagine di opzioni personalizzate" src="http://videos.videopress.com/PtJczfmH/video-c048d525c3_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 13:44:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:71:"WPTavern: WordPress 3.8 Merge Window Closed: New Features Now Locked In";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11541";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://www.wptavern.com/wordpress-3-8-merge-window-closed-new-features-now-locked-in";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3114:"<p>Today was an important day for moving forward on the WordPress <a href="http://make.wordpress.org/core/version-3-8-project-schedule/" target="_blank">3.8 project schedule</a>. The merge window is now closed for new features, which means that all the main features included in this release are set. </p>
<p>There were no surprises during the regularly scheduled WordPress development chat. All of the expected plugin candidates made it in on time, including the new dashboard design, MP6, and the THX (Theme Experience) project.  <a href="http://www.wptavern.com/wordpress-twenty-fourteen-project-enters-crunch-time-for-3-8-release" target="_blank">Twenty Fourteen</a> was also merged into the trunk, so the theme will officially be making its debut in WordPress 3.8 before the end of the year. </p>
<p>All of these <a href="http://make.wordpress.org/core/features-as-plugins/" target="_blank">features-as-plugins</a> candidates will soon be shedding their quirky names and assimilated into core. The plugins will no longer be needed but will always have a special place in WordPress history as the features formerly known as MP6, THX and DASH.</p>
<p><div id="attachment_11547" class="wp-caption aligncenter"><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/byemp6.png" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/byemp6.png?resize=560%2C280" alt="photo credit - Matt Thomas" class="size-full wp-image-11547" /></a><p class="wp-caption-text">photo credit &#8211; <a href="https://twitter.com/iammattthomas/status/400754749152051200/photo/1" target="_blank">Matt Thomas</a></p></div><span id="more-11541"></span></p>
<p>Beta 1 is just around the corner and is scheduled to be out November 20th. At that point in time, no more commits for any new enhancements or feature requests will be included in 3.8. Contributors will focus on bug fixes and inline documentation.</p>
<h3>Getting Ready for WordPress 3.9</h3>
<p>Matt closed the development meeting by encouraging everyone to start getting fired up about new features for the 3.9 release. </p>
<blockquote><p>One final thing, everyone should start thinking about plugin projects, and renewed energy on ones that didn&#8217;t make 3.8, starting after beta 1. For 3.9 to go smoothly we need the head start, just like we had for 3.8.</p></blockquote>
<p>He suggested that developers start periodic chats to talk about new plugin projects outside of the timeline of releases. During next week&#8217;s development meeting there will be time carved out for folks to mention the projects and invite others to join for longer scheduled chats. &#8220;The obvious first ones on deck are ones that missed 3.8,&#8221; Matt said. &#8220;But we can kick off entirely new things as well, just needs folks who want to work on it.&#8221; </p>
<p>Now is a great time to get involved in <a href="http://make.wordpress.org/core/" target="_blank">WordPress core development</a>. If you have feature that you&#8217;d like to work on as a plugin, you&#8217;re invited to throw your hat into the ring next Wednesday.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 01:28:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:58:"WPTavern: My Opera Shutting Down, How To Move To WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11480";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://www.wptavern.com/my-opera-shutting-down-how-to-move-to-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2217:"<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/MyOperaLogo.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/MyOperaLogo.jpg?resize=143%2C51" alt="MyOperaLogo" class="alignright size-full wp-image-11512" /></a>On October 31st, <a href="http://my.opera.com/desktopteam/blog/important-announcement-about-your-my-opera-account" title="http://my.opera.com/desktopteam/blog/important-announcement-about-your-my-opera-account">Opera announced</a> that it is shutting down My Opera on March 1, 2014. My Opera is a social network of sorts made up of blogs, email, and a place to discuss Opera with friends. While the initial concept was launched in 2001 and then expanded upon in 2006, Opera states there are successful businesses that specifically cater to those wanting a social network or a place to share photos. &#8220;<em>Over the years, we&#8217;ve seen social media and blogging sites pop up, which offer more and better features than we could possibly maintain. These offerings are their sole business. You all know their names and you probably use their services already.</em>&#8221; Thus, the decision to close My Opera and to concentrate their development resources elsewhere.<br />
<span id="more-11480"></span></p>
<h3>Two Different Ways To Export My Opera Content</h3>
<p>My Opera is providing two different methods to export content from the site. You can either <a href="http://my.opera.com/community/help/community/#exportblog" title="http://my.opera.com/community/help/community/#exportblog">export your blog</a> or <a href="http://my.opera.com/community/help/community/" title="http://my.opera.com/community/help/community/">download all of your content</a>. If you choose to export your content, you can take that file and import it into <em>WordPress, Squarespace, Typepad, Movable Type, Drupal</em> or any other system that supports XML files.</p>
<p>If you&#8217;d like to migrate to WordPress.com, they have an <a href="http://en.support.wordpress.com/import/import-from-opera/" title="http://en.support.wordpress.com/import/import-from-opera/">excellent guide</a> that walks you through the process, complete with screenshots. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Nov 2013 21:00:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WPTavern: Drupal Release Cycle Improvements Inspired by WordPress and Other Platforms";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11502";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:99:"http://www.wptavern.com/drupal-release-cycle-improvements-inspired-by-wordpress-and-other-platforms";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4464:"<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/druplicon.png" rel="thumbnail"><img class="alignright size-full wp-image-11506" alt="druplicon" src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/druplicon.png?resize=175%2C200" /></a>Tis the season for open source projects to work together and learn from one another. The Joomla community gave a warm welcome to Matt Mullenweg and Andrew Nacin at the Joomla World Conference, where Matt delivered a <a href="http://www.wptavern.com/wordpress-co-founder-matt-mullenweg-keynotes-joomla-world-conference" target="_blank">keynote address</a>. This event opened up some interesting cross-platform discussions on development. The folks at WordCamp Miami are <a href="https://twitter.com/wordcampmiami/status/399606341456494592" target="_blank">welcoming Joomla users and developers</a> to attend their event next year in order to foster more shared experiences.</p>
<p>Leaders of the Drupal project are also looking to learn from other projects&#8217; approach to development. <a href="https://drupal.org/user/1" target="_blank">Dries Buytaert</a>, Drupal founder and project lead, <a href="https://drupal.org/node/2135189" target="_blank">announced</a> today that the project will be moving towards a more agile development approach in order to deliver small changes faster.<span id="more-11502"></span></p>
<p>Buytaert sites several issues with Drupal core development: &#8220;<strong><em>not innovating fast enough, insufficient commercial incentive to contribute, contributor burnout, and unpredictable release cycles.</em></strong>&#8221; Any living, breathing open source project will always have its own unique obstacles to overcome. While analyzing how Drupal&#8217;s current development approach can be improved, they <a href="https://docs.google.com/spreadsheet/ccc?key=0Au2jx5BO5ObGdHAteENTWWx4RmxwZ2xqNEEwZWNuTUE&usp=drive_web#gid=1" target="_blank">compared and contrasted release strategies employed by other similar projects</a>, including <a href="http://make.wordpress.org/core/handbook/how-the-release-cycle-works/" target="_blank">WordPress</a>, Joomla, Typo3, Firefox, Ubuntu, Symfony and PHP.</p>
<p>The data collected shows that WordPress tends to iterate more quickly than others, putting out more major releases, but only offering security support for the current release. The difference here is that WordPress tries hard to never break backwards compatibility, even for major releases. Other projects surveyed may have longer waits between major releases with less emphasis on backwards compatibility but still maintain security support, or what they term LTS (Long Term Support), for older releases.</p>
<blockquote><p>All have a substantive release anywhere from every 6 weeks (for Firefox) to 1 year (for PHP), with most at around 6 months. The projects differ in whether or how they provide LTS releases: Ubuntu does so once every two years and supports them for 5 years, while WordPress only provides security support for their latest release, but tries hard to always preserve BC, even in major releases.</p></blockquote>
<p>Buytaert&#8217;s <a href="https://drupal.org/node/2135189" target="_blank">proposal to manage the Drupal 8 release cycle</a> takes the best ideas from these projects and applies them in a way that will work for the Drupal community. They will be adopting a new strategy of mostly preserving backwards compatibility while aiming for an innovative release every six months, which is similar to most of the projects surveyed. At the same time, Drupal will be providing a single LTS release as the final minor release, similar to Joomla, and will support that LTS release until two additional ones have been released, in the style of Ubuntu. </p>
<p>The <a href="http://make.wordpress.org/core/handbook/how-the-release-cycle-works/" target="_blank">WordPress approach to release cycles</a> is not the only way and it&#8217;s not the best way, either. It&#8217;s just the way that works for us so far. The tandem release cycle of WordPress 3.7 and 3.8 was a new approach for us, but it seems to be paying off big time. It&#8217;s exciting to see the Drupal community putting together a new strategy that will work for them, based on the strengths they see in other similar projects. The proposed changes seem to be well-received and it will be interesting to watch how this next release cycle changes things for Drupal folks.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Nov 2013 20:31:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WordPress.tv: Zack Tollman: Enhancing Developer Creativity With Git";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=25230";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://wordpress.tv/2013/11/13/zack-tollman-enhancing-developer-creativity-with-git/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:689:"<div id="v-kiK3DzLj-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/25230/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/25230/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=25230&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/13/zack-tollman-enhancing-developer-creativity-with-git/"><img alt="Zack Tollman: Enhancing Developer Creativity With Git" src="http://videos.videopress.com/kiK3DzLj/video-7440ea8ff1_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Nov 2013 20:26:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"WPTavern: WordPress For Android Gets a Major Update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11458";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:65:"http://www.wptavern.com/wordpress-for-android-gets-a-major-update";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3559:"<p>The <a href="http://play.google.com/store/apps/details?id=org.wordpress.android" target="_blank">WordPress Android app</a> received some significant <a href="http://android.wordpress.org/2013/11/11/2-5-release/" target="_blank">updates</a> this week, making it easier than ever to post on the go. As a long time Android user, I&#8217;ve seen the app go through many different stages. This update brings the most beautiful mobile experience to Android users so far. </p>
<h3>More Robust Support for Media Handling</h3>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/media.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/media.jpg?resize=560%2C349" alt="media" class="aligncenter size-full wp-image-11494" /></a></p>
<p>One of the most exciting updates included in this release is improved support for media. You can now access any of the files in your media library and edit title, description and caption for any item. When blogging on the go, chances are high that you&#8217;ll be including images and/or video. The app now provides a much smoother experience for uploading photos and videos from your device to the media library.<span id="more-11458"></span></p>
<p>The gallery support in this release blows me away. Creating tiled galleries is as simple as using a long-press to select multiple media items and then tapping the gallery button to create a new gallery. The app now lets you choose a gallery style and even reorder images with drag and drop. </p>
<h3>Stats Revamped with Faster, Native Support</h3>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/stats.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/stats.jpg?resize=214%2C300" alt="stats" class="alignright size-medium wp-image-11489" /></a>WordPress for Android now includes native support for viewing stats. Users obsessed with their stats will be delighted to find that they load up faster than every before. Status support includes all the vital information:</p>
<ul>
<li>Visitors and Views</li>
<li>Totals, Followers &#038; Shares</li>
<li>Clicks</li>
<li>Referrers</li>
<li>Search Engine Terms</li>
</ul>
<p>Full stats are still available by tapping &#8220;View full site&#8221; in the overflow menu.</p>
<h3>Protect Content With the New PIN Lock Feature</h3>
<p>The app now includes a new item in the settings menu where users can enable a PIN lock. This helps you to protect your content from any random Joe who might get access to your phone. If you enable this feature, you&#8217;ll be prompted for your PIN to unlock the app.</p>
<p>Another very cool thing about PIN lock is that Automattic has made the code open source and available on <a href="https://github.com/wordpress-mobile/Android-PasscodeLock" target="_blank">github</a>. Developers can drop this same functionality into another app if desired.</p>
<h3>Coming Soon: A Native WordPress Reader</h3>
<p>Another big update is in the works. The team hinted at what you can expect in the future from WordPress for Android:</p>
<blockquote><p>Expect another big update soon that adds a native WordPress.com Reader, as well as a revamped welcome and blog setup experience.</p></blockquote>
<p>Android users, go check out those updates if your app hasn&#8217;t already prompted you for it. More robust support for media has me feeling more inclined to blog via mobile. How are other android users liking this update? What&#8217;s on your wishlist for the WordPress for Android app?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Nov 2013 18:10:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Matt: KRNFX Get Lucky";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43173";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:37:"http://ma.tt/2013/11/krnfx-get-lucky/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:75:"<p><span class="embed-youtube"></span></p>
<p>Very cool looped version.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Nov 2013 16:54:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:59:"WPTavern: Themify Announces Security Vulnerability With Fix";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11471";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:73:"http://www.wptavern.com/themify-announces-security-vulnerability-with-fix";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1537:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/ThemifyLogo.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/ThemifyLogo.jpg?resize=182%2C60" alt="Themify Logo" class="alignright size-full wp-image-11473" /></a>Themify <a href="http://themify.me/blog/urgent-vulnerability-found-in-themify-framework-please-read" title="http://themify.me/blog/urgent-vulnerability-found-in-themify-framework-please-read">has announced</a> that they have discovered and confirmed a vulnerability in their framework. The vulnerability stems from an unsecure file named <em>themify-ajax.php</em>. The fix was released on <strong>November 9th, 2012</strong> but the auto upgrade process failed to delete the file. Themify states they have &#8220;<em>recently received several reports of intruders using <em>themify-ajax.php</em> to upload files to users servers</em>&#8220;. </p>
<p>The vulnerability is limited to users who installed the Themify framework version 1.2.1 and below. Users are encouraged to check their webhosting accounts to see if their theme contains the vulnerable file. If you don&#8217;t find it, chances are your safe. If the file is present, you need to download the latest version of the Themify framework from the <a href="http://themify.me/member" title="http://themify.me/member">members area</a> and replace the entire theme folder with it. If you think you&#8217;ve been compromised due to this vulnerability, you should contact Themify as soon as possible. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Nov 2013 08:15:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:74:"WPTavern: Database Migrations Made Easy Thanks To The WP DB Migrate Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11422";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"http://www.wptavern.com/wordpress-plugin-review-wp-db-migrate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3552:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPDBMigrateLogo.jpg" rel="thumbnail"><img class="alignright size-full wp-image-11430" alt="WPDBMigrateLogo" src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPDBMigrateLogo.jpg?resize=211%2C43" /></a><a title="http://wordpress.org/plugins/wp-migrate-db/" href="http://wordpress.org/plugins/wp-migrate-db/">WP DB Migrate</a> is an awesome plugin created by <a title="http://profiles.wordpress.org/bradt/" href="http://profiles.wordpress.org/bradt/">Brad Touesnard</a>. This plugin makes it easy to transfer the database contents between WordPress powered sites. While there is a <a title="http://deliciousbrains.com/wp-migrate-db-pro/" href="http://deliciousbrains.com/wp-migrate-db-pro/">Pro version</a> of this plugin available, my experience was with the free version, hosted on the WordPress plugin repository. <span id="more-11422"></span></p>
<p>I needed a quick and easy way to move a database of information from a public WordPress website to my local install. Since I didn&#8217;t have access to phpMyAdmin to retrieve the database, WP Migrate DB was the next best thing. It&#8217;s as easy as installing the plugin on the site I&#8217;m migrating data from and then installing it on the site I&#8217;m moving the data to. After installation, you&#8217;ll find the settings located within the <strong>Tools</strong> menu. </p>
<h3>Easily Perform Search and Replace Before Exporting</h3>
<p>One of my favorite features of this plugin is the ability to replace the site URL and the file path to match the location of the site you&#8217;re migrating to. It&#8217;s the equivalent of performing a search and replace during a normal MySQL export/import routine. Being able to perform this task without having to use SQL statements or another plugin is a big time saver.</p>
<div id="attachment_11448" class="wp-caption aligncenter"><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPDBMigrateOptions.jpg" rel="thumbnail"><img class="size-large wp-image-11448" alt="WP DB Migrate Options" src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/WPDBMigrateOptions.jpg?resize=500%2C372" /></a><p class="wp-caption-text">Changing the site URL is easy!</p></div>
<p>This plugin also provides the following options:</p>
<ul>
<li>Replace GUIDs</li>
<li>Disable the exporting of spam comments</li>
<li>Disable the exporting of post revisions</li>
<li>Save the database file to your computer</li>
<li>Compress the file with gzip</li>
</ul>
<h3>Works As Expected</h3>
<p>The plugin worked without any problems. I was able to download the MySQL file with the changes I applied and then I imported that file into my local install of WordPress. Now my local install is in synch with the public version. Although it does take some time to import the file, it&#8217;s still not enough to motivate me to figure out how to mirror the sites at least once a day. However, if I decided that this would become a routine, I would upgrade to the Pro version which contains the ability to pull remote databases and push them to my local install. That feature alone would be worth the <a title="https://deliciousbrains.com/wp-migrate-db-pro/pricing/" href="https://deliciousbrains.com/wp-migrate-db-pro/pricing/"><strong>$39</strong></a> dollars which also includes updates and support for one year.</p>
<p>I realize there are other plugins that provide a similar feature set, but WP Migrate DB made the process so smooth, it was worthy of sharing.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Nov 2013 23:45:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WPTavern: WordPress Twenty Fourteen Project Enters Crunch Time for 3.8 Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11392";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://www.wptavern.com/wordpress-twenty-fourteen-project-enters-crunch-time-for-3-8-release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3697:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/twenty-fourteen.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/twenty-fourteen.jpg?resize=278%2C300" alt="twenty-fourteen" class="alignright size-medium wp-image-11444" /></a>The Twenty Fourteen project team, led by Lance Willett, is working like crazy to get the theme ready for the upcoming 3.8 release. The theme&#8217;s inclusion in 3.8 is dependent upon how many things can be accomplished during the crunch time before the merge window closes tomorrow.</p>
<p>Since last week&#8217;s development chat, the team has made great strides and <a href="http://make.wordpress.org/core/2013/11/12/twenty-fourteen-project-update-4/" target="_blank">announced</a> a number of major improvements today, including:<span id="more-11392"></span></p>
<ul>
<li>Many design changes to make the “first run” nicer and look better without featured images</li>
<li>UI for Featured Content moved completely into Customizer (tag, display, count)</li>
<li>Added contextual help and tips around the admin interface for setting up the Featured Content area</li>
<li>Performance tweaks for faster loading</li>
<li>IE, RTL, and i18n fixes</li>
</ul>
<h3>The Decision to Remove Placeholder Images</h3>
<p>Creating a theme that is so highly dependent upon featured images makes it a challenging to display content nicely without them. Originally, Twenty Fourteen included placeholder images in case no featured images were set. This was meant to encourage users to add featured images. Instead, it ended up making the theme look awkward without featured images. This week the team opted to remove the placeholders in favor of giving it a more general appeal as a blog theme. However, Twenty Fourteen will still look its best when feature images are used.</p>
<h3>Featured Content in Twenty Fourteen</h3>
<p>Twenty Fourteen is intended to be a magazine style default theme, so having an easy way to promote featured content is important. The theme was originally intended to work hand-in-hand with the &#8220;Featured Content&#8221; plugin that is being developed for 3.8. As it is yet unclear if that plugin will be ready, the team opted to implement a &#8220;featured content&#8221; tag instead, which can now be found in the Customizer.</p>
<h3>Author Widget</h3>
<p>Lance Willett said that they are hoping to include the Author Widget plugin in Twenty Fourteen to <a href="http://core.trac.wordpress.org/ticket/24856" target="_blank">highlight multiple authors</a>. This is well-suited to a magazine theme. For now it exists as the <a href="http://wordpress.org/plugins/wp-author-widget/" target="_blank">Authors Widget</a> plugin but Willett says, &#8220;It’s fairly light and can merge right away.&#8221;</p>
<h3>How to Access Twenty Fourteen for Testing</h3>
<p>If you want to see how Twenty Fourteen is shaping up, check out a live demo at: <a href="http://twentyfourteendemo.wordpress.com/" target="_blank">twentyfourteendemo.wordpress.com/</a>. This site is synced nearly every day with the core version of Twenty Fourteen. </p>
<p>There are a number of ways to get access to the theme for testing. You can grab it <a href="http://wordpress.org/download/svn/" target="_blank">via SVN</a> or switch to trunk using the <a href="http://wordpress.org/plugins/wordpress-beta-tester/" target="_blank">WordPress Beta Tester</a> plugin. The easiest option, however, might be to simply <a href="https://github.com/WordPress/WordPress" target="_blank">download the WordPress zip</a> from its github repository, which is a mirror of the subversion repository and synced via SVN every 15 minutes.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Nov 2013 23:20:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:38:"Alex King: UX Panel at WordCamp Denver";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://alexking.org/?p=18730";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://alexking.org/blog/2013/11/12/ux-panel-at-wordcamp-denver";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:477:"<p>I will be moderating <a href="http://2013.denver.wordcamp.org/session/panel-how-a-ux-focus-is-driving-wordpress-forward/">a panel on user experience</a> at WordCamp Denver this weekend. I hope to see you there.</p>
<p>If you&#8217;ve got ideas for topics you&#8217;d like to see us cover, please post them in the comments. I can&#8217;t promise we&#8217;ll cover them all, but it&#8217;s always nice to know we&#8217;re touching on topics the audience finds interesting.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Nov 2013 22:53:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"Alex";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:82:"WPTavern: Easily Turn A Static HTML Site Into A WordPress Theme With Theme Matcher";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11193";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:96:"http://www.wptavern.com/easily-turn-a-static-html-site-into-a-wordpress-theme-with-theme-matcher";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3598:"<p>Despite WordPress powering over 20% of the web, there are still a lot of static websites that could use a dynamic upgrade. In order for a static website to take advantage of WordPress it requires two things: A WordPress installation and a WordPress theme that looks like the static HTML site. Thanks to a new website called <a title="http://themematcher.com/" href="http://themematcher.com/">Theme Matcher</a>, creating a WordPress theme from a static website is easy. <span id="more-11193"></span></p>
<h2>How It Works Using The Example Theme</h3>
<p>Theme Matcher, created by Patrick Moody, takes static websites and automatically generates WordPress themes using <a title="http://themble.com/bones/" href="http://themble.com/bones/">Bones</a>. Bones is a minimalistic theme that is great to use as a foundation. To see how this site works, visit <a title="http://themematcher.com/" href="http://themematcher.com/">Themematcher.com</a> and use <a title="http://themematcher.com/example/" href="http://themematcher.com/example/">http://themematcher.com/example/</a> as the example URL. Follow the directions as described in the video. If you have difficulty finding the right spot to select as content, just select an area, then use the plus or minus buttons to add or subtract elements that will make up the content portion of the theme.</p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/ThemeCatcherGenerator.jpg" rel="thumbnail"><img class="aligncenter size-large wp-image-11411" alt="Theme Catcher Generator" src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/ThemeCatcherGenerator.jpg?resize=500%2C197" /></a></p>
<p>Next, select the area you want for the sidebar which will usually be to the left, or right of the content. If you feel adventurous, you can select an area outside of the content to use as the sidebar. You just might not be happy with the results. Alternatively, you can select an option to not have a sidebar via a link at the top of the website. After selecting the sidebar location, you can delete areas or preview the theme. When previewing the theme, experienced developers will be able to tell right away which parts are WordPress while the rest of the design remains static.</p>
<h3>Patrick Moody Answers A Few Questions</h3>
<p><strong>Why did you choose the Bones theme to power ThemeMatcher.com?</strong><br />
<em>Bones is an incredible starter theme that has already been highly refined and optimized by over 60 contributors over the course of several years. It&#8217;s a great foundation that is fast, lightweight, and has very clean code. These are all benefits that are easy to miss on &#8216;custom&#8217; projects, but are incorporated into every Theme Matcher conversion.</em></p>
<p><strong>Who are you targeting with this service?</strong></p>
<ul>
	<em>
<li>WordPress developers saving time and getting a head start on client projects, and then customizing the theme further.</li>
<li>Non-technical webmasters wanting to add a WordPress blog to an existing site.</li>
<li>Designers that create a HTML template/mockup, then fast-track it into a WordPress theme with ease.</li>
<li>Freelancers migrating sites to WordPress from another system</li>
<p></em>
</ul>
<h3>Nice Way To Save Time</h3>
<p>While the above is an excellent example of how Theme Matcher can help developers save time, there are a number of other uses for the site. Using Theme Matcher won&#8217;t take care of 100% of the work when transitioning a static site into a WordPress theme, but it gets you at least two-thirds of the way there.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Nov 2013 21:45:24 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:73:"WPTavern: WordPress Global Admin Search Evolves To Tackle Bigger Problems";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11386";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:87:"http://www.wptavern.com/wordpress-global-admin-search-evolves-to-tackle-bigger-problems";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4619:"<p>The WordPress Global Admin Search plugin, previously known as &#8220;Omnisearch&#8221;, is becoming a bigger project than it originally appeared to be. Searching the admin area of WordPress sounds so simple, right? But it turns out that search is a very nuanced feature that everyone has an opinion about.</p>
<p>Last week Matt Mullenweg held a <a href="http://www.wptavern.com/breaking-new-features-selected-to-merge-into-wordpress-3-8-core" target="_blank">meeting</a> to select new features ready to merge into the core for WordPress 3.8, but Omnisearch required more discussion before moving on. Up until this point, George Stephanis, the plugin&#8217;s developer, hadn&#8217;t received much feedback on the plugin in its current form. </p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/search.png" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/search.png?resize=560%2C141" alt="search" class="aligncenter size-full wp-image-11398" /></a></p>
<p>Yesterday&#8217;s &#8220;Search Initiative&#8221; <a href="http://make.wordpress.org/core/2013/11/11/the-search-initiative/" target="_blank">meeting</a> provided a flood of feedback on how search might be used, what it should search and how it might be implemented.<span id="more-11386"></span></p>
<h3>Global Admin Search Aims to Solve A Long List of Problems</h3>
<p>Stephanis outlined the pain points raised during the meeting surrounding the current state of admin search. One of the most bothersome things is that we have multiple search forms within the admin. If you want to search something you must first navigate to the correct thing you want to search, whether it&#8217;s posts, comments, custom post types, etc. This requires you to already know approximately where that content is located.</p>
<p>Working with results can also be troublesome, because it isn&#8217;t always clear why specific results have been included. If relevant data is stored in a postmeta field, it can be very difficult to find, because these fields are not indexed for searching. Also, a search query with no results found ends up being a dead end for users if a related or revised suggestion isn&#8217;t offered. </p>
<h3>Next Steps to Advancing Admin Search</h3>
<p><div id="attachment_11404" class="wp-caption alignright"><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/medium_68022059631.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/medium_68022059631.jpg?resize=280%2C178" alt="photo credit: 1D110 via photopin cc" class="size-full wp-image-11404" /></a><p class="wp-caption-text">photo credit: <a href="http://www.flickr.com/photos/22297595@N02/6802205963/">1D110</a> via <a href="http://photopin.com">photopin</a> <a href="http://creativecommons.org/licenses/by-nc-nd/2.0/">cc</a></p></div>WordPress does not yet have a unified search results page to send people to on the back-end, so putting this in place would become part of this project. A possible implementation suggested during the meeting was a tabbed interface, which might include an &#8216;Overview&#8217; tab and then others for different types of data being searched. Stephanis offers an example: a generic search term might land you on the overview tab but a search within the posts page for specific content would send you to the Posts tab with content displayed similar to how you would view results on their respective pages throughout the admin.</p>
<p>A number of other periphery suggestions came up, such as auto-suggesting results based on links off of the current page, similar to the <a href="http://www.wptavern.com/jarvis-a-free-quicksearch-tool-for-the-wordpress-dashboard" target="_blank">Jarvis</a> or <a href="http://wordpress.org/plugins/wp-butler/" target="_blank">WP-Butler</a> plugins. It&#8217;s yet to be decided whether some of these things will be left for plugin territory.</p>
<p>Global admin search is likely to miss the <a href="http://make.wordpress.org/core/version-3-8-project-schedule/" target="_blank">3.8 merge window</a> that closes tomorrow, but will remain in active development for inclusion in an upcoming release. The project will evolve considerably to tackle the current issues with searching the admin and will hopefully provide an elegant solution in the coming days.</p>
<p>Timely feedback is valuable for shaping the future direction of the admin search. What do you think about where search is headed? Do you see yourself using the global admin search? What is the most important problem that search would solve for you?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Nov 2013 20:49:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WordPress.tv: Noe Lopez: My First 3 Months Working With WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24422";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wordpress.tv/2013/11/11/noe-lopez-my-first-3-months-working-with-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:679:"<div id="v-B0gav8bD-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24422/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24422/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24422&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/11/noe-lopez-my-first-3-months-working-with-wordpress/"><img alt="Noe Lopez: My First 3 Months Working With WordPress" src="http://videos.videopress.com/B0gav8bD/video-fc9ec6c3ba_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Nov 2013 00:18:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:46:"WordPress.tv: Nathaniel Schweinberg: Debugging";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24370";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.tv/2013/11/11/nathaniel-schweinberg-debugging/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:647:"<div id="v-7kNdWaNH-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24370/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24370/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24370&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/11/nathaniel-schweinberg-debugging/"><img alt="Nathaniel Schweinberg: Debugging" src="http://videos.videopress.com/7kNdWaNH/video-73543f325a_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Nov 2013 22:20:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Matt: Apple and Google Maps, and Defaults";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43168";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:36:"http://ma.tt/2013/11/apple-defaults/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:1368:"<p>Comscore, whose accuracy is generally between a Lotto Quick Pick and a drunken dart throw, says Google Maps usage has fallen since Apple Maps came on the scene. The Guardian has a good overview: <a href="http://www.theguardian.com/technology/2013/nov/11/apple-maps-google-iphone-users">How Google lost when everyone thought it had won</a>.</p>
<p>We shouldn&#8217;t be surprised that in the absence of choice, people take the path of least resistance. What&#8217;s missing in these discussions is how it&#8217;s criminal Apple gets away with not allowing alternative defaults for maps, browsers, calendars, and any number of other areas, which means every time you click a link or address in the OS it opens Safari or Apple Maps, in my opinion inferior apps. Some developers get away with this by having settings to set Chrome or Google Maps as your default, like <a href="http://tripit.com/">Tripit</a> just added, but this is implemented in a hacky, per-application way, and every app puts their setting in a different place if they support it at all.</p>
<p>If Microsoft did this a decade ago we&#8217;d call for the DoJ to reopen their investigation. Apple has the best phone, best tablet, and in many ways the best operating system &#8212; we should not give them a pass for this blatantly self-interested and user-hostile stance. Defaults <em>matter</em>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Nov 2013 22:10:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WP Android: Powerful Media Handling, New Theme Browser, Better Stats, and More";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"http://android.wordpress.org/?p=906";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://android.wordpress.org/2013/11/11/2-5-release/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3612:"<p><a href="http://wpandroid.files.wordpress.com/2013/10/android-2-5-promo.png"><img class="alignnone size-large wp-image-929" alt="android-2-5-promo" src="http://wpandroid.files.wordpress.com/2013/10/android-2-5-promo.png?w=840&h=560" width="840" height="560" /></a></p>
<p>As more and more of you blog on the go, the mobile WordPress experience needs to keep up! Head to <a href="http://play.google.com/store/apps/details?id=org.wordpress.android">Google Play</a> today to download the newest WordPress for Android update, a big release that makes posting and administration simpler and more beautiful.</p>
<h3>Media Library</h3>
<p>The app can now access all the files in your Media Library. Edit the Title, Description or Caption for any item. with a few taps, add any media to a post, or upload photos and videos from your phone or tablet right to your Media Library.</p>
<h3>Gallery Support</h3>
<p>Create tiled galleries with items in your Media Library, no photo editing software necessary. Long-press to select multiple media items, and tap the gallery button to create a new gallery. From there, choose your preferred gallery style and reorder your images with drag and drop.</p>
<h3>WordPress.com Theme Browser</h3>
<p>If you have a WordPress.com blog, theme browser allows you to browse for, preview, and activate a new theme for your site right from your device. Looking for a particular theme or theme feature? Head to the ‘Themes’ menu in the navigation drawer, search using the ActionBar, and see results instantly. (Note: you’ll need administrator rights for the site to use the theme browser.)</p>
<h3>Native Stats</h3>
<p>We’ve overhauled the stats view, replacing the web-based version with a much faster (and better looking!) version. Use the filter in the ActionBar to review key stats at a glance:</p>
<ul>
<li>Visitors and Views</li>
<li>Totals, Followers &amp; Shares</li>
<li>Clicks</li>
<li>Referrers</li>
<li>Search Engine Terms</li>
</ul>
<p>If you’re hungry for more, you can still view the full stats site by tapping ‘View full site’ in the overflow menu.</p>
<h3>PIN Lock</h3>
<p>In the app settings, you’ll find an option to enable PIN Lock to protect your site’s content. When enabled, the app will ask you to enter the PIN lock code every time you return to the app.</p>
<p>(Developers! We made the PIN Lock an open source library that you can drop into your app to add the same functionality. See details at <a href="https://github.com/wordpress-mobile/Android-PasscodeLock" rel="nofollow noreferrer">https://github.com/wordpress-mobile/Android-PasscodeLock</a>.)</p>
<h2>Thanks and What&#8217;s Next</h2>
<p>Big thanks to all of the hard-working contributors that helped get this release out the door: <a href="https://github.com/xtreme-fredrich-ombico">xtreme-fredrich-ombico</a>, <a href="https://github.com/daniloercoli">daniloercoli</a>, <a href="https://github.com/roundhill">roundhill</a>, <a href="https://github.com/maxme">maxme</a>, <a href="https://github.com/nbradbury">nbradbury</a> and <a href="https://github.com/aerych">aerych</a>!<a href="http://wordpress.org/support/profile/mrroundhill"><br />
</a></p>
<p>Expect another big update soon that adds a native WordPress.com Reader, as well as a revamped welcome and blog setup experience.</p>
<p>What do you think of the update? Drop us a comment here or follow us <a href="http://twitter.com/wpandroid">@WPAndroid</a><span>.</p><img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=android.wordpress.org&blog=9426921&post=906&subd=wpandroid&ref=&feed=1" width="1" height="1" />";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Nov 2013 21:54:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:3:"Dan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:77:"WPTavern: iThemes Launches Sync Service for Updating Multiple WordPress Sites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11369";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:91:"http://www.wptavern.com/ithemes-launches-sync-service-for-updating-multiple-wordpress-sites";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4821:"<p>Cory Miller and the team at <a href="http://ithemes.com/" target="_blank">iThemes</a> announced today that they are launching a new WordPress service into the market. <a href="http://ithemes.com/sync/" target="_blank">iThemes Sync</a> made its debut today, offering customers a way to manage WordPress core, theme and plugin updates from one centralized dashboard. </p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/sync-member-panel2.png" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/sync-member-panel2.png?resize=560%2C286" alt="sync-member-panel2" class="aligncenter size-full wp-image-11370" /></a><span id="more-11369"></span></p>
<p>During our interview with Cory on the <a href="http://www.wptavern.com/wpweekly-episode-126-catching-up-with-cory-miller-from-ithemes" target="_blank">WordPress Weekly Podcast</a>, he explained that what started out as a theme company has gradually evolved into a plugin and service company. iThemes is focusing more on plugins than themes these days. With <a href="http://ithemes.com/purchase/backupbuddy/" target="_blank">BackupBuddy</a> in their tool belt along with <a href="http://ithemes.com/exchange/" target="_blank">Exchange</a>, iThemes&#8217; most recent foray into e-commerce, the company is more heavily investing in plugins and services. iThemes is aiming to become a one-stop shop for all things related to running a WordPress-powered business. The Sync service is one more piece in that puzzle.</p>
<h3>Competition Heats Up Among Centralized WordPress Dashboard Services</h3>
<p>Managing multiple WordPres sites from one place is nothing new. Services such as <a href="https://managewp.com/" target="_blank">ManageWP</a>, <a href="http://infinitewp.com/" target="_blank">InfiniteWP</a>, <a href="http://cmscommander.com/" target="_blank">CMS Commander</a> and <a href="http://www.wptavern.com/wp-remote-launches-commercial-backup-and-updating-services-for-wordpress" target="_blank">WP Remote</a> have been in this space for a few years and have already developed a wide array of complex features. Where does iThemes sync fit in? </p>
<p>Miller says that Sync was developed based on feedback from their current customers:</p>
<blockquote><p> We&#8217;re always seeking to save our customers time and hassle &#8212; what we believe good software, whether it&#8217;s a theme or plugin, should do for people. And frankly updating WP and themes and plugins were a time sink for our customer community and for us as WordPress users. That&#8217;s why we ultimately built iThemes Sync. But it also pairs very well with our other products, like BackupBuddy, and we&#8217;re planning some cool integrations with it very soon that will help people do more with Sync and BackupBuddy.&#8221;</p></blockquote>
<p>In addition to anticipating customer needs, Miller says that their product will also serve to ramp up the competition among others that provide this service. &#8220;Regarding competing against others that may already be in this space, it&#8217;s both. It&#8217;s a value add for our customers, but iThemes Sync is intended to be a full-fledged product in our lineup with a great roadmap.&#8221;</p>
<p>Step one will be for iThemes to make the Sync product available to non-iThemes customers. They are aiming to do this by the end of November.</p>
<p>As WordPress usage is increasing across the web, the challenge of administrating multiple WordPress sites is becoming more common, even among non-developers. Competition to provide the best service for this challenge is only natural. </p>
<p>While <a href="http://ithemes.com/sync/" target="_blank">iThemes Sync</a> may not yet have all the bells and whistles of others who provide this service, Miller is excited to get into this space and embraces the competition.</p>
<blockquote><p>Competition is a part of business, something on which I wrote a detailed <a href="http://corymiller.com/on-competition-in-business/" target="_blank">post</a> about earlier this year. I have a love-hate relationship with competition. Most of us, if we&#8217;re honest, hate competition. We&#8217;d all rather have monopolies and keep doing what we&#8217;re doing. But ultimately, competition benefits the user (and customer). It makes us all better for those who pay us for what we do. And that&#8217;s a good thing for WordPress too.</p></blockquote>
<p>Many WordPress companies that started as theme providers are branching out into plugin and service territory and taking the market by storm. Do you think large WordPress companies can successfully deliver high quality products across such a broad spectrum? Do you enjoy having more options to choose from or would you prefer to use a service that focuses solely on delivering a centralized dashboard?</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Nov 2013 21:49:37 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:30;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:38:"WPTavern: WordPress 3.8 Is On Schedule";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11334";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://www.wptavern.com/wordpress-3-8-is-on-schedule";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3661:"<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/3dot8ReleaseDate.jpg" rel="thumbnail"><img class="alignright size-full wp-image-11348" alt="WordPress 3.8 Release Date" src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/3dot8ReleaseDate.jpg?resize=185%2C57" /></a>During <a title="http://www.wptavern.com/wordpress-co-founder-matt-mullenweg-keynotes-joomla-world-conference" href="http://www.wptavern.com/wordpress-co-founder-matt-mullenweg-keynotes-joomla-world-conference">Matt Mullenweg&#8217;s keynote speech</a> at the Joomla World Conference this past weekend, he announced the date WordPress 3.8 would be released. The magical day is <strong>December 12th</strong>. It&#8217;s not that the release date was a secret, considering the <a title="http://make.wordpress.org/core/version-3-8-project-schedule/" href="http://make.wordpress.org/core/version-3-8-project-schedule/">project schedule</a> was published before development got started. It&#8217;s just that for as long as I can remember, release dates didn&#8217;t mean anything. At least, that&#8217;s how it appeared.<span id="more-11334"></span></p>
<h3>Attitude Change Or Par For The Course?</h3>
<p>When I asked Matt what was the sudden attitude change towards release dates, he responded with: &#8220;<em>Deadlines aren’t arbitrary -<a title=" http://wordpress.org/about/philosophy/" href="http://www.wptavern.com/ http://wordpress.org/about/philosophy/"> http://wordpress.org/about/philosophy/</a></em>&#8220;. Andrew Nacin also chimed in by linking to the same document. I get it. Release dates are <strong>not arbitrary</strong>. But it&#8217;s nice to see WordPress being delivered on whatever dates are being chosen. WordPress 3.7 shipped on time and it looks like they are going to be 2 for 2 with 3.8.</p>
<p>In the past, WordPress would have a project schedule with dates showing the different stages of development, including the final release date. Those schedules came with the caveat that they were not set in stone. From my perspective, it looked like those dates were rarely followed, if ever. Andrew Nacin educated me on the previous versions of WordPress and how close they were (or not) to being on schedule.</p>
<blockquote class="twitter-tweet" width="550"><p><a href="https://twitter.com/jeffr0">@jeffr0</a> <a href="https://twitter.com/sabreuse">@sabreuse</a> 3.0, 3.1, 3.6 slipped ~2 months (not much in the grand scheme). 3.3, 3.4, 3.5, 3.7 didn\'t drag on. Many lessons learned.</p>
<p>&mdash; Andrew Nacin (@nacin) <a href="https://twitter.com/nacin/statuses/399662079655030784">November 10, 2013</a></p></blockquote>
<p></p>
<p>Even if WordPress was late, it wasn&#8217;t the end of the world. We just had to wait a little longer for shiny new features. Thanks to the concurrent development of WordPress 3.7 and 3.8 along with proposed features being developed as plugins first, WordPress 3.8 is already ahead of the game. The old process would have had MP6, DASH, and WordPress 3.8 development start at the same time. Matt Mullenweg <a href="http://www.youtube.com/watch?v=3X1iYm68VdI&feature=share&t=36m10s" title="http://www.youtube.com/watch?v=3X1iYm68VdI&feature=share&t=36m10s">explains the new development process</a> much better than I can.</p>
<h3>Nice To Be On Schedule</h3>
<p>Development schedules are promises that occasionally are broken. We know that release deadlines are not arbitrary. However, watching WordPress actually abide by the schedule set out before development starts is a nice change. Besides, how will we schedule WordPress release parties if we never know when the guest of honor will arrive? </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Nov 2013 19:00:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:31;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WPTavern: WordPress Co-Founder Matt Mullenweg Keynotes Joomla World Conference";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11325";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:92:"http://www.wptavern.com/wordpress-co-founder-matt-mullenweg-keynotes-joomla-world-conference";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:4246:"<p><div id="attachment_11336" class="wp-caption alignright"><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/matt-joomla.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/matt-joomla.jpg?resize=225%2C300" alt="Image Credit: Dianne Henning" class="size-medium wp-image-11336" /></a><p class="wp-caption-text">Image Credit: <a href="https://twitter.com/qbparis/status/399620378001022977" target="_blank">Dianne Henning</a></p></div>This past weekend Matt Mullenweg joined Joomla fans and contributors for the second <a href="http://conference.joomla.org/" target="_blank">Joomla World Conference</a> in Boston, MA. Mullenweg gave the conference&#8217;s closing keynote on Sunday and shared some insights gained along the way on his journey with WordPress.</p>
<p>During his presentation, Matt highlighted the mission of WordPress: <strong>Democratizing publishing by making it easy for anyone to have a beautiful, functional web presence.</strong> But WordPress didn&#8217;t start out with this mission, he said. It started because Matt wanted software for his blog and Mike Little left a comment offering to work with him on a fork of B2. </p>
<p>Over the years, the mission to democratize publishing took shape as the software and community grew. WordPress faced rifts and challenges that ultimately helped to refine its mission and values in support of the <a href="http://www.gnu.org/licenses/quick-guide-gplv3.html" target="_blank">four freedoms</a>. <span id="more-11325"></span></p>
<p>If you want to hear a quick, concise history of WordPress, I recommend that you take a few minutes to watch the recording of Matt&#8217;s keynote at the Joomla World Conference. </p>
<p></p>
<h3>Connection Across Open Source Projects</h3>
<p>Also in attendance was WordPress lead developer Andrew Nacin, who received a warm welcome from the Joomla community.   </p>
<blockquote class="twitter-tweet" width="550"><p>This weekend\'s <a href="https://twitter.com/search?q=%23JWC13&src=hash">#JWC13</a> includes <a href="https://twitter.com/beep">@beep</a> <a href="https://twitter.com/nacin">@nacin</a> <a href="https://twitter.com/webchick">@webchick</a> <a href="https://twitter.com/photomatt">@photomatt</a>. Great to see Joomla giving warm and wide welcomes.</p>
<p>&mdash; Steve Burge (@stevejburge) <a href="https://twitter.com/stevejburge/statuses/399245948419072000">November 9, 2013</a></p></blockquote>
<p></p>
<blockquote class="twitter-tweet" width="550"><p>Fly-on-the-wall at lunch convo b/w a <a href="https://twitter.com/search?q=%23joomla&src=hash">#joomla</a> lead dev <a href="https://twitter.com/mbabker">@mbabker</a> and a <a href="https://twitter.com/search?q=%23wordpress&src=hash">#wordpress</a> lead dev <a href="https://twitter.com/nacin">@nacin</a>. More of this needs to happen in OSS. <a href="https://twitter.com/search?q=%23jwc13&src=hash">#jwc13</a></p>
<p>&mdash; Ryan Ozimek (@cozimek) <a href="https://twitter.com/cozimek/statuses/399241089443708929">November 9, 2013</a></p></blockquote>
<p></p>
<p>Nacin <a href="http://nacin.com/2013/11/09/joomla-world-conference/" target="_blank">blogged</a> prior to the conference:</p>
<blockquote><p>I’m really glad we’re here, as engagement across communities is vital. Too many web communities are isolated, and I suspect there is a lot the WordPress and Joomla communities can learn from one another.</p></blockquote>
<p>Matt&#8217;s appearance at the Joomla World Conference has <a href="https://twitter.com/wordcampmiami/status/399606341456494592" target="_blank">inspired</a> WordCamp Miami organizers to invite Joomla users and developers to come to their event next year to share experiences. </p>
<p>As someone who came from Drupal to WordPress, I love to see this kind of connection across open source projects. Exploring ideas and philosophy with other developers who have a different history can be a valuable experience. This is especially true with open source projects as similar as WordPress and Joomla. We&#8217;re not in competition with one another. Matt&#8217;s keynote address at the Joomla World Conference is a reminder that we&#8217;re all working together to make the web a better place. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 11 Nov 2013 13:45:52 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:32;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"WordPress.tv: Jake Goldman: Interview Cheat Sheet: 10 Questions I Ask Every Developer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24123";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"http://wordpress.tv/2013/11/10/jake-goldman-interview-cheat-sheet-10-questions-i-ask-every-developer/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:724:"<div id="v-GwUZUP5N-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24123/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24123/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24123&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/10/jake-goldman-interview-cheat-sheet-10-questions-i-ask-every-developer/"><img alt="Jake Goldman: Interview Cheat Sheet: 10 Questions I Ask Every Developer" src="http://videos.videopress.com/GwUZUP5N/video-d4e4a98e65_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Nov 2013 16:53:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:33;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:66:"WordPress.tv: Frederick Townes: WordPress Performance Optimization";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24099";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:83:"http://wordpress.tv/2013/11/10/frederick-townes-wordpress-performance-optimization/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:681:"<div id="v-C1aPuMt1-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24099/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24099/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24099&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/10/frederick-townes-wordpress-performance-optimization/"><img alt="Frederick Townes: WordPress Performance Optimization" src="http://videos.videopress.com/C1aPuMt1/video-7106f8c9a0_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Nov 2013 16:21:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:34;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"WordPress.tv: Tony Perez: WordPress Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24089";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:61:"http://wordpress.tv/2013/11/09/tony-perez-wordpress-security/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:643:"<div id="v-aDJ6mRFk-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24089/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24089/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24089&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/09/tony-perez-wordpress-security/"><img alt="Tony Perez: WordPress Security" src="http://videos.videopress.com/aDJ6mRFk/video-a3e0296802_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 09 Nov 2013 17:16:01 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:35;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"WordPress.tv: Panel Discussion: BuddyPress QandA Panel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24125";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.tv/2013/11/09/panel-discussion-buddypress-qanda-panel/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:657:"<div id="v-t4lN8L39-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24125/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24125/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24125&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/09/panel-discussion-buddypress-qanda-panel/"><img alt="Panel Discussion: BuddyPress QandA Panel" src="http://videos.videopress.com/t4lN8L39/video-836bf0bd9f_std.original.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 09 Nov 2013 14:34:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:36;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:95:"WPTavern: WPWeekly Episode 127 – Roundtable With Brad Williams Who Eats API’s For Breakfast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11319";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:102:"http://www.wptavern.com/wpweekly-episode-127-roundtable-with-brad-williams-who-eats-apis-for-breakfast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3621:"<p><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/08/WordPressWeekly_albumart2.jpg?resize=150%2C150" alt="WordPress Weekly Cover Art" class="alignright size-thumbnail wp-image-8715" /></a> In this weeks episode, we were joined by Brad Williams of <a href="http://www.webdevstudios.com" title="http://www.webdevstudios.com">Webdevstudios</a> and <a href="http://www.dradcast.com" title="http://www.dradcast.com">Dradcast</a> to discuss the headlines of the week. We covered a large assortment of news items and received some updates on projects Webdevstudios is working on such as the latest release of <a href="http://wordpress.org/plugins/badgeos/" title="http://wordpress.org/plugins/badgeos/">BadgeOS</a>. Brad is a long time participant of the WordPress Weekly show and it was great to have him back. The last time he was on the show was June 6th, 2010 when he called into the show from WordCamp Chicago. This episode reminded me how much fun it is to be part of a roundtable type of show.<span id="more-11319"></span></p>
<h2>Stories Discussed:</h2>
<p><a href="http://www.wptavern.com/breaking-new-features-selected-to-merge-into-wordpress-3-8-core" title="http://www.wptavern.com/breaking-new-features-selected-to-merge-into-wordpress-3-8-core">Breaking: New Features Selected To Merge Into WordPress 3.8 Core</a><br />
<a href="http://www.wptavern.com/the-future-of-wordpress-widgets-a-better-ui-with-real-time-previews" title="http://www.wptavern.com/the-future-of-wordpress-widgets-a-better-ui-with-real-time-previews">The Future of WordPress Widgets: A Better UI With Real-Time Previews</a><br />
<a href="http://www.wptavern.com/cart66-launches-wordpress-managed-hosting-for-e-commerce" title="http://www.wptavern.com/cart66-launches-wordpress-managed-hosting-for-e-commerce">Cart66 Launches WordPress Managed Hosting for E-Commerce</a><br />
<a href="http://www.wptavern.com/my-approachable-wordpress-story" title="http://www.wptavern.com/my-approachable-wordpress-story">My Approachable WordPress Story</a><br />
<a href="http://www.wptavern.com/should-wordpress-include-a-password-generator" title="http://www.wptavern.com/should-wordpress-include-a-password-generator">Should WordPress Include a Password Generator?</a><br />
<a href="http://www.wptavern.com/buddypress-1-9-to-retire-default-theme-and-add-new-notifications-component" title="http://www.wptavern.com/buddypress-1-9-to-retire-default-theme-and-add-new-notifications-component">BuddyPress 1.9 To Retire Default Theme and Add New Notifications Component</a><br />
<a href="http://www.wptavern.com/gravityforms-1-8-beta-released-introduces-api" title="http://www.wptavern.com/gravityforms-1-8-beta-released-introduces-api">GravityForms 1.8 Beta Released, Introduces API</a></p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Friday, November 15th 3 P.M. Eastern &#8211; Special Guest will be Brian Gardner of StudioPress.com</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href="https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href="http://www.wptavern.com/feed/podcast" target="_blank">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href="http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr" target="_blank">Click here to subscribe</a></p>
<p><strong>Listen To Episode #127:</strong><br />
</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 09 Nov 2013 03:46:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:37;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:67:"WPTavern: Free WordPress Writr Theme Now Available on WordPress.org";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11288";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:81:"http://www.wptavern.com/free-wordpress-writr-theme-now-available-on-wordpress-org";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:3119:"<p>Last week WordPress.com released <a href="http://en.blog.wordpress.com/2013/10/31/writr/" target="_blank">Writr</a>, a beautiful free theme that really puts your content in the spotlight. The tumblelog style is perfect for power bloggers who like to utilize <a href="http://en.support.wordpress.com/posts/post-formats/" target="_blank">post formats</a> for different types of content. </p>
<p>The good news this week is that Writr is now available for self-hosted WordPress sites via its new page on <a href="http://wordpress.org/themes/writr" target="_blank">WordPress.org</a>. You can install it directly through your dashboard and take advantage of the same features the theme offers on WordPress.com.</p>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/writr.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/writr.jpg?resize=560%2C420" alt="writr" class="aligncenter size-full wp-image-11292" /></a><span id="more-11288"></span></p>
<p>Writr is responsive and looks absolutely stunning on any device. On smaller devices the sidebar is either displayed or hidden via a neatly tucked corner toggle. Instead of stacking the sidebar content below the list of posts, it&#8217;s always at your fingertips with one click. <a href="http://writrdemo.wordpress.com/" target="_blank">Test the demo</a> by resizing your browser window to see how nicely it works.</p>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/responsive.png" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/responsive.png?resize=560%2C204" alt="responsive" class="aligncenter size-full wp-image-11297" /></a></p>
<h3>Theme Options for Customizing Writr</h3>
<p>Writr comes with unique icons for each post type as well as 6 different color schemes: turquoise (default), blue, green, grey, purple, and red. It also has support for a custom header image, background, menu and social icons.</p>
<p>One of my favorite features of the Writr theme is the optional wider content area. It can be easily increased by visiting the customizer and ticking the “Wider Content Area” checkbox &#8211; no CSS edits necessary!</p>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/writr_wider_content_area.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/writr_wider_content_area.jpg?resize=560%2C293" alt="writr_wider_content_area" class="aligncenter size-full wp-image-11307" /></a></p>
<p>Since Writr was originally built for use on WordPress.com and has passed the <a href="http://codex.wordpress.org/Theme_Review" target="_blank">rigorous theme standards</a> of WordPress.org, you know that it&#8217;s a high quality theme. An added benefit here is that it&#8217;s supported by professional developers so you&#8217;ll be good to go for future updates.</p>
<p>Does <a href="http://wordpress.org/themes/writr" target="_blank">Writr</a> have you thinking about changing the theme on your blog? Install it from WordPress.org and check it out in live preview mode.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 23:33:49 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:38;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:79:"WPTavern: CoSchedule – A Viable Alternative To The Edit Flow WordPress Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11218";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:89:"http://www.wptavern.com/coschedule-a-viable-alternative-to-the-edit-flow-wordpress-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:11402:"<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleLogo.jpg" rel="thumbnail"><img class="alignright size-full wp-image-11248" alt="CoSchedule Logo" src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleLogo.jpg?resize=273%2C80" /></a>I&#8217;m a huge fan of the <a title="http://wordpress.org/plugins/edit-flow/" href="http://wordpress.org/plugins/edit-flow/">Edit Flow plugin</a>, especially since this site started publishing articles from multiple authors. It has all sorts of cool features such as custom post statuses, notifications, and editorial comments within posts. Unfortunately, Edit Flow is broken in a few places. I&#8217;ve been in touch with at least a few people who told me they switched to a different plugin because of the issues they encountered with Edit Flow. Thankfully, those items are being addressed and a fix should be released soon. In the mean time, I discovered a paid alternative to Edit Flow that looks to be just as good if not better than Edit Flow called <a title="http://coschedule.com/" href="http://coschedule.com/">CoSchedule</a>. <span id="more-11218"></span></p>
<div class="aligncenter">
<p><span class="embed-youtube"></span></p>
</div>
<h3>CoSchedule In a Nutshell</h3>
<p>CoSchedule is a service created by <a title="http://profiles.wordpress.org/todaymade/" href="http://profiles.wordpress.org/todaymade/">Garret Moon</a> of <a title="http://todaymade.com/" href="http://todaymade.com/">Todaymade</a> that is accessible in WordPress via a plugin. It provides an editorial workflow complete with a calendar to help keep track of activity across the site. It&#8217;s $10.00 per month per WordPress site. The plan includes:</p>
<ul>
<li>Unlimited Users</li>
<li>Unlimited Social Accounts</li>
<li>No hidden fees</li>
<li>Free support</li>
<li>The option of cancelling your account at any time, no credit card required.</li>
</ul>
<p>New users have 14 days to try out the service.</p>
<h3>Installing And Configuring CoSchedule</h3>
<p>Installing and configuring CoSchedule was a breeze thanks in large part to a video explanation and the excellent use of pointers introduced in <a href="http://wordpress.org/news/2011/12/sonny/" title="http://wordpress.org/news/2011/12/sonny/">WordPress 3.3</a>. It&#8217;s the first time those tips came in handy. They also disappeared once I went through the process once. When setting up for the first time, make certain you select the appropriate time zone. If you don&#8217;t, it will throw off the entire system. </p>
<h3>Controlling Social Media And Content From One Interface</h3>
<p>Not only can writers create and manage posts through CoSchedule, they can also manager their social media presence by connecting their accounts similar to the way <a title="http://jetpack.me/support/publicize/" href="http://jetpack.me/support/publicize/">Publicize works in Jetpack</a>. Unlike Jetpack, you can control when the social media message is broadcasted. Being able to control when and how your social media messages are displayed along with content is a great combination.</p>
<div id="attachment_11250" class="wp-caption aligncenter"><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleSocialMediaPost.jpg" rel="thumbnail"><img class="size-large wp-image-11250" alt="Creating A Social Media Post" src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleSocialMediaPost.jpg?resize=500%2C357" /></a><p class="wp-caption-text">Creating A Social Media Post</p></div>
<p>As you can see from the following screenshot, social media posts show up in the calendar alongside blog posts. Changing when these events occur is as simple as clicking and dragging the post from one day to the next. </p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleTwitterPost.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleTwitterPost.jpg?resize=441%2C267" alt="CoScheduleTwitterPost" class="aligncenter size-full wp-image-11251" /></a></p>
<h3>Light Grey On White Is Not A Good Combination</h3>
<p>One thing I didn&#8217;t like is the lack of bold colors for the fonts used throughout the interface. The light grey colored fonts used on top of a white background were hard to see. Even though CoSchedule ships with multiple color schemes, none of them improved the situation. In fact, some of the color schemes made the problem worse. Take this screenshot for example. I&#8217;m hoping the next version of CoSchedule experiments with bolder colors.</p>
<div id="attachment_11252" class="wp-caption aligncenter"><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleInterfaceColors.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleInterfaceColors.jpg?resize=500%2C223" alt="CoSchedule Interface Colors" class="size-large wp-image-11252" /></a><p class="wp-caption-text">Hard To Read Light Grey Text</p></div>
<h3>Not Native To WordPress But It Works</h3>
<p>The interface for managing posts whether it be the calendar view or when writing/editing a blog post is not the native WordPress interface. But it&#8217;s not a drastic departure either. In fact, I like it and it works well. </p>
<h3>The Manager With Many Hats</h3>
<p>Just like Edit Flow, CoSchedule gives you the ability to create users and assign them specific roles. This is known as the team. The owner of the site has the power to create new users and assign them roles. One improvement that could be made here is when typing in a users name, CoSchedule looks at the WordPress users and auto suggests a match. That way, it just adds them to the team members list. I love how there is a clear explanation of what each role allows on the bottom of the Team Members page. </p>
<div id="attachment_11253" class="wp-caption aligncenter"><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleUsers.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleUsers.jpg?resize=500%2C302" alt="Creating CoSchedule Users" class="size-large wp-image-11253" /></a><p class="wp-caption-text">Controlling CoSchedule Users</p></div>
<p>CoSchedule has integration support for Bitly, Google Analytics, and Google Calendar. </p>
<h3>My Favorite Feature Of CoSchedule</h3>
<p>Just like Edit Flow, my favorite feature in CoSchedule is the ability to provide editorial comments attached to a post. This has proved to be an invaluable feature that makes collaboration easy. Besides being able to write comments, depending on your user role, you can assign tasks to that writer. For each task that is completed, the task creator will receive a notification that it&#8217;s been completed. You can also follow posts. Following a post means you&#8217;ll receive notifications for any activity that occurs on that post. </p>
<div id="attachment_11255" class="wp-caption aligncenter"><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleCommentsAndTasks.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoScheduleCommentsAndTasks.jpg?resize=362%2C412" alt="Adding Comments Or Tasks" class="size-full wp-image-11255" /></a><p class="wp-caption-text">Adding Comments Or Tasks</p></div>
<h3>Interview With Founder Garret Moon</h3>
<p><strong>How much functionality of CoSchedule is in the actual plugin versus the website?</strong><br />
<em>CoSchedule relies completely on WordPress core for post scheduling and publishing. Posts on the calendar are simply synced with your WordPress install, not moved. Social messages are handled a bit differently, and sent remotely from the CoSchedule servers. </p>
<p>CoSchedule is a web application that integrates deeply with WordPress through the use of the CoSchedule plugin. We aren&#8217;t 100% embedded into your WordPress install for all purposes, but this is by design. This combination provides the best possible user experience and reliability. Our goal is to allow WordPress to do what it does best, and our own service to add as much value as it possibly can. </em></p>
<p><strong>What happens if CoSchedule stops working or the website disappears? Will data be lost?</strong><br />
<em>Post data is never moved to our servers and remains on your local install. Post data loss is not a possibility with CoSchedule. Scheduled social messages are stored on our servers, but data loss is still very unlikely. We maintain redundant databases at all times and complete hourly backups of user data. Our data is secured with some of the largest data providers in the world.</em></p>
<p><strong>Was Edit Flow an inspiration when creating CoSchedule?</strong><br />
<em>Not really. We created CoSchedule because we wanted a robust tool for scheduling social media messages and blog posts on the same calendar, and in a team environment. We also believe in WordPress as a publishing platform, so we felt that the best way to accomplish this was through a custom application that worked in-hand with WordPress.</em></p>
<p><strong>How did you arrive at the $10 per month price point?</strong></p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoSchedulePricing.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/CoSchedulePricing.jpg?resize=500%2C245" alt="CoSchedule Pricing" class="aligncenter size-large wp-image-11284" /></a></p>
<p><em>We talked to our users a lot about this, and ultimately decided on something that would make CoSchedule available to as many people as possible, while providing the income necessary to maintain the highest quality service possible. So far, the response had been good since the $10/month price point is still very affordable for most bloggers.</em></p>
<p><strong>What are some of the features you have in the works for the next iteration of CoSchedule?</strong><br />
<em>We have a lot of improvements to our social scheduling in the works. We recently added Buffer and Google+ Pages integration, which was a huge win. Up next, are core enhancements to the messages that are created –specifically how they look when they are published to social networks. We also have some exciting features in the works that will make social scheduling easier and more automated.  </p>
<p>Since we began building CoSchedule we have been very responsive to feedback, and in-tune with what our users want us to build. While we have many plans for CoSchedule, we are always looking for feedback from the community on how they want to see it grow. </em></p>
<h3>Conclusion</h3>
<p>CoSchedule is a great service. The application inside of WordPress was responsive without any noticeable lag. If it were not for the price tag, I could see myself ditching Edit Flow in favor of this. But at $10.00 a month, it&#8217;s very affordable. Sites running WordPress that have multiple authors need something like CoSchedule in place to make sense of all the chaos. I discovered a few minor styling issues while testing but I&#8217;ve already let the developers know and they are in the process of fixing them. Don&#8217;t take my word for it. Give <a href="http://coschedule.com/" title="http://coschedule.com/">CoSchedule</a> a try for 14 days and arrive at your own conclusion. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 22:00:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:39;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WordPress.tv: Mike Van Winkle: Adding Source Control To Your Code";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24129";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:82:"http://wordpress.tv/2013/11/08/mike-van-winkle-adding-source-control-to-your-code/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:685:"<div id="v-RXMnfkEq-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24129/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24129/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24129&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/08/mike-van-winkle-adding-source-control-to-your-code/"><img alt="Mike Van Winkle: Adding Source Control To Your Code" src="http://videos.videopress.com/RXMnfkEq/video-1d24340b87_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 20:19:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:40;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:84:"WPTavern: VIP Quickstart: A Local Development Environment That Mirrors WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11259";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:97:"http://www.wptavern.com/vip-quickstart-a-local-development-environment-that-mirrors-wordpress-com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2920:"<p>The <a href="http://vip.wordpress.com/" target="_blank">WordPress.com VIP</a> development team maintains some of the largest WordPress installations on the web, including Time, NBC Sports, TechCrunch, CNN and many others. Creating a proper development environment is crucial to serving clients who use WordPress on such a large scale, but it&#8217;s not very easy to set up. That&#8217;s why the VIP development team decided to put together an environment that closely mirrors what they would be deploying to on WordPress.com.</p>
<p><a href="http://vip.wordpress.com/2013/10/07/vip-quickstart/" target="_blank">VIP Quickstart</a> makes setting up a development environment a quick and easy process. The really awesome thing is that this is open source software, now available on <a href="https://github.com/Automattic/vip-quickstart" target="_blank">github</a> for anyone to use. VIP Quickstart includes all the features and scalability that WordPress.com uses to power millions of blogs.<span id="more-11259"></span></p>
<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/code.png" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/code.png?resize=560%2C310" alt="code" class="aligncenter size-full wp-image-11262" /></a></p>
<p>The package is made up of a mix of Vagrant, Puppet, Bash scripts, and some PHP code to create the WordPress.com development environment, plus it also includes all the extra tools recommended for developers:</p>
<ul>
<li>Ubuntu 12.04</li>
<li>WordPress trunk</li>
<li>WordPress.com VIP Shared Plugins repository</li>
<li>WordPress multisite</li>
<li>WordPress Developer Plugin and all VIP recommended plugins</li>
<li>Custom WordPress.com modifications</li>
<li>WP-CLI</li>
<li>MySQL</li>
<li>PHP</li>
<li>Nginx</li>
</ul>
<p>This package creates a WordPress multisite installation from the latest trunk build. VIP Quickstart will be maintained on github but you can always get the latest by running the VIP init script included in the package. Developers familiar with <a href="http://docs.vagrantup.com/v2/cli/index.html" target="_blank">Vagrant</a> can use those commands as well.</p>
<p>New WordPress development tools will be added, along with more VIP specific tools. Recently, the team added a Windows installer and support for PHPMyAdmin, which you can find if you navigate to: <a href="http://vip.dev/phpmyadmin" target="_blank">http://vip.dev/phpmyadmin</a>. </p>
<p>If you want to quickly create an enterprise class development environment or simply check out the technology that powers WordPress.com, have a look at <a href="https://github.com/Automattic/vip-quickstart" target="_blank">VIP Quickstart</a>. If you need help setting up your development environment, please refer to the <a href="http://vip.wordpress.com/documentation/development-environment/" target="_blank">documentation</a> on the VIP website.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 19:06:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:41;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Matt: The Way We Age Now";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ma.tt/?p=43166";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://ma.tt/2013/11/the-way-we-age-now/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:963:"<blockquote><p>As engineers have long recognized, many simple devices do not age. They function reliably until a critical component fails, and the whole thing dies instantly. A windup toy works smoothly until a gear rusts or a spring breaks, and then it doesn’t work at all. But complex systems—power plants, say—have to survive and function despite having thousands of critical components. Engineers therefore design these machines with multiple layers of redundancy: with backup systems, and backup systems for the backup systems. The backups may not be as efficient as the first-line components, but they allow the machine to keep going even as damage accumulates. Gavrilov argues that, within the parameters established by our genes, that’s exactly how human beings appear to work.</p></blockquote>
<p>An oldie but a goodie from the New Yorker: <a href="http://www.newyorker.com/reporting/2007/04/30/070430fa_fact_gawande">The Way We Age Now</a>.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 15:50:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:42;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:114:"WordPress.tv: John James Jacoby: Everything And Anything You’ve Ever Wanted To Know About BuddyPress And bbPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24121";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:128:"http://wordpress.tv/2013/11/08/john-james-jacoby-everything-and-anything-youve-ever-wanted-to-know-about-buddypress-and-bbpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:784:"<div id="v-gkFwlr1T-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24121/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24121/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24121&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/08/john-james-jacoby-everything-and-anything-youve-ever-wanted-to-know-about-buddypress-and-bbpress/"><img alt="John James Jacoby: Everything And Anything You&#8217;ve Ever Wanted To Know About BuddyPress And bbPress" src="http://videos.videopress.com/gkFwlr1T/video-328f955c02_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 14:07:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:43;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"WPTavern: How WordPress 3.7 Affects the Hotfix Plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11227";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://www.wptavern.com/how-wordpress-3-7-affects-the-hotfix-plugin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2518:"<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/hotfix.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/hotfix.jpg?resize=560%2C181" alt="hotfix" class="aligncenter size-full wp-image-11235" /></a></p>
<p>For the past two years or so, <a href="http://wordpress.org/plugins/hotfix/" target="_blank">Hotfix</a> has been one of those essential WordPress plugins that many users have added immediately upon installation. This plugin was <a href="http://make.wordpress.org/core/2011/02/08/hotfix/" target="_blank"> created by Mark Jaquith in early 2011</a> to provide early, automatic fixes for WordPress based on the version you’re using. He created it during a time when WordPress was cranking out a bunch of point-point releases in a short period of time. Update fatigue was becoming a problem.<span id="more-11227"></span></p>
<p>The Hotfix plugin was meant to address bugs not severe enough or common enough to warrant a separate release. At that time, performing WordPress updates on a large number of sites was very time-consuming and annoying. The Hotfix plugin provided a convenient solution that was far superior to packing hot fixes into an Akismet <a href="http://make.wordpress.org/core/2011/02/08/via-the-akismet-blog-akismet-2-5-3-has/" target="_blank">update</a>.</p>
<h3>Is the Hotfix Plugin Unnecessary With WordPress 3.7?</h3>
<p>Now that WordPress 3.7 has arrived with automatic background capabilities, where does Hotfix fit in? It seems to be much less useful for sites with automatic updates enabled. I checked with Andrew Nacin, who is one of the contributors to Hotfix, to see if this plugin would be fading away. He said that only time will tell. &#8220;But it&#8217;s less useful, not due to background updates directly, but because they eliminated update fatigue, making us inclined to quickly release.&#8221;</p>
<p>I asked him if they will continue to selectively push hot fixes through the plugin. He confirmed that they might if they need to. While it appears that it hasn&#8217;t been updated in nearly a year, Nacin says that &#8220;there wasn&#8217;t anything in 3.6 or 3.7 that A) could have been fixed using it and B) only affected a small number of people.&#8221; So if any of you have the Hotfix plugin in place, don&#8217;t rule this one out just yet. There&#8217;s no reason to go out of your way to deactivate it, as it may be used again in the future to push out hot fixes for installations that need them.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 14:01:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:44;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:61:"WordPress.tv: Shane Pearlman: Managing Distributed Code Teams";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24117";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://wordpress.tv/2013/11/07/shane-pearlman-managing-distributed-code-teams/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:677:"<div id="v-yXhk7xBN-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24117/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24117/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24117&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/07/shane-pearlman-managing-distributed-code-teams/"><img alt="Shane Pearlman: Managing Distributed Code Teams" src="http://videos.videopress.com/yXhk7xBN/video-12047b0c38_scruberthumbnail_0.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 02:51:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:45;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:76:"WPTavern: WP Sessions Offers Free Video Series on Building WordPress Plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11190";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:90:"http://www.wptavern.com/wp-sessions-offers-free-video-series-on-building-wordpress-plugins";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2838:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/wpsessions1.jpg" rel="thumbnail"><img src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/wpsessions1.jpg?resize=300%2C375" alt="wpsessions" class="alignright size-full wp-image-11210" /></a>Want to learn the basics of creating a WordPress plugin? If you&#8217;re a visual/audio learner, check out the free <a href="http://wpsessions.com/sessions/building-wordpress-plugins/" target="_blank">Building WordPress Plugins</a> video series from <a href="http://wpsessions.com/" target="_blank">WP Sessions</a>. </p>
<p>Inspired by the WordCamp style presentations of the <a href="http://www.wptavern.com/wordsesh-2013-live-streaming-24-hours-of-free-wordpress-education" target="_blank">24hr WordSesh event</a>, Brian Richards wanted to create a site to bring WordPress educational resources to people at home. The format of WP Sessions encourages users to watch live and ask questions. WP Sessions has several <a href="http://wpsessions.com/sessions/" target="_blank">video series</a> available with high quality speakers, but the plugin building series is the first that&#8217;s being offered for free.  <span id="more-11190"></span></p>
<p>The Building WordPress Plugins series features Pippin Williamson, Daniel Espinoza and Topher DeRosia, all of whom are highly experienced plugin developers. The series starts with beginner/introductory topics and ranges all the way to more advanced topics, such as data validation and sanitization.</p>
<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/these-guys-build-plugins.jpg" rel="thumbnail"><img src="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/these-guys-build-plugins.jpg?resize=466%2C152" alt="these-guys-build-plugins" class="aligncenter size-full wp-image-11202" /></a></p>
<p>These three professional developers will help you to understand basic plugin architecture. You&#8217;ll also learn about using hooks and filters, registering admin menu items, releasing your plugin on WordPress.org and much more. If you&#8217;re planning on adding plugin development to your list of WordPress skills, make sure to bookmark this free video series to get you started.</p>
<p>Next up on the WP Sessions schedule is a series on <a href="http://wpsessions.com/sessions/wordpress-unit-testing/" target="_blank">WordPress Unit Testing</a>, offered November 30, 2013, featuring Alison Barrett, John P. Bloch and K. Adam White. This might be a great followup session after you learn how to build plugins. The cost is $20 for early registration. Session prices offset the costs of running the site and compensating instructors for the first few months they are offered. As more sessions are added, all previous sessions will be made available for free on a rolling basis. </p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 23:19:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:46;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WPTavern: GravityForms 1.8 Beta Released, Introduces API";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11173";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"http://www.wptavern.com/gravityforms-1-8-beta-released-introduces-api";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6698:"<p><a href="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2009/08/gravitylogo.png" rel="thumbnail"><img class="alignright size-full wp-image-2322" alt="gravityforms logo" src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2009/08/gravitylogo.png?resize=108%2C109" /></a>Rocketgenius, the team behind GravityForms <a title="http://www.gravityhelp.com/gravity-forms-v1-8-beta-1-released/" href="http://www.gravityhelp.com/gravity-forms-v1-8-beta-1-released/">has announced</a> the release of GravitfyForms 1.8 Beta 1. This is a big release as 1.8 contains a number of features such as:</p>
<ul>
<li>Support for the Heartbeat API</li>
<li>Integration with the Trash component of WordPress</li>
<li>Multi-file uploading</li>
<li>Form scheduling</li>
<li>Form Sorting</li>
<li>WordPress Multisite (Gravity Forms now supports being installed within the MU-PLUGINS folder on WordPress Multisite installations.)</li>
</ul>
<p>Developers are going to love this release since it contains a <a title="http://www.gravityhelp.com/documentation/page/Gravity_Forms_API" href="http://www.gravityhelp.com/documentation/page/Gravity_Forms_API">complete API</a> that allows developers to interact with a specific Gravity Forms install to add, update, delete and return Gravity Forms data. This new version also contains user interface refinements such as standardizing on the use of web fonts. <span id="more-11173"></span></p>
<p>One of the things I like most about GravityForms is that they&#8217;ve stayed true to the look and feel of WordPress. Even with their UI refinements, it still looks and functions as if it were part of WordPress all along. I got in touch with Carl Hancock, one of the lead developers of GravityForms and asked him two questions.</p>
<p><strong>How important has it been to develop GravityForms so it looks and functions as if it were part of WordPress all along?</strong></p>
<div id="attachment_11200" class="wp-caption aligncenter"><a href="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/gravity-forms-18-ui-enhancements.png" rel="thumbnail"><img class="size-large wp-image-11200" alt="GravityForms UI Refinements In 1.8" src="http://i0.wp.com/www.wptavern.com/wp-content/uploads/2013/11/gravity-forms-18-ui-enhancements-500x311.png?resize=500%2C311" /></a><p class="wp-caption-text">GravityForms UI Refinements In 1.8</p></div>
<p><em>Very important. But not at the expense of what we are trying to accomplish. We try to use WordPress UI styling where we can. Where we can’t, we try to make it look like it was. There’s some interfaces we need that WordPress simply doesn’t have an example to utilize. Then there are other UI’s that we could use, but frankly they aren’t ideal.</p>
<p>A good example of a WordPress UI that we don’t use is the horizontal tabs. They simply don’t scale. Not scale as in responsive, but scale as in number of tabs. For the sub-navigation we use in various areas that require it we re purposed the look and feel of the WordPress Help that appears when you click on the “Help” link in the top right of various WordPress pages that have help. You’ll see that it has vertical sub-navigation. That scales. So we went with it.</p>
<p>I’m sure we’ll encounter more situations where there simply isn’t a WordPress UI convention that we can leverage. But we’ll tackle them as we encounter them to make sure that what we do, still looks good within the WordPress admin. We don’t want to create a product that looks completely out of place within the WordPress admin. We prefer consistency.<br />
</em><br />
<strong>Everyone is excited about the API introduced with GravityForms 1.8 Beta 1. What types of opportunities open up thanks to this API?</strong></p>
<p><em>Endless opportunities. That really is the truth.</p>
<p>The API within Gravity Forms v1.8 has two parts which can be used by developers depending on what they are trying to accomplish. One piece is a set of API Functions within a Gravity Forms class that can be used to interact with Gravity Forms from within the same WordPress install. So they can be used within a theme, plugin or custom code to interact with Gravity Forms data.</p>
<p>The second piece is the traditional Web API which is designed for interaction between your WordPress install and a 3rd party server. Although it could still also be accessed via code that resides on the same WordPress install if the site developer wanted to do so.</p>
<p>Prior to the API there was no standard way to easily add, update, get or delete Gravity Forms related data such as Forms and Entries outside of the Gravity Forms interface itself. It could be done. But it wasn’t simple. You could certainly query the data directly, but you’d need to know the data structure and how everything works to do it properly.</p>
<p>One example of how the Web API will be used is the Zapier Add-On. Zapier is a web service that allows you to integrate with almost 250 different other web services (<a title="https://zapier.com/zapbook/" href="https://zapier.com/zapbook/">https://zapier.com/zapbook/</a>). This allows you to integrate Gravity Forms with almost 250 different web services, which means a lot of services we don’t currently have native Add-Ons for. Currently the Zapier Add-On process isn’t very user friendly due to the way Zapier works. With the new Web API, it’s going to be extremely simple and most of the work will occur via Zapier’s admin instead of within Gravity Forms once your form exists. Within Zapier you’ll enter the URL of your site and your API keys and Zapier will then be able to get a list of all your forms via the Web API and from there you can setup your “Zaps” to integrate with any of the almost 250 web services they allow you to integrate with.</p>
<p>One example of opportunities that the new API functions open up is more power for 3rd party developers. Combined with the <a title="http://www.gravityhelp.com/documentation/page/Add-On_Framework" href="http://www.gravityhelp.com/documentation/page/Add-On_Framework">Add-On Framework</a> developers will be able to create Add-Ons and integration with Gravity Forms much easier than they could previously. There are already a LOT of 3rd party Add-Ons in the wild for Gravity Forms and these new developer features are going to be huge for their future growth.</p>
<p>They will also be huge for our future growth. For example our Web API could be used to allow something like say… a mobile app… to access and manage your Gravity Forms data.</p>
<p>We’re very excited about what both the Add-On Framework and the API means for the future of Gravity Forms. We’ve only just begun.</em></p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 22:45:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:6:"Jeffro";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:47;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"WordPress.tv: Aaron Holbrook: WordPress Is A CMS Dammit!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:28:"http://wordpress.tv/?p=24119";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"http://wordpress.tv/2013/11/07/aaron-holbrook-wordpress-is-a-cms-dammit/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:666:"<div id="v-8LI2gxhr-1" class="video-player">
</div><br />  <a rel="nofollow" href="http://feeds.wordpress.com/1.0/gocomments/wptv.wordpress.com/24119/"><img alt="" border="0" src="http://feeds.wordpress.com/1.0/comments/wptv.wordpress.com/24119/" /></a> <img alt="" border="0" src="http://stats.wordpress.com/b.gif?host=wordpress.tv&blog=5089392&post=24119&subd=wptv&ref=&feed=1" width="1" height="1" /><div><a href="http://wordpress.tv/2013/11/07/aaron-holbrook-wordpress-is-a-cms-dammit/"><img alt="Aaron Holbrook: WordPress Is A CMS Dammit!" src="http://videos.videopress.com/8LI2gxhr/video-22c506f23a_scruberthumbnail_1.jpg" width="160" height="120" /></a></div>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 20:12:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"WordPress.tv";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:48;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:93:"WPTavern: Behind The Scenes With Dogshaming.com: Helping People Humiliate Pets With WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"http://www.wptavern.com/?p=11164";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:106:"http://www.wptavern.com/behind-the-scenes-with-dogshaming-com-helping-people-humiliate-pets-with-wordpress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:6577:"<p><a href="http://i1.wp.com/www.wptavern.com/wp-content/uploads/2013/11/dogshaming.jpg" rel="thumbnail"><img src="http://i2.wp.com/www.wptavern.com/wp-content/uploads/2013/11/dogshaming.jpg?resize=360%2C365" alt="dogshaming" class="alignright size-full wp-image-11166" /></a>Some dogs are just plain naughty. Mine is 100% mischief so naturally I&#8217;m a pretty big fan of <a href="http://www.dogshaming.com/" target="_blank">Dogshaming.com</a>. I was thrilled to find out that this popular site is running on WordPress. </p>
<p>Inspired by her own naughty pup who chews holes in underwear for kicks, Pascale Lemire originated the online trend of &#8220;dog shaming.&#8221; The idea went viral and soon dog owners around the world were posting pictures of their wicked canines with homemade signs to illustrate their crimes. </p>
<p>Lemire now had a unique idea for a website. She got in touch with her husband&#8217;s friend, <a href="http://townhall.ca/" target="_blank">Jairus Pryor</a>, who happens to be a WordPress developer. Together they built Dogshaming.com to offer dog owners a place to publicly shame their dogs.<span id="more-11164"></span></p>
<h3>WordPress + DogShaming: Optimizing for Performance</h3>
<p>I asked Pryor if he builds with other platforms and why he selected WordPress for Dogshaming.com. He answered that for him it comes down to the community surrounding the project. <strong>&#8220;I work mostly with WordPress. I find the developer community to be second-to-none.&#8221;</strong>  </p>
<p>While building the site, he had no idea that it would become so popular. &#8220;I don&#8217;t think anyone could have anticipated just how much the site has resonated with people! Just the other week I saw Annie Lennox post a photo of the Dogshaming book to her Facebook page. It&#8217;s completely amazing.&#8221; Due to the heavy traffic the site receives, Pryor needed to have a performance plan in place to support the site&#8217;s heavy traffic load. Dogshaming.com regularly posts images that can easily go viral and take the server down if not properly optimized. After some experimentation, he settled on <a href="http://wordpress.org/plugins/wp-super-cache/" target="_blank">WP Super Cache</a> and <a href="http://jetpack.me/support/photon/" target="_blank">Jetpack&#8217;s Photon CDN</a>:</p>
<blockquote><p>We&#8217;re using WP Super Cache along with XCache on the server end and Jetpack&#8217;s Photon CDN on the front end. We tried a number of different solutions (including W3TC and Cloudflare), but this combination ended up being the most stable.</p></blockquote>
<p>In addition to keeping up with traffic, Pryor also keeps track of the site&#8217;s maintenance requirements.  &#8220;There&#8217;s a fair amount of maintenance involved. With high-profile sites you&#8217;re always discovering a new bug or trying to roll out a new feature, so there&#8217;s usually something you want to keep an eye on.&#8221; </p>
<h3>The Dogshaming Custom WordPress Theme</h3>
<p>I did a little snooping into the theme and found that Dogshaming.com makes use of the increasingly popular <a href="http://www.wptavern.com/10-free-wordpress-themes-based-on-the-foundation-framework" target="_blank">Foundation framework</a>. Pryor explained why he selected Foundation as the backbone of his custom theme:</p>
<blockquote><p>The Dogshaming site is built on a custom theme, using the Foundation framework as a basis for the presentation layer, and the Bones Theme as a basis for the theme itself. I generally use either <a href="http://underscores.me/" target="_blank">Underscores</a> or <a href="http://themble.com/bones/" target="_blank">Bones</a>, depending on the project. I love how easy <a href="http://foundation.zurb.com/" target="_blank">Foundation</a> is to work with if you&#8217;re into SASS, and Bones comes with SASS out of the box, which is really what sets it apart from Underscores.</p></blockquote>
<p>If you view Dogshaming.com on a mobile device, you&#8217;ll see that it responds nicely due to the combination of Foundation and Bones. The theme&#8217;s framework was a crucial part of helping the site gain more mobile traffic. </p>
<h3>Plugins Behind Dogshaming.com</h3>
<p>Dogshaming.com makes use of a small collection of plugins to power the site. Content is generated by regular submissions to the site. Pryor opted for a simple implementation of <a href="http://www.gravityforms.com/" target="_blank">Gravity Forms</a>. &#8220;We use Gravity Forms for the &#8216;<a href="http://www.dogshaming.com/submit-dog/" target="_blank">Submit a Dog</a>&#8216; section, pretty much out of the box,&#8221; he said. &#8220;Each submission is a new post, which makes the workflow to publish approved submissions simple.&#8221; The Dog Shaming Generator is actually a standalone app, created as part of the book launch and isn&#8217;t actually run by WordPress.</p>
<p>I asked Pryor to highlight some of the plugins that are necessary for running the site. They&#8217;re keeping it fairly lean: </p>
<blockquote><p>Akismet, Gravity Forms, Jetpack and Super Cache. The site lives and breathes by those four plugins. Nothing beyond that, we wanted to keep it as light as possible.</p></blockquote>
<p>I&#8217;m always amazed to see how quickly someone can build a kickass, performance-optimized website using plugins that are already available. No custom plugin development was required for this project. </p>
<p>If you visited the site on April Fool&#8217;s Day, you may have gotten to see Pryor&#8217;s sneaky dev prank:</p>
<blockquote><p> The owners of the site are obviously big on dogs, but I&#8217;m actually a cat person. On April Fools Day I dropped in a piece of Javascript that changed all of the dogs on the site to images of kittens from <a href="http://placekitten.com/" target="_blank">placekitten.com</a>, which I thought was hilarious. Turns out that some people who come looking for dogs get very upset when they see kittens instead! How can you be upset with so many kittens looking at you? It doesn&#8217;t even make sense.</p></blockquote>
<p>Pryor said that the Dogshaming site has been a great addition to his portfolio. These days he&#8217;s working with his partner through their company <a href="http://townhall.ca/" target="_blank">Townhall Communications</a>. While in discussions with a potential client who asked for portfolio examples, Pryor sent over a list of high-profile projects. The client sent back a one-line reply: &#8220;I&#8217;m sorry: I didn&#8217;t read anything after Dogshaming. BIG FAN!&#8221;</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 20:11:02 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Sarah Gooding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:49;a:6:{s:4:"data";s:13:"
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"BuddyPress: BuddyPress Theme Development by Tammie Lister";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:31:"http://buddypress.org/?p=173605";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://buddypress.org/2013/11/buddypress-theme-development-by-tammie-lister/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:2105:"<p>I&#8217;m pleased to announce the release of my book &#8216;<a href="http://www.packtpub.com/buddypress-theme-development/book">BuddyPress Theme Development</a>&#8216; published by Packt. This book serves as a guide (with practical tutorials) on how to make the most out of BuddyPress with custom templates and styles. It gives insight into the current state of BuddyPress theme creation and gently leads readers through creating one of their own.</p>
<p><img class="aligncenter size-full wp-image-173611" alt="webimage" src="http://buddypress.org/wp-content/uploads/1/2013/10/webimage.png" width="600" height="430" /></p>
<p>This book has a very BuddyPress origin story, with it&#8217;s beginning coming during BuddyCamp Miami in March of 2013 (the chapters and structure were worked out while I was there) and it was a pleasure to have the one and only <a href="http://profiles.wordpress.org/DJPaul">Paul Gibbs</a> perform the technical review.</p>
<p>My publisher allowed me to include the entire theme process from sketch and wireframe through to code, and I included coverage of some general theme topics like responsive design, theme checks, and testing. Far too often, we forget how important the planning and feature-complete stages of a theme are, and this book tries to address both. All this content, crammed into 130 pages &#8211; a feat of editing.</p>
<p>When I started writing BuddyPress Theme Development, I had 4 goals (along with providing a good resource for creating themes):</p>
<ol>
<li>Blow away the myth that creating BuddyPress themes is hard.</li>
<li>Encourage readers to tailor their experience, choosing which components are critical to their success.</li>
<li>Raise the quality of BuddyPress themes and highlight good theme practices.</li>
<li>Encourage people to get involved with the BuddyPress project.</li>
</ol>
<p>You can get the book <a href="http://www.packtpub.com/buddypress-theme-development/book">through Packt Publishing</a>, or through Amazon. It&#8217;s available in soft-cover and eBook, and comes with code samples to follow along with the tutorials.</p>";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 07 Nov 2013 17:03:54 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"karmatosed";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 16 Nov 2013 11:54:30 GMT";s:12:"content-type";s:8:"text/xml";s:14:"content-length";s:6:"165233";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Sat, 16 Nov 2013 11:45:13 GMT";s:4:"x-nc";s:11:"HIT lax 249";s:13:"accept-ranges";s:5:"bytes";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (243, 'hmbkp_schedule_default-1', 'a:3:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (244, 'hmbkp_schedule_default-2', 'a:3:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (245, 'hmbkp_plugin_version', '2.3.3', 'yes') ; 
INSERT INTO `wp_options` VALUES (734, '_site_transient_timeout_wporg_theme_feature_list', '1384649103', 'yes') ; 
INSERT INTO `wp_options` VALUES (735, '_site_transient_wporg_theme_feature_list', 'a:5:{s:6:"Colors";a:15:{i:0;s:5:"black";i:1;s:4:"blue";i:2;s:5:"brown";i:3;s:4:"gray";i:4;s:5:"green";i:5;s:6:"orange";i:6;s:4:"pink";i:7;s:6:"purple";i:8;s:3:"red";i:9;s:6:"silver";i:10;s:3:"tan";i:11;s:5:"white";i:12;s:6:"yellow";i:13;s:4:"dark";i:14;s:5:"light";}s:7:"Columns";a:6:{i:0;s:10:"one-column";i:1;s:11:"two-columns";i:2;s:13:"three-columns";i:3;s:12:"four-columns";i:4;s:12:"left-sidebar";i:5;s:13:"right-sidebar";}s:5:"Width";a:2:{i:0;s:11:"fixed-width";i:1;s:14:"flexible-width";}s:8:"Features";a:19:{i:0;s:8:"blavatar";i:1;s:10:"buddypress";i:2;s:17:"custom-background";i:3;s:13:"custom-colors";i:4;s:13:"custom-header";i:5;s:11:"custom-menu";i:6;s:12:"editor-style";i:7;s:21:"featured-image-header";i:8;s:15:"featured-images";i:9;s:15:"flexible-header";i:10;s:20:"front-page-post-form";i:11;s:19:"full-width-template";i:12;s:12:"microformats";i:13;s:12:"post-formats";i:14;s:20:"rtl-language-support";i:15;s:11:"sticky-post";i:16;s:13:"theme-options";i:17;s:17:"threaded-comments";i:18;s:17:"translation-ready";}s:7:"Subject";a:3:{i:0;s:7:"holiday";i:1;s:13:"photoblogging";i:2;s:8:"seasonal";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (702, 'theme_mods_twentythirteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1384607383;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:1:{i:0;s:9:"twitter-2";}s:18:"orphaned_widgets_1";a:5:{i:0;s:14:"recent-posts-2";i:1;s:17:"recent-comments-2";i:2;s:10:"archives-2";i:3;s:12:"categories-2";i:4;s:6:"meta-2";}s:18:"orphaned_widgets_2";a:0:{}s:18:"orphaned_widgets_3";a:0:{}s:18:"orphaned_widgets_4";a:0:{}s:18:"orphaned_widgets_5";a:0:{}s:18:"orphaned_widgets_6";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (196, 'current_theme', 'Expound', 'yes') ; 
INSERT INTO `wp_options` VALUES (197, 'theme_mods_tigertheme', 'a:8:{i:0;b:0;s:16:"header_textcolor";s:6:"e9e0e1";s:16:"background_color";s:6:"e9e0d1";s:16:"background_image";s:0:"";s:17:"background_repeat";s:6:"repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1384638303;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:9:"twitter-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (198, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (677, '_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1384649787', 'no') ; 
INSERT INTO `wp_options` VALUES (678, '_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1384606587', 'no') ; 
INSERT INTO `wp_options` VALUES (679, '_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51', '1384649787', 'no') ; 
INSERT INTO `wp_options` VALUES (680, '_transient_dash_4077549d03da2e451c8b5f002294ff51', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2013/10/wordpress-3-7-1/\' title=\'WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including: Images with captions no longer appear broken in the visual editor. Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org. Avoid fatal errors with certain plugins that were incorrectly calling some […]\'>WordPress 3.7.1 Maintenance Release</a> <span class="rss-date">October 29, 2013</span><div class=\'rssSummary\'>WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including: Images with captions no longer appear broken in the visual editor. Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org. Avoid fatal errors with certain plugins that were incorrectly calling som [&hellip;]</div></li><li><a class=\'rsswidget\' href=\'http://wordpress.org/news/2013/10/basie/\' title=\'Version 3.7 of WordPress, named “Basie” in honor of Count Basie, is available for download or update in your WordPress dashboard. This release features some of the most important architectural updates we’ve made to date. Here are the big ones: Updates while you sleep: With WordPress 3.7, you don’t have to lift a finger to […]\'>WordPress 3.7 “Basie”</a> <span class="rss-date">October 24, 2013</span><div class=\'rssSummary\'>Version 3.7 of WordPress, named “Basie” in honor of Count Basie, is available for download or update in your WordPress dashboard. This release features some of the most important architectural updates we’ve made to date. Here are the big ones: Updates while you sleep: With WordPress 3.7, you don’t have to lift a finger to […]</div></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (681, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1384649787', 'no') ; 
INSERT INTO `wp_options` VALUES (682, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:44:"http://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"WordPress Plugins » View: Most Popular";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 16 Nov 2013 11:42:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"Contact Form 7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2141@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"All in One SEO Pack";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"753@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your Wordpress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"WordPress SEO by Yoast";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8321@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:131:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using the WordPress SEO plugin by Yoast.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Akismet";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"15@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:19:"Google XML Sitemaps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:63:"http://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"132@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:5:"Arnee";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WooCommerce - excelling eCommerce";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"http://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29860@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"WordPress Importer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"18101@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Jetpack by WordPress.com";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"23862@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:104:"Supercharge your WordPress site with powerful features previously only available to WordPress.com users.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"NextGEN Gallery";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"1169@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:122:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 7.5 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WP Super Cache";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://wordpress.org/plugins/wp-super-cache/#post-2572";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Nov 2007 11:40:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2572@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:73:"A very fast caching engine for WordPress that produces static html files.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Donncha O Caoimh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Wordfence Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"29832@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Wordfence Security is a free enterprise class security plugin that includes a firewall, virus scanning, real-time traffic with geolocation and more.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:11:"WP-Optimize";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"http://wordpress.org/plugins/wp-optimize/#post-8691";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 21 Jan 2009 04:28:48 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"8691@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:115:"This simple but effective plugin allows you to clean up your WordPress database and optimize it without phpMyAdmin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"ruhanirabin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:7:"Captcha";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://wordpress.org/plugins/captcha/#post-26129";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Apr 2011 05:53:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"26129@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:79:"This plugin allows you to implement super security captcha form into web forms.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"bestwebsoft";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"Ultimate TinyMCE";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://wordpress.org/plugins/ultimate-tinymce/#post-32088";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 14 Nov 2011 09:06:40 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"32088@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:94:"Description: Beef up the WordPress TinyMCE content editor with a plethora of advanced options.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:19:"Josh (Ult. Tinymce)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"TinyMCE Advanced";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"2082@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:45:"http://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:7:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 16 Nov 2013 11:54:30 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:13:"last-modified";s:29:"Thu, 02 Aug 2007 12:45:03 GMT";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (248, '_transient_timeout_hmbkp_schedule_default-1_filesize', '2758063022', 'no') ; 
INSERT INTO `wp_options` VALUES (249, '_transient_hmbkp_schedule_default-1_filesize', '411488', 'no') ; 
INSERT INTO `wp_options` VALUES (666, '_transient_timeout_feed_mod_a09314b1a57acfaba9faaca775e0e5d2', '1384649721', 'no') ; 
INSERT INTO `wp_options` VALUES (667, '_transient_feed_mod_a09314b1a57acfaba9faaca775e0e5d2', '1384606521', 'no') ; 
INSERT INTO `wp_options` VALUES (671, '_transient_timeout_feed_mod_808390979aa7eed5a9c06ad6a9dd19d0', '1384649786', 'no') ; 
INSERT INTO `wp_options` VALUES (672, '_transient_feed_mod_808390979aa7eed5a9c06ad6a9dd19d0', '1384606586', 'no') ; 
INSERT INTO `wp_options` VALUES (673, '_transient_timeout_dash_20494a3d90a6669585674ed0eb8dcd8f', '1384649786', 'no') ; 
INSERT INTO `wp_options` VALUES (674, '_transient_dash_20494a3d90a6669585674ed0eb8dcd8f', '<p>This dashboard widget queries <a href="http://blogsearch.google.com/">Google Blog Search</a> so that when another blog links to your site it will show up here. It has found no incoming links&hellip; yet. It&#8217;s okay &#8212; there is no rush.</p>
', 'no') ; 
INSERT INTO `wp_options` VALUES (669, '_transient_timeout_feed_808390979aa7eed5a9c06ad6a9dd19d0', '1384649786', 'no') ; 
INSERT INTO `wp_options` VALUES (670, '_transient_feed_808390979aa7eed5a9c06ad6a9dd19d0', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:4:"
  
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:33:"
    
    
    
    
    
    
  ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"link:http://www.andytan.net/tigers/ - Google Blog Search";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://www.google.com/search?ie=utf-8&q=link:http://www.andytan.net/tigers/&tbm=blg&tbs=sbd:1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:87:"Your search - <b>link:http://www.andytan.net/tigers/</b> - did not match any documents.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://a9.com/-/spec/opensearch/1.1/";a:3:{s:12:"totalResults";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:10:"startIndex";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:12:"itemsPerPage";a:1:{i:0;a:5:{s:4:"data";s:2:"10";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:12:"content-type";s:28:"text/xml; charset=ISO-8859-1";s:4:"date";s:29:"Sat, 16 Nov 2013 11:54:29 GMT";s:7:"expires";s:2:"-1";s:13:"cache-control";s:18:"private, max-age=0";s:10:"set-cookie";a:2:{i:0;s:143:"PREF=ID=76a1e1e383bc12dd:FF=0:TM=1384602869:LM=1384602870:S=g2beSp-pdyo-PQGT; expires=Mon, 16-Nov-2015 11:54:30 GMT; path=/; domain=.google.com";i:1;s:212:"NID=67=NiCNj0hcVUGarnLRyszOnIoLI39Qf3-q41B-prA4D-8gD1YaDuk-IIxFONJb3nCzQrzOMvsuC2Y74KPviSNEtOJkfTz1ntwiCkFqmZeer5o3-HN4oeYfRxREZeD7F8El; expires=Sun, 18-May-2014 11:54:30 GMT; path=/; domain=.google.com; HttpOnly";}s:3:"p3p";s:122:"CP="This is not a P3P policy! See http://www.google.com/support/accounts/bin/answer.py?hl=en&answer=151657 for more info."";s:6:"server";s:3:"gws";s:16:"x-xss-protection";s:13:"1; mode=block";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:18:"alternate-protocol";s:7:"80:quic";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (668, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1384947369;s:7:"checked";a:5:{s:7:"expound";s:3:"1.8";s:10:"tigertheme";s:1:"1";s:14:"twentythirteen";s:3:"1.1";s:12:"twentytwelve";s:3:"1.3";s:14:"ultimatetigers";s:3:"1.0";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (559, 'hupso_version', '3.9.22', 'yes') ; 
INSERT INTO `wp_options` VALUES (562, 'lightboxplus_options', 'a:57:{s:18:"lightboxplus_multi";s:1:"0";s:10:"use_inline";s:1:"0";s:10:"inline_num";s:1:"5";s:18:"lightboxplus_style";s:5:"black";s:16:"use_custom_style";s:1:"0";s:11:"disable_css";s:1:"0";s:10:"hide_about";s:1:"0";s:12:"output_htmlv";s:1:"0";s:9:"data_name";s:12:"lightboxplus";s:13:"load_location";s:9:"wp_footer";s:13:"load_priority";s:2:"10";s:11:"use_perpage";s:1:"0";s:11:"use_forpage";s:1:"0";s:11:"use_forpost";s:1:"0";s:10:"transition";s:7:"elastic";s:5:"speed";s:1:"0";s:5:"width";s:0:"";s:6:"height";s:0:"";s:11:"inner_width";s:3:"600";s:12:"inner_height";s:0:"";s:13:"initial_width";s:0:"";s:14:"initial_height";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:6:"resize";s:1:"0";s:7:"opacity";s:1:"0";s:10:"preloading";s:1:"0";s:11:"label_image";s:0:"";s:8:"label_of";s:0:"";s:8:"previous";s:0:"";s:4:"next";s:0:"";s:5:"close";s:0:"";s:13:"overlay_close";s:1:"0";s:9:"slideshow";s:1:"0";s:14:"slideshow_auto";s:1:"0";s:15:"slideshow_speed";s:3:"500";s:15:"slideshow_start";s:5:"start";s:14:"slideshow_stop";s:4:"stop";s:17:"use_caption_title";s:1:"0";s:20:"gallery_lightboxplus";s:1:"1";s:18:"multiple_galleries";s:1:"0";s:16:"use_class_method";s:1:"0";s:10:"class_name";s:11:"lbp_primary";s:16:"no_auto_lightbox";s:1:"0";s:10:"text_links";s:1:"0";s:16:"no_display_title";s:1:"0";s:9:"scrolling";s:1:"0";s:5:"photo";s:1:"0";s:3:"rel";s:1:"0";s:4:"loop";s:1:"0";s:7:"esc_key";s:1:"0";s:9:"arrow_key";s:1:"0";s:3:"top";s:0:"";s:6:"bottom";s:0:"";s:4:"left";s:0:"";s:5:"right";s:0:"";s:5:"fixed";s:1:"0";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (563, 'wpcf7', 'a:1:{s:7:"version";s:5:"3.5.4";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (508, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (675, '_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', '1384649787', 'no') ; 
INSERT INTO `wp_options` VALUES (676, '_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:25:"http://wordpress.org/news";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:14:"WordPress News";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 29 Oct 2013 21:04:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:39:"http://wordpress.org/?v=3.8-alpha-26127";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 3.7.1 Maintenance Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/10/wordpress-3-7-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2013/10/wordpress-3-7-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 29 Oct 2013 21:04:59 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2745";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:371:"WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including: Images with captions no longer appear broken in the visual editor. Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org. Avoid fatal errors with certain plugins that were incorrectly calling some [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1594:"<p>WordPress 3.7.1 is now available! This maintenance release addresses 11 bugs in WordPress 3.7, including:</p>
<ul>
<li>Images with captions no longer appear broken in the visual editor.</li>
<li>Allow some sites running on old or poorly configured servers to continue to check for updates from WordPress.org.</li>
<li>Avoid fatal errors with certain plugins that were incorrectly calling some WordPress functions too early.</li>
<li>Fix hierarchical sorting in get_pages(), exclusions in wp_list_categories(), and in_category() when called with empty values.</li>
<li>Fix a warning that may occur in certain setups while performing a search, and a few other notices.</li>
</ul>
<p>For a full list of changes, consult the <a href="http://core.trac.wordpress.org/query?milestone=3.7.1">list of tickets</a> and <a href="http://core.trac.wordpress.org/log/branches/3.7?stop_rev=25914&amp;rev=25986">the changelog</a>.</p>
<p>If you are one of the <a href="http://wordpress.org/download/counter/">nearly two million</a> already running WordPress 3.7, we will start rolling out the all-new <a href="http://wordpress.org/news/2013/10/basie/">automatic background updates</a> for WordPress 3.7.1 in the next few hours. For sites <a href="http://wordpress.org/plugins/background-update-tester/">that support them</a>, of course.</p>
<p><a href="http://wordpress.org/download/">Download WordPress 3.7.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221;</p>
<p><em>Just a few fixes<br />
Your new update attitude:<br />
Zero clicks given</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/10/wordpress-3-7-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.7 “Basie”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2013/10/basie/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2013/10/basie/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 24 Oct 2013 22:35:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2736";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:357:"Version 3.7 of WordPress, named &#8220;Basie&#8221; in honor of Count Basie, is available for download or update in your WordPress dashboard. This release features some of the most important architectural updates we&#8217;ve made to date. Here are the big ones: Updates while you sleep: With WordPress 3.7, you don&#8217;t have to lift a finger to [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:17229:"<p>Version 3.7 of WordPress, named &#8220;Basie&#8221; in honor of <a href="http://en.wikipedia.org/wiki/Count_basie">Count Basie</a>, is available <a href="http://wordpress.org/download/">for download</a> or update in your WordPress dashboard. This release features some of the most important architectural updates we&#8217;ve made to date. Here are the big ones:</p>
<ul>
<li><strong>Updates while you sleep</strong>: With WordPress 3.7, you don&#8217;t have to lift a finger to apply maintenance and security updates. Most sites are now able to automatically apply these updates in the background. The update process also has been made even more reliable and secure, with dozens of new checks and safeguards.</li>
<li><strong>Stronger password recommendations</strong>: Your password is your site&#8217;s first line of defense. It&#8217;s best to create passwords that are complex, long, and unique. To that end, our password meter has been updated in WordPress 3.7 to recognize common mistakes that can weaken your password: dates, names, keyboard patterns (123456789), and even pop culture references.</li>
<li><strong>Better global support</strong>: Localized versions of WordPress will receive faster and more complete translations. WordPress 3.7 adds support for automatically installing the right language files and keeping them up to date, a boon for the many millions who use WordPress in a language other than English.</li>
</ul>
<p>For developers there are lots of options around how to control the new updates feature, including allowing it to handle major upgrades as well as minor ones, more sophisticated date query support, and multisite improvements. As always, if you&#8217;re hungry for more <a href="http://codex.wordpress.org/Version_3.7">dive into the Codex</a> or browse the <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.7">over 400 closed tickets on Trac</a>.</p>
<h3>A New Wave</h3>
<p>This release was led by Andrew Nacin, backed up by Dion Hulse and Jon Cave. This is our first release using the new plugin-first development process, with a much shorter timeframe than in the past. (3.6 was released in August.) The 3.8 release, due in December, will continue this plugin-led development cycle that gives much more autonomy to plugin leads and allows us to decouple feature development from a release. You can follow this grand experiment, and what we&#8217;re learning from it, <a href="http://make.wordpress.org/core/">on the make/core blog</a>. There are 211 contributors with props in this release:</p>
<p><a href="http://profiles.wordpress.org/technosailor">Aaron Brazell</a>, <a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/aaronholbrook">Aaron Holbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/adamsilverstein">adamsilverstein</a>, <a href="http://profiles.wordpress.org/ahoereth">Alexander Hoereth</a>, <a href="http://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/andg">andg</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/norcross">Andrew Norcross</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/andrewspittle">Andrew Spittle</a>, <a href="http://profiles.wordpress.org/askapache">askapache</a>, <a href="http://profiles.wordpress.org/atimmer">atimmer</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/beaulebens">Beau Lebens</a>, <a href="http://profiles.wordpress.org/benmoody">ben.moody</a>, <a href="http://profiles.wordpress.org/bhengh">Ben Miller</a>, <a href="http://profiles.wordpress.org/neoxx">Bernhard Riedl</a>, <a href="http://profiles.wordpress.org/bftrick">BFTrick</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy (bananastalktome)</a>, <a href="http://profiles.wordpress.org/bmb">bmb</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brianhogg">brianhogg</a>, <a href="http://profiles.wordpress.org/rzen">Brian Richards</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/carldanley">Carl Danley</a>, <a href="http://profiles.wordpress.org/charlesclarkson">CharlesClarkson</a>, <a href="http://profiles.wordpress.org/chipbennett">Chip Bennett</a>, <a href="http://profiles.wordpress.org/chouby">Chouby</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/chrisrudzki">Chris Rudzki</a>, <a href="http://profiles.wordpress.org/aeg0125">coderaaron</a>, <a href="http://profiles.wordpress.org/coenjacobs">Coen Jacobs</a>, <a href="http://profiles.wordpress.org/crrobi01">Colin Robinson</a>, <a href="http://profiles.wordpress.org/andreasnrb">cyonite</a>, <a href="http://profiles.wordpress.org/daankortenbach">Daan Kortenbach</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/convissor">Daniel Convissor</a>, <a href="http://profiles.wordpress.org/dartiss">dartiss</a>, <a href="http://profiles.wordpress.org/koop">Daryl Koopersmith</a>, <a href="http://profiles.wordpress.org/csixty4">Dave Ross</a>, <a href="http://profiles.wordpress.org/davidjlaietta">David Laietta</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/dllh">dllh</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling (ocean90)</a>, <a href="http://profiles.wordpress.org/dpash">dpash</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="http://profiles.wordpress.org/drprotocols">DrProtocols</a>, <a href="http://profiles.wordpress.org/dustyf">Dustin Filippini</a>, <a href="http://profiles.wordpress.org/dzver">dzver</a>, <a href="http://profiles.wordpress.org/cais">Edward Caissie</a>, <a href="http://profiles.wordpress.org/enej">enej</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/faishal">faishal</a>, <a href="http://profiles.wordpress.org/faison">Faison</a>, <a href="http://profiles.wordpress.org/foofy">Foofy</a>, <a href="http://profiles.wordpress.org/fjarrett">Frankie Jarrett</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="http://profiles.wordpress.org/gayadesign">Gaya Kessler</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/gizburdt">Gizburdt</a>, <a href="http://profiles.wordpress.org/goldenapples">goldenapples</a>, <a href="http://profiles.wordpress.org/gradyetc">gradyetc</a>, <a href="http://profiles.wordpress.org/gcorne">Gregory Cornelius</a>, <a href="http://profiles.wordpress.org/webord">Gustavo Bordoni</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/creativeinfusion">itinerant</a>, <a href="http://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="http://profiles.wordpress.org/jakubtyrcha">jakub.tyrcha</a>, <a href="http://profiles.wordpress.org/jamescollins">James Collins</a>, <a href="http://profiles.wordpress.org/jenmylo">Jen Mylo</a>, <a href="http://profiles.wordpress.org/buffler">Jeremy Buller</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (jayjdk)</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="http://profiles.wordpress.org/johnnyb">John Beales</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn (johnbillion)</a>, <a href="http://profiles.wordpress.org/johnafish">John Fish</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/johnpbloch">John P. Bloch</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/jchristopher">Jonathan Christopher</a>, <a href="http://profiles.wordpress.org/desrosj">Jonathan Desrosiers</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jonlynch">Jon Lynch</a>, <a href="http://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="http://profiles.wordpress.org/josephscott">Joseph Scott</a>, <a href="http://profiles.wordpress.org/betzster">Josh Betz</a>, <a href="http://profiles.wordpress.org/devesine">Justin de Vesine</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">K.Adam White</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/ketwaroo">Ketwaroo</a>, <a href="http://profiles.wordpress.org/kevinb">kevinB</a>, <a href="http://profiles.wordpress.org/kpdesign">Kim Parsell</a>, <a href="http://profiles.wordpress.org/kitchin">kitchin</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/koopersmith">koopersmith</a>, <a href="http://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis (leewillis77)</a>, <a href="http://profiles.wordpress.org/lessbloat">lessbloat</a>, <a href="http://profiles.wordpress.org/layotte">Lew Ayotte</a>, <a href="http://profiles.wordpress.org/lgedeon">Luke Gedeon</a>, <a href="http://profiles.wordpress.org/iworks">Marcin Pietrzak</a>, <a href="http://profiles.wordpress.org/cimmo">Marco Cimmino</a>, <a href="http://profiles.wordpress.org/marco_teethgrinder">Marco Galasso</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markmcwilliams">Mark McWilliams</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/tw2113">Michael Beckwith</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/mikeschinkel">Mike Schinkel</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/usermrpapa">Mr Papa</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/naomicbush">Naomi</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/natejacobs">NateJacobs</a>, <a href="http://profiles.wordpress.org/nathanrice">nathanrice</a>, <a href="http://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="http://profiles.wordpress.org/nickdaugherty">Nick Daugherty</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/nickmomrik">Nick Momrik</a>, <a href="http://profiles.wordpress.org/nikv">Nikhil Vimal (NikV)</a>, <a href="http://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="http://profiles.wordpress.org/noahsilverstein">noahsilverstein</a>, <a href="http://profiles.wordpress.org/nofearinc">nofearinc</a>, <a href="http://profiles.wordpress.org/nukaga">nukaga</a>, <a href="http://profiles.wordpress.org/nullvariable">nullvariable</a>, <a href="http://profiles.wordpress.org/butuzov">Oleg Butuzov</a>, <a href="http://profiles.wordpress.org/paolal">Paolo Belcastro</a>, <a href="http://profiles.wordpress.org/xparham">Parham</a>, <a href="http://profiles.wordpress.org/pbiron">Paul Biron</a>, <a href="http://profiles.wordpress.org/pauldewouters">Paul de Wouters</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/peterjaap">peterjaap</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/plocha">plocha</a>, <a href="http://profiles.wordpress.org/pollett">Pollett</a>, <a href="http://profiles.wordpress.org/ptahdunbar">Ptah Dunbar</a>, <a href="http://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="http://profiles.wordpress.org/rasheed">Rasheed Bydousi</a>, <a href="http://profiles.wordpress.org/raybernard">RayBernard</a>, <a href="http://profiles.wordpress.org/rboren">rboren</a>, <a href="http://profiles.wordpress.org/greuben">Reuben Gunday</a>, <a href="http://profiles.wordpress.org/rfair404">rfair404</a>, <a href="http://profiles.wordpress.org/iamfriendly">Richard Tape</a>, <a href="http://profiles.wordpress.org/r3df">Rick Radko</a>, <a href="http://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="http://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/wpmuguru">Ron Rennick</a>, <a href="http://profiles.wordpress.org/rpattillo">rpattillo</a>, <a href="http://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/hotchkissconsulting">Sam Hotchkiss</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/scottsweb">scottsweb</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/scruffian">scruffian</a>, <a href="http://profiles.wordpress.org/tenpura">Seisuke Kuraishi (tenpura)</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/shinichin">ShinichiN</a>, <a href="http://profiles.wordpress.org/pross">Simon Prosser</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/siobhyb">Siobhan Bamber (siobhyb)</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/sillybean">Stephanie Leary</a>, <a href="http://profiles.wordpress.org/netweb">Stephen Edgar (@netweb)</a>, <a href="http://profiles.wordpress.org/stephenharris">Stephen Harris</a>, <a href="http://profiles.wordpress.org/strangerstudios">strangerstudios</a>, <a href="http://profiles.wordpress.org/sweetie089">sweetie089</a>, <a href="http://profiles.wordpress.org/swissspidy">swissspidy</a>, <a href="http://profiles.wordpress.org/miyauchi">Takayuki Miyauchi</a>, <a href="http://profiles.wordpress.org/tmtoy">Takuma Morikawa</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/tivnet">tivnet</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/tomauger">Tom Auger</a>, <a href="http://profiles.wordpress.org/toscho">toscho</a>, <a href="http://profiles.wordpress.org/wpsmith">Travis Smith</a>, <a href="http://profiles.wordpress.org/sorich87">Ulrich Sossou</a>, <a href="http://profiles.wordpress.org/vericgar">vericgar</a>, <a href="http://profiles.wordpress.org/vinod-dalvi">Vinod Dalvi</a>, <a href="http://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="http://profiles.wordpress.org/wikicms">wikicms</a>, <a href="http://profiles.wordpress.org/willnorris">Will Norris</a>, <a href="http://profiles.wordpress.org/wojtekszkutnik">Wojtek Szkutnik</a>, <a href="http://profiles.wordpress.org/wycks">wycks</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, and <a href="http://profiles.wordpress.org/yurivictor">Yuri Victor</a>.</p>
<p>Enjoy what may be one of your last few manual updates. See you soon for version 3.8!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2013/10/basie/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.7 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Oct 2013 00:05:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2729";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:417:"The second release candidate of WordPress 3.7 is now available for testing! Those of you already testing WordPress 3.7 will be updated automatically to RC2. (Nice.) If you&#8217;d like to start testing, there&#8217;s no time like the present! Try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”) or download the release candidate here (zip). Please post to the Alpha/Beta [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1183:"<p>The second release candidate of WordPress 3.7 is now available for testing!</p>
<p>Those of you already testing WordPress 3.7 will be updated automatically to RC2. (<em>Nice.</em>) If you&#8217;d like to start testing, there&#8217;s no time like the present! Try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”) or <a href="http://wordpress.org/wordpress-3.7-RC2.zip">download the release candidate here</a> (zip). Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a> if you think you&#8217;ve found a bug, and if any known issues are raised, you’ll be able to <a href="http://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>Developers, please test your plugins and themes against WordPress 3.7. If there is a compatibility issue, let us know as soon as possible so we can deal with it before the final release.</p>
<p>For more on WordPress 3.7, check out the <a href="http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/">announcement post for Release Candidate 1</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Upcoming WordCamps";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 22 Oct 2013 19:25:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:9:"Community";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2723";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:368:"WordCamps are casual, locally-organized conferences that celebrate everything related to WordPress, and are a great opportunity to meet other WordPress users and professionals in your community. This has been a great year for WordCamps &#8212; there have been 56 so far in more than 20 countries, and there another 15 on the calendar before the year&#8217;s [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"Jen Mylo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3584:"<p><a href="http://central.wordcamp.org/">WordCamps</a> are casual, locally-organized conferences that celebrate everything related to WordPress, and are a great opportunity to meet other WordPress users and professionals in your community. This has been a great year for WordCamps &#8212; there have been 56 so far in more than 20 countries, and there another 15 on the calendar before the year&#8217;s over. If there&#8217;s one near you, check it out! In addition to getting to know your local WordPress community, most WordCamps attract some traveling visitors a well, giving you the chance to meet contributors to the WordPress open source project and <a href="http://make.wordpress.org/">get involved</a> yourself.</p>
<p>Here are the WordCamps on the schedule for the rest of this year.</p>
<p>October 25-27: <strong><a href="http://2013.boston.wordcamp.org/">WordCamp Boston</a></strong>, Boston, MA, USA<br />
October 25-26: <strong><a href="http://2013.malaga.wordcamp.org/">WordCamp Malaga</a></strong>, Spain<br />
October 26: <strong><a href="http://2013.nepal.wordcamp.org/">WordCamp Nepal</a></strong>, Kathmandu, Nepal<br />
October 26: <strong><a href="http://2013.sofia.wordcamp.org/">WordCamp Sofia</a></strong>, Bulgaria<br />
November 7: <strong><a href="http://2013.capetown.wordcamp.org/">WordCamp Cape Town</a></strong>, South Africa<br />
November 9: <strong><a href="http://2013.porto.wordcamp.org/">WordCamp Porto</a></strong>, Portugal<br />
November 9-10: <strong><a href="http://2013.kenya.wordcamp.org/">WordCamp Kenya</a></strong>, Nairobi, Kenya<br />
November 15: <strong><a href="http://2013.edmonton.wordcamp.org/">WordCamp Edmonton</a></strong>, AB, Canada<br />
November 16-17: <strong><a href="http://2013.orlando.wordcamp.org/">WordCamp Orlando</a></strong>, FL, USA<br />
November 16: <strong><a href="http://2013.denver.wordcamp.org/">WordCamp Denver</a></strong>, CO, USA<br />
November 23-24: <strong><a href="http://2013.london.wordcamp.org/">WordCamp London</a></strong>, UK<br />
November 23-24: <strong><a href="http://2013.raleigh.wordcamp.org/">WordCamp Raleigh</a></strong>, NC, USA<br />
November 23: <strong><a href="http://2013.saopaulo.wordcamp.org/">WordCamp São Paulo</a></strong>, Brazil<br />
December 14: <strong><a href="http://2013.vegas.wordcamp.org/">WordCamp Las Vegas</a></strong>, NV, USA<br />
December 14-15: <strong><a href="http://2013.sevilla.wordcamp.org/">WordCamp Sevilla</a></strong>, Spain</p>
<p>No WordCamps on this list in your area? Not to worry! There are thriving <a href="http://wordpress.meetup.com/">WordPress meetups</a> all over the world where you can meet like-minded people, and we maintain a library of <a href="http://wordpress.tv/category/wordcamptv/">WordCamp videos</a> at <a href="http://wordpress.tv/">WordPress.tv</a>.</p>
<h3>Get Involved</h3>
<ul>
<li>If you&#8217;re interested in organizing a WordCamp in your area, check out our <a href="http://plan.wordcamp.org/">WordCamp planning</a> site.</li>
<li>If you&#8217;re interested in <a href="http://make.wordpress.org/community/meetup-interest-form/">starting a WordPress meetup</a> in your area, let us know and we can set up a group on meetup.com for you.</li>
<li>And speaking of WordCamp videos, we&#8217;ve recently enabled volunteer-generated subtitles/closed captioning of the videos on WordPress.tv to make them more accessible. Interested in helping? Check out the <a href="http://wordpress.tv/using-amara-org-to-caption-or-subtitle-a-wordpress-tv-video/">WordPress.tv subtitling instructions</a>.</li>
</ul>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/10/upcoming-wordcamps-4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 3.7 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:75:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Oct 2013 19:52:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2718";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:331:"The first release candidate for WordPress 3.7 is now available! In RC 1, we&#8217;ve made some adjustments to the update process to make it more reliable than ever. We hope to ship WordPress 3.7 next week, but we need your help to get there. If you haven’t tested 3.7 yet, there’s no time like the present. (Please, [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2237:"<p>The first release candidate for WordPress 3.7 is now available!</p>
<p>In RC 1, we&#8217;ve made some adjustments to the update process to make it more reliable than ever. We hope to ship WordPress 3.7 <em>next week</em>, but we need your help to get there. If you haven’t tested 3.7 yet, there’s no time like the present. (Please, not on a production site, unless you’re adventurous.)</p>
<p>WordPress 3.7 introduces <strong>automatic background updates</strong> for security and minor releases (like updating from 3.7 to 3.7.1). These are really easy to test  — RC 1 will update every 12 hours or so to the latest development version, and then email you the results. (You may get two emails: one for debugging, and one all users of 3.7 will receive.) If something went wrong, you can report it.</p>
<p><strong>Think you’ve found a bug? </strong>Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>. If any known issues come up, you’ll be able to <a href="http://core.trac.wordpress.org/report/5">find them here</a>.</p>
<p>To test WordPress 3.7 RC1, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href="http://wordpress.org/wordpress-3.7-RC1.zip">download the release candidate here</a> (zip). If you’d like to learn more about what&#8217;s new in WordPress 3.7, visit the awesome About screen in your dashboard (<strong><img alt="" src="http://core.svn.wordpress.org/branches/3.6/wp-content/themes/twentyten/images/wordpress.png" /> → About</strong> in the toolbar). There, you can also see if your install is eligible for background updates. WordPress won’t automatically update, for example, if you’re using version control like Subversion or Git.</p>
<p><strong>Developers,</strong> please test your plugins and themes against WordPress 3.7, so that if there is a compatibility issue, we can figure it out before the final release. Make sure you post any issues to the support forums.</p>
<p><em>WordPress three seven</em><br />
<em>A self-updating engine</em><br />
<em>Lies beneath the hood</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:71:"http://wordpress.org/news/2013/10/wordpress-3-7-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.7 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/10/wordpress-3-7-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/10/wordpress-3-7-beta-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Oct 2013 21:28:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2706";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:357:"WordPress 3.7 Beta 2 is now available for download and testing. This is software still in development, so we don&#8217;t recommend that you run it on a production site. This has been a quiet beta period. We&#8217;re hoping to get some more testers for automatic background updates, which will occur for security and minor releases (like updating [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2108:"<p>WordPress 3.7 Beta 2 is now available for download and testing. This is software still in development, so we don&#8217;t recommend that you run it on a production site.</p>
<p>This has been a quiet beta period. We&#8217;re hoping to get some more testers for <strong>automatic background updates</strong>, which will occur for security and minor releases (like updating from 3.7 to 3.7.1). It&#8217;s really easy to test this, as Beta 2 will update each day to the latest development version and then email you the results. If something goes wrong, you can report it — it&#8217;s that simple. To get the beta, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="http://wordpress.org/wordpress-3.7-beta2.zip">download the beta here</a> (zip). Check out <strong>Dashboard → Updates</strong> to see if your install is eligible for background updates. WordPress won&#8217;t update if, for example, you&#8217;re using version control like SVN or Git.</p>
<p>For more of what&#8217;s new in version 3.7, <a title="WordPress 3.7 Beta 1" href="http://wordpress.org/news/2013/09/wordpress-3-7-beta-1/">check out the Beta 1 blog post</a>. In Beta 2, we further increased the stability of background updates and also added about 50 bug fixes, including a fix for Internet Explorer 11 in the visual editor.</p>
<p>If you think you’ve found a bug, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.7">everything we’ve fixed</a>.</p>
<p>Happy testing!</p>
<p><em>Beta 2 released<br />
Dotting i&#8217;s and crossing t&#8217;s</em><br />
<em>Expect RC next</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/10/wordpress-3-7-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 3.7 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/09/wordpress-3-7-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/news/2013/09/wordpress-3-7-beta-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 28 Sep 2013 07:25:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2688";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:339:"I&#8217;m pleased to announce the availability of WordPress 3.7 Beta 1. For WordPress 3.7 we decided to shorten the development cycle and focus on a few key improvements. We plan to release the final product in October, and then follow it in December with a jam-packed WordPress 3.8 release, which is already in development. Some [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3684:"<p>I&#8217;m pleased to announce the availability of WordPress 3.7 Beta 1.</p>
<p>For WordPress 3.7 we decided to shorten the development cycle and focus on a few key improvements. We plan to release the final product in October, and then follow it in December with a jam-packed WordPress 3.8 release, which is already in development. Some of the best stuff in WordPress 3.7 is subtle &#8212; by design! So let&#8217;s walk through what we&#8217;d love for you to test, just in time for the weekend.</p>
<p><strong>Automatic, background updates.</strong> 3.7 Beta 1 will keep itself updated. That&#8217;s right &#8212; you&#8217;ll be updated each night to the newest development build, and eventually to Beta 2. We&#8217;re working to provide as many installs as possible with fast updates to security releases of WordPress &#8212; and you can help us test by just installing Beta 1 on your server and seeing how it works!</p>
<p>When you go to <strong>Dashboard → Updates</strong>, you&#8217;ll see a note letting you know whether your install is working for automatic updates. There are a few situations where WordPress can&#8217;t reliably and securely update itself. But if it can, you&#8217;ll get an email (sent to the &#8216;Admin Email&#8217; on the General Settings page) after each update letting you know what worked and what didn&#8217;t. If it worked, great! If something failed, the email will suggest you make a post in the support forums or create a bug report.</p>
<p>Here are some other things you should test out:</p>
<ul>
<li>If you&#8217;re running <strong>WordPress in another language</strong>, we&#8217;ll automatically download any available translations for official WordPress importers and the default themes. (More to come here.)</li>
<li>Our <strong>password meter</strong> got a whole lot better, thanks to Dropbox&#8217;s <a href="https://tech.dropbox.com/2012/04/zxcvbn-realistic-password-strength-estimation/">zxcvbn</a> library. Again, subtle but effective. Strong passwords are very important!</li>
<li><strong>Search results</strong> are now <a href="http://core.trac.wordpress.org/changeset/25632">ordered by relevance</a>, rather than just by date. When your keywords match post titles and not just content, they&#8217;ll be pushed to the top.</li>
<li>Developers should check out the new <strong>advanced date queries</strong> in <code>WP_Query</code>. (<a href="http://core.trac.wordpress.org/ticket/18694">#18694</a>)</li>
</ul>
<p><strong>This software is still in development</strong>, so we don&#8217;t recommend you run it on a production site. I&#8217;d suggest setting up a test site just to play with the new version. To test WordPress 3.7, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="http://wordpress.org/wordpress-3.7-beta1.zip">download the beta here</a> (zip).</p>
<p>As always, <strong>if you think you’ve found a bug</strong>, you can post to the <a href="http://wordpress.org/support/forum/alphabeta">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a reproducible bug report, <a href="http://core.trac.wordpress.org/">file one on the WordPress Trac</a>. There, you can also find <a href="http://core.trac.wordpress.org/report/5">a list of known bugs</a> and <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=3.7">everything we’ve fixed</a> so far.</p>
<p>Happy testing!</p>
<p><em>WordPress three seven<br />
Saves your weary hand a click<br />
Updates while you sleep</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:60:"http://wordpress.org/news/2013/09/wordpress-3-7-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"WordPress 3.6.1 Maintenance and Security Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:50:"http://wordpress.org/news/2013/09/wordpress-3-6-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/news/2013/09/wordpress-3-6-1/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 11 Sep 2013 20:48:23 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Security";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2675";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:353:"After nearly 7 million downloads of WordPress 3.6, we are pleased to announce the availability of version 3.6.1. This maintenance release fixes 13 bugs in version 3.6, which was a very smooth release. WordPress 3.6.1 is also a security release for all previous WordPress versions and we strongly encourage you to update your sites immediately. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Andrew Nacin";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2033:"<p>After <a href="http://wordpress.org/download/counter/">nearly 7 million downloads</a> of WordPress 3.6, we are pleased to announce the availability of version 3.6.1. This maintenance release <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.6.1">fixes 13 bugs</a> in version 3.6, which was a very smooth release.</p>
<p><strong>WordPress 3.6.1 is also a security release for all previous WordPress versions</strong> and we strongly encourage you to update your sites immediately. It addresses three issues fixed by the WordPress security team:</p>
<ul>
<li>Block unsafe PHP unserialization that could occur in limited situations and setups, which can lead to remote code execution. Reported by <a href="http://vagosec.org/" rel="nofollow">Tom Van Goethem</a>.</li>
<li>Prevent a user with an Author role, using a specially crafted request, from being able to create a post &#8220;written by&#8221; another user. Reported by <a href="http://anakornk.wordpress.com/" rel="nofollow">Anakorn Kyavatanakij</a>.</li>
<li>Fix insufficient input validation that could result in redirecting or leading a user to another website. Reported by Dave Cummo, a Northrup Grumman subcontractor for the <a href="http://www.cdc.gov/" rel="nofollow">U.S. Centers for Disease Control and Prevention</a>.</li>
</ul>
<p>Additionally, we&#8217;ve adjusted security restrictions around file uploads to mitigate the potential for cross-site scripting.</p>
<p>We appreciated <a href="http://codex.wordpress.org/FAQ_Security">responsible disclosure</a> of these issues directly to our security team. For more information on the changes, see the <a href="http://codex.wordpress.org/Version_3.6.1">release notes</a> or consult <a href="http://core.trac.wordpress.org/log/branches/3.6?stop_rev=24972&amp;rev=25345">the list of changes</a>.</p>
<p><a href="http://wordpress.org/wordpress-3.6.1.zip">Download WordPress 3.6.1</a> or update now from the Dashboard → Updates menu in your site&#8217;s admin area.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:55:"http://wordpress.org/news/2013/09/wordpress-3-6-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"WordPress 3.6 “Oscar”";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/news/2013/08/oscar/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:49:"http://wordpress.org/news/2013/08/oscar/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Aug 2013 21:43:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2661";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:368:"The latest and greatest WordPress, version 3.6, is now live to the world and includes a beautiful new blog-centric theme, bullet-proof autosave and post locking, a revamped revision browser, native support for audio and video embeds, and improved integrations with Spotify, Rdio, and SoundCloud. Here&#8217;s a video that shows off some of the features using [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:18626:"<p>The latest and greatest WordPress, version 3.6, is now <a href="http://wordpress.org/download/">live to the world</a> and includes a beautiful new blog-centric theme, bullet-proof autosave and post locking, a revamped revision browser, native support for audio and video embeds, and improved integrations with Spotify, Rdio, and SoundCloud. Here&#8217;s a video that shows off some of the features using our cast of professional actors:</p>
<div id="v-UmhwbWJH-1" class="video-player"><embed id="v-UmhwbWJH-1-video" src="http://s0.videopress.com/player.swf?v=1.03&amp;guid=UmhwbWJH&amp;isDynamicSeeking=true" type="application/x-shockwave-flash" width="692" height="388" title="Introducing WordPress 3.6 &quot;Oscar&quot;" wmode="direct" seamlesstabbing="true" allowfullscreen="true" allowscriptaccess="always" overstretch="true"></embed></div>
<p>We&#8217;re calling this release &#8220;Oscar&#8221; in honor of the great jazz pianist <a href="http://en.wikipedia.org/wiki/Oscar_Peterson">Oscar Peterson</a>. Here&#8217;s a bit more about some of the new features, which you can also find on the about page in your dashboard after you upgrade.</p>
<h3>User Features</h3>
<p><img class="alignright" alt="" src="https://wordpress.org/images/core/3.6/twentythirteen.png" width="300" /></p>
<ul>
<li>The <strong>new Twenty Thirteen theme</strong> inspired by modern art puts focus on your content with a colorful, single-column design made for media-rich blogging.</li>
<li><strong>Revamped Revisions</strong> save every change and the new interface allows you to scroll easily through changes to see line-by-line who changed what and when.</li>
<li><strong>Post Locking</strong> and <strong>Augmented Autosave</strong> will especially be a boon to sites where more than a single author is working on a post. Each author now has their own autosave stream, which stores things locally as well as on the server (so much harder to lose something) and there&#8217;s an interface for taking over editing of a post, as demonstrated beautifully by our bearded buddies in the video above.</li>
<li><strong>Built-in HTML5 media player</strong> for native audio and video embeds with no reliance on external services.</li>
<li>The <strong>Menu Editor</strong> is now much easier to understand and use.</li>
</ul>
<h3>Developer features</h3>
<ul>
<li>A new audio/video API gives you access to metadata like ID3 tags.</li>
<li>You can now choose HTML5 markup for things like comment and search forms, and comment lists.</li>
<li>Better filters for how revisions work, so you can store a different amount of history for different post types.</li>
<li>Tons more <a href="http://codex.wordpress.org/Version_3.6">listed on the Codex</a>, and of course you can always <a href="http://core.trac.wordpress.org/query?status=closed&amp;group=resolution&amp;milestone=3.6">browse the over 700 closed tickets</a>.</li>
</ul>
<h3>The Band</h3>
<p>This release was led by <a href="http://markjaquith.com/">Mark Jaquith</a> and <a href="http://geekreprieve.com/">Aaron Campbell</a>, and included contributions from the following fine folks. Pull up some Oscar Peterson on your music service of choice, or vinyl if you have it, and check out some of their profiles:</p>
<p><a href="http://profiles.wordpress.org/technosailor">Aaron Brazell</a>, <a href="http://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="http://profiles.wordpress.org/aaronholbrook">Aaron Holbrook</a>, <a href="http://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="http://profiles.wordpress.org/kawauso">Adam Harley</a>, <a href="http://profiles.wordpress.org/adamsilverstein">adamsilverstein</a>, <a href="http://profiles.wordpress.org/akted">AK Ted</a>, <a href="http://profiles.wordpress.org/xknown">Alex Concha</a>, <a href="http://profiles.wordpress.org/alexkingorg">Alex King</a>, <a href="http://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="http://profiles.wordpress.org/momo360modena">Amaury Balmer</a>, <a href="http://profiles.wordpress.org/sabreuse">Amy Hendrix (sabreuse)</a>, <a href="http://profiles.wordpress.org/anatolbroder">Anatol Broder</a>, <a href="http://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="http://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="http://profiles.wordpress.org/andrewryno">Andrew Ryno</a>, <a href="http://profiles.wordpress.org/andy">Andy Skelton</a>, <a href="http://profiles.wordpress.org/gorgoglionemeister">Antonio</a>, <a href="http://profiles.wordpress.org/apimlott">apimlott</a>, <a href="http://profiles.wordpress.org/awellis13">awellis13</a>, <a href="http://profiles.wordpress.org/barry">Barry</a>, <a href="http://profiles.wordpress.org/beaulebens">Beau Lebens</a>, <a href="http://profiles.wordpress.org/belloswan">BelloSwan</a>, <a href="http://profiles.wordpress.org/bilalcoder">bilalcoder</a>, <a href="http://profiles.wordpress.org/bananastalktome">Billy (bananastalktome)</a>, <a href="http://profiles.wordpress.org/bobbingwide">bobbingwide</a>, <a href="http://profiles.wordpress.org/bobbravo2">Bob Gregor</a>, <a href="http://profiles.wordpress.org/bradparbs">bradparbs</a>, <a href="http://profiles.wordpress.org/bradyvercher">Brady Vercher</a>, <a href="http://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="http://profiles.wordpress.org/brianlayman">Brian Layman</a>, <a href="http://profiles.wordpress.org/beezeee">Brian Zeligson</a>, <a href="http://profiles.wordpress.org/bpetty">Bryan Petty</a>, <a href="http://profiles.wordpress.org/chmac">Callum Macdonald</a>, <a href="http://profiles.wordpress.org/carldanley">Carl Danley</a>, <a href="http://profiles.wordpress.org/caspie">Caspie</a>, <a href="http://profiles.wordpress.org/charlestonsw">Charleston Software Associates</a>, <a href="http://profiles.wordpress.org/cheeserolls">cheeserolls</a>, <a href="http://profiles.wordpress.org/chipbennett">Chip Bennett</a>, <a href="http://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="http://profiles.wordpress.org/cochran">Christopher Cochran</a>, <a href="http://profiles.wordpress.org/cfinke">Christopher Finke</a>, <a href="http://profiles.wordpress.org/chriswallace">Chris Wallace</a>, <a href="http://profiles.wordpress.org/corvannoorloos">Cor van Noorloos</a>, <a href="http://profiles.wordpress.org/crazycoders">crazycoders</a>, <a href="http://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="http://profiles.wordpress.org/mzaweb">Daniel Dvorkin (MZAWeb)</a>, <a href="http://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="http://profiles.wordpress.org/daniloercoli">daniloercoli</a>, <a href="http://profiles.wordpress.org/dannydehaan">Danny de Haan</a>, <a href="http://profiles.wordpress.org/csixty4">Dave Ross</a>, <a href="http://profiles.wordpress.org/dfavor">David Favor</a>, <a href="http://profiles.wordpress.org/jdtrower">David Trower</a>, <a href="http://profiles.wordpress.org/davidwilliamson">David Williamson</a>, <a href="http://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="http://profiles.wordpress.org/dllh">dllh</a>, <a href="http://profiles.wordpress.org/ocean90">Dominik Schilling (ocean90)</a>, <a href="http://profiles.wordpress.org/dovyp">dovyp</a>, <a href="http://profiles.wordpress.org/drewapicture">Drew Jaynes (DrewAPicture)</a>, <a href="http://profiles.wordpress.org/dvarga">dvarga</a>, <a href="http://profiles.wordpress.org/cais">Edward Caissie</a>, <a href="http://profiles.wordpress.org/elfin">elfin</a>, <a href="http://profiles.wordpress.org/empireoflight">Empireoflight</a>, <a href="http://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="http://profiles.wordpress.org/ethitter">Erick Hitter</a>, <a href="http://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="http://profiles.wordpress.org/evansolomon">Evan Solomon</a>, <a href="http://profiles.wordpress.org/faishal">faishal</a>, <a href="http://profiles.wordpress.org/feedmeastraycat">feedmeastraycat</a>, <a href="http://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="http://profiles.wordpress.org/f-j-kaiser">Franz Josef Kaiser</a>, <a href="http://profiles.wordpress.org/fstop">FStop</a>, <a href="http://profiles.wordpress.org/mintindeed">Gabriel Koen</a>, <a href="http://profiles.wordpress.org/garyc40">Gary Cao</a>, <a href="http://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="http://profiles.wordpress.org/gcorne">gcorne</a>, <a href="http://profiles.wordpress.org/geertdd">GeertDD</a>, <a href="http://profiles.wordpress.org/soulseekah">Gennady Kovshenin</a>, <a href="http://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="http://profiles.wordpress.org/gish">gish</a>, <a href="http://profiles.wordpress.org/tivnet">Gregory Karpinsky</a>, <a href="http://profiles.wordpress.org/hakre">hakre</a>, <a href="http://profiles.wordpress.org/hbanken">hbanken</a>, <a href="http://profiles.wordpress.org/hebbet">hebbet</a>, <a href="http://profiles.wordpress.org/helen">Helen Hou-Sandi</a>, <a href="http://profiles.wordpress.org/helgatheviking">helgatheviking</a>, <a href="http://profiles.wordpress.org/hirozed">hirozed</a>, <a href="http://profiles.wordpress.org/hurtige">hurtige</a>, <a href="http://profiles.wordpress.org/hypertextranch">hypertextranch</a>, <a href="http://profiles.wordpress.org/iandunn">Ian Dunn</a>, <a href="http://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="http://profiles.wordpress.org/jakub">jakub</a>, <a href="http://profiles.wordpress.org/h4ck3rm1k3">James Michael DuPont</a>, <a href="http://profiles.wordpress.org/jbutkus">jbutkus</a>, <a href="http://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="http://profiles.wordpress.org/jerrysarcastic">Jerry Bates (JerrySarcastic)</a>, <a href="http://profiles.wordpress.org/jayjdk">Jesper Johansen (Jayjdk)</a>, <a href="http://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="http://profiles.wordpress.org/joen">Joen Asmussen</a>, <a href="http://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="http://profiles.wordpress.org/johnbillion">John Blackbourn (johnbillion)</a>, <a href="http://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="http://profiles.wordpress.org/jond3r">Jonas Bolinder (jond3r)</a>, <a href="http://profiles.wordpress.org/desrosj">Jonathan Desrosiers</a>, <a href="http://profiles.wordpress.org/jonbishop">Jon Bishop</a>, <a href="http://profiles.wordpress.org/duck_">Jon Cave</a>, <a href="http://profiles.wordpress.org/jcastaneda">Jose Castaneda</a>, <a href="http://profiles.wordpress.org/josephscott">Joseph Scott</a>, <a href="http://profiles.wordpress.org/jvisick77">Josh Visick</a>, <a href="http://profiles.wordpress.org/jrbeilke">jrbeilke</a>, <a href="http://profiles.wordpress.org/jrf">jrf</a>, <a href="http://profiles.wordpress.org/devesine">Justin de Vesine</a>, <a href="http://profiles.wordpress.org/justinsainton">Justin Sainton</a>, <a href="http://profiles.wordpress.org/kadamwhite">kadamwhite</a>, <a href="http://profiles.wordpress.org/trepmal">Kailey (trepmal)</a>, <a href="http://profiles.wordpress.org/karmatosed">karmatosed</a>, <a href="http://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="http://profiles.wordpress.org/keoshi">keoshi</a>, <a href="http://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="http://profiles.wordpress.org/obenland">Konstantin Obenland</a>, <a href="http://profiles.wordpress.org/ktdreyer">ktdreyer</a>, <a href="http://profiles.wordpress.org/kurtpayne">Kurt Payne</a>, <a href="http://profiles.wordpress.org/kwight">kwight</a>, <a href="http://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="http://profiles.wordpress.org/leewillis77">Lee Willis (leewillis77)</a>, <a href="http://profiles.wordpress.org/lessbloat">lessbloat</a>, <a href="http://profiles.wordpress.org/settle">Mantas Malcius</a>, <a href="http://profiles.wordpress.org/maor">Maor Chasen</a>, <a href="http://profiles.wordpress.org/macbrink">Marcel Brinkkemper</a>, <a href="http://profiles.wordpress.org/marcuspope">MarcusPope</a>, <a href="http://profiles.wordpress.org/mark-k">Mark-k</a>, <a href="http://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="http://profiles.wordpress.org/markmcwilliams">Mark McWilliams</a>, <a href="http://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="http://profiles.wordpress.org/mjbanks">Matt Banks</a>, <a href="http://profiles.wordpress.org/mboynes">Matthew Boynes</a>, <a href="http://profiles.wordpress.org/matthewruddy">MatthewRuddy</a>, <a href="http://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="http://profiles.wordpress.org/maxcutler">Max Cutler</a>, <a href="http://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="http://profiles.wordpress.org/mgibbs189">mgibbs189</a>, <a href="http://profiles.wordpress.org/fanquake">Michael</a>, <a href="http://profiles.wordpress.org/mdawaffe">Michael Adams (mdawaffe)</a>, <a href="http://profiles.wordpress.org/tw2113">Michael Beckwith</a>, <a href="http://profiles.wordpress.org/mfields">Michael Fields</a>, <a href="http://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="http://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="http://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="http://profiles.wordpress.org/mitchoyoshitaka">mitcho (Michael Yoshitaka Erlewine)</a>, <a href="http://profiles.wordpress.org/batmoo">Mohammad Jangda</a>, <a href="http://profiles.wordpress.org/najamelan">najamelan</a>, <a href="http://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="http://profiles.wordpress.org/alex-ye">Nashwan Doaqan</a>, <a href="http://profiles.wordpress.org/niallkennedy">Niall Kennedy</a>, <a href="http://profiles.wordpress.org/nickdaugherty">Nick Daugherty</a>, <a href="http://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="http://profiles.wordpress.org/ninnypants">ninnypants</a>, <a href="http://profiles.wordpress.org/norcross">norcross</a>, <a href="http://profiles.wordpress.org/paradiseporridge">ParadisePorridge</a>, <a href="http://profiles.wordpress.org/pauldewouters">Paul</a>, <a href="http://profiles.wordpress.org/pdclark">Paul Clark</a>, <a href="http://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="http://profiles.wordpress.org/petemall">Pete Mall</a>, <a href="http://profiles.wordpress.org/westi">Peter Westwood</a>, <a href="http://profiles.wordpress.org/phill_brown">Phill Brown</a>, <a href="http://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="http://profiles.wordpress.org/pollett">Pollett</a>, <a href="http://profiles.wordpress.org/nprasath002">Prasath Nadarajah</a>, <a href="http://profiles.wordpress.org/programmin">programmin</a>, <a href="http://profiles.wordpress.org/rachelbaker">rachelbaker</a>, <a href="http://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="http://profiles.wordpress.org/redpixelstudios">redpixelstudios</a>, <a href="http://profiles.wordpress.org/reidburke">reidburke</a>, <a href="http://profiles.wordpress.org/retlehs">retlehs</a>, <a href="http://profiles.wordpress.org/greuben">Reuben Gunday</a>, <a href="http://profiles.wordpress.org/rlerdorf">rlerdorf</a>, <a href="http://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="http://profiles.wordpress.org/roulandf">roulandf</a>, <a href="http://profiles.wordpress.org/rovo89">rovo89</a>, <a href="http://profiles.wordpress.org/ryanduff">Ryan Duff</a>, <a href="http://profiles.wordpress.org/ryanhellyer">Ryan Hellyer</a>, <a href="http://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="http://profiles.wordpress.org/zeo">Safirul Alredha</a>, <a href="http://profiles.wordpress.org/saracannon">sara cannon</a>, <a href="http://profiles.wordpress.org/scholesmafia">scholesmafia</a>, <a href="http://profiles.wordpress.org/sc0ttkclark">Scott Kingsley Clark</a>, <a href="http://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="http://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="http://profiles.wordpress.org/scribu">scribu</a>, <a href="http://profiles.wordpress.org/tenpura">Seisuke Kuraishi (tenpura)</a>, <a href="http://profiles.wordpress.org/sergej">Sergej</a>, <a href="http://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="http://profiles.wordpress.org/sim">Simon Hampel</a>, <a href="http://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="http://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="http://profiles.wordpress.org/sirzooro">sirzooro</a>, <a href="http://profiles.wordpress.org/slene">slene</a>, <a href="http://profiles.wordpress.org/solarissmoke">solarissmoke</a>, <a href="http://profiles.wordpress.org/srinig">SriniG</a>, <a href="http://profiles.wordpress.org/stephenh1988">Stephen Harris</a>, <a href="http://profiles.wordpress.org/storkontheroof">storkontheroof</a>, <a href="http://profiles.wordpress.org/sunnyratilal">Sunny Ratilal</a>, <a href="http://profiles.wordpress.org/sweetie089">sweetie089</a>, <a href="http://profiles.wordpress.org/tar">Tar</a>, <a href="http://profiles.wordpress.org/tlovett1">Taylor Lovett</a>, <a href="http://profiles.wordpress.org/thomasvanderbeek">Thomas van der Beek</a>, <a href="http://profiles.wordpress.org/n7studios">Tim Carr</a>, <a href="http://profiles.wordpress.org/tjsingleton">tjsingleton</a>, <a href="http://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="http://profiles.wordpress.org/toscho">toscho</a>, <a href="http://profiles.wordpress.org/taupecat">Tracy Rotton</a>, <a href="http://profiles.wordpress.org/travishoffman">TravisHoffman</a>, <a href="http://profiles.wordpress.org/uuf6429">uuf6429</a>, <a href="http://profiles.wordpress.org/lightningspirit">Vitor Carvalho</a>, <a href="http://profiles.wordpress.org/wojtek">wojtek</a>, <a href="http://profiles.wordpress.org/wpewill">wpewill</a>, <a href="http://profiles.wordpress.org/wraithkenny">WraithKenny</a>, <a href="http://profiles.wordpress.org/wycks">wycks</a>, <a href="http://profiles.wordpress.org/xibe">Xavier Borderie</a>, <a href="http://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="http://profiles.wordpress.org/thelastcicada">Zachary Brown</a>, <a href="http://profiles.wordpress.org/tollmanz">Zack Tollman</a>, <a href="http://profiles.wordpress.org/zekeweeks">zekeweeks</a>, <a href="http://profiles.wordpress.org/ziegenberg">ziegenberg</a>, and <a href="http://profiles.wordpress.org/viniciusmassuchetto">viniciusmassuchetto</a>.</p>
<p>Time to upgrade!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:45:"http://wordpress.org/news/2013/08/oscar/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress 3.6 Release Candidate 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/news/2013/07/wordpress-3-6-release-candidate-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:77:"http://wordpress.org/news/2013/07/wordpress-3-6-release-candidate-2/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 24 Jul 2013 07:25:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:7:"Testing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"http://wordpress.org/news/?p=2649";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:341:"The second release candidate for WordPress 3.6 is now available for download and testing. We&#8217;re down to only a few remaining issues, and the final release should be available in a matter of days. In RC2, we&#8217;ve tightened up some aspects of revisions, autosave, and the media player, and fixed some bugs that were spotted [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Mark Jaquith";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1325:"<p>The second release candidate for WordPress 3.6 is now available for download and testing.</p>
<p>We&#8217;re down to only a few remaining issues, and the final release should be available in a matter of days. In RC2, we&#8217;ve tightened up some aspects of revisions, autosave, and the media player, and fixed some bugs that were spotted in RC1. Please test this release candidate as much as you can, so we can deliver a smooth final release!</p>
<p><strong>Think you&#8217;ve found a bug?</strong> Please post to the <a href="http://wordpress.org/support/forum/alphabeta/">Alpha/Beta area in the support forums</a>.</p>
<p><strong>Developers,</strong> please continue to test your plugins and themes, so that if there is a compatibility issue, we can figure it out before the final release. You can find our <a href="http://core.trac.wordpress.org/report/6">list of known issues here</a>.</p>
<p>To test WordPress 3.6, try the <a href="http://wordpress.org/extend/plugins/wordpress-beta-tester/">WordPress Beta Tester</a> plugin (you&#8217;ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href="http://wordpress.org/wordpress-3.6-RC2.zip">download the release candidate here (zip)</a>.</p>
<p><em>Revisions so smooth</em><br />
<em>We autosave your changes</em><br />
<em>Data loss begone!</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"http://wordpress.org/news/2013/07/wordpress-3-6-release-candidate-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:31:"http://wordpress.org/news/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:8:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 16 Nov 2013 11:54:29 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:10:"x-pingback";s:36:"http://wordpress.org/news/xmlrpc.php";s:13:"last-modified";s:29:"Tue, 29 Oct 2013 21:04:59 GMT";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (549, 'theme_mods_expound', 'a:8:{i:0;b:0;s:16:"header_textcolor";s:6:"3a3a3a";s:16:"background_color";s:6:"ffffff";s:16:"background_image";s:0:"";s:17:"background_repeat";s:6:"repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";s:18:"nav_menu_locations";a:1:{s:7:"primary";i:0;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (756, '_transient_timeout_tlc_up__e46625b24e3688cd61ea7ba19d802251', '1384643492', 'no') ; 
INSERT INTO `wp_options` VALUES (757, '_transient_tlc_up__e46625b24e3688cd61ea7ba19d802251', 'a:6:{i:0;s:32:"tlc_lock_5287fa78a99411.67988223";i:1;s:36:"twp_cab7117af2a233ba68a81a588837edab";i:2;i:300;i:3;a:2:{i:0;O:15:"wpTwitterWidget":14:{s:34:" wpTwitterWidget _wp_twitter_oauth";O:9:"wpTwitter":3:{s:24:" wpTwitter _consumer_key";s:19:"jsu4vXpRoHzNdRdrsrw";s:27:" wpTwitter _consumer_secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:17:" wpTwitter _token";N;}s:12:" * _settings";a:2:{s:3:"twp";a:18:{s:12:"consumer-key";s:19:"jsu4vXpRoHzNdRdrsrw";s:15:"consumer-secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:5:"title";s:0:"";s:6:"errmsg";s:0:"";s:8:"username";s:0:"";s:4:"list";s:0:"";s:13:"http_vs_https";s:5:"https";s:11:"hidereplies";s:5:"false";s:12:"showretweets";s:4:"true";s:8:"hidefrom";s:5:"false";s:11:"showintents";s:4:"true";s:10:"showfollow";s:4:"true";s:6:"avatar";s:0:"";s:15:"showXavisysLink";s:5:"false";s:11:"targetBlank";s:5:"false";s:5:"items";s:2:"10";s:6:"showts";s:5:"86400";s:10:"dateFormat";s:14:"h:i:s A F d, Y";}s:16:"twp-authed-users";a:1:{s:15:"ash_skywalker10";a:4:{s:11:"oauth_token";s:50:"399730397-UUaCZnrCulookeadOgPWcpkEclDv2vZ6IMw9wf8t";s:18:"oauth_token_secret";s:45:"nHgo0EzVefbEbsp5L7FoTlcXaWjSLsu6i0gGOISYFWS7f";s:7:"user_id";s:9:"399730397";s:11:"screen_name";s:15:"ash_skywalker10";}}}s:8:" * _hook";s:16:"twitterWidgetPro";s:8:" * _file";s:40:"twitter-widget-pro/wp-twitter-widget.php";s:13:" * _pageTitle";s:18:"Twitter Widget Pro";s:13:" * _menuTitle";s:14:"Twitter Widget";s:15:" * _accessLevel";s:14:"manage_options";s:15:" * _optionGroup";s:11:"twp-options";s:15:" * _optionNames";a:1:{i:0;s:3:"twp";}s:19:" * _optionCallbacks";a:0:{}s:8:" * _slug";s:18:"twitter-widget-pro";s:12:" * _feed_url";s:19:"http://ran.ge/feed/";s:18:" * _paypalButtonId";s:7:"9993090";s:21:" * _optionsPageAction";s:11:"options.php";}i:1;s:9:"parseFeed";}i:4;a:1:{i:0;a:28:{s:4:"name";s:7:"Sidebar";s:2:"id";s:9:"sidebar-1";s:11:"description";s:0:"";s:5:"class";s:0:"";s:13:"before_widget";s:52:"<aside id="twitter-2" class="widget widget_twitter">";s:12:"after_widget";s:8:"</aside>";s:12:"before_title";s:25:"<h1 class="widget-title">";s:11:"after_title";s:5:"</h1>";s:9:"widget_id";s:9:"twitter-2";s:11:"widget_name";s:18:"Twitter Widget Pro";s:12:"consumer-key";s:19:"jsu4vXpRoHzNdRdrsrw";s:15:"consumer-secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:5:"title";s:0:"";s:6:"errmsg";s:72:"Oops! Looks like Twitter is down, we\'ll get on to this as soon as we can";s:8:"username";s:15:"ash_skywalker10";s:4:"list";s:0:"";s:13:"http_vs_https";s:5:"https";s:11:"hidereplies";s:5:"false";s:12:"showretweets";s:4:"true";s:8:"hidefrom";s:5:"false";s:11:"showintents";s:4:"true";s:10:"showfollow";s:4:"true";s:6:"avatar";s:0:"";s:15:"showXavisysLink";s:5:"false";s:11:"targetBlank";s:5:"false";s:5:"items";i:5;s:6:"showts";s:6:"604800";s:10:"dateFormat";s:14:"h:i:s A F d, Y";}}i:5;i:120;}', 'no') ; 
INSERT INTO `wp_options` VALUES (438, '_site_transient_timeout_browser_00760e848c8aef5785b4a3f89f42352c', '1384656149', 'yes') ; 
INSERT INTO `wp_options` VALUES (439, '_site_transient_browser_00760e848c8aef5785b4a3f89f42352c', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"30.0.1599.101";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (297, 'theme_mods_wingchun', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1381755221;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";N;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (507, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:41:"https://wordpress.org/wordpress-3.7.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:41:"https://wordpress.org/wordpress-3.7.1.zip";s:10:"no_content";s:52:"https://wordpress.org/wordpress-3.7.1-no-content.zip";s:11:"new_bundled";s:53:"https://wordpress.org/wordpress-3.7.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.7.1";s:7:"version";s:5:"3.7.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.6";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1384947370;s:15:"version_checked";s:5:"3.7.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (683, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1384649787', 'no') ; 
INSERT INTO `wp_options` VALUES (684, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1384606587', 'no') ; 
INSERT INTO `wp_options` VALUES (685, '_transient_timeout_feed_77fa140e07ce53fe8c87136636f83d72', '1384649788', 'no') ; 
INSERT INTO `wp_options` VALUES (686, '_transient_feed_77fa140e07ce53fe8c87136636f83d72', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:72:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:40:"http://wordpress.org/plugins/browse/new/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:33:"WordPress Plugins » View: Newest";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 16 Nov 2013 11:30:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:15:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:27:"Formidable Email Shortcodes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/plugins/formidable-email-shortcodes/#post-60662";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Nov 2013 20:47:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60662@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:147:"Create shortcodes with unique identifiers to use in your Formidable Email Notification Settings. Change email addresses globally from one location.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"thomstark";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:25:"Formidable Customizations";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:66:"http://wordpress.org/plugins/formidable-customizations/#post-60653";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Nov 2013 18:13:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60653@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:125:"A compendium of useful customizations and extensions for Formidable Pro. Easily customize your form fields from one location.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"thomstark";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"DeMomentSomTres Categories";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wordpress.org/plugins/demomentsomtres-categories/#post-59215";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 08 Oct 2013 06:03:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"59215@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Displays all categories and its descriptions on a list";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:20:"Marc Queralt i Bassa";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"Read Holy Quran";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/read-holy-quran/#post-60608";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 12:51:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60608@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:42:"This is a simple Holy Quran Reader Plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Masum Billah";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"DeMomentSomTres Image Feed Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://wordpress.org/plugins/demomentsomtres-image-feed-widget/#post-52379";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 22 Apr 2013 17:22:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"52379@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"A widget to display imges from RSS feeds such as twitter, flickr or youtube or instagram

This plugin is a corrected version of Image Feed Widget by y";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:20:"Marc Queralt i Bassa";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:24:"Added WP Functions by QP";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.org/plugins/qp-added-wp-functions/#post-60339";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 08 Nov 2013 06:18:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60339@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:87:"Easily add more functionality to WordPress function.php using Added WP Functions by QP.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Quati Pixels";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:18:"Custom Users Order";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"http://wordpress.org/plugins/custom-users-order/#post-60600";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 09:37:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60600@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:83:"This plugin will order all the users with simple Drag and Drop Sortable capability.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Hiren Patel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:21:"Pro Categories Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://wordpress.org/plugins/pro-categories-widget/#post-60650";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Nov 2013 16:35:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60650@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:76:"Pro Categories Widget plugin.You have choice to specific categories exclude.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"shambhu patnaik";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"zeev jump to content";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/jump-to-content/#post-60545";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Nov 2013 08:13:25 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60545@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:109:"this plugin a jump to content hidden feild at the top of the site, it is activated with &#34;tab&#34; botton.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"zeevm.co.il";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:27:"Disable Comments By Referer";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"http://wordpress.org/plugins/disable-comments-by-referer/#post-60639";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Nov 2013 10:37:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60639@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:64:"Ban visitors from certain sites from viewing or adding comments.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Kat Hagan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:33:"Flynsarmy Subcategory List Widget";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"http://wordpress.org/plugins/subcategory-list-widget/#post-60643";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 15 Nov 2013 12:44:19 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60643@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:81:"Adds a widget that can displays subcategories of a given category (or top level).";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"flynsarmy";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:17:"KVP YouTube: Lite";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://wordpress.org/plugins/kvp-youtube-lite/#post-60624";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Nov 2013 21:52:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60624@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:85:"Provider plugin which enables YouTube functionality for use with Katalyst Video Plus.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Keiser Media";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:15:"Audemedia Tools";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"http://wordpress.org/plugins/audemedia-tools/#post-59583";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 18 Oct 2013 07:35:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"59583@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:82:"Audemedia Tools is a set of plugins that extend Audemedia&#039;s WordPress Themes.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"audemedia";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:29:"WP User Listing and Searching";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:70:"http://wordpress.org/plugins/wp-user-listing-and-searching/#post-60544";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 13 Nov 2013 07:56:09 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"60544@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:149:"You can create wordpress user listing on front page. A search functionality will give your visitor more comfort in finding any user.
Visitor can also";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"avinashphp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:16:"IFrame Shortcode";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:67:"http://wordpress.org/plugins/flynsarmy-iframe-shortcode/#post-59737";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 23 Oct 2013 01:04:28 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"59737@http://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:109:"Allows the insertion of code to display an external webpage within an iframe.

**Requires PHP 5.3 or later.**";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"flynsarmy";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:41:"http://wordpress.org/plugins/rss/view/new";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:10:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Sat, 16 Nov 2013 11:54:31 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:7:"expires";s:29:"Sat, 16 Nov 2013 12:05:42 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Sat, 16 Nov 2013 11:30:42 +0000";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (483, 'twp', 'a:16:{s:12:"consumer-key";s:19:"jsu4vXpRoHzNdRdrsrw";s:15:"consumer-secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:8:"username";s:0:"";s:4:"list";s:0:"";s:5:"title";s:0:"";s:5:"items";s:2:"10";s:6:"avatar";s:0:"";s:6:"errmsg";s:0:"";s:6:"showts";s:5:"86400";s:10:"dateFormat";s:14:"h:i:s A F d, Y";s:12:"showretweets";s:4:"true";s:11:"hidereplies";s:5:"false";s:8:"hidefrom";s:5:"false";s:11:"showintents";s:4:"true";s:10:"showfollow";s:4:"true";s:11:"targetBlank";s:5:"false";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (703, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (486, '_twp_request_token_3d960485ab858e08bb82835ccb9838f6', 'a:4:{s:11:"oauth_token";s:42:"t0LdHOY5SNdagZHvUy9oB2wxb60QgYwzIQJ7NgmQ7c";s:18:"oauth_token_secret";s:42:"e8Hq8T4vCFrCbT3fRXOGc6ROXXBXViBRWn9rfduTRU";s:24:"oauth_callback_confirmed";s:4:"true";s:5:"nonce";s:32:"3d960485ab858e08bb82835ccb9838f6";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (488, 'twp-authed-users', 'a:1:{s:15:"ash_skywalker10";a:4:{s:11:"oauth_token";s:50:"399730397-UUaCZnrCulookeadOgPWcpkEclDv2vZ6IMw9wf8t";s:18:"oauth_token_secret";s:45:"nHgo0EzVefbEbsp5L7FoTlcXaWjSLsu6i0gGOISYFWS7f";s:7:"user_id";s:9:"399730397";s:11:"screen_name";s:15:"ash_skywalker10";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (740, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1384651002', 'yes') ; 
INSERT INTO `wp_options` VALUES (741, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3898";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2456";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2344";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1930";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1856";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1583";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1329";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1325";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1310";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1260";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1225";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1121";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1000";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"982";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"974";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"950";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"844";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"821";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"780";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"722";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"686";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"681";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"678";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"623";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"615";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"595";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"572";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"570";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"541";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"539";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"530";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"522";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"506";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"505";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"471";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"458";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"453";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"452";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"436";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"432";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (501, 'widget_twitter', 'a:2:{i:2;a:18:{s:12:"consumer-key";s:19:"jsu4vXpRoHzNdRdrsrw";s:15:"consumer-secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:5:"title";s:0:"";s:6:"errmsg";s:72:"Oops! Looks like Twitter is down, we\'ll get on to this as soon as we can";s:8:"username";s:15:"ash_skywalker10";s:4:"list";s:0:"";s:13:"http_vs_https";s:5:"https";s:11:"hidereplies";s:5:"false";s:12:"showretweets";s:4:"true";s:8:"hidefrom";s:5:"false";s:11:"showintents";s:4:"true";s:10:"showfollow";s:4:"true";s:6:"avatar";s:0:"";s:15:"showXavisysLink";s:5:"false";s:11:"targetBlank";s:5:"false";s:5:"items";s:1:"5";s:6:"showts";s:6:"604800";s:10:"dateFormat";s:14:"h:i:s A F d, Y";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (504, '_transient_timeout_tlc__e46625b24e3688cd61ea7ba19d802251', '1415708395', 'no') ; 
INSERT INTO `wp_options` VALUES (505, '_transient_tlc__e46625b24e3688cd61ea7ba19d802251', 'a:2:{i:0;i:1384172395;i:1;a:1:{i:0;O:8:"stdClass":22:{s:10:"created_at";s:30:"Thu Oct 27 23:20:47 +0000 2011";s:2:"id";i:129699090836627458;s:6:"id_str";s:18:"129699090836627458";s:4:"text";s:138:"@contikiaus #contiki I\'m seeking amazing sights, fantastic architecture, absorb large amounts of history,  DELICIOUS FOOD and good friends";s:6:"source";s:118:"<a href="http://contiki.com.au/pages/1734-europe-2012-13-microsite-fortheseekers" rel="nofollow">Contiki Australia</a>";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";i:17455144;s:23:"in_reply_to_user_id_str";s:8:"17455144";s:23:"in_reply_to_screen_name";s:10:"contikiaus";s:4:"user";O:8:"stdClass":38:{s:2:"id";i:399730397;s:6:"id_str";s:9:"399730397";s:4:"name";s:8:"Andy Tan";s:11:"screen_name";s:15:"ash_skywalker10";s:8:"location";s:0:"";s:11:"description";s:0:"";s:3:"url";N;s:8:"entities";O:8:"stdClass":1:{s:11:"description";O:8:"stdClass":1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:1;s:13:"friends_count";i:0;s:12:"listed_count";i:0;s:10:"created_at";s:30:"Thu Oct 27 23:20:36 +0000 2011";s:16:"favourites_count";i:0;s:10:"utc_offset";N;s:9:"time_zone";N;s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:1;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:79:"http://abs.twimg.com/sticky/default_profile_images/default_profile_3_normal.png";s:23:"profile_image_url_https";s:80:"https://abs.twimg.com/sticky/default_profile_images/default_profile_3_normal.png";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:1;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";O:8:"stdClass":4:{s:8:"hashtags";a:1:{i:0;O:8:"stdClass":2:{s:4:"text";s:7:"contiki";s:7:"indices";a:2:{i:0;i:12;i:1;i:20;}}}s:7:"symbols";a:0:{}s:4:"urls";a:0:{}s:13:"user_mentions";a:1:{i:0;O:8:"stdClass":5:{s:11:"screen_name";s:10:"contikiaus";s:4:"name";s:17:"Contiki Australia";s:2:"id";i:17455144;s:6:"id_str";s:8:"17455144";s:7:"indices";a:2:{i:0;i:0;i:1;i:11;}}}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:4:"lang";s:2:"en";}}}', 'no') ; 
INSERT INTO `wp_options` VALUES (747, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1384947370;s:7:"checked";a:11:{s:30:"advanced-custom-fields/acf.php";s:5:"4.3.0";s:19:"akismet/akismet.php";s:5:"2.5.9";s:35:"backupwordpress/backupwordpress.php";s:5:"2.3.3";s:36:"contact-form-7/wp-contact-form-7.php";s:5:"3.5.4";s:43:"custom-post-type-ui/custom-post-type-ui.php";s:5:"0.8.2";s:9:"hello.php";s:3:"1.6";s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";s:6:"3.9.22";s:30:"lightbox-plus/lightboxplus.php";s:3:"2.6";s:45:"limit-login-attempts/limit-login-attempts.php";s:5:"1.7.1";s:23:"ml-slider/ml-slider.php";s:9:"2.5-beta2";s:40:"twitter-widget-pro/wp-twitter-widget.php";s:5:"2.6.0";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (758, '_transient_all_the_cool_cats', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (791, '_transient_doing_cron', '1384947365.5803079605102539062500', 'yes') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Wednesday 20. November 2013 11:36 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=167 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (141 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2, 4, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (5, 8, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (4, 4, '_edit_lock', '1382243026:1') ; 
INSERT INTO `wp_postmeta` VALUES (6, 8, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (7, 8, '_menu_item_object_id', '8') ; 
INSERT INTO `wp_postmeta` VALUES (8, 8, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (9, 8, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (10, 8, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (11, 8, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (12, 8, '_menu_item_url', 'http://www.andytan.net/tigers/') ; 
INSERT INTO `wp_postmeta` VALUES (13, 8, '_menu_item_orphaned', '1384051406') ; 
INSERT INTO `wp_postmeta` VALUES (14, 9, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (15, 9, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (16, 9, '_menu_item_object_id', '2') ; 
INSERT INTO `wp_postmeta` VALUES (17, 9, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (18, 9, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (19, 9, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (20, 9, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (21, 9, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (22, 9, '_menu_item_orphaned', '1384051406') ; 
INSERT INTO `wp_postmeta` VALUES (23, 11, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (24, 11, '_edit_lock', '1384089066:1') ; 
INSERT INTO `wp_postmeta` VALUES (25, 11, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (26, 13, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (27, 13, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (28, 13, '_menu_item_object_id', '13') ; 
INSERT INTO `wp_postmeta` VALUES (29, 13, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (30, 13, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (31, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (32, 13, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (33, 13, '_menu_item_url', 'http://www.andytan.net/tigers/') ; 
INSERT INTO `wp_postmeta` VALUES (34, 13, '_menu_item_orphaned', '1384347924') ; 
INSERT INTO `wp_postmeta` VALUES (35, 14, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (36, 14, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (37, 14, '_menu_item_object_id', '2') ; 
INSERT INTO `wp_postmeta` VALUES (38, 14, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (39, 14, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (40, 14, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (41, 14, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (42, 14, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (43, 14, '_menu_item_orphaned', '1384347924') ; 
INSERT INTO `wp_postmeta` VALUES (44, 15, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (45, 15, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (46, 15, '_menu_item_object_id', '11') ; 
INSERT INTO `wp_postmeta` VALUES (47, 15, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (48, 15, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (49, 15, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (50, 15, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (51, 15, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (52, 15, '_menu_item_orphaned', '1384347924') ; 
INSERT INTO `wp_postmeta` VALUES (53, 16, '_form', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit "Send"]</p>') ; 
INSERT INTO `wp_postmeta` VALUES (54, 16, '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:206:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://www.andytan.net/tigers)";s:9:"recipient";s:22:"andy.tan2624@gmail.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (55, 16, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:148:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://www.andytan.net/tigers)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (56, 16, '_messages', 'a:6:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";}') ; 
INSERT INTO `wp_postmeta` VALUES (57, 16, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (58, 16, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (59, 17, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (60, 17, '_edit_lock', '1384518062:1') ; 
INSERT INTO `wp_postmeta` VALUES (61, 17, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (62, 19, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (63, 19, 'field_5286137be45ed', 'a:14:{s:3:"key";s:19:"field_5286137be45ed";s:5:"label";s:15:"URL to Web Site";s:4:"name";s:3:"url";s:4:"type";s:4:"text";s:12:"instructions";s:32:"Enter in the url for the project";s:8:"required";s:1:"1";s:13:"default_value";s:7:"http://";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (94, 19, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"work";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (65, 19, 'position', 'normal') ; 
INSERT INTO `wp_postmeta` VALUES (66, 19, 'layout', 'no_box') ; 
INSERT INTO `wp_postmeta` VALUES (67, 19, 'hide_on_screen', 'a:13:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:13:"custom_fields";i:3;s:10:"discussion";i:4;s:8:"comments";i:5;s:9:"revisions";i:6;s:4:"slug";i:7;s:6:"author";i:8;s:6:"format";i:9;s:14:"featured_image";i:10;s:10:"categories";i:11;s:4:"tags";i:12;s:15:"send-trackbacks";}') ; 
INSERT INTO `wp_postmeta` VALUES (68, 19, '_edit_lock', '1384608600:1') ; 
INSERT INTO `wp_postmeta` VALUES (69, 19, 'field_528613b5a7c3f', 'a:12:{s:3:"key";s:19:"field_528613b5a7c3f";s:5:"label";s:11:"Description";s:4:"name";s:11:"description";s:4:"type";s:8:"textarea";s:12:"instructions";s:37:"Enter in a description of the project";s:8:"required";s:1:"1";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:10:"formatting";s:4:"none";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}') ; 
INSERT INTO `wp_postmeta` VALUES (70, 19, 'field_528613d8a7c40', 'a:11:{s:3:"key";s:19:"field_528613d8a7c40";s:5:"label";s:26:"Display on Homepage Slider";s:4:"name";s:19:"display_on_homepage";s:4:"type";s:8:"checkbox";s:12:"instructions";s:62:"Check if you would like this project to appear on the homepage";s:8:"required";s:1:"0";s:7:"choices";a:1:{s:3:"Yes";s:3:"Yes";}s:13:"default_value";s:0:"";s:6:"layout";s:8:"vertical";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}') ; 
INSERT INTO `wp_postmeta` VALUES (72, 19, 'field_52861404e4bb9', 'a:11:{s:3:"key";s:19:"field_52861404e4bb9";s:5:"label";s:21:"Homepage Slider Image";s:4:"name";s:21:"homepage_slider_image";s:4:"type";s:5:"image";s:12:"instructions";s:66:"Upload the image to appear for this project on the homepage slider";s:8:"required";s:1:"0";s:11:"save_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_528613d8a7c40";s:8:"operator";s:2:"==";s:5:"value";s:3:"Yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}') ; 
INSERT INTO `wp_postmeta` VALUES (74, 19, 'field_5286142c651d6', 'a:9:{s:3:"key";s:19:"field_5286142c651d6";s:5:"label";s:16:"Background Color";s:4:"name";s:16:"background_color";s:4:"type";s:12:"color_picker";s:12:"instructions";s:67:"Select the color to appear as the background color for this project";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_528613d8a7c40";s:8:"operator";s:2:"==";s:5:"value";s:3:"Yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}') ; 
INSERT INTO `wp_postmeta` VALUES (84, 20, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (85, 20, 'field_5286151f7c129', 'a:14:{s:3:"key";s:19:"field_5286151f7c129";s:5:"label";s:4:"Name";s:4:"name";s:4:"name";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (77, 19, 'field_5286144ec634d', 'a:9:{s:3:"key";s:19:"field_5286144ec634d";s:5:"label";s:12:"Button Color";s:4:"name";s:12:"button_color";s:4:"type";s:12:"color_picker";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:13:"default_value";s:7:"#ffffff";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_528613d8a7c40";s:8:"operator";s:2:"==";s:5:"value";s:3:"Yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:5;}') ; 
INSERT INTO `wp_postmeta` VALUES (79, 19, 'field_5286148066e87', 'a:14:{s:3:"key";s:19:"field_5286148066e87";s:5:"label";s:20:"Related Testimonials";s:4:"name";s:20:"related_testimonials";s:4:"type";s:12:"relationship";s:12:"instructions";s:31:"Select any related testimonials";s:8:"required";s:1:"0";s:13:"return_format";s:6:"object";s:9:"post_type";a:1:{i:0;s:4:"post";}s:8:"taxonomy";a:1:{i:0;s:3:"all";}s:7:"filters";a:1:{i:0;s:6:"search";}s:15:"result_elements";a:1:{i:0;s:9:"post_type";}s:3:"max";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_528613d8a7c40";s:8:"operator";s:2:"==";s:5:"value";s:3:"Yes";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:6;}') ; 
INSERT INTO `wp_postmeta` VALUES (97, 20, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (87, 20, 'position', 'normal') ; 
INSERT INTO `wp_postmeta` VALUES (88, 20, 'layout', 'no_box') ; 
INSERT INTO `wp_postmeta` VALUES (89, 20, 'hide_on_screen', 'a:13:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:13:"custom_fields";i:3;s:10:"discussion";i:4;s:8:"comments";i:5;s:9:"revisions";i:6;s:4:"slug";i:7;s:6:"author";i:8;s:6:"format";i:9;s:14:"featured_image";i:10;s:10:"categories";i:11;s:4:"tags";i:12;s:15:"send-trackbacks";}') ; 
INSERT INTO `wp_postmeta` VALUES (90, 20, '_edit_lock', '1384519222:1') ; 
INSERT INTO `wp_postmeta` VALUES (102, 23, 'field_52861657879f6', 'a:11:{s:3:"key";s:19:"field_52861657879f6";s:5:"label";s:11:"Testimonial";s:4:"name";s:11:"testimonial";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:17:"Enter description";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:5:"basic";s:12:"media_upload";s:2:"no";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}') ; 
INSERT INTO `wp_postmeta` VALUES (98, 20, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (99, 20, '_wp_trash_meta_time', '1384519227') ; 
INSERT INTO `wp_postmeta` VALUES (100, 23, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (101, 23, 'field_52861648879f5', 'a:14:{s:3:"key";s:19:"field_52861648879f5";s:5:"label";s:4:"Name";s:4:"name";s:4:"name";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"none";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (159, 23, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (104, 23, 'position', 'normal') ; 
INSERT INTO `wp_postmeta` VALUES (105, 23, 'layout', 'no_box') ; 
INSERT INTO `wp_postmeta` VALUES (106, 23, 'hide_on_screen', 'a:13:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:13:"custom_fields";i:3;s:10:"discussion";i:4;s:8:"comments";i:5;s:9:"revisions";i:6;s:4:"slug";i:7;s:6:"author";i:8;s:6:"format";i:9;s:14:"featured_image";i:10;s:10:"categories";i:11;s:4:"tags";i:12;s:15:"send-trackbacks";}') ; 
INSERT INTO `wp_postmeta` VALUES (107, 23, '_edit_lock', '1384608584:1') ; 
INSERT INTO `wp_postmeta` VALUES (108, 1, '_edit_lock', '1384609831:1') ; 
INSERT INTO `wp_postmeta` VALUES (109, 2, '_edit_lock', '1384524386:1') ; 
INSERT INTO `wp_postmeta` VALUES (110, 24, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (111, 24, '_edit_lock', '1384524465:1') ; 
INSERT INTO `wp_postmeta` VALUES (112, 26, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (113, 26, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (114, 26, '_menu_item_object_id', '24') ; 
INSERT INTO `wp_postmeta` VALUES (115, 26, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (116, 26, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (117, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (118, 26, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (119, 26, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (121, 27, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (122, 27, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (123, 27, '_menu_item_object_id', '17') ; 
INSERT INTO `wp_postmeta` VALUES (124, 27, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (125, 27, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (126, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (127, 27, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (128, 27, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (130, 28, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (131, 28, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (132, 28, '_menu_item_object_id', '2') ; 
INSERT INTO `wp_postmeta` VALUES (133, 28, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (134, 28, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (135, 28, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (136, 28, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (137, 28, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (149, 31, 'field_52876a39d6918', 'a:14:{s:3:"key";s:19:"field_52876a39d6918";s:5:"label";s:4:"Name";s:4:"name";s:4:"name";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (139, 29, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (140, 29, '_menu_item_menu_item_parent', '28') ; 
INSERT INTO `wp_postmeta` VALUES (141, 29, '_menu_item_object_id', '11') ; 
INSERT INTO `wp_postmeta` VALUES (142, 29, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (143, 29, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (144, 29, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (145, 29, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (146, 29, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (148, 31, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (157, 23, 'field_52876b8abf55d', 'a:14:{s:3:"key";s:19:"field_52876b8abf55d";s:5:"label";s:6:"Dechen";s:4:"name";s:6:"dechen";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}') ; 
INSERT INTO `wp_postmeta` VALUES (156, 31, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";s:8:"order_no";i:0;s:8:"group_no";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (152, 31, 'position', 'normal') ; 
INSERT INTO `wp_postmeta` VALUES (153, 31, 'layout', 'no_box') ; 
INSERT INTO `wp_postmeta` VALUES (154, 31, 'hide_on_screen', 'a:13:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:13:"custom_fields";i:3;s:10:"discussion";i:4;s:8:"comments";i:5;s:9:"revisions";i:6;s:4:"slug";i:7;s:6:"author";i:8;s:6:"format";i:9;s:14:"featured_image";i:10;s:10:"categories";i:11;s:4:"tags";i:12;s:15:"send-trackbacks";}') ; 
INSERT INTO `wp_postmeta` VALUES (155, 31, '_edit_lock', '1384606312:1') ; 
INSERT INTO `wp_postmeta` VALUES (158, 23, 'field_52876b93bf55e', 'a:14:{s:3:"key";s:19:"field_52876b93bf55e";s:5:"label";s:6:"Gendun";s:4:"name";s:6:"gendun";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}') ; 
INSERT INTO `wp_postmeta` VALUES (160, 23, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (161, 23, '_wp_trash_meta_time', '1384608597') ; 
INSERT INTO `wp_postmeta` VALUES (162, 31, '_wp_trash_meta_status', 'publish') ; 
INSERT INTO `wp_postmeta` VALUES (163, 31, '_wp_trash_meta_time', '1384608606') ; 
INSERT INTO `wp_postmeta` VALUES (164, 1, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (166, 33, 'ml-slider_settings', 'a:31:{s:4:"type";s:4:"flex";s:6:"random";b:0;s:8:"cssClass";s:0:"";s:8:"printCss";b:1;s:7:"printJs";b:1;s:5:"width";i:700;s:6:"height";i:300;s:3:"spw";i:7;s:3:"sph";i:5;s:5:"delay";i:3000;s:6:"sDelay";i:30;s:7:"opacity";d:0.6999999999999999555910790149937383830547332763671875;s:10:"titleSpeed";i:500;s:6:"effect";s:6:"random";s:10:"navigation";b:1;s:5:"links";b:1;s:10:"hoverPause";b:1;s:5:"theme";s:7:"default";s:9:"direction";s:10:"horizontal";s:7:"reverse";b:0;s:14:"animationSpeed";i:600;s:8:"prevText";s:1:"<";s:8:"nextText";s:1:">";s:6:"slices";i:15;s:6:"center";b:0;s:9:"smartCrop";b:1;s:12:"carouselMode";b:0;s:6:"easing";s:6:"linear";s:8:"autoPlay";b:1;s:11:"thumb_width";i:150;s:12:"thumb_height";i:100;}') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Wednesday 20. November 2013 11:36 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (29 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2013-09-07 12:44:34', '2013-09-07 12:44:34', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2013-11-16 13:30:19', '2013-11-16 13:30:19', '', 0, 'http://www.andytan.net/tigers/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2013-09-07 12:44:34', '2013-09-07 12:44:34', 'This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2013-09-07 12:44:34', '2013-09-07 12:44:34', '', 0, 'http://www.andytan.net/tigers/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2013-10-20 03:58:23', '2013-10-20 03:58:23', '', 'Something', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2013-10-20 03:58:23', '2013-10-20 03:58:23', '', 4, 'http://www.andytan.net/tigers/uncategorized/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2013-10-20 03:58:23', '2013-10-20 03:58:23', '', 'Something', '', 'publish', 'open', 'open', '', 'something', '', '', '2013-10-20 03:58:23', '2013-10-20 03:58:23', '', 0, 'http://www.andytan.net/tigers/?p=4', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2013-11-10 02:43:26', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-10 02:43:26', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=8', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2013-11-10 02:43:26', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-10 02:43:26', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=9', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2013-11-10 11:35:02', '2013-11-10 11:35:02', '', 'Baby Ming Hao', '', 'publish', 'open', 'open', '', 'baby-ming-hao', '', '', '2013-11-10 11:35:02', '2013-11-10 11:35:02', '', 2, 'http://www.andytan.net/tigers/?page_id=11', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2013-11-10 11:35:02', '2013-11-10 11:35:02', '', 'Baby Ming Hao', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2013-11-10 11:35:02', '2013-11-10 11:35:02', '', 11, 'http://www.andytan.net/tigers/uncategorized/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2013-11-13 13:05:24', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 13:05:24', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=13', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2013-11-13 13:05:24', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 13:05:24', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=14', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2013-11-13 13:05:24', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 13:05:24', '0000-00-00 00:00:00', '', 2, 'http://www.andytan.net/tigers/?p=15', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (16, 1, '2013-11-13 13:33:35', '2013-11-13 13:33:35', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit "Send"]</p>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://www.andytan.net/tigers)
andy.tan2624@gmail.com


0

[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://www.andytan.net/tigers)
[your-email]


0
Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.', 'Contact form 1', '', 'publish', 'open', 'open', '', 'contact-form-1', '', '', '2013-11-13 13:33:35', '2013-11-13 13:33:35', '', 0, 'http://www.andytan.net/tigers/?post_type=wpcf7_contact_form&p=16', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2013-11-13 13:34:05', '2013-11-13 13:34:05', '[contact-form-7 id="16" title="Contact form 1"]', 'Contact', '', 'publish', 'open', 'open', '', 'contact', '', '', '2013-11-13 13:34:05', '2013-11-13 13:34:05', '', 0, 'http://www.andytan.net/tigers/?page_id=17', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (18, 1, '2013-11-13 13:34:05', '2013-11-13 13:34:05', '[contact-form-7 id="16" title="Contact form 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2013-11-13 13:34:05', '2013-11-13 13:34:05', '', 17, 'http://www.andytan.net/tigers/uncategorized/17-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (19, 1, '2013-11-15 12:29:30', '2013-11-15 12:29:30', '', 'Work', '', 'publish', 'closed', 'closed', '', 'acf_work', '', '', '2013-11-15 12:38:36', '2013-11-15 12:38:36', '', 0, 'http://www.andytan.net/tigers/?post_type=acf&#038;p=19', 0, 'acf', '', 0) ; 
INSERT INTO `wp_posts` VALUES (20, 1, '2013-11-15 12:36:03', '2013-11-15 12:36:03', '', 'Testimonials', '', 'trash', 'closed', 'closed', '', 'acf_testimonials', '', '', '2013-11-15 12:40:27', '2013-11-15 12:40:27', '', 0, 'http://www.andytan.net/tigers/?post_type=acf&#038;p=20', 0, 'acf', '', 0) ; 
INSERT INTO `wp_posts` VALUES (21, 1, '2013-11-15 12:37:05', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2013-11-15 12:37:05', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?post_type=work&p=21', 0, 'work', '', 0) ; 
INSERT INTO `wp_posts` VALUES (22, 1, '2013-11-15 12:39:38', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2013-11-15 12:39:38', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?post_type=work&p=22', 0, 'work', '', 0) ; 
INSERT INTO `wp_posts` VALUES (23, 1, '2013-11-15 12:41:23', '2013-11-15 12:41:23', '', 'Testimonial', '', 'trash', 'closed', 'closed', '', 'acf_testimonial', '', '', '2013-11-16 13:29:57', '2013-11-16 13:29:57', '', 0, 'http://www.andytan.net/tigers/?post_type=acf&#038;p=23', 0, 'acf', '', 0) ; 
INSERT INTO `wp_posts` VALUES (24, 1, '2013-11-15 14:08:50', '2013-11-15 14:08:50', '', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2013-11-15 14:08:50', '2013-11-15 14:08:50', '', 0, 'http://www.andytan.net/tigers/?page_id=24', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (25, 1, '2013-11-15 14:08:50', '2013-11-15 14:08:50', '', 'Home', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2013-11-15 14:08:50', '2013-11-15 14:08:50', '', 24, 'http://www.andytan.net/tigers/uncategorized/24-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (26, 1, '2013-11-15 14:12:11', '2013-11-15 14:12:11', ' ', '', '', 'publish', 'open', 'open', '', '26', '', '', '2013-11-15 14:12:20', '2013-11-15 14:12:20', '', 0, 'http://www.andytan.net/tigers/?p=26', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (27, 1, '2013-11-15 14:12:11', '2013-11-15 14:12:11', ' ', '', '', 'publish', 'open', 'open', '', '27', '', '', '2013-11-15 14:12:20', '2013-11-15 14:12:20', '', 0, 'http://www.andytan.net/tigers/?p=27', 4, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (28, 1, '2013-11-15 14:12:11', '2013-11-15 14:12:11', ' ', '', '', 'publish', 'open', 'open', '', '28', '', '', '2013-11-15 14:12:20', '2013-11-15 14:12:20', '', 0, 'http://www.andytan.net/tigers/?p=28', 2, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (29, 1, '2013-11-15 14:12:11', '2013-11-15 14:12:11', ' ', '', '', 'publish', 'open', 'open', '', '29', '', '', '2013-11-15 14:12:20', '2013-11-15 14:12:20', '', 2, 'http://www.andytan.net/tigers/?p=29', 3, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (30, 1, '2013-11-16 12:45:15', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2013-11-16 12:45:15', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?post_type=work&p=30', 0, 'work', '', 0) ; 
INSERT INTO `wp_posts` VALUES (31, 1, '2013-11-16 12:51:20', '2013-11-16 12:51:20', '', 'Liam', '', 'trash', 'closed', 'closed', '', 'acf_liam', '', '', '2013-11-16 13:30:06', '2013-11-16 13:30:06', '', 0, 'http://www.andytan.net/tigers/?post_type=acf&#038;p=31', 0, 'acf', '', 0) ; 
INSERT INTO `wp_posts` VALUES (32, 1, '2013-11-16 13:30:19', '2013-11-16 13:30:19', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2013-11-16 13:30:19', '2013-11-16 13:30:19', '', 1, 'http://www.andytan.net/tigers/1-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (33, 1, '2013-11-16 22:46:22', '2013-11-16 22:46:22', '', 'New Slider', '', 'publish', 'open', 'open', '', 'new-slider', '', '', '2013-11-16 22:46:22', '2013-11-16 22:46:22', '', 0, 'http://www.andytan.net/tigers/?post_type=ml-slider&p=33', 0, 'ml-slider', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Wednesday 20. November 2013 11:36 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (13 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (3, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (4, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (6, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (4, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (26, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (27, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (28, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (29, 3, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1, 4, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Wednesday 20. November 2013 11:36 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (5 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'link_category', '', 0, 7) ; 
INSERT INTO `wp_term_taxonomy` VALUES (3, 3, 'nav_menu', '', 0, 4) ; 
INSERT INTO `wp_term_taxonomy` VALUES (4, 4, 'category', '', 0, 1) ; 
INSERT INTO `wp_term_taxonomy` VALUES (5, 5, 'ml-slider', '', 0, 0) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Wednesday 20. November 2013 11:36 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (5 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Blogroll', 'blogroll', 0) ; 
INSERT INTO `wp_terms` VALUES (3, 'Main Menu', 'main-menu', 0) ; 
INSERT INTO `wp_terms` VALUES (4, 'Featured', 'featured', 0) ; 
INSERT INTO `wp_terms` VALUES (5, '33', '33', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Wednesday 20. November 2013 11:36 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (19 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'aim', '') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'yim', '') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'jabber', '') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '7') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_customize_current_theme_link,wp350_media') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'wp_user-settings', 'editor=tinymce&hidetb=1&libraryContent=browse') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'wp_user-settings-time', '1382243143') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Wednesday 20. November 2013 11:36 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'andy.tan2624', '$P$BIJNjFU5EZ3u/C/wMhI3gi1h/BfdvK1', 'admin', 'andy.tan2624@gmail.com', '', '2013-09-07 12:44:34', '', 0, 'admin') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

