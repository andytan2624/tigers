# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Thursday 14. November 2013 02:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Thursday 14. November 2013 02:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_comments (1 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2010-06-18 20:51:35', '2010-06-18 20:51:35', 'Hi, this is a comment.<br />To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Thursday 14. November 2013 02:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_links (7 records)
#
 
INSERT INTO `wp_links` VALUES (1, 'http://codex.wordpress.org/', 'Documentation', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (2, 'http://wordpress.org/development/', 'WordPress Blog', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', 'http://wordpress.org/development/feed/') ; 
INSERT INTO `wp_links` VALUES (3, 'http://wordpress.org/extend/ideas/', 'Suggest Ideas', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (4, 'http://wordpress.org/support/', 'Support Forum', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (5, 'http://wordpress.org/extend/plugins/', 'Plugins', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (6, 'http://wordpress.org/extend/themes/', 'Themes', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ; 
INSERT INTO `wp_links` VALUES (7, 'http://planet.wordpress.org/', 'WordPress Planet', '', '', '', 'Y', 1, 0, '0000-00-00 00:00:00', '', '', '') ;
#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Thursday 14. November 2013 02:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=580 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_options (162 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://localhost/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'blogname', 'Gosford Junior Australian Football Club', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogdescription', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'admin_email', 'andy.tan2624@gmail.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'date_format', 'F j, Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'time_format', 'g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_updated_date_format', 'F j, Y g:i a', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'links_recently_updated_prepend', '<em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'links_recently_updated_append', '</em>', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'links_recently_updated_time', '120', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'permalink_structure', '/%category%/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (33, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (36, 'active_plugins', 'a:6:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";i:3;s:30:"lightbox-plus/lightboxplus.php";i:4;s:45:"limit-login-attempts/limit-login-attempts.php";i:5;s:40:"twitter-widget-pro/wp-twitter-widget.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'home', 'http://www.andytan.net/tigers', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (41, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'recently_edited', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'template', 'expound', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'stylesheet', 'expound', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (49, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'db_version', '25824', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'upload_path', '/home/andytann/public_html/tigers/wp-content/uploads', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'blog_public', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (83, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'timezone_string', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'embed_size_w', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'embed_size_h', '600', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'page_on_front', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (98, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (100, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (101, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:9:"twitter-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (102, 'ftp_credentials', 'a:3:{s:8:"hostname";s:9:"localhost";s:8:"username";N;s:15:"connection_type";s:3:"ftp";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (103, 'uninstall_plugins', 'a:2:{s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";s:22:"hupso_plugin_uninstall";s:30:"lightbox-plus/lightboxplus.php";s:12:"UninstallLBP";}', 'no') ; 
INSERT INTO `wp_options` VALUES (104, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (105, 'link_manager_enabled', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (106, 'initial_db_version', '15260', 'yes') ; 
INSERT INTO `wp_options` VALUES (107, 'db_upgraded', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (108, 'cron', 'a:6:{i:1384397083;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1384397214;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1384401455;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1384412400;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1384470000;a:1:{s:19:"hmbkp_schedule_hook";a:2:{s:32:"61a45f8e0e711228d9f0aa04271d0a05";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:9:"default-2";}s:8:"interval";i:604800;}s:32:"887abd106b36605fbb285d0dec9f47ac";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:9:"default-1";}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (506, 'rewrite_rules', 'a:72:{s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:31:".+?/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:".+?/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:".+?/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:".+?/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"(.+?)/([^/]+)/trackback/?$";s:57:"index.php?category_name=$matches[1]&name=$matches[2]&tb=1";s:46:"(.+?)/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:41:"(.+?)/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&feed=$matches[3]";s:34:"(.+?)/([^/]+)/page/?([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&paged=$matches[3]";s:41:"(.+?)/([^/]+)/comment-page-([0-9]{1,})/?$";s:70:"index.php?category_name=$matches[1]&name=$matches[2]&cpage=$matches[3]";s:26:"(.+?)/([^/]+)(/[0-9]+)?/?$";s:69:"index.php?category_name=$matches[1]&name=$matches[2]&page=$matches[3]";s:20:".+?/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:".+?/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:".+?/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:".+?/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:33:"(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:26:"(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:33:"(.+?)/comment-page-([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&cpage=$matches[2]";s:8:"(.+?)/?$";s:35:"index.php?category_name=$matches[1]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (118, 'limit_login_retries', 'a:1:{s:3:"::1";i:1;}', 'no') ; 
INSERT INTO `wp_options` VALUES (237, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (576, '_site_transient_timeout_theme_roots', '1384374837', 'yes') ; 
INSERT INTO `wp_options` VALUES (577, '_site_transient_theme_roots', 'a:4:{s:7:"expound";s:7:"/themes";s:10:"tigertheme";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (541, '_transient_timeout_feed_808390979aa7eed5a9c06ad6a9dd19d0', '1384386929', 'no') ; 
INSERT INTO `wp_options` VALUES (542, '_transient_feed_808390979aa7eed5a9c06ad6a9dd19d0', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:4:"
  
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:33:"
    
    
    
    
    
    
  ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:56:"link:http://www.andytan.net/tigers/ - Google Blog Search";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:93:"http://www.google.com/search?ie=utf-8&q=link:http://www.andytan.net/tigers/&tbm=blg&tbs=sbd:1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:87:"Your search - <b>link:http://www.andytan.net/tigers/</b> - did not match any documents.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://a9.com/-/spec/opensearch/1.1/";a:3:{s:12:"totalResults";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:10:"startIndex";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:12:"itemsPerPage";a:1:{i:0;a:5:{s:4:"data";s:2:"10";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:9:{s:12:"content-type";s:28:"text/xml; charset=ISO-8859-1";s:4:"date";s:29:"Wed, 13 Nov 2013 10:53:41 GMT";s:7:"expires";s:2:"-1";s:13:"cache-control";s:18:"private, max-age=0";s:10:"set-cookie";a:2:{i:0;s:143:"PREF=ID=80edd9d550b1c3c2:FF=0:TM=1384340021:LM=1384340021:S=UHX3buPIMCqGz4Jr; expires=Fri, 13-Nov-2015 10:53:41 GMT; path=/; domain=.google.com";i:1;s:212:"NID=67=whN0YpXZ7fZMyGcWnnTj1GHNeWDMkROLCO5sUP_LLdeX3p9DElS-7uJtH4gbB0Z-WZ32J9GcDFG8XaCoDRZOZcB-ZlxBgbw06lQcdkFxUGEzxS5FtvB8i67UDZbuj7bo; expires=Thu, 15-May-2014 10:53:41 GMT; path=/; domain=.google.com; HttpOnly";}s:3:"p3p";s:122:"CP="This is not a P3P policy! See http://www.google.com/support/accounts/bin/answer.py?hl=en&answer=151657 for more info."";s:6:"server";s:3:"gws";s:16:"x-xss-protection";s:13:"1; mode=block";s:15:"x-frame-options";s:10:"SAMEORIGIN";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (119, 'limit_login_retries_valid', 'a:1:{s:3:"::1";i:1381796543;}', 'no') ; 
INSERT INTO `wp_options` VALUES (120, '_transient_random_seed', '05b1f52ae0bf7e1973415ec8bad6f650', 'yes') ; 
INSERT INTO `wp_options` VALUES (123, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:29:"http://www.andytan.net/tigers";s:4:"link";s:105:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://www.andytan.net/tigers/";s:3:"url";s:138:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://www.andytan.net/tigers/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:26:"http://wordpress.org/news/";s:3:"url";s:31:"http://wordpress.org/news/feed/";s:5:"title";s:14:"WordPress Blog";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:28:"http://planet.wordpress.org/";s:3:"url";s:33:"http://planet.wordpress.org/feed/";s:5:"title";s:20:"Other WordPress News";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (374, 'twp_version', '2.6.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (241, 'hmbkp_default_path', '/Applications/MAMP/htdocs/tigers/wp-content/backupwordpress-43bcb68547-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (242, 'hmbkp_path', '/Applications/MAMP/htdocs/tigers/wp-content/backupwordpress-43bcb68547-backups', 'yes') ; 
INSERT INTO `wp_options` VALUES (464, '_transient_timeout_plugin_slugs', '1384436016', 'no') ; 
INSERT INTO `wp_options` VALUES (465, '_transient_plugin_slugs', 'a:8:{i:0;s:19:"akismet/akismet.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:2;s:36:"contact-form-7/wp-contact-form-7.php";i:3;s:9:"hello.php";i:4;s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";i:5;s:30:"lightbox-plus/lightboxplus.php";i:6;s:45:"limit-login-attempts/limit-login-attempts.php";i:7;s:40:"twitter-widget-pro/wp-twitter-widget.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (535, '_transient_timeout_feed_a09314b1a57acfaba9faaca775e0e5d2', '1384386927', 'no') ; 
INSERT INTO `wp_options` VALUES (536, '_transient_feed_a09314b1a57acfaba9faaca775e0e5d2', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:51:"
	
	
	
	
	
	
		
		
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:26:"Range:  Week in WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:13:"http://ran.ge";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:45:"High quality design and WordPress development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 22:18:21 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"en-US";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:29:"http://wordpress.org/?v=3.7.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"Brian guest appears on a podcast  Week in WordPress!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/11/01/brian-guest-appears-on-a-podcast/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:67:"http://ran.ge/2013/11/01/brian-guest-appears-on-a-podcast/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 01 Nov 2013 21:03:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:13:"Uncategorized";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4131";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:167:"Our own Brian Krogsgard talked to Matt Medeiros and Scott Sousa of Slocum Studio on Week in WordPress, a podcast about the news of the week in the WordPress ecosystem.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:555:"<p>Our own Brian Krogsgard talked to Matt Medeiros and Scott Sousa of <a href="http://slocumstudio.com/">Slocum Studio</a> on Week in WordPress, a podcast about the news of the week in the WordPress ecosystem.</p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/81i_v73ONgQ?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:63:"http://ran.ge/2013/11/01/brian-guest-appears-on-a-podcast/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:22:"Ranger Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"http://ran.ge/2013/10/13/ranger-brian-krogsgard/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:57:"http://ran.ge/2013/10/13/ranger-brian-krogsgard/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 13 Oct 2013 17:45:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:5:"Range";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4112";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:348:"Hey y&#8217;all. My name is Brian Krogsgard, and I&#8217;m happy to be joining Range as a Junior Partner. I&#8217;m looking forward to working with the outstanding team here. I&#8217;ve followed Range since its inception, and I&#8217;ve always loved their mentality that a small company could do big things. So, who am I? I graduated from [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:15:"Brian Krogsgard";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1658:"<p><span style="line-height: 1.5;">Hey y&#8217;all. My name is Brian Krogsgard, and I&#8217;m happy to be joining Range as a Junior Partner. I&#8217;m looking forward to working with the outstanding team here.</span></p>
<p>I&#8217;ve followed Range since its inception, and I&#8217;ve always loved their mentality that a small company could do big things.</p>
<p>So, who am I?</p>
<p>I graduated from Auburn University with an Industrial Engineering degree, and for a few years web development was purely a hobby for me. My first job was as a technical sales engineer in the manufacturing industry, where I got my feet wet learning the value of effectively managing customer relationships and complex projects from start to finish.</p>
<p>But eventually I made the leap and turned my web development hobby into my career. Today, I bring experience building websites large and small across a variety of industries. I specialize in theme and light plugin development.</p>
<p>I also keep a keen eye on what&#8217;s happening in the WordPress community. I run a WordPress news blog called Post Status, which helps me learn more about my craft, share what I learn, and get to know many wonderful people that make the WordPress ecosystem great.</p>
<p>I&#8217;m based out of Birmingham, Alabama, where I live with my wife, Erica, and our blue Great Dane, Lucy May. I organize the Birmingham WordPress Meetup Group and co-organize WordCamp Birmingham.</p>
<p>At Range, I&#8217;ll wear many hats, just like Sara, Pete, and Aaron. My skill set compliments theirs nicely, and I really look forward to learning from them and bringing my best efforts to the table.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ran.ge/2013/10/13/ranger-brian-krogsgard/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"7";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:57:"
		
		
		
		
		
				
		
		
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:36:"Disney Books relaunches on WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"http://ran.ge/2013/10/10/disney-books-relaunches-on-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:71:"http://ran.ge/2013/10/10/disney-books-relaunches-on-wordpress/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Oct 2013 14:32:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:6:{i:0;a:5:{s:4:"data";s:8:"Branding";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:6:"Design";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:9:"Front End";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:4;a:5:{s:4:"data";s:17:"Project Spotlight";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:5;a:5:{s:4:"data";s:9:"WordPress";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4082";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:348:"Disney Publishing Worldwide has relaunched it&#8217;s books site, books.disney.com, on WordPress. When Disney came to us, we were excited, but it was clear that the biggest struggle was going to be the timeline. They wanted to build an all new books.disney.com on WordPress, and they needed it in less than a month. It was a tall order, [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Pete Mall";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1719:"<p><img class="size-large alignright" alt="disney-books-iphone" style="box-shadow: none;" src="http://s1.ran.ge/content/uploads/2013/10/disney-books-iphone-241x500.png" width="241" height="500" /><br />
Disney Publishing Worldwide has relaunched it&#8217;s books site, <a title="Disney Publishing Worldwide" href="http://books.disney.com/">books.disney.com</a>, on WordPress. When Disney came to us, we were excited, but it was clear that the biggest struggle was going to be the timeline. They wanted to build an all new books.disney.com on WordPress, and they needed it in less than a month. It was a tall order, but we pulled it off. From concept, to wireframing, design, development, and launch, Range put in a team effort to design and build the new books.disney.com.</p>
<p>In order to keep such a tight timeline, we knew wireframes needed to be done in less than a week, and the design needed to be finished just a week after that. Sara Cannon stepped up to the plate to lead the wireframes and design, and kept the schedule right on track. The design is also responsive, so it looks great on every device.</p>
<p>The development team pulled some crazy hours for a little while there, but the end result is an amazing site that meets our client&#8217;s needs and was delivered on time. We couldn&#8217;t have done it without Disney, who was a great partner. They held up their end of the bargain to trust our instincts and give quick feedback every time we needed it.</p>
<p>We are proud of the end result, and we hope you like it too. Be sure to <a title="Disney Publishing Worldwide" href="http://books.disney.com/">check out the site</a>, and who knows, you may find a new book for you and your family.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:67:"http://ran.ge/2013/10/10/disney-books-relaunches-on-wordpress/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:50:"Sara Cannon’s Be the Unicorn Published on Torque";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ran.ge/2013/07/29/sara-cannons-be-the-unicorn/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:62:"http://ran.ge/2013/07/29/sara-cannons-be-the-unicorn/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 30 Jul 2013 04:35:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:7:"Writing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"unicorns";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:7:"writing";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=4024";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:342:"Check Out the full post on Torque at WCSF! Be The Unicorn by Sara Cannon What’s all this talk about Unicorns? Beautiful, sparkling, Golden Unicorns. My beginnings in Web Design and Development surfaced out of a love for technology an art. I was an artist and print designer with a thirst for something more. Because I wanted to [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2904:"<p><strong>Check Out the full post on <a href="http://torquemag.io/be-the-unicorn/">Torque</a> at WCSF!</strong></p>
<h3 style="padding-left: 60px;">Be The Unicorn by Sara Cannon</h3>
<p style="padding-left: 60px;">What’s all this talk about Unicorns? Beautiful, sparkling, Golden Unicorns.</p>
<p dir="ltr" style="padding-left: 60px;">My beginnings in Web Design and Development surfaced out of a love for technology an art. I was an artist and print designer with a thirst for something more. Because I wanted to be relevant and engaged, I ended up diving head first into the fast moving waters of web design and development. To get things done, I hunkered down, studied, imitated, and learned. To be completely self-sustainable, you end up learning bits of everything. I strived to become a renaissance woman. I wanted to build and create, without needing to rely on others to achieve my goals.</p>
<p dir="ltr" style="padding-left: 60px;">A few years later, I was hired by a small agency that really needed a one woman show. They did not want to need to rely multiple departments and titles to get the job done.</p>
<h3 dir="ltr" style="padding-left: 60px;">They needed a Golden Unicorn<img alt="" src="https://lh4.googleusercontent.com/Kf7Lg_5t9odG5Kjj7LF1MPQA39rSG3P_Thk7egmbWK8GEwAJ9hQ6lFcCZbFxbE3__nTgYNeF7qdMWcXI0Y0bl_lDQQFjQFsnrh_J2bZiyJGK_H-tNbPZbgZ8" width="223px;" height="233px;" /></h3>
<p dir="ltr" style="padding-left: 60px;">They wanted someone who could not only always solve the technical problems at hand, but had an eye for design and user experience. Someone who could say “yes that can happen” without hesitation and then google it right after making the promise. Since then, I decided to strive to be the unicorn.</p>
<p dir="ltr" style="padding-left: 60px;">In the industry now, there seems to be a long standing tension between designers and developers. This tension is manifested in the workplace, in social settings, but it is also within ourselves – with how we think. It is the longstanding battle of the left brain and right brain. The left side of the brain is known to be logical, analytical, and objective (hello technical directors!) while the right side is known to be intuitive, thoughtful, and subjective (creative thinkers). But the one thing both sides of our brains have in common is Problem Solving. Even though both sides are radically different, there is a common thread there. No one wants to be a code monkey or a pixel pusher. We want to solve problems, and do great work.</p>
<p dir="ltr" style="padding-left: 60px;"><img alt="" src="https://lh3.googleusercontent.com/Qw9xPk_1Ao-OXe8S2SSW0Qe78766iau8sXfgAQxvW46rljL5hG-ejlInKKnFFLPpSslgx0TYxyN-kS2lJ_T6l6tupzlWf0uaethYaGfFDW1yKzFWo1QLqx0X" width="652px;" height="484px;" /></p>
<p><strong>Check Out the rest of the Post on <a href="http://torquemag.io/be-the-unicorn/">Torque</a></strong></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/07/29/sara-cannons-be-the-unicorn/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:72:"Pete Mall to talk about the YouTube Upload Widget Live today at 10am PDT";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"http://ran.ge/2013/07/10/pete-mall-to-talk-about-the-youtube-upload-widget/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:84:"http://ran.ge/2013/07/10/pete-mall-to-talk-about-the-youtube-upload-widget/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 10 Jul 2013 16:26:07 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:5:"Range";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=3996";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:351:"Join Ran.ge and YouTube this week to find out more about our open source upload widget for WordPress. We will show you how it works and walk you through the source code for the widget itself. Tune in to @YouTube Developers Live at 10am PDT https://developers.google.com/live/shows/38132276-6003 &#160; update: check out the video of the show [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:840:"<p>Join Ran.ge and YouTube this week to find out more about our open source upload widget for WordPress. We will show you how it works and walk you through the source code for the widget itself.</p>
<p>Tune in to @YouTube Developers Live at 10am PDT</p>
<p><a title="Range and YouTube" href="https://developers.google.com/live/shows/38132276-6003">https://developers.google.com/live/shows/38132276-6003</a></p>
<p>&nbsp;</p>
<p><em>update: check out the video of the show &amp; demo below!</em></p>
<p><span class=\'embed-youtube\' style=\'text-align:center; display: block;\'><iframe class=\'youtube-player\' type=\'text/html\' width=\'640\' height=\'390\' src=\'http://www.youtube.com/embed/LXYwLo4fkIA?version=3&#038;rel=1&#038;fs=1&#038;showsearch=0&#038;showinfo=1&#038;iv_load_policy=1&#038;wmode=transparent\' frameborder=\'0\'></iframe></span></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:80:"http://ran.ge/2013/07/10/pete-mall-to-talk-about-the-youtube-upload-widget/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:32:"Sara Cannon to Speak in Montreal";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/04/17/sara-cannon-to-speak-in-montreal/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:67:"http://ran.ge/2013/04/17/sara-cannon-to-speak-in-montreal/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 17 Apr 2013 18:01:56 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:25:"http://dev.ran.ge/?p=3916";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:320:"I can&#8217;t tell you how excited I am to be able to speak at the Montreal WordPress Developers Meetup and the Montreal Girl Geeks! On Tuesday, April 23: The Future of UI: How Mobile Design is Shaping the Web Web design is not an interactive brochure anymore. Smart mobile devices have forever changed the way [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4096:"<p>I can&#8217;t tell you how excited I am to be able to speak at the <a href="http://wpmtl.org/2013/04/montreal-wordpress-developer_meetup-april-23rd-2013/">Montreal WordPress Developers Meetup</a> and the <a href="http://montrealgirlgeeks.com/2013/04/18/april-event/">Montreal Girl Geeks</a>!</p>
<hr />
<p><img class="size-full wp-image-3918 alignleft" alt="wcmtl-developer-meetup-facebook-size-179px" src="http://s1.ran.ge/content/uploads/2013/05/wcmtl-developer-meetup-facebook-size-179px.png" width="179" height="126" />On Tuesday, April 23:</p>
<p><strong>The Future of UI: How Mobile Design is Shaping the Web</strong></p>
<p>Web design is not an interactive brochure anymore. Smart mobile devices have forever changed the way we think and interact with websites. Now you have to consider an array of things you didn’t have to worry about before, such as HiDPI graphics, UI/UX patterns, touch target sizes, gestures, and managing expectations. All the while not losing track of what’s important: Content.</p>
<p>We’re going to discuss the influence of mobile on design, trends, and implementation methods, as well as how touch is changing our lives. As designers and developers, we can benefit from learning about how mobile is changing the way we interact with websites, and what that means for the future of UI. <a href="http://wpmtl.org/2013/04/montreal-wordpress-developer_meetup-april-23rd-2013/" target="_blank" rel="nofollow nofollow">http://wpmtl.org/2013/04/montreal-wordpress-developer_meetup-april-23rd-2013/</a></p>
<p><iframe style="border: 1px solid #CCC; border-width: 1px 1px 0; margin-bottom: 5px;" src="http://www.slideshare.net/slideshow/embed_code/19911427" height="356" width="427" allowfullscreen="" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></p>
<div style="margin-bottom: 5px;"><strong> <a title="The Future of UI - How Mobile Design is Shaping The Web 2" href="http://www.slideshare.net/saracannon/the-future-of-ui-how-mobile-design-is-shaping-the-web-2" target="_blank">The Future of UI &#8211; How Mobile Design is Shaping The Web 2</a> </strong> from <strong><a href="http://www.slideshare.net/saracannon" target="_blank">Sara Cannon</a></strong></div>
<hr />
<p><img class="alignleft size-full wp-image-3917" alt="MTLGGbarcode1-300x300" src="http://s1.ran.ge/content/uploads/2013/05/MTLGGbarcode1-300x300.jpg" width="300" height="300" />On Thursday, April 25:</p>
<p><strong>Font Swoon!</strong></p>
<p>Times New Roman. Helvetica. Comic Sans. We’ve all got fonts we love to use or love to hate. Typography is one of those topics that’s easy to overlook, but when you bring it up, everyone has an opinion. Sara’s talk is not just for designers spending hours debating on the slant of a curly-quote or the perfect sans serif – it’s for anyone who’s ever typed, read, or even just stared at the screen or page. Because typography is essential to how we read, consume, convey, and process the written word and it’s BFF, design.</p>
<p>Let’s take our relationship with web typography to the next level and crush on the latest fonts, check out some awesome CSS3 implementations, and find incredible inspiration for interaction, refinement and our next dates with negative space. Come fall head over heels with us at Font Swoon! <a href="http://montrealgirlgeeks.com/2013/04/18/april-event/" target="_blank" rel="nofollow nofollow">http://montrealgirlgeeks.com/2013/04/18/april-event/</a></p>
<p><iframe style="border: 1px solid #CCC; border-width: 1px 1px 0; margin-bottom: 5px;" src="http://www.slideshare.net/slideshow/embed_code/19994942" height="356" width="427" allowfullscreen="" frameborder="0" marginwidth="0" marginheight="0" scrolling="no"></iframe></p>
<div style="margin-bottom: 5px;"><strong> <a title="Font swoon" href="http://www.slideshare.net/saracannon/font-swoon" target="_blank">Font swoon</a> </strong> from <strong><a href="http://www.slideshare.net/saracannon" target="_blank">Sara Cannon</a></strong></div>
<p>If you are in Montreal, come on out &#8211; I&#8217;d love to meet you!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:63:"http://ran.ge/2013/04/17/sara-cannon-to-speak-in-montreal/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:28:"Join Me at WordSesh Tonight!";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://ran.ge/2013/04/12/join-me-at-wordsesh-tonight/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:62:"http://ran.ge/2013/04/12/join-me-at-wordsesh-tonight/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 12 Apr 2013 21:24:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"be the unicorn";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:8:"WordSesh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=1844";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:365:"Tonight I&#8217;m going to be speaking at the first ever WordSesh online WordPress Conference! WordSesh is a day of live WordPress presentations from all over the world streamed live, and it&#8217;s free! Tune in at 4UTC 12am EST (midnight tonight!) to join me in my talk &#8220;Be the Unicorn.&#8221; I&#8217;m really looking forward to hearing all the [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:519:"<p>Tonight I&#8217;m going to be speaking at the first ever <a href="http://wordsesh.org/">WordSesh</a> online WordPress Conference! WordSesh is a day of live WordPress presentations from all over the world streamed live, and it&#8217;s free! Tune in at 4UTC 12am EST (midnight tonight!) to join me in my talk &#8220;Be the Unicorn.&#8221;</p>
<p>I&#8217;m really looking forward to hearing all the other awesome speakers! If you can&#8217;t make it, don&#8217;t worry, all the sessions will be recorded. #WPYall</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:58:"http://ran.ge/2013/04/12/join-me-at-wordsesh-tonight/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"Re-thinking WordPress Post Format UI An Exercise ";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:74:"http://ran.ge/2013/04/11/re-thinking-wordpress-post-format-ui-an-exercise/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:83:"http://ran.ge/2013/04/11/re-thinking-wordpress-post-format-ui-an-exercise/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 11 Apr 2013 07:30:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:7:"UI / UX";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:14:"WordPress Core";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=1771";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:338:"Post Formats are slated to drop in 3.6 and are currently in Beta. I love how WordPress is standardizing formats so that when you change your theme, the content format and metadata associated with that format is preserved. This opens up new doors and possibilities for bloggers who want a unique look without having to customize [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:12714:"<div id="attachment_1818" style="width: 1034px" class="wp-caption alignleft"><a href="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach.jpg"><img class="size-large wp-image-1818" alt="Post Format Modal" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach-1024x698.jpg" width="1024" height="698" /></a><p class="wp-caption-text">Post Format Modal</p></div>
<p>Post Formats are slated to drop in 3.6 and are currently in Beta. I love how WordPress is standardizing formats so that when you change your theme, the content format and metadata associated with that format is preserved. This opens up new doors and possibilities for bloggers who want a unique look without having to customize a category display.</p>
<p><img class="alignleft size-full wp-image-1772" alt="3.5 post formats enabled" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.51.52-AM.png" width="299" height="253" />Post formats are currently in WordPress 3.5 but are just in a tiny modal box to you right (if your theme has them enabled)</p>
<p>They don&#8217;t change the metaboxes for use with the content (aka make a &#8220;Video URL&#8221; field when selecting) but in 3.6 they will &#8211; which is exciting.</p>
<p>There has been lots of discussion and wireframes about the Post Formats UI and user testing&#8230; I decided to do an exercise that might address some of the pain points of the current UI&#8217;s iteration.</p>
<h2>Researching Other similar tools</h2>
<h2><strong>WordPress.com New Dash</strong></h2>
<p>Taking a look at the simplified blogging tool for WordPress.com &#8211; they deal with Post Formats right away.</p>
<div id="attachment_1776" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1776" alt="WordPress.com New Dash - Screen right after you hit &quot;New Post&quot;" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.58.11-AM-1024x438.png" width="1024" height="438" /><p class="wp-caption-text">WordPress.com New Dash &#8211; Screen right after you hit &#8220;New Post&#8221;</p></div>
<div id="attachment_1775" style="width: 1068px" class="wp-caption alignleft"><img class=" wp-image-1775" alt="WordPress.com New Dash - Post Page" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.58.22-AM.png" width="1058" height="567" /><p class="wp-caption-text">WordPress.com New Dash &#8211; Post Page :: a simplified version of the one in the admin</p></div>
<div id="attachment_1774" style="width: 1061px" class="wp-caption alignleft"><img class=" wp-image-1774" alt="WordPress.com New Dash - Screen" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-12.58.36-AM.png" width="1051" height="553" /><p class="wp-caption-text">WordPress.com New Dash &#8211; Video Post Selected<br />note the customized interface just for uploading photos</p></div>
<h2><strong style="font-size: 1.2em;"><strong style="font-size: 1.2em;">Tumblr</strong></strong></h2>
<div id="attachment_1784" style="width: 954px" class="wp-caption alignleft"><img class="size-full wp-image-1784" alt="Tumblr.com Dashboard - choose the format from the icons across before posting" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.16.27-AM.png" width="944" height="453" /><p class="wp-caption-text">Tumblr.com Dashboard &#8211; choose the format from the icons across before posting</p></div>
<div id="attachment_1783" style="width: 977px" class="wp-caption alignleft"><img class="size-full wp-image-1783" alt="tumblr.com Post a Video Screen" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.16.41-AM.png" width="967" height="482" /><p class="wp-caption-text">tumblr.com Post a Video Screen</p></div>
<p>The glaring similarities between WordPress.com New Dash and Tumblr is that they are 1) making a post format decision  before they get to the editor and 2) the editor is only giving them the modals and upload buttons that they need. If we think about #1 philosophically from a UX point of view &#8211; the formats are action-centric. They are not passively opening up the post editor then wondering what they are going to post &#8211; they are forced to make a decision, an action, and therefore the UI they are given is tailored to this decision making for a better UX.</p>
<p>Neither Tumblr or New Dash have a way of changing the post formats &#8211; which I think is good because they would lose all the data that they put in there to the custom modals. (more on this later)</p>
<h2><strong style="font-size: 1.2em;"></strong>Current 3.6 Iteration in Beta</h2>
<div id="attachment_1786" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1786" alt="WordPress.com 3.6 Beta" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.28.04-AM-1024x414.png" width="1024" height="414" /><p class="wp-caption-text">WordPress.com 3.6 Beta</p></div>
<p>The current iteration of the new Post-Formats UI that is now in 3.6 Beta has icons for each of the 10 formats spread across the top of the post editor. They are currently passive button-like selectors with a label to the right. Dave Martin ran some user tests on the current UI and the results were <a href="http://make.wordpress.org/ui/2013/04/09/post-formats-usability-test-round-4/">not good</a>.</p>
<p>I decided to do some action-centric decision-first based UI exercises to explore some options.</p>
<h2>Decision Based Approach &#8211; Working Within the Current Menu System</h2>
<p>The first exercise is one based on just using the current menu system. It turns out that it *could* in theory work &#8211; but in reality there are just way too many post formats.</p>
<div id="attachment_1790" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1790" alt="Action-Centric Dashboard Menu" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-h-copy-1024x695.jpg" width="1024" height="695" /><p class="wp-caption-text">Action-Centric Dashboard Menu</p></div>
<div id="attachment_1792" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1792" alt="Post Page - Sub Menu" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-p-copy-1024x698.jpg" width="1024" height="698" /><p class="wp-caption-text">Post Page &#8211; Sub Menu</p></div>
<p>Basically in this iteration, we make the choice in the menu and then the post screen will have just what you need.</p>
<div id="attachment_1794" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1794" alt="Video Post Format - note the simplified interface, the title changes to include the word &quot;video&quot; in it , and the labels are inside the boxes" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-video-post-1024x699.jpg" width="1024" height="699" /><p class="wp-caption-text">Video Post Format &#8211; note the simplified interface, the title changes to include the word &#8220;video&#8221; in it , and the labels are inside the boxes</p></div>
<h2>Changing Formats</h2>
<p>In the above screenshot &#8211; there is a way to change formats (unlike new dash or tumblr.) It is in the publish meta box. This is a more passive-switch than an in-your-face one which is important, as someone would have to completely change their mind to use it. It also falls under the same importance as the other items in the publish meta box.</p>
<div id="attachment_1799" style="width: 307px" class="wp-caption aligncenter"><img class="size-large wp-image-1799 " alt="Post Format Switching" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.57.34-AM.png" width="297" height="270" /><p class="wp-caption-text">Post Format Switching</p></div>
<div id="attachment_1797" style="width: 306px" class="wp-caption aligncenter"><img class="size-full wp-image-1797 " alt="Post Format Switching - drop down option" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.59.19-AM.png" width="296" height="313" /><p class="wp-caption-text">Post Format Switching &#8211; drop down option</p></div>
<div id="attachment_1798" style="width: 304px" class="wp-caption aligncenter"><img class="size-full wp-image-1798 " alt="Post Format Switching - radio button option" src="http://s1.ran.ge/content/uploads/2013/04/Screen-Shot-2013-04-11-at-1.58.42-AM.png" width="294" height="541" /><p class="wp-caption-text">Post Format Switching &#8211; radio button option</p></div>
<p>Exploring both radio buttons for switching or a drop-down &#8211; That meta box currently uses both as a standard, but I think I prefer the radio simply because the icons are visual cues.</p>
<h2>Explorations outside of the current navigation pattern</h2>
<p>So, seeing that the navigation above is a bit cramped - I decided to explore in-page and modal decision patterns.</p>
<div id="attachment_1803" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1803" alt="In Page decision with post editor greyed out. Icons will go away and the &quot;switching&quot; will be in the siidebar like above" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-i-copy-1024x698.jpg" width="1024" height="698" /><p class="wp-caption-text">In Page decision with post editor greyed out. Icons will go away and the &#8220;switching&#8221; will be in the sidebar like above</p></div>
<div id="attachment_1804" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1804" alt="not greyed out but post editor fades in after decision" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-i-copy1-1024x698.jpg" width="1024" height="698" /><p class="wp-caption-text">not greyed out but post editor fades in after decision</p></div>
<div id="attachment_1805" style="width: 1034px" class="wp-caption alignleft"><img class="size-large wp-image-1805" alt="without labels - cursor rollover changes page title" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-in-page-approach-with-cursor-rollover-1024x355.jpg" width="1024" height="355" /><p class="wp-caption-text">without labels &#8211; cursor rollover changes page title</p></div>
<p>While all this is interesting &#8211; I&#8217;m not sure if it feels quite right as it is outside of the typical WordPress interface, but could be explored further.</p>
<h2>Modal Window</h2>
<p>So our natural progression here is to try out a modal. Usually I&#8217;m not-a-fan of modals at all. They tend to be disruptive. After the new media editor launched last release, its made me re-think modals. Lightbox was so terrible and slow &#8211; but using a modal for this action kind of makes sense as you can be on any page and receive it before hitting the post editor, without another page load or coming from any add post action. (think top nav bar add new)</p>
<div id="attachment_1818" style="width: 1034px" class="wp-caption alignleft"><a href="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach.jpg"><img class="size-large wp-image-1818" alt="Post Format Modal" src="http://s1.ran.ge/content/uploads/2013/04/post-formats-classic-modal-approach-1024x698.jpg" width="1024" height="698" /></a><p class="wp-caption-text">Post Format Modal</p></div>
<p>At this point, I am leaning towards a fast modal with a few caveats. 1) you can turn the modal off if you don&#8217;t use other formats as much and just want to use the passive switcher. 2) you can turn all post formats off from within core settings to override what your theme set. 3) you can filter list tables by format (like you do categories.) The last two I think this should be an option regardless of the approach.</p>
<p>However, that being said, I know we are in Beta for 3.6 and the modal window approach might be a bit out of reach for this release. If I were to have a #2 I would say the greyed out post edit UI with the larger icons. approach might be viable (after the decision is made, the icons go away, post editor fades in, and the format switching is in the publish meta box.)</p>
<p>In conclusion, I hope to get some conversation going and hear what everyone else thinks so that we can make WordPress amazing together.</p>
<p><strong><em>update: if anyone else wants to tinker, here are my thrown together photoshop files etc s.sar.ac/071P0S3r2H2Q</em></strong></p>
<p>Update 2: Mark Jaquith is asking for feedback on the Make UI Blog <a href="http://make.wordpress.org/ui/2013/04/11/saracannon-has-posted-her-take-on-a-new/">http://make.wordpress.org/ui/2013/04/11/saracannon-has-posted-her-take-on-a-new/</a></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:79:"http://ran.ge/2013/04/11/re-thinking-wordpress-post-format-ui-an-exercise/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"29";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:51:"
		
		
		
		
		
				
		
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:54:"Globalnews.ca Data Migration The MSSQL to MySQL Delima";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:84:"http://ran.ge/2013/03/26/globalnews-ca-data-migration-and-the-mssql-to-mysql-delima/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:93:"http://ran.ge/2013/03/26/globalnews-ca-data-migration-and-the-mssql-to-mysql-delima/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 26 Mar 2013 16:19:20 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:4:{i:0;a:5:{s:4:"data";s:11:"Development";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:9:"Migration";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:5:"MSSQL";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:3;a:5:{s:4:"data";s:5:"MySQL";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:25:"http://dev.ran.ge/?p=3844";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:350:"Recently Globalnews.ca made the move to WordPress and we were tasked with migrating all their data from their existing custom MSSQL-based environment to the new WordPress environment hosted with WordPress.com VIP. We have a normal process for this kind of thing, and it goes something like this: Create a local WordPress install and get rid [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Aaron D. Campbell";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3593:"<p>Recently Globalnews.ca made the move to WordPress and we were tasked with migrating all their data from their existing custom MSSQL-based environment to the new WordPress environment hosted with <a href="http://vip.wordpress.com/">WordPress.com VIP</a>. We have a normal process for this kind of thing, and it goes something like this:</p>
<ol>
<li>Create a local WordPress install and get rid of the default posts, comments, and meta data.</li>
<li>Put the clients old data into tables in the same WordPress database.</li>
<li>Write a script that pulls the data from the old tables and uses a combination of WordPress functions and direct database queries to put it into the WordPress install.</li>
<li>Check the data and if it&#8217;s not quite right blast out the posts, comments, and meta data and go back to step 3.</li>
<li>When the data is exactly what we want in WordPress we use <a href="http://wp-cli.org/">wp-cli</a> to export the data in <abbr title="WordPress eXtended Rss">WXR</abbr> format, and submit those files to WordPress.com VIP.</li>
</ol>
<p>It sounds pretty straight forward, and usually it is, with the most difficult part obviously being the script that imports the data from the old tables into WordPress. Not this time however. This time the most difficult part turned out to be step 2, putting the clients data into the same database as WordPress. The problem was that the conversion from MSSQL to MySQL was no trivial matter.</p>
<p>Often you can use <a href="http://www.mysql.com/products/workbench/">MySQL Workbench</a> to migrate data from MSSQL to MySQL, so we started by spinning up a Windows cloud server with MSSQL. We imported the data into an MSSQL database on this new server, and then we installed MySQL and the MySQL Workbench. Due to the large amount of data being converted, we ran into memory issues several times and had to resize the cloud server, but once the memory issues were under control we realized that MySQL Workbench simply could not migrate many of the tables that we needed.</p>
<p>After many hours of digging and research, I finally found the problem. It turns out that there were a couple data types that were causing things to choke. In our case that was mostly limited to nvarchar and ntext. Why? Well because MSSQL doesn&#8217;t actually support UTF-8. What?! I know&#8230;I was surprised too, but it seems MSSQL doesn&#8217;t support the standard in character encoding. Instead it has nvarchar and ntext that don&#8217;t store as UTF-8 but offer similar output in a classic Microsoft-proprietary way.</p>
<p>I was able to work around this limitation by creating duplicate tables for each table that contained one of these field types, using nvarchar in place of varchar and ntext in place of text. Then I ran queries to select the data from the old tables and insert it into these newly created tables.</p>
<pre class="brush: sql; title: ; notranslate">
CREATE TABLE [dbo].[ImportFixed](
	[RowNum] [bigint] NULL,
	[post_title] [nvarchar](200) NOT NULL, -- Previously varchar
	[content_html] [ntext] NULL -- Previously text
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
----------------------
INSERT INTO [import].[dbo].[ImportFixed](
	[RowNum],
	[post_title],
	[content_html]
)
SELECT
	[RowNum],
	[post_title],
	[content_html]
FROM [import].[dbo].[Import]
GO
</pre>
<p>This then allowed MySQL Workbench to properly handle the encoding during it&#8217;s migration from MSSQL to MySQL. Even once the process is known it&#8217;s tedious and time consuming at best, but it seems to be very reliable and stable.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:89:"http://ran.ge/2013/03/26/globalnews-ca-data-migration-and-the-mssql-to-mysql-delima/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:52:"Sara Cannon to Speak at WordCamp Atlanta on Saturday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:78:"http://ran.ge/2013/03/12/sara-cannon-to-speak-at-wordcamp-atlanta-on-saturday/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:87:"http://ran.ge/2013/03/12/sara-cannon-to-speak-at-wordcamp-atlanta-on-saturday/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 12 Mar 2013 22:57:50 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:8:"Speaking";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"WordCamp";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:16:"WordCamp Atlanta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:21:"http://ran.ge/?p=1684";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:317:"I&#8217;m so excited to be speaking at WordCamp Atlanta this Saturday! If you haven&#8217;t got tickets, its already SOLD OUT at 450 people. WOW. If you&#8217;re in the South and you missed it, be sure to keep an eye on 2013.Birmingham.WordCamp.org for a date announcement &#38; early tickets for late summer. &#160;";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Sara Cannon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:657:"<p><a href="http://2013.Atlanta.WordCamp.org"><img class="size-full wp-image-3744 alignleft" alt="WCBadge2013-Speaker" src="http://sara-cannon.com/wp-content/uploads/2013/03/WCBadge2013-Speaker.jpg" width="150" height="150" /></a>I&#8217;m so excited to be speaking at <a href="http://2013.atlanta.wordcamp.org/">WordCamp Atlanta</a> this Saturday! If you haven&#8217;t got tickets, its already SOLD OUT at 450 people. WOW. If you&#8217;re in the South and you missed it, be sure to keep an eye on <a href="http://2013.Birmingham.WordCamp.org">2013.Birmingham.WordCamp.org</a> for a date announcement &amp; early tickets for late summer.</p>
<p>&nbsp;</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:83:"http://ran.ge/2013/03/12/sara-cannon-to-speak-at-wordcamp-atlanta-on-saturday/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:19:"http://ran.ge/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Wed, 13 Nov 2013 10:53:38 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";a:2:{i:0;s:15:"Accept-Encoding";i:1;s:6:"Cookie";}s:13:"cache-control";s:28:"max-age=206, must-revalidate";s:12:"x-powered-by";s:21:"PHP/5.4.19-1~dotdeb.0";s:10:"x-pingback";s:27:"http://ran.ge/wp/xmlrpc.php";s:13:"last-modified";s:29:"Fri, 01 Nov 2013 22:18:21 GMT";s:4:"etag";s:34:""21a61201f9b1815ebe86a76fe4ece902"";s:4:"node";s:20:"web11.dfw.wphost.com";}s:5:"build";s:14:"20131111121622";}', 'no') ; 
INSERT INTO `wp_options` VALUES (243, 'hmbkp_schedule_default-1', 'a:3:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:11:"max_backups";i:14;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (244, 'hmbkp_schedule_default-2', 'a:3:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:11:"max_backups";i:12;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (245, 'hmbkp_plugin_version', '2.3.3', 'yes') ; 
INSERT INTO `wp_options` VALUES (547, '_site_transient_timeout_wporg_theme_feature_list', '1384358941', 'yes') ; 
INSERT INTO `wp_options` VALUES (548, '_site_transient_wporg_theme_feature_list', 'a:5:{s:6:"Colors";a:15:{i:0;s:5:"black";i:1;s:4:"blue";i:2;s:5:"brown";i:3;s:4:"gray";i:4;s:5:"green";i:5;s:6:"orange";i:6;s:4:"pink";i:7;s:6:"purple";i:8;s:3:"red";i:9;s:6:"silver";i:10;s:3:"tan";i:11;s:5:"white";i:12;s:6:"yellow";i:13;s:4:"dark";i:14;s:5:"light";}s:7:"Columns";a:6:{i:0;s:10:"one-column";i:1;s:11:"two-columns";i:2;s:13:"three-columns";i:3;s:12:"four-columns";i:4;s:12:"left-sidebar";i:5;s:13:"right-sidebar";}s:5:"Width";a:2:{i:0;s:11:"fixed-width";i:1;s:14:"flexible-width";}s:8:"Features";a:19:{i:0;s:8:"blavatar";i:1;s:10:"buddypress";i:2;s:17:"custom-background";i:3;s:13:"custom-colors";i:4;s:13:"custom-header";i:5;s:11:"custom-menu";i:6;s:12:"editor-style";i:7;s:21:"featured-image-header";i:8;s:15:"featured-images";i:9;s:15:"flexible-header";i:10;s:20:"front-page-post-form";i:11;s:19:"full-width-template";i:12;s:12:"microformats";i:13;s:12:"post-formats";i:14;s:20:"rtl-language-support";i:15;s:11:"sticky-post";i:16;s:13:"theme-options";i:17;s:17:"threaded-comments";i:18;s:17:"translation-ready";}s:7:"Subject";a:3:{i:0;s:7:"holiday";i:1;s:13:"photoblogging";i:2;s:8:"seasonal";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (195, 'theme_mods_twentythirteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1378626744;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:0:{}s:19:"primary-widget-area";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:21:"secondary-widget-area";a:0:{}s:24:"first-footer-widget-area";a:0:{}s:25:"second-footer-widget-area";a:0:{}s:24:"third-footer-widget-area";a:0:{}s:25:"fourth-footer-widget-area";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (196, 'current_theme', 'Expound', 'yes') ; 
INSERT INTO `wp_options` VALUES (197, 'theme_mods_tigertheme', 'a:8:{i:0;b:0;s:16:"header_textcolor";s:6:"e9e0e1";s:16:"background_color";s:6:"e9e0d1";s:16:"background_image";s:0:"";s:17:"background_repeat";s:6:"repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1384348141;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:9:"twitter-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (198, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (248, '_transient_timeout_hmbkp_schedule_default-1_filesize', '2758063022', 'no') ; 
INSERT INTO `wp_options` VALUES (249, '_transient_hmbkp_schedule_default-1_filesize', '411488', 'no') ; 
INSERT INTO `wp_options` VALUES (537, '_transient_timeout_feed_mod_a09314b1a57acfaba9faaca775e0e5d2', '1384386927', 'no') ; 
INSERT INTO `wp_options` VALUES (538, '_transient_feed_mod_a09314b1a57acfaba9faaca775e0e5d2', '1384343727', 'no') ; 
INSERT INTO `wp_options` VALUES (543, '_transient_timeout_feed_mod_808390979aa7eed5a9c06ad6a9dd19d0', '1384386929', 'no') ; 
INSERT INTO `wp_options` VALUES (544, '_transient_feed_mod_808390979aa7eed5a9c06ad6a9dd19d0', '1384343729', 'no') ; 
INSERT INTO `wp_options` VALUES (545, '_transient_timeout_dash_20494a3d90a6669585674ed0eb8dcd8f', '1384386929', 'no') ; 
INSERT INTO `wp_options` VALUES (546, '_transient_dash_20494a3d90a6669585674ed0eb8dcd8f', '<p>This dashboard widget queries <a href="http://blogsearch.google.com/">Google Blog Search</a> so that when another blog links to your site it will show up here. It has found no incoming links&hellip; yet. It&#8217;s okay &#8212; there is no rush.</p>
', 'no') ; 
INSERT INTO `wp_options` VALUES (557, '_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a', '1384359839', 'yes') ; 
INSERT INTO `wp_options` VALUES (567, '_transient_is_multi_author', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (568, '_transient_all_the_cool_cats', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (559, 'hupso_version', '3.9.22', 'yes') ; 
INSERT INTO `wp_options` VALUES (562, 'lightboxplus_options', 'a:57:{s:18:"lightboxplus_multi";s:1:"0";s:10:"use_inline";s:1:"0";s:10:"inline_num";s:1:"5";s:18:"lightboxplus_style";s:5:"black";s:16:"use_custom_style";s:1:"0";s:11:"disable_css";s:1:"0";s:10:"hide_about";s:1:"0";s:12:"output_htmlv";s:1:"0";s:9:"data_name";s:12:"lightboxplus";s:13:"load_location";s:9:"wp_footer";s:13:"load_priority";s:2:"10";s:11:"use_perpage";s:1:"0";s:11:"use_forpage";s:1:"0";s:11:"use_forpost";s:1:"0";s:10:"transition";s:7:"elastic";s:5:"speed";s:1:"0";s:5:"width";s:0:"";s:6:"height";s:0:"";s:11:"inner_width";s:3:"600";s:12:"inner_height";s:0:"";s:13:"initial_width";s:0:"";s:14:"initial_height";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:6:"resize";s:1:"0";s:7:"opacity";s:1:"0";s:10:"preloading";s:1:"0";s:11:"label_image";s:0:"";s:8:"label_of";s:0:"";s:8:"previous";s:0:"";s:4:"next";s:0:"";s:5:"close";s:0:"";s:13:"overlay_close";s:1:"0";s:9:"slideshow";s:1:"0";s:14:"slideshow_auto";s:1:"0";s:15:"slideshow_speed";s:3:"500";s:15:"slideshow_start";s:5:"start";s:14:"slideshow_stop";s:4:"stop";s:17:"use_caption_title";s:1:"0";s:20:"gallery_lightboxplus";s:1:"1";s:18:"multiple_galleries";s:1:"0";s:16:"use_class_method";s:1:"0";s:10:"class_name";s:11:"lbp_primary";s:16:"no_auto_lightbox";s:1:"0";s:10:"text_links";s:1:"0";s:16:"no_display_title";s:1:"0";s:9:"scrolling";s:1:"0";s:5:"photo";s:1:"0";s:3:"rel";s:1:"0";s:4:"loop";s:1:"0";s:7:"esc_key";s:1:"0";s:9:"arrow_key";s:1:"0";s:3:"top";s:0:"";s:6:"bottom";s:0:"";s:4:"left";s:0:"";s:5:"right";s:0:"";s:5:"fixed";s:1:"0";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (564, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1384356730;s:7:"checked";a:8:{s:19:"akismet/akismet.php";s:5:"2.5.9";s:35:"backupwordpress/backupwordpress.php";s:5:"2.3.3";s:36:"contact-form-7/wp-contact-form-7.php";s:5:"3.5.4";s:9:"hello.php";s:3:"1.6";s:71:"hupso-share-buttons-for-twitter-facebook-google/share-buttons-hupso.php";s:6:"3.9.22";s:30:"lightbox-plus/lightboxplus.php";s:3:"2.6";s:45:"limit-login-attempts/limit-login-attempts.php";s:5:"1.7.1";s:40:"twitter-widget-pro/wp-twitter-widget.php";s:5:"2.6.0";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (563, 'wpcf7', 'a:1:{s:7:"version";s:5:"3.5.4";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (508, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (578, '_site_transient_update_themes', 'O:8:"stdClass":1:{s:12:"last_checked";i:1384373038;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (549, 'theme_mods_expound', 'a:7:{i:0;b:0;s:16:"header_textcolor";s:6:"3a3a3a";s:16:"background_color";s:6:"333333";s:16:"background_image";s:0:"";s:17:"background_repeat";s:6:"repeat";s:21:"background_position_x";s:4:"left";s:21:"background_attachment";s:5:"fixed";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (569, '_transient_timeout_tlc_up__e46625b24e3688cd61ea7ba19d802251', '1384349950', 'no') ; 
INSERT INTO `wp_options` VALUES (570, '_transient_tlc_up__e46625b24e3688cd61ea7ba19d802251', 'a:6:{i:0;s:32:"tlc_lock_52837fd2cd10b7.37026784";i:1;s:36:"twp_cab7117af2a233ba68a81a588837edab";i:2;i:300;i:3;a:2:{i:0;O:15:"wpTwitterWidget":14:{s:34:" wpTwitterWidget _wp_twitter_oauth";O:9:"wpTwitter":3:{s:24:" wpTwitter _consumer_key";s:19:"jsu4vXpRoHzNdRdrsrw";s:27:" wpTwitter _consumer_secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:17:" wpTwitter _token";N;}s:12:" * _settings";a:2:{s:3:"twp";a:18:{s:12:"consumer-key";s:19:"jsu4vXpRoHzNdRdrsrw";s:15:"consumer-secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:5:"title";s:0:"";s:6:"errmsg";s:0:"";s:8:"username";s:0:"";s:4:"list";s:0:"";s:13:"http_vs_https";s:5:"https";s:11:"hidereplies";s:5:"false";s:12:"showretweets";s:4:"true";s:8:"hidefrom";s:5:"false";s:11:"showintents";s:4:"true";s:10:"showfollow";s:4:"true";s:6:"avatar";s:0:"";s:15:"showXavisysLink";s:5:"false";s:11:"targetBlank";s:5:"false";s:5:"items";s:2:"10";s:6:"showts";s:5:"86400";s:10:"dateFormat";s:14:"h:i:s A F d, Y";}s:16:"twp-authed-users";a:1:{s:15:"ash_skywalker10";a:4:{s:11:"oauth_token";s:50:"399730397-UUaCZnrCulookeadOgPWcpkEclDv2vZ6IMw9wf8t";s:18:"oauth_token_secret";s:45:"nHgo0EzVefbEbsp5L7FoTlcXaWjSLsu6i0gGOISYFWS7f";s:7:"user_id";s:9:"399730397";s:11:"screen_name";s:15:"ash_skywalker10";}}}s:8:" * _hook";s:16:"twitterWidgetPro";s:8:" * _file";s:40:"twitter-widget-pro/wp-twitter-widget.php";s:13:" * _pageTitle";s:18:"Twitter Widget Pro";s:13:" * _menuTitle";s:14:"Twitter Widget";s:15:" * _accessLevel";s:14:"manage_options";s:15:" * _optionGroup";s:11:"twp-options";s:15:" * _optionNames";a:1:{i:0;s:3:"twp";}s:19:" * _optionCallbacks";a:0:{}s:8:" * _slug";s:18:"twitter-widget-pro";s:12:" * _feed_url";s:19:"http://ran.ge/feed/";s:18:" * _paypalButtonId";s:7:"9993090";s:21:" * _optionsPageAction";s:11:"options.php";}i:1;s:9:"parseFeed";}i:4;a:1:{i:0;a:28:{s:4:"name";s:7:"Sidebar";s:2:"id";s:9:"sidebar-1";s:11:"description";s:0:"";s:5:"class";s:0:"";s:13:"before_widget";s:52:"<aside id="twitter-2" class="widget widget_twitter">";s:12:"after_widget";s:8:"</aside>";s:12:"before_title";s:25:"<h1 class="widget-title">";s:11:"after_title";s:5:"</h1>";s:9:"widget_id";s:9:"twitter-2";s:11:"widget_name";s:18:"Twitter Widget Pro";s:12:"consumer-key";s:19:"jsu4vXpRoHzNdRdrsrw";s:15:"consumer-secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:5:"title";s:0:"";s:6:"errmsg";s:72:"Oops! Looks like Twitter is down, we\'ll get on to this as soon as we can";s:8:"username";s:15:"ash_skywalker10";s:4:"list";s:0:"";s:13:"http_vs_https";s:5:"https";s:11:"hidereplies";s:5:"false";s:12:"showretweets";s:4:"true";s:8:"hidefrom";s:5:"false";s:11:"showintents";s:4:"true";s:10:"showfollow";s:4:"true";s:6:"avatar";s:0:"";s:15:"showXavisysLink";s:5:"false";s:11:"targetBlank";s:5:"false";s:5:"items";i:5;s:6:"showts";s:6:"604800";s:10:"dateFormat";s:14:"h:i:s A F d, Y";}}i:5;i:120;}', 'no') ; 
INSERT INTO `wp_options` VALUES (579, '_transient_doing_cron', '1384396490.5517470836639404296875', 'yes') ; 
INSERT INTO `wp_options` VALUES (438, '_site_transient_timeout_browser_00760e848c8aef5785b4a3f89f42352c', '1384656149', 'yes') ; 
INSERT INTO `wp_options` VALUES (439, '_site_transient_browser_00760e848c8aef5785b4a3f89f42352c', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"30.0.1599.101";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (297, 'theme_mods_wingchun', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1381755221;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";N;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (507, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:41:"https://wordpress.org/wordpress-3.7.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:41:"https://wordpress.org/wordpress-3.7.1.zip";s:10:"no_content";s:52:"https://wordpress.org/wordpress-3.7.1-no-content.zip";s:11:"new_bundled";s:53:"https://wordpress.org/wordpress-3.7.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"3.7.1";s:7:"version";s:5:"3.7.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"3.6";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1384373037;s:15:"version_checked";s:5:"3.7.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (483, 'twp', 'a:16:{s:12:"consumer-key";s:19:"jsu4vXpRoHzNdRdrsrw";s:15:"consumer-secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:8:"username";s:0:"";s:4:"list";s:0:"";s:5:"title";s:0:"";s:5:"items";s:2:"10";s:6:"avatar";s:0:"";s:6:"errmsg";s:0:"";s:6:"showts";s:5:"86400";s:10:"dateFormat";s:14:"h:i:s A F d, Y";s:12:"showretweets";s:4:"true";s:11:"hidereplies";s:5:"false";s:8:"hidefrom";s:5:"false";s:11:"showintents";s:4:"true";s:10:"showfollow";s:4:"true";s:11:"targetBlank";s:5:"false";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (480, 'category_children', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (486, '_twp_request_token_3d960485ab858e08bb82835ccb9838f6', 'a:4:{s:11:"oauth_token";s:42:"t0LdHOY5SNdagZHvUy9oB2wxb60QgYwzIQJ7NgmQ7c";s:18:"oauth_token_secret";s:42:"e8Hq8T4vCFrCbT3fRXOGc6ROXXBXViBRWn9rfduTRU";s:24:"oauth_callback_confirmed";s:4:"true";s:5:"nonce";s:32:"3d960485ab858e08bb82835ccb9838f6";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (488, 'twp-authed-users', 'a:1:{s:15:"ash_skywalker10";a:4:{s:11:"oauth_token";s:50:"399730397-UUaCZnrCulookeadOgPWcpkEclDv2vZ6IMw9wf8t";s:18:"oauth_token_secret";s:45:"nHgo0EzVefbEbsp5L7FoTlcXaWjSLsu6i0gGOISYFWS7f";s:7:"user_id";s:9:"399730397";s:11:"screen_name";s:15:"ash_skywalker10";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (558, '_site_transient_poptags_40cd750bba9870f18aada2478b24840a', 'a:40:{s:6:"widget";a:3:{s:4:"name";s:6:"widget";s:4:"slug";s:6:"widget";s:5:"count";s:4:"3898";}s:4:"post";a:3:{s:4:"name";s:4:"Post";s:4:"slug";s:4:"post";s:5:"count";s:4:"2456";}s:6:"plugin";a:3:{s:4:"name";s:6:"plugin";s:4:"slug";s:6:"plugin";s:5:"count";s:4:"2344";}s:5:"admin";a:3:{s:4:"name";s:5:"admin";s:4:"slug";s:5:"admin";s:5:"count";s:4:"1930";}s:5:"posts";a:3:{s:4:"name";s:5:"posts";s:4:"slug";s:5:"posts";s:5:"count";s:4:"1856";}s:7:"sidebar";a:3:{s:4:"name";s:7:"sidebar";s:4:"slug";s:7:"sidebar";s:5:"count";s:4:"1583";}s:7:"twitter";a:3:{s:4:"name";s:7:"twitter";s:4:"slug";s:7:"twitter";s:5:"count";s:4:"1329";}s:6:"google";a:3:{s:4:"name";s:6:"google";s:4:"slug";s:6:"google";s:5:"count";s:4:"1325";}s:8:"comments";a:3:{s:4:"name";s:8:"comments";s:4:"slug";s:8:"comments";s:5:"count";s:4:"1310";}s:6:"images";a:3:{s:4:"name";s:6:"images";s:4:"slug";s:6:"images";s:5:"count";s:4:"1260";}s:4:"page";a:3:{s:4:"name";s:4:"page";s:4:"slug";s:4:"page";s:5:"count";s:4:"1225";}s:5:"image";a:3:{s:4:"name";s:5:"image";s:4:"slug";s:5:"image";s:5:"count";s:4:"1121";}s:9:"shortcode";a:3:{s:4:"name";s:9:"shortcode";s:4:"slug";s:9:"shortcode";s:5:"count";s:4:"1000";}s:8:"facebook";a:3:{s:4:"name";s:8:"Facebook";s:4:"slug";s:8:"facebook";s:5:"count";s:3:"982";}s:5:"links";a:3:{s:4:"name";s:5:"links";s:4:"slug";s:5:"links";s:5:"count";s:3:"974";}s:3:"seo";a:3:{s:4:"name";s:3:"seo";s:4:"slug";s:3:"seo";s:5:"count";s:3:"950";}s:9:"wordpress";a:3:{s:4:"name";s:9:"wordpress";s:4:"slug";s:9:"wordpress";s:5:"count";s:3:"844";}s:7:"gallery";a:3:{s:4:"name";s:7:"gallery";s:4:"slug";s:7:"gallery";s:5:"count";s:3:"821";}s:6:"social";a:3:{s:4:"name";s:6:"social";s:4:"slug";s:6:"social";s:5:"count";s:3:"780";}s:3:"rss";a:3:{s:4:"name";s:3:"rss";s:4:"slug";s:3:"rss";s:5:"count";s:3:"722";}s:7:"widgets";a:3:{s:4:"name";s:7:"widgets";s:4:"slug";s:7:"widgets";s:5:"count";s:3:"686";}s:6:"jquery";a:3:{s:4:"name";s:6:"jquery";s:4:"slug";s:6:"jquery";s:5:"count";s:3:"681";}s:5:"pages";a:3:{s:4:"name";s:5:"pages";s:4:"slug";s:5:"pages";s:5:"count";s:3:"678";}s:5:"email";a:3:{s:4:"name";s:5:"email";s:4:"slug";s:5:"email";s:5:"count";s:3:"623";}s:4:"ajax";a:3:{s:4:"name";s:4:"AJAX";s:4:"slug";s:4:"ajax";s:5:"count";s:3:"615";}s:5:"media";a:3:{s:4:"name";s:5:"media";s:4:"slug";s:5:"media";s:5:"count";s:3:"595";}s:10:"javascript";a:3:{s:4:"name";s:10:"javascript";s:4:"slug";s:10:"javascript";s:5:"count";s:3:"572";}s:5:"video";a:3:{s:4:"name";s:5:"video";s:4:"slug";s:5:"video";s:5:"count";s:3:"570";}s:10:"buddypress";a:3:{s:4:"name";s:10:"buddypress";s:4:"slug";s:10:"buddypress";s:5:"count";s:3:"541";}s:4:"feed";a:3:{s:4:"name";s:4:"feed";s:4:"slug";s:4:"feed";s:5:"count";s:3:"539";}s:7:"content";a:3:{s:4:"name";s:7:"content";s:4:"slug";s:7:"content";s:5:"count";s:3:"530";}s:5:"photo";a:3:{s:4:"name";s:5:"photo";s:4:"slug";s:5:"photo";s:5:"count";s:3:"522";}s:4:"link";a:3:{s:4:"name";s:4:"link";s:4:"slug";s:4:"link";s:5:"count";s:3:"506";}s:6:"photos";a:3:{s:4:"name";s:6:"photos";s:4:"slug";s:6:"photos";s:5:"count";s:3:"505";}s:5:"login";a:3:{s:4:"name";s:5:"login";s:4:"slug";s:5:"login";s:5:"count";s:3:"471";}s:4:"spam";a:3:{s:4:"name";s:4:"spam";s:4:"slug";s:4:"spam";s:5:"count";s:3:"458";}s:5:"stats";a:3:{s:4:"name";s:5:"stats";s:4:"slug";s:5:"stats";s:5:"count";s:3:"453";}s:8:"category";a:3:{s:4:"name";s:8:"category";s:4:"slug";s:8:"category";s:5:"count";s:3:"452";}s:7:"youtube";a:3:{s:4:"name";s:7:"youtube";s:4:"slug";s:7:"youtube";s:5:"count";s:3:"436";}s:7:"comment";a:3:{s:4:"name";s:7:"comment";s:4:"slug";s:7:"comment";s:5:"count";s:3:"432";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (501, 'widget_twitter', 'a:2:{i:2;a:18:{s:12:"consumer-key";s:19:"jsu4vXpRoHzNdRdrsrw";s:15:"consumer-secret";s:43:"4ED7yZDp3ymvlkK9NSohKLV0bEtkrxOcIN7dKOCKMZ8";s:5:"title";s:0:"";s:6:"errmsg";s:72:"Oops! Looks like Twitter is down, we\'ll get on to this as soon as we can";s:8:"username";s:15:"ash_skywalker10";s:4:"list";s:0:"";s:13:"http_vs_https";s:5:"https";s:11:"hidereplies";s:5:"false";s:12:"showretweets";s:4:"true";s:8:"hidefrom";s:5:"false";s:11:"showintents";s:4:"true";s:10:"showfollow";s:4:"true";s:6:"avatar";s:0:"";s:15:"showXavisysLink";s:5:"false";s:11:"targetBlank";s:5:"false";s:5:"items";s:1:"5";s:6:"showts";s:6:"604800";s:10:"dateFormat";s:14:"h:i:s A F d, Y";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (504, '_transient_timeout_tlc__e46625b24e3688cd61ea7ba19d802251', '1415708395', 'no') ; 
INSERT INTO `wp_options` VALUES (505, '_transient_tlc__e46625b24e3688cd61ea7ba19d802251', 'a:2:{i:0;i:1384172395;i:1;a:1:{i:0;O:8:"stdClass":22:{s:10:"created_at";s:30:"Thu Oct 27 23:20:47 +0000 2011";s:2:"id";i:129699090836627458;s:6:"id_str";s:18:"129699090836627458";s:4:"text";s:138:"@contikiaus #contiki I\'m seeking amazing sights, fantastic architecture, absorb large amounts of history,  DELICIOUS FOOD and good friends";s:6:"source";s:118:"<a href="http://contiki.com.au/pages/1734-europe-2012-13-microsite-fortheseekers" rel="nofollow">Contiki Australia</a>";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";i:17455144;s:23:"in_reply_to_user_id_str";s:8:"17455144";s:23:"in_reply_to_screen_name";s:10:"contikiaus";s:4:"user";O:8:"stdClass":38:{s:2:"id";i:399730397;s:6:"id_str";s:9:"399730397";s:4:"name";s:8:"Andy Tan";s:11:"screen_name";s:15:"ash_skywalker10";s:8:"location";s:0:"";s:11:"description";s:0:"";s:3:"url";N;s:8:"entities";O:8:"stdClass":1:{s:11:"description";O:8:"stdClass":1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:1;s:13:"friends_count";i:0;s:12:"listed_count";i:0;s:10:"created_at";s:30:"Thu Oct 27 23:20:36 +0000 2011";s:16:"favourites_count";i:0;s:10:"utc_offset";N;s:9:"time_zone";N;s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:1;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:79:"http://abs.twimg.com/sticky/default_profile_images/default_profile_3_normal.png";s:23:"profile_image_url_https";s:80:"https://abs.twimg.com/sticky/default_profile_images/default_profile_3_normal.png";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:1;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";O:8:"stdClass":4:{s:8:"hashtags";a:1:{i:0;O:8:"stdClass":2:{s:4:"text";s:7:"contiki";s:7:"indices";a:2:{i:0;i:12;i:1;i:20;}}}s:7:"symbols";a:0:{}s:4:"urls";a:0:{}s:13:"user_mentions";a:1:{i:0;O:8:"stdClass":5:{s:11:"screen_name";s:10:"contikiaus";s:4:"name";s:17:"Contiki Australia";s:2:"id";i:17455144;s:6:"id_str";s:8:"17455144";s:7:"indices";a:2:{i:0;i:0;i:1;i:11;}}}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:4:"lang";s:2:"en";}}}', 'no') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Thursday 14. November 2013 02:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_postmeta (60 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (2, 4, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (5, 8, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (4, 4, '_edit_lock', '1382243026:1') ; 
INSERT INTO `wp_postmeta` VALUES (6, 8, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (7, 8, '_menu_item_object_id', '8') ; 
INSERT INTO `wp_postmeta` VALUES (8, 8, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (9, 8, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (10, 8, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (11, 8, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (12, 8, '_menu_item_url', 'http://www.andytan.net/tigers/') ; 
INSERT INTO `wp_postmeta` VALUES (13, 8, '_menu_item_orphaned', '1384051406') ; 
INSERT INTO `wp_postmeta` VALUES (14, 9, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (15, 9, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (16, 9, '_menu_item_object_id', '2') ; 
INSERT INTO `wp_postmeta` VALUES (17, 9, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (18, 9, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (19, 9, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (20, 9, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (21, 9, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (22, 9, '_menu_item_orphaned', '1384051406') ; 
INSERT INTO `wp_postmeta` VALUES (23, 11, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (24, 11, '_edit_lock', '1384089066:1') ; 
INSERT INTO `wp_postmeta` VALUES (25, 11, '_wp_page_template', 'default') ; 
INSERT INTO `wp_postmeta` VALUES (26, 13, '_menu_item_type', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (27, 13, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (28, 13, '_menu_item_object_id', '13') ; 
INSERT INTO `wp_postmeta` VALUES (29, 13, '_menu_item_object', 'custom') ; 
INSERT INTO `wp_postmeta` VALUES (30, 13, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (31, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (32, 13, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (33, 13, '_menu_item_url', 'http://www.andytan.net/tigers/') ; 
INSERT INTO `wp_postmeta` VALUES (34, 13, '_menu_item_orphaned', '1384347924') ; 
INSERT INTO `wp_postmeta` VALUES (35, 14, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (36, 14, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (37, 14, '_menu_item_object_id', '2') ; 
INSERT INTO `wp_postmeta` VALUES (38, 14, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (39, 14, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (40, 14, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (41, 14, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (42, 14, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (43, 14, '_menu_item_orphaned', '1384347924') ; 
INSERT INTO `wp_postmeta` VALUES (44, 15, '_menu_item_type', 'post_type') ; 
INSERT INTO `wp_postmeta` VALUES (45, 15, '_menu_item_menu_item_parent', '0') ; 
INSERT INTO `wp_postmeta` VALUES (46, 15, '_menu_item_object_id', '11') ; 
INSERT INTO `wp_postmeta` VALUES (47, 15, '_menu_item_object', 'page') ; 
INSERT INTO `wp_postmeta` VALUES (48, 15, '_menu_item_target', '') ; 
INSERT INTO `wp_postmeta` VALUES (49, 15, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ; 
INSERT INTO `wp_postmeta` VALUES (50, 15, '_menu_item_xfn', '') ; 
INSERT INTO `wp_postmeta` VALUES (51, 15, '_menu_item_url', '') ; 
INSERT INTO `wp_postmeta` VALUES (52, 15, '_menu_item_orphaned', '1384347924') ; 
INSERT INTO `wp_postmeta` VALUES (53, 16, '_form', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit "Send"]</p>') ; 
INSERT INTO `wp_postmeta` VALUES (54, 16, '_mail', 'a:7:{s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:206:"From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://www.andytan.net/tigers)";s:9:"recipient";s:22:"andy.tan2624@gmail.com";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (55, 16, '_mail_2', 'a:8:{s:6:"active";b:0;s:7:"subject";s:14:"[your-subject]";s:6:"sender";s:26:"[your-name] <[your-email]>";s:4:"body";s:148:"Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://www.andytan.net/tigers)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:0:"";s:11:"attachments";s:0:"";s:8:"use_html";i:0;}') ; 
INSERT INTO `wp_postmeta` VALUES (56, 16, '_messages', 'a:6:{s:12:"mail_sent_ok";s:43:"Your message was sent successfully. Thanks.";s:12:"mail_sent_ng";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:16:"validation_error";s:74:"Validation errors occurred. Please confirm the fields and submit it again.";s:4:"spam";s:93:"Failed to send your message. Please try later or contact the administrator by another method.";s:12:"accept_terms";s:35:"Please accept the terms to proceed.";s:16:"invalid_required";s:31:"Please fill the required field.";}') ; 
INSERT INTO `wp_postmeta` VALUES (57, 16, '_additional_settings', '') ; 
INSERT INTO `wp_postmeta` VALUES (58, 16, '_locale', 'en_US') ; 
INSERT INTO `wp_postmeta` VALUES (59, 17, '_edit_last', '1') ; 
INSERT INTO `wp_postmeta` VALUES (60, 17, '_edit_lock', '1384349645:1') ; 
INSERT INTO `wp_postmeta` VALUES (61, 17, '_wp_page_template', 'default') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Thursday 14. November 2013 02:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_posts (16 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2013-09-07 12:44:34', '2013-09-07 12:44:34', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2013-09-07 12:44:34', '2013-09-07 12:44:34', '', 0, 'http://www.andytan.net/tigers/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2013-09-07 12:44:34', '2013-09-07 12:44:34', 'This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2013-09-07 12:44:34', '2013-09-07 12:44:34', '', 0, 'http://www.andytan.net/tigers/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (5, 1, '2013-10-20 03:58:23', '2013-10-20 03:58:23', '', 'Something', '', 'inherit', 'open', 'open', '', '4-revision-v1', '', '', '2013-10-20 03:58:23', '2013-10-20 03:58:23', '', 4, 'http://www.andytan.net/tigers/uncategorized/4-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (4, 1, '2013-10-20 03:58:23', '2013-10-20 03:58:23', '', 'Something', '', 'publish', 'open', 'open', '', 'something', '', '', '2013-10-20 03:58:23', '2013-10-20 03:58:23', '', 0, 'http://www.andytan.net/tigers/?p=4', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (7, 1, '2013-11-10 02:42:32', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2013-11-10 02:42:32', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=7', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (8, 1, '2013-11-10 02:43:26', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-10 02:43:26', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=8', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (9, 1, '2013-11-10 02:43:26', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-10 02:43:26', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=9', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (10, 1, '2013-11-10 11:34:36', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2013-11-10 11:34:36', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=10', 0, 'post', '', 0) ; 
INSERT INTO `wp_posts` VALUES (11, 1, '2013-11-10 11:35:02', '2013-11-10 11:35:02', '', 'Baby Ming Hao', '', 'publish', 'open', 'open', '', 'baby-ming-hao', '', '', '2013-11-10 11:35:02', '2013-11-10 11:35:02', '', 2, 'http://www.andytan.net/tigers/?page_id=11', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (12, 1, '2013-11-10 11:35:02', '2013-11-10 11:35:02', '', 'Baby Ming Hao', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2013-11-10 11:35:02', '2013-11-10 11:35:02', '', 11, 'http://www.andytan.net/tigers/uncategorized/11-revision-v1/', 0, 'revision', '', 0) ; 
INSERT INTO `wp_posts` VALUES (13, 1, '2013-11-13 13:05:24', '0000-00-00 00:00:00', '', 'Home', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 13:05:24', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=13', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (14, 1, '2013-11-13 13:05:24', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 13:05:24', '0000-00-00 00:00:00', '', 0, 'http://www.andytan.net/tigers/?p=14', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (15, 1, '2013-11-13 13:05:24', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'open', 'open', '', '', '', '', '2013-11-13 13:05:24', '0000-00-00 00:00:00', '', 2, 'http://www.andytan.net/tigers/?p=15', 1, 'nav_menu_item', '', 0) ; 
INSERT INTO `wp_posts` VALUES (16, 1, '2013-11-13 13:33:35', '2013-11-13 13:33:35', '<p>Your Name (required)<br />
    [text* your-name] </p>

<p>Your Email (required)<br />
    [email* your-email] </p>

<p>Subject<br />
    [text your-subject] </p>

<p>Your Message<br />
    [textarea your-message] </p>

<p>[submit "Send"]</p>
[your-subject]
[your-name] <[your-email]>
From: [your-name] <[your-email]>
Subject: [your-subject]

Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://www.andytan.net/tigers)
andy.tan2624@gmail.com


0

[your-subject]
[your-name] <[your-email]>
Message Body:
[your-message]

--
This e-mail was sent from a contact form on Gosford Junior Australian Football Club (http://www.andytan.net/tigers)
[your-email]


0
Your message was sent successfully. Thanks.
Failed to send your message. Please try later or contact the administrator by another method.
Validation errors occurred. Please confirm the fields and submit it again.
Failed to send your message. Please try later or contact the administrator by another method.
Please accept the terms to proceed.
Please fill the required field.', 'Contact form 1', '', 'publish', 'open', 'open', '', 'contact-form-1', '', '', '2013-11-13 13:33:35', '2013-11-13 13:33:35', '', 0, 'http://www.andytan.net/tigers/?post_type=wpcf7_contact_form&p=16', 0, 'wpcf7_contact_form', '', 0) ; 
INSERT INTO `wp_posts` VALUES (17, 1, '2013-11-13 13:34:05', '2013-11-13 13:34:05', '[contact-form-7 id="16" title="Contact form 1"]', 'Contact', '', 'publish', 'open', 'open', '', 'contact', '', '', '2013-11-13 13:34:05', '2013-11-13 13:34:05', '', 0, 'http://www.andytan.net/tigers/?page_id=17', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (18, 1, '2013-11-13 13:34:05', '2013-11-13 13:34:05', '[contact-form-7 id="16" title="Contact form 1"]', 'Contact', '', 'inherit', 'open', 'open', '', '17-revision-v1', '', '', '2013-11-13 13:34:05', '2013-11-13 13:34:05', '', 17, 'http://www.andytan.net/tigers/uncategorized/17-revision-v1/', 0, 'revision', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Thursday 14. November 2013 02:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_relationships (9 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (2, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (3, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (4, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (5, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (6, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (7, 2, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ; 
INSERT INTO `wp_term_relationships` VALUES (4, 1, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Thursday 14. November 2013 02:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_term_taxonomy (2 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 2) ; 
INSERT INTO `wp_term_taxonomy` VALUES (2, 2, 'link_category', '', 0, 7) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Thursday 14. November 2013 02:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_terms (2 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Uncategorized', 'uncategorized', 0) ; 
INSERT INTO `wp_terms` VALUES (2, 'Blogroll', 'blogroll', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Thursday 14. November 2013 02:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_usermeta (19 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'nickname', 'admin') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'aim', '') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'yim', '') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'jabber', '') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";s:1:"1";}') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'wp_dashboard_quick_press_last_post_id', '7') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_customize_current_theme_link,wp350_media') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'wp_user-settings', 'editor=tinymce&hidetb=1&libraryContent=browse') ; 
INSERT INTO `wp_usermeta` VALUES (17, 1, 'wp_user-settings-time', '1382243143') ; 
INSERT INTO `wp_usermeta` VALUES (18, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}') ; 
INSERT INTO `wp_usermeta` VALUES (19, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://www.andytan.net/tigers MySQL database backup
#
# Generated: Thursday 14. November 2013 02:34 UTC
# Hostname: localhost
# Database: `andytann_tigers`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'andy.tan2624', '$P$BIJNjFU5EZ3u/C/wMhI3gi1h/BfdvK1', 'admin', 'andy.tan2624@gmail.com', '', '2013-09-07 12:44:34', '', 0, 'admin') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

